<?php
/**
 * =========================================================================
 * KAOS POLOS MANAGEMENT - PHP & MYSQL SYNC BRIDGE
 * =========================================================================
 * File ini dipasang di hosting cPanel Anda (di dalam folder public_html).
 * 
 * Keuntungan:
 * 1. Tidak diblokir Firewall / Port 3306 karena berjalan internal via localhost!
 * 2. Menggunakan koneksi HTTPS/HTTP standar (Port 443 / 80).
 * 3. Langsung membaca & menulis ke phpMyAdmin secara realtime.
 * =========================================================================
 */

@set_time_limit(180);
@ini_set('memory_limit', '256M');

// Izinkan CORS dari aplikasi Anda
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Sync-Token");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// -------------------------------------------------------------
// KONFIGURASI DATABASE HOSTING CPANEL ANDA
// -------------------------------------------------------------
// Karena file ini berjalan di server hosting Anda sendiri,
// DB_HOST WAJIB menggunakan 'localhost'!
define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('DB_USER', 'hump6894_kaospolos');
define('DB_PASS', '10203040@kaospolos');
define('DB_NAME', 'hump6894_Gd_kaospolos');

// Token keamanan (opsional, disesuaikan)
define('SECRET_TOKEN', 'kaospolos_sync_secret_2026');

// -------------------------------------------------------------
// KONEKSI DATABASE PDO
// -------------------------------------------------------------
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    }
    return $pdo;
}

// -------------------------------------------------------------
// INISIALISASI TABEL OTOMATIS (JIKA BELUM ADA)
// -------------------------------------------------------------
function initTables($pdo) {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `master_gudang` (
            `gudang_id` VARCHAR(50) NOT NULL PRIMARY KEY,
            `nama_gudang` VARCHAR(100) NOT NULL,
            `lokasi` VARCHAR(255) DEFAULT NULL,
            `penanggung_jawab` VARCHAR(100) DEFAULT NULL,
            `is_active` TINYINT(1) DEFAULT 1,
            `is_default` TINYINT(1) DEFAULT 0,
            `telepon` VARCHAR(50) DEFAULT NULL,
            `keterangan` TEXT DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `master_produk` (
            `sku_id` VARCHAR(100) NOT NULL PRIMARY KEY,
            `nama_produk` VARCHAR(255) NOT NULL,
            `warna` VARCHAR(100) DEFAULT NULL,
            `ukuran` VARCHAR(50) DEFAULT NULL,
            `kategori` VARCHAR(100) DEFAULT NULL,
            `jenis_lengan` VARCHAR(50) DEFAULT 'PENDEK',
            `reorder_level` INT DEFAULT 10,
            `barcode_id` VARCHAR(100) DEFAULT NULL,
            `harga_hpp` DECIMAL(15,2) DEFAULT 0.00,
            `harga_jual` DECIMAL(15,2) DEFAULT 0.00,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `inventori` (
            `id` VARCHAR(150) NOT NULL PRIMARY KEY,
            `gudang_id` VARCHAR(50) NOT NULL,
            `sku_id` VARCHAR(100) NOT NULL,
            `nama_produk` VARCHAR(255) NOT NULL,
            `jumlah_ready` INT DEFAULT 0,
            `reorder_level` INT DEFAULT 10,
            `reorder` VARCHAR(10) DEFAULT 'NO',
            `order_date` VARCHAR(50) DEFAULT NULL,
            `warna` VARCHAR(100) DEFAULT NULL,
            `ukuran` VARCHAR(50) DEFAULT NULL,
            `kategori` VARCHAR(100) DEFAULT NULL,
            `jenis_lengan` VARCHAR(50) DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY `uk_gudang_sku` (`gudang_id`, `sku_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `pelanggan` (
            `id` VARCHAR(50) NOT NULL PRIMARY KEY,
            `nama` VARCHAR(150) NOT NULL,
            `telepon` VARCHAR(50) DEFAULT NULL,
            `alamat` TEXT DEFAULT NULL,
            `kota` VARCHAR(100) DEFAULT NULL,
            `tipe` VARCHAR(50) DEFAULT 'UMUM',
            `plafon_piutang` DECIMAL(15,2) DEFAULT 0.00,
            `catatan` TEXT DEFAULT NULL,
            `created_at` VARCHAR(50) DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `transaksi_penjualan` (
            `nomor_sale` VARCHAR(50) NOT NULL PRIMARY KEY,
            `tanggal` VARCHAR(50) NOT NULL,
            `gudang_id` VARCHAR(50) NOT NULL,
            `gudang_nama` VARCHAR(100) NOT NULL,
            `username` VARCHAR(100) NOT NULL,
            `pelanggan` VARCHAR(150) NOT NULL,
            `pelanggan_id` VARCHAR(50) DEFAULT NULL,
            `tipe_pelanggan` VARCHAR(50) DEFAULT NULL,
            `kontak` VARCHAR(50) DEFAULT NULL,
            `alamat` TEXT DEFAULT NULL,
            `metode` VARCHAR(50) DEFAULT NULL,
            `catatan` TEXT DEFAULT NULL,
            `subtotal_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `diskon_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `total_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `status_pembayaran` VARCHAR(30) DEFAULT 'LUNAS',
            `jumlah_bayar` DECIMAL(15,2) DEFAULT 0.00,
            `sisa_piutang` DECIMAL(15,2) DEFAULT 0.00,
            `jatuh_tempo` VARCHAR(50) DEFAULT NULL,
            `items_json` LONGTEXT DEFAULT NULL,
            `riwayat_pelunasan_json` LONGTEXT DEFAULT NULL,
            `created_at` VARCHAR(50) DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `order_po` (
            `nomor_order` VARCHAR(50) NOT NULL PRIMARY KEY,
            `tanggal` VARCHAR(50) NOT NULL,
            `gudang_id` VARCHAR(50) NOT NULL,
            `gudang_nama` VARCHAR(100) NOT NULL,
            `username` VARCHAR(100) NOT NULL,
            `supplier` VARCHAR(150) NOT NULL,
            `kontak` VARCHAR(50) DEFAULT NULL,
            `alamat` TEXT DEFAULT NULL,
            `metode` VARCHAR(50) DEFAULT NULL,
            `catatan` TEXT DEFAULT NULL,
            `subtotal_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `diskon_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `total_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `status_pembayaran` VARCHAR(30) DEFAULT 'LUNAS',
            `jumlah_bayar` DECIMAL(15,2) DEFAULT 0.00,
            `sisa_piutang` DECIMAL(15,2) DEFAULT 0.00,
            `jatuh_tempo` VARCHAR(50) DEFAULT NULL,
            `tampilkan_nominal` TINYINT(1) DEFAULT 1,
            `items_json` LONGTEXT DEFAULT NULL,
            `signature_admin_json` LONGTEXT DEFAULT NULL,
            `signature_supervisor_json` LONGTEXT DEFAULT NULL,
            `created_at` VARCHAR(50) DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `surat_jalan` (
            `nomor_sj` VARCHAR(50) NOT NULL PRIMARY KEY,
            `tanggal` VARCHAR(50) NOT NULL,
            `gudang_id` VARCHAR(50) NOT NULL,
            `gudang_nama` VARCHAR(100) NOT NULL,
            `username` VARCHAR(100) NOT NULL,
            `tujuan` VARCHAR(150) NOT NULL,
            `penerima` VARCHAR(150) NOT NULL,
            `driver` VARCHAR(150) DEFAULT NULL,
            `kendaraan` VARCHAR(100) DEFAULT NULL,
            `catatan` TEXT DEFAULT NULL,
            `tampilkan_nominal` TINYINT(1) DEFAULT 0,
            `total_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `items_json` LONGTEXT DEFAULT NULL,
            `signature_pengirim_json` LONGTEXT DEFAULT NULL,
            `signature_driver_json` LONGTEXT DEFAULT NULL,
            `signature_penerima_json` LONGTEXT DEFAULT NULL,
            `created_at` VARCHAR(50) DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `log_transaksi` (
            `id` INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
            `timestamp` VARCHAR(50) NOT NULL,
            `transaksi_id` VARCHAR(50) NOT NULL,
            `sku_id` VARCHAR(100) NOT NULL,
            `gudang_id` VARCHAR(50) NOT NULL,
            `jumlah` INT NOT NULL,
            `tipe_transaksi` VARCHAR(50) NOT NULL,
            `users` VARCHAR(100) NOT NULL,
            `keterangan` TEXT DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `app_settings` (
            `id` VARCHAR(50) NOT NULL PRIMARY KEY,
            `settings_json` LONGTEXT NOT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `app_users` (
            `id` VARCHAR(50) NOT NULL PRIMARY KEY,
            `username` VARCHAR(100) NOT NULL,
            `password` VARCHAR(255) NOT NULL,
            `full_name` VARCHAR(150) NOT NULL,
            `role` VARCHAR(50) NOT NULL,
            `site_access` VARCHAR(100) NOT NULL,
            `is_active` TINYINT(1) DEFAULT 1,
            `phone` VARCHAR(50) DEFAULT NULL,
            `email` VARCHAR(100) DEFAULT NULL,
            `created_at` VARCHAR(50) DEFAULT NULL,
            `last_login` VARCHAR(50) DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY `uk_username` (`username`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
}

// -------------------------------------------------------------
// ROUTER AKSI
// -------------------------------------------------------------
$action = isset($_GET['action']) ? $_GET['action'] : 'status';

try {
    $pdo = getDB();
    initTables($pdo);

    // 1. STATUS KONEKSI & HITUNG DATA
    if ($action === 'status') {
        $countQuery = function($table) use ($pdo) {
            try {
                $stmt = $pdo->query("SELECT COUNT(*) FROM `$table`");
                return (int)$stmt->fetchColumn();
            } catch (Exception $e) {
                return 0;
            }
        };

        $tableCounts = [
            'products'       => $countQuery('master_produk'),
            'inventory'      => $countQuery('inventori'),
            'warehouses'     => $countQuery('master_gudang'),
            'customers'      => $countQuery('pelanggan'),
            'sales'          => $countQuery('transaksi_penjualan'),
            'orders'         => $countQuery('order_po'),
            'suratJalanList' => $countQuery('surat_jalan'),
            'logs'           => $countQuery('log_transaksi'),
            'users'          => $countQuery('app_users'),
        ];

        echo json_encode([
            'connected'   => true,
            'type'        => 'bridge',
            'bridgeUrl'   => '/api.php',
            'host'        => DB_HOST,
            'port'        => DB_PORT,
            'database'    => DB_NAME,
            'user'        => DB_USER,
            'tableCounts' => $tableCounts,
            'server_time' => date('Y-m-d H:i:s'),
            'message'     => 'Koneksi PHP Bridge (api.php) ke phpMyAdmin berhasil!'
        ]);
        exit;
    }

    // 2. PULL ALL DATA (Tarik semua data dari phpMyAdmin ke aplikasi)
    if ($action === 'pull-all') {
        $getRows = function($table, $orderBy = '') use ($pdo) {
            $sql = "SELECT * FROM `$table`" . ($orderBy ? " ORDER BY $orderBy" : "");
            $stmt = $pdo->query($sql);
            return $stmt->fetchAll();
        };

        $products = array_map(function($r) {
            return [
                'SKU_ID'        => $r['sku_id'],
                'NAMA_PRODUK'   => $r['nama_produk'],
                'WARNA'         => $r['warna'] ?? '',
                'UKURAN'        => $r['ukuran'] ?? '',
                'KATEGORI'      => $r['kategori'] ?? '',
                'JENIS_LENGAN'  => $r['jenis_lengan'] ?? 'PENDEK',
                'REORDER_LEVEL' => (int)($r['reorder_level'] ?? 10),
                'BARCODE_ID'    => !empty($r['barcode_id']) ? $r['barcode_id'] : null,
                'HARGA_HPP'     => (float)($r['harga_hpp'] ?? 0),
                'HARGA_JUAL'    => (float)($r['harga_jual'] ?? 0),
            ];
        }, $getRows('master_produk'));

        $inventory = array_map(function($r) {
            return [
                'GUDANG_ID'     => $r['gudang_id'],
                'SKU_ID'        => $r['sku_id'],
                'NAMA_PRODUK'   => $r['nama_produk'],
                'JUMLAH_READY'  => (int)($r['jumlah_ready'] ?? 0),
                'REORDER_LEVEL' => (int)($r['reorder_level'] ?? 10),
                'REORDER'       => $r['reorder'] ?? 'NO',
                'ORDER_DATE'    => !empty($r['order_date']) ? $r['order_date'] : null,
                'WARNA'         => $r['warna'] ?? null,
                'UKURAN'        => $r['ukuran'] ?? null,
                'KATEGORI'      => $r['kategori'] ?? null,
                'JENIS_LENGAN'  => $r['jenis_lengan'] ?? null,
            ];
        }, $getRows('inventori'));

        $warehouses = array_map(function($r) {
            return [
                'GUDANG_ID'        => $r['gudang_id'],
                'NAMA_GUDANG'      => $r['nama_gudang'],
                'LOKASI'           => $r['lokasi'] ?? '',
                'PENANGGUNG_JAWAB' => $r['penanggung_jawab'] ?? '',
                'IS_ACTIVE'        => (bool)$r['is_active'],
                'IS_DEFAULT'       => (bool)$r['is_default'],
                'TELEPON'          => $r['telepon'] ?? '',
                'KETERANGAN'       => $r['keterangan'] ?? '',
            ];
        }, $getRows('master_gudang'));

        $customers = array_map(function($r) {
            return [
                'id'            => $r['id'],
                'nama'          => $r['nama'],
                'telepon'       => $r['telepon'] ?? '',
                'alamat'        => $r['alamat'] ?? '',
                'kota'          => $r['kota'] ?? '',
                'tipe'          => $r['tipe'] ?? 'UMUM',
                'plafonPiutang' => (float)($r['plafon_piutang'] ?? 0),
                'catatan'       => $r['catatan'] ?? '',
                'createdAt'     => $r['created_at'] ?? date('c'),
            ];
        }, $getRows('pelanggan'));

        $sales = array_map(function($r) {
            return [
                'nomorSale'        => $r['nomor_sale'],
                'tanggal'          => $r['tanggal'],
                'gudangId'         => $r['gudang_id'],
                'gudangNama'       => $r['gudang_nama'],
                'username'         => $r['username'],
                'pelanggan'        => $r['pelanggan'],
                'pelangganId'      => !empty($r['pelanggan_id']) ? $r['pelanggan_id'] : null,
                'tipePelanggan'    => !empty($r['tipe_pelanggan']) ? $r['tipe_pelanggan'] : null,
                'kontak'           => $r['kontak'] ?? '',
                'alamat'           => $r['alamat'] ?? '',
                'metode'           => $r['metode'] ?? 'TUNAI',
                'catatan'          => $r['catatan'] ?? '',
                'subtotalNominal'  => (float)($r['subtotal_nominal'] ?? 0),
                'diskonNominal'    => (float)($r['diskon_nominal'] ?? 0),
                'totalNominal'     => (float)($r['total_nominal'] ?? 0),
                'statusPembayaran' => $r['status_pembayaran'] ?? 'LUNAS',
                'jumlahBayar'      => (float)($r['jumlah_bayar'] ?? 0),
                'sisaPiutang'      => (float)($r['sisa_piutang'] ?? 0),
                'jatuhTempo'       => !empty($r['jatuh_tempo']) ? $r['jatuh_tempo'] : null,
                'items'            => json_decode($r['items_json'] ?? '[]', true) ?: [],
                'riwayatPelunasan' => json_decode($r['riwayat_pelunasan_json'] ?? '[]', true) ?: [],
                'createdAt'        => $r['created_at'] ?? $r['tanggal'],
            ];
        }, $getRows('transaksi_penjualan', '`created_at` DESC'));

        $orders = array_map(function($r) {
            return [
                'nomorOrder'          => $r['nomor_order'],
                'tanggal'             => $r['tanggal'],
                'gudangId'            => $r['gudang_id'],
                'gudangNama'          => $r['gudang_nama'],
                'username'            => $r['username'],
                'supplier'            => $r['supplier'],
                'kontak'              => $r['kontak'] ?? '',
                'alamat'              => $r['alamat'] ?? '',
                'metode'              => $r['metode'] ?? '',
                'catatan'             => $r['catatan'] ?? '',
                'subtotalNominal'     => (float)($r['subtotal_nominal'] ?? 0),
                'diskonNominal'       => (float)($r['diskon_nominal'] ?? 0),
                'totalNominal'        => (float)($r['total_nominal'] ?? 0),
                'statusPembayaran'    => $r['status_pembayaran'] ?? 'LUNAS',
                'jumlahBayar'         => (float)($r['jumlah_bayar'] ?? 0),
                'sisaPiutang'         => (float)($r['sisa_piutang'] ?? 0),
                'jatuhTempo'          => !empty($r['jatuh_tempo']) ? $r['jatuh_tempo'] : null,
                'tampilkanNominal'    => (bool)($r['tampilkan_nominal'] ?? 1),
                'items'               => json_decode($r['items_json'] ?? '[]', true) ?: [],
                'signatureAdmin'      => json_decode($r['signature_admin_json'] ?? 'null', true),
                'signatureSupervisor' => json_decode($r['signature_supervisor_json'] ?? 'null', true),
                'createdAt'           => $r['created_at'] ?? $r['tanggal'],
            ];
        }, $getRows('order_po', '`created_at` DESC'));

        $suratJalanList = array_map(function($r) {
            return [
                'nomorSJ'           => $r['nomor_sj'],
                'tanggal'           => $r['tanggal'],
                'gudangId'          => $r['gudang_id'],
                'gudangNama'        => $r['gudang_nama'],
                'username'          => $r['username'],
                'tujuan'            => $r['tujuan'],
                'penerima'          => $r['penerima'],
                'driver'            => $r['driver'] ?? '',
                'kendaraan'         => $r['kendaraan'] ?? '',
                'catatan'           => $r['catatan'] ?? '',
                'tampilkanNominal'  => (bool)($r['tampilkan_nominal'] ?? 0),
                'totalNominal'      => (float)($r['total_nominal'] ?? 0),
                'items'             => json_decode($r['items_json'] ?? '[]', true) ?: [],
                'signaturePengirim' => json_decode($r['signature_pengirim_json'] ?? 'null', true),
                'signatureDriver'   => json_decode($r['signature_driver_json'] ?? 'null', true),
                'signaturePenerima' => json_decode($r['signature_penerima_json'] ?? 'null', true),
                'createdAt'         => $r['created_at'] ?? $r['tanggal'],
            ];
        }, $getRows('surat_jalan', '`created_at` DESC'));

        $logs = array_map(function($r) {
            return [
                'TIMESTAMP'      => $r['timestamp'],
                'TRANSAKSI_ID'   => $r['transaksi_id'],
                'SKU_ID'         => $r['sku_id'],
                'GUDANG_ID'      => $r['gudang_id'],
                'JUMLAH'         => (int)$r['jumlah'],
                'TIPE_TRANSAKSI' => $r['tipe_transaksi'],
                'USERS'          => $r['users'],
                'KETERANGAN'     => $r['keterangan'] ?? '',
            ];
        }, $getRows('log_transaksi', '`id` DESC LIMIT 500'));

        $settings = null;
        $stmtSet = $pdo->query("SELECT `settings_json` FROM `app_settings` WHERE `id` = 'default' LIMIT 1");
        $rowSet = $stmtSet->fetch();
        if ($rowSet && !empty($rowSet['settings_json'])) {
            $settings = json_decode($rowSet['settings_json'], true);
        }

        $users = array_map(function($r) {
            return [
                'id'         => $r['id'],
                'username'   => $r['username'],
                'password'   => $r['password'],
                'fullName'   => $r['full_name'],
                'role'       => $r['role'],
                'siteAccess' => $r['site_access'],
                'isActive'   => (bool)$r['is_active'],
                'phone'      => $r['phone'] ?? '',
                'email'      => $r['email'] ?? '',
                'createdAt'  => $r['created_at'],
                'lastLogin'  => !empty($r['last_login']) ? $r['last_login'] : null,
            ];
        }, $getRows('app_users'));

        echo json_encode([
            'success' => true,
            'source'  => 'bridge',
            'counts'  => [
                'products'       => count($products),
                'inventory'      => count($inventory),
                'warehouses'     => count($warehouses),
                'customers'      => count($customers),
                'sales'          => count($sales),
                'orders'         => count($orders),
                'suratJalanList' => count($suratJalanList),
                'logs'           => count($logs),
                'users'          => count($users),
            ],
            'data' => [
                'products'       => $products,
                'inventory'      => $inventory,
                'warehouses'     => $warehouses,
                'customers'      => $customers,
                'sales'          => $sales,
                'orders'         => $orders,
                'suratJalanList' => $suratJalanList,
                'logs'           => $logs,
                'settings'       => $settings,
                'users'          => $users,
            ]
        ]);
        exit;
    }

    // 3. PUSH ALL DATA (Simpan semua data dari aplikasi ke phpMyAdmin)
    if ($action === 'push-all') {
        $rawBody = file_get_contents('php://input');
        $input = json_decode($rawBody, true);
        if (!is_array($input)) {
            throw new Exception("Data input kosong atau tidak valid JSON");
        }

        $safeStr = function($val, $default = '', $maxLen = 0) {
            if ($val === null || is_array($val) || is_object($val)) {
                $s = (string)$default;
            } else {
                $s = (string)$val;
            }
            if ($maxLen > 0 && strlen($s) > $maxLen) {
                $s = function_exists('mb_substr') ? mb_substr($s, 0, $maxLen, 'UTF-8') : substr($s, 0, $maxLen);
            }
            return $s;
        };

        $pdo->beginTransaction();
        $totalUpserted = 0;

        // Sync Gudang
        if (!empty($input['warehouses']) && is_array($input['warehouses'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `master_gudang` (gudang_id, nama_gudang, lokasi, penanggung_jawab, is_active, is_default, telepon, keterangan)
                VALUES (:gudang_id, :nama_gudang, :lokasi, :penanggung_jawab, :is_active, :is_default, :telepon, :keterangan)
                ON DUPLICATE KEY UPDATE
                    nama_gudang = VALUES(nama_gudang),
                    lokasi = VALUES(lokasi),
                    penanggung_jawab = VALUES(penanggung_jawab),
                    is_active = VALUES(is_active),
                    is_default = VALUES(is_default),
                    telepon = VALUES(telepon),
                    keterangan = VALUES(keterangan)
            ");
            foreach ($input['warehouses'] as $w) {
                $gid = $safeStr($w['GUDANG_ID'] ?? $w['gudang_id'] ?? '', '', 50);
                if ($gid === '') continue;
                $stmt->execute([
                    ':gudang_id'        => $gid,
                    ':nama_gudang'      => $safeStr($w['NAMA_GUDANG'] ?? $w['nama_gudang'] ?? $gid, $gid, 100),
                    ':lokasi'           => $safeStr($w['LOKASI'] ?? $w['lokasi'] ?? '', '', 255),
                    ':penanggung_jawab' => $safeStr($w['PENANGGUNG_JAWAB'] ?? $w['penanggung_jawab'] ?? '', '', 100),
                    ':is_active'        => !empty($w['IS_ACTIVE'] ?? $w['is_active'] ?? true) ? 1 : 0,
                    ':is_default'       => !empty($w['IS_DEFAULT'] ?? $w['is_default'] ?? false) ? 1 : 0,
                    ':telepon'          => $safeStr($w['TELEPON'] ?? $w['telepon'] ?? '', '', 50),
                    ':keterangan'       => $safeStr($w['KETERANGAN'] ?? $w['keterangan'] ?? ''),
                ]);
                $totalUpserted++;
            }
        }

        // Sync Produk
        if (!empty($input['products']) && is_array($input['products'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `master_produk` (sku_id, nama_produk, warna, ukuran, kategori, jenis_lengan, reorder_level, barcode_id, harga_hpp, harga_jual)
                VALUES (:sku_id, :nama_produk, :warna, :ukuran, :kategori, :jenis_lengan, :reorder_level, :barcode_id, :harga_hpp, :harga_jual)
                ON DUPLICATE KEY UPDATE 
                    nama_produk = VALUES(nama_produk),
                    warna = VALUES(warna),
                    ukuran = VALUES(ukuran),
                    kategori = VALUES(kategori),
                    jenis_lengan = VALUES(jenis_lengan),
                    reorder_level = VALUES(reorder_level),
                    barcode_id = VALUES(barcode_id),
                    harga_hpp = VALUES(harga_hpp),
                    harga_jual = VALUES(harga_jual)
            ");
            foreach ($input['products'] as $p) {
                $sku = $safeStr($p['SKU_ID'] ?? $p['sku_id'] ?? '', '', 100);
                if ($sku === '') continue;
                $barcodeVal = $p['BARCODE_ID'] ?? $p['barcode_id'] ?? null;
                $stmt->execute([
                    ':sku_id'        => $sku,
                    ':nama_produk'   => $safeStr($p['NAMA_PRODUK'] ?? $p['nama_produk'] ?? $sku, $sku, 255),
                    ':warna'         => $safeStr($p['WARNA'] ?? $p['warna'] ?? '', '', 100),
                    ':ukuran'        => $safeStr($p['UKURAN'] ?? $p['ukuran'] ?? '', '', 50),
                    ':kategori'      => $safeStr($p['KATEGORI'] ?? $p['kategori'] ?? '', '', 100),
                    ':jenis_lengan'  => $safeStr($p['JENIS_LENGAN'] ?? $p['jenis_lengan'] ?? 'PENDEK', 'PENDEK', 50),
                    ':reorder_level' => (int)($p['REORDER_LEVEL'] ?? $p['reorder_level'] ?? 10),
                    ':barcode_id'    => ($barcodeVal !== null && $barcodeVal !== '') ? $safeStr($barcodeVal, '', 100) : null,
                    ':harga_hpp'     => (float)($p['HARGA_HPP'] ?? $p['harga_hpp'] ?? 0),
                    ':harga_jual'    => (float)($p['HARGA_JUAL'] ?? $p['harga_jual'] ?? 0),
                ]);
                $totalUpserted++;
            }
        }

        // Sync Inventory
        if (!empty($input['inventory']) && is_array($input['inventory'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `inventori` (id, gudang_id, sku_id, nama_produk, jumlah_ready, reorder_level, reorder, order_date, warna, ukuran, kategori, jenis_lengan)
                VALUES (:id, :gudang_id, :sku_id, :nama_produk, :jumlah_ready, :reorder_level, :reorder, :order_date, :warna, :ukuran, :kategori, :jenis_lengan)
                ON DUPLICATE KEY UPDATE
                    nama_produk = VALUES(nama_produk),
                    jumlah_ready = VALUES(jumlah_ready),
                    reorder_level = VALUES(reorder_level),
                    reorder = VALUES(reorder),
                    order_date = VALUES(order_date),
                    warna = VALUES(warna),
                    ukuran = VALUES(ukuran),
                    kategori = VALUES(kategori),
                    jenis_lengan = VALUES(jenis_lengan)
            ");
            foreach ($input['inventory'] as $inv) {
                $gid = $safeStr($inv['GUDANG_ID'] ?? $inv['gudang_id'] ?? '', '', 50);
                $sku = $safeStr($inv['SKU_ID'] ?? $inv['SKU'] ?? $inv['sku_id'] ?? '', '', 100);
                if ($gid === '' || $sku === '') continue;
                $id = $safeStr(!empty($inv['id']) ? $inv['id'] : ($gid . '_' . $sku), '', 150);
                $orderDateVal = $inv['ORDER_DATE'] ?? $inv['order_date'] ?? null;
                $stmt->execute([
                    ':id'            => $id,
                    ':gudang_id'     => $gid,
                    ':sku_id'        => $sku,
                    ':nama_produk'   => $safeStr($inv['NAMA_PRODUK'] ?? $inv['nama_produk'] ?? $sku, $sku, 255),
                    ':jumlah_ready'  => (int)($inv['JUMLAH_READY'] ?? $inv['jumlah_ready'] ?? 0),
                    ':reorder_level' => (int)($inv['REORDER_LEVEL'] ?? $inv['reorder_level'] ?? 10),
                    ':reorder'       => $safeStr($inv['REORDER'] ?? $inv['reorder'] ?? 'NO', 'NO', 10),
                    ':order_date'    => ($orderDateVal !== null && $orderDateVal !== '') ? $safeStr($orderDateVal, '', 50) : null,
                    ':warna'         => isset($inv['WARNA']) || isset($inv['warna']) ? $safeStr($inv['WARNA'] ?? $inv['warna'] ?? '', '', 100) : null,
                    ':ukuran'        => isset($inv['UKURAN']) || isset($inv['ukuran']) ? $safeStr($inv['UKURAN'] ?? $inv['ukuran'] ?? '', '', 50) : null,
                    ':kategori'      => isset($inv['KATEGORI']) || isset($inv['kategori']) ? $safeStr($inv['KATEGORI'] ?? $inv['kategori'] ?? '', '', 100) : null,
                    ':jenis_lengan'  => isset($inv['JENIS_LENGAN']) || isset($inv['jenis_lengan']) ? $safeStr($inv['JENIS_LENGAN'] ?? $inv['jenis_lengan'] ?? '', '', 50) : null,
                ]);
                $totalUpserted++;
            }
        }

        // Sync Pelanggan
        if (!empty($input['customers']) && is_array($input['customers'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `pelanggan` (id, nama, telepon, alamat, kota, tipe, plafon_piutang, catatan, created_at)
                VALUES (:id, :nama, :telepon, :alamat, :kota, :tipe, :plafon_piutang, :catatan, :created_at)
                ON DUPLICATE KEY UPDATE
                    nama = VALUES(nama),
                    telepon = VALUES(telepon),
                    alamat = VALUES(alamat),
                    kota = VALUES(kota),
                    tipe = VALUES(tipe),
                    plafon_piutang = VALUES(plafon_piutang),
                    catatan = VALUES(catatan)
            ");
            foreach ($input['customers'] as $c) {
                $cid = $safeStr($c['id'] ?? '', '', 50);
                if ($cid === '') continue;
                $stmt->execute([
                    ':id'             => $cid,
                    ':nama'           => $safeStr($c['nama'] ?? 'Pelanggan', 'Pelanggan', 150),
                    ':telepon'        => $safeStr($c['telepon'] ?? '', '', 50),
                    ':alamat'         => $safeStr($c['alamat'] ?? ''),
                    ':kota'           => $safeStr($c['kota'] ?? '', '', 100),
                    ':tipe'           => $safeStr($c['tipe'] ?? 'UMUM', 'UMUM', 50),
                    ':plafon_piutang' => (float)($c['plafonPiutang'] ?? $c['plafon_piutang'] ?? 0),
                    ':catatan'        => $safeStr($c['catatan'] ?? ''),
                    ':created_at'     => $safeStr($c['createdAt'] ?? $c['created_at'] ?? date('c'), date('c'), 50),
                ]);
                $totalUpserted++;
            }
        }

        // Sync Penjualan
        if (!empty($input['sales']) && is_array($input['sales'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `transaksi_penjualan` (
                    nomor_sale, tanggal, gudang_id, gudang_nama, username, pelanggan, pelanggan_id,
                    tipe_pelanggan, kontak, alamat, metode, catatan, subtotal_nominal, diskon_nominal,
                    total_nominal, status_pembayaran, jumlah_bayar, sisa_piutang, jatuh_tempo,
                    items_json, riwayat_pelunasan_json, created_at
                ) VALUES (
                    :nomor_sale, :tanggal, :gudang_id, :gudang_nama, :username, :pelanggan, :pelanggan_id,
                    :tipe_pelanggan, :kontak, :alamat, :metode, :catatan, :subtotal_nominal, :diskon_nominal,
                    :total_nominal, :status_pembayaran, :jumlah_bayar, :sisa_piutang, :jatuh_tempo,
                    :items_json, :riwayat_pelunasan_json, :created_at
                ) ON DUPLICATE KEY UPDATE
                    tanggal = VALUES(tanggal),
                    pelanggan = VALUES(pelanggan),
                    metode = VALUES(metode),
                    subtotal_nominal = VALUES(subtotal_nominal),
                    diskon_nominal = VALUES(diskon_nominal),
                    total_nominal = VALUES(total_nominal),
                    status_pembayaran = VALUES(status_pembayaran),
                    jumlah_bayar = VALUES(jumlah_bayar),
                    sisa_piutang = VALUES(sisa_piutang),
                    items_json = VALUES(items_json),
                    riwayat_pelunasan_json = VALUES(riwayat_pelunasan_json)
            ");
            foreach ($input['sales'] as $s) {
                $nomorSale = $safeStr($s['nomorSale'] ?? $s['nomor_sale'] ?? '', '', 50);
                if ($nomorSale === '') continue;
                $pelangganIdVal = $s['pelangganId'] ?? $s['pelanggan_id'] ?? null;
                $tipePelangganVal = $s['tipePelanggan'] ?? $s['tipe_pelanggan'] ?? null;
                $jatuhTempoVal = $s['jatuhTempo'] ?? $s['jatuh_tempo'] ?? null;
                $tanggalVal = $safeStr($s['tanggal'] ?? date('Y-m-d'), date('Y-m-d'), 50);
                $stmt->execute([
                    ':nomor_sale'             => $nomorSale,
                    ':tanggal'                => $tanggalVal,
                    ':gudang_id'              => $safeStr($s['gudangId'] ?? $s['gudang_id'] ?? 'GDG-01', 'GDG-01', 50),
                    ':gudang_nama'            => $safeStr($s['gudangNama'] ?? $s['gudang_nama'] ?? 'Gudang', 'Gudang', 100),
                    ':username'               => $safeStr($s['username'] ?? 'admin', 'admin', 100),
                    ':pelanggan'              => $safeStr($s['pelanggan'] ?? 'Pelanggan Umum', 'Pelanggan Umum', 150),
                    ':pelanggan_id'           => ($pelangganIdVal !== null && $pelangganIdVal !== '') ? $safeStr($pelangganIdVal, '', 50) : null,
                    ':tipe_pelanggan'         => ($tipePelangganVal !== null && $tipePelangganVal !== '') ? $safeStr($tipePelangganVal, '', 50) : null,
                    ':kontak'                 => $safeStr($s['kontak'] ?? '', '', 50),
                    ':alamat'                 => $safeStr($s['alamat'] ?? ''),
                    ':metode'                 => $safeStr($s['metode'] ?? 'TUNAI', 'TUNAI', 50),
                    ':catatan'                => $safeStr($s['catatan'] ?? ''),
                    ':subtotal_nominal'       => (float)($s['subtotalNominal'] ?? $s['subtotal_nominal'] ?? 0),
                    ':diskon_nominal'         => (float)($s['diskonNominal'] ?? $s['diskon_nominal'] ?? 0),
                    ':total_nominal'          => (float)($s['totalNominal'] ?? $s['total_nominal'] ?? 0),
                    ':status_pembayaran'      => $safeStr($s['statusPembayaran'] ?? $s['status_pembayaran'] ?? 'LUNAS', 'LUNAS', 30),
                    ':jumlah_bayar'           => (float)($s['jumlahBayar'] ?? $s['jumlah_bayar'] ?? 0),
                    ':sisa_piutang'           => (float)($s['sisaPiutang'] ?? $s['sisa_piutang'] ?? 0),
                    ':jatuh_tempo'            => ($jatuhTempoVal !== null && $jatuhTempoVal !== '') ? $safeStr($jatuhTempoVal, '', 50) : null,
                    ':items_json'             => json_encode($s['items'] ?? []),
                    ':riwayat_pelunasan_json' => json_encode($s['riwayatPelunasan'] ?? $s['riwayat_pelunasan'] ?? []),
                    ':created_at'             => $safeStr($s['createdAt'] ?? $s['created_at'] ?? $tanggalVal, $tanggalVal, 50),
                ]);
                $totalUpserted++;
            }
        }

        // Sync Orders (PO)
        if (!empty($input['orders']) && is_array($input['orders'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `order_po` (
                    nomor_order, tanggal, gudang_id, gudang_nama, username, supplier, kontak, alamat,
                    metode, catatan, subtotal_nominal, diskon_nominal, total_nominal, status_pembayaran,
                    jumlah_bayar, sisa_piutang, jatuh_tempo, tampilkan_nominal, items_json,
                    signature_admin_json, signature_supervisor_json, created_at
                ) VALUES (
                    :nomor_order, :tanggal, :gudang_id, :gudang_nama, :username, :supplier, :kontak, :alamat,
                    :metode, :catatan, :subtotal_nominal, :diskon_nominal, :total_nominal, :status_pembayaran,
                    :jumlah_bayar, :sisa_piutang, :jatuh_tempo, :tampilkan_nominal, :items_json,
                    :signature_admin_json, :signature_supervisor_json, :created_at
                ) ON DUPLICATE KEY UPDATE
                    tanggal = VALUES(tanggal),
                    supplier = VALUES(supplier),
                    total_nominal = VALUES(total_nominal),
                    status_pembayaran = VALUES(status_pembayaran),
                    items_json = VALUES(items_json)
            ");
            foreach ($input['orders'] as $o) {
                $nomorOrder = $safeStr($o['nomorOrder'] ?? $o['nomor_order'] ?? '', '', 50);
                if ($nomorOrder === '') continue;
                $jatuhTempoVal = $o['jatuhTempo'] ?? $o['jatuh_tempo'] ?? null;
                $tanggalVal = $safeStr($o['tanggal'] ?? date('Y-m-d'), date('Y-m-d'), 50);
                $stmt->execute([
                    ':nomor_order'               => $nomorOrder,
                    ':tanggal'                   => $tanggalVal,
                    ':gudang_id'                 => $safeStr($o['gudangId'] ?? $o['gudang_id'] ?? 'GDG-01', 'GDG-01', 50),
                    ':gudang_nama'               => $safeStr($o['gudangNama'] ?? $o['gudang_nama'] ?? 'Gudang', 'Gudang', 100),
                    ':username'                  => $safeStr($o['username'] ?? 'admin', 'admin', 100),
                    ':supplier'                  => $safeStr($o['supplier'] ?? 'Supplier', 'Supplier', 150),
                    ':kontak'                    => $safeStr($o['kontak'] ?? '', '', 50),
                    ':alamat'                    => $safeStr($o['alamat'] ?? ''),
                    ':metode'                    => $safeStr($o['metode'] ?? '', '', 50),
                    ':catatan'                   => $safeStr($o['catatan'] ?? ''),
                    ':subtotal_nominal'          => (float)($o['subtotalNominal'] ?? $o['subtotal_nominal'] ?? 0),
                    ':diskon_nominal'            => (float)($o['diskonNominal'] ?? $o['diskon_nominal'] ?? 0),
                    ':total_nominal'             => (float)($o['totalNominal'] ?? $o['total_nominal'] ?? 0),
                    ':status_pembayaran'         => $safeStr($o['statusPembayaran'] ?? $o['status_pembayaran'] ?? 'LUNAS', 'LUNAS', 30),
                    ':jumlah_bayar'              => (float)($o['jumlahBayar'] ?? $o['jumlah_bayar'] ?? 0),
                    ':sisa_piutang'              => (float)($o['sisaPiutang'] ?? $o['sisa_piutang'] ?? 0),
                    ':jatuh_tempo'               => ($jatuhTempoVal !== null && $jatuhTempoVal !== '') ? $safeStr($jatuhTempoVal, '', 50) : null,
                    ':tampilkan_nominal'         => !empty($o['tampilkanNominal'] ?? $o['tampilkan_nominal']) ? 1 : 0,
                    ':items_json'                => json_encode($o['items'] ?? []),
                    ':signature_admin_json'      => json_encode($o['signatureAdmin'] ?? $o['signature_admin'] ?? null),
                    ':signature_supervisor_json' => json_encode($o['signatureSupervisor'] ?? $o['signature_supervisor'] ?? null),
                    ':created_at'                => $safeStr($o['createdAt'] ?? $o['created_at'] ?? $tanggalVal, $tanggalVal, 50),
                ]);
                $totalUpserted++;
            }
        }

        // Sync Surat Jalan
        if (!empty($input['suratJalanList']) && is_array($input['suratJalanList'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `surat_jalan` (
                    nomor_sj, tanggal, gudang_id, gudang_nama, username, tujuan, penerima, driver,
                    kendaraan, catatan, tampilkan_nominal, total_nominal, items_json,
                    signature_pengirim_json, signature_driver_json, signature_penerima_json, created_at
                ) VALUES (
                    :nomor_sj, :tanggal, :gudang_id, :gudang_nama, :username, :tujuan, :penerima, :driver,
                    :kendaraan, :catatan, :tampilkan_nominal, :total_nominal, :items_json,
                    :signature_pengirim_json, :signature_driver_json, :signature_penerima_json, :created_at
                ) ON DUPLICATE KEY UPDATE
                    tanggal = VALUES(tanggal),
                    tujuan = VALUES(tujuan),
                    penerima = VALUES(penerima),
                    items_json = VALUES(items_json)
            ");
            foreach ($input['suratJalanList'] as $sj) {
                $nomorSj = $safeStr($sj['nomorSJ'] ?? $sj['nomor_sj'] ?? '', '', 50);
                if ($nomorSj === '') continue;
                $tanggalVal = $safeStr($sj['tanggal'] ?? date('Y-m-d'), date('Y-m-d'), 50);
                $stmt->execute([
                    ':nomor_sj'                => $nomorSj,
                    ':tanggal'                 => $tanggalVal,
                    ':gudang_id'               => $safeStr($sj['gudangId'] ?? $sj['gudang_id'] ?? 'GDG-01', 'GDG-01', 50),
                    ':gudang_nama'             => $safeStr($sj['gudangNama'] ?? $sj['gudang_nama'] ?? 'Gudang', 'Gudang', 100),
                    ':username'                => $safeStr($sj['username'] ?? 'admin', 'admin', 100),
                    ':tujuan'                  => $safeStr($sj['tujuan'] ?? '-', '-', 150),
                    ':penerima'                => $safeStr($sj['penerima'] ?? '-', '-', 150),
                    ':driver'                  => $safeStr($sj['driver'] ?? '', '', 150),
                    ':kendaraan'               => $safeStr($sj['kendaraan'] ?? '', '', 100),
                    ':catatan'                 => $safeStr($sj['catatan'] ?? ''),
                    ':tampilkan_nominal'       => !empty($sj['tampilkanNominal'] ?? $sj['tampilkan_nominal']) ? 1 : 0,
                    ':total_nominal'           => (float)($sj['totalNominal'] ?? $sj['total_nominal'] ?? 0),
                    ':items_json'              => json_encode($sj['items'] ?? []),
                    ':signature_pengirim_json' => json_encode($sj['signaturePengirim'] ?? $sj['signature_pengirim'] ?? null),
                    ':signature_driver_json'   => json_encode($sj['signatureDriver'] ?? $sj['signature_driver'] ?? null),
                    ':signature_penerima_json' => json_encode($sj['signaturePenerima'] ?? $sj['signature_penerima'] ?? null),
                    ':created_at'              => $safeStr($sj['createdAt'] ?? $sj['created_at'] ?? $tanggalVal, $tanggalVal, 50),
                ]);
                $totalUpserted++;
            }
        }

        // Sync Logs (hindari duplikasi jika log sudah tersimpan sebelumnya)
        if (!empty($input['logs']) && is_array($input['logs'])) {
            $checkLog = $pdo->prepare("SELECT 1 FROM `log_transaksi` WHERE `transaksi_id` = ? AND `sku_id` = ? AND `gudang_id` = ? LIMIT 1");
            $insertLog = $pdo->prepare("
                INSERT INTO `log_transaksi` (timestamp, transaksi_id, sku_id, gudang_id, jumlah, tipe_transaksi, users, keterangan)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            foreach ($input['logs'] as $lg) {
                $txId = $safeStr($lg['TRANSAKSI_ID'] ?? $lg['transaksi_id'] ?? '', '', 50);
                $skuId = $safeStr($lg['SKU_ID'] ?? $lg['sku_id'] ?? '', '', 100);
                $gid = $safeStr($lg['GUDANG_ID'] ?? $lg['gudang_id'] ?? '', '', 50);
                if ($txId === '' || $skuId === '') continue;
                $checkLog->execute([$txId, $skuId, $gid]);
                if (!$checkLog->fetchColumn()) {
                    $insertLog->execute([
                        $safeStr($lg['TIMESTAMP'] ?? $lg['timestamp'] ?? date('c'), date('c'), 50),
                        $txId,
                        $skuId,
                        $gid,
                        (int)($lg['JUMLAH'] ?? $lg['jumlah'] ?? 0),
                        $safeStr($lg['TIPE_TRANSAKSI'] ?? $lg['tipe_transaksi'] ?? 'LOG', 'LOG', 50),
                        $safeStr($lg['USERS'] ?? $lg['users'] ?? 'system', 'system', 100),
                        $safeStr($lg['KETERANGAN'] ?? $lg['keterangan'] ?? ''),
                    ]);
                    $totalUpserted++;
                }
            }
        }

        // Sync Settings
        if (!empty($input['settings']) && is_array($input['settings'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `app_settings` (id, settings_json)
                VALUES ('default', :settings_json)
                ON DUPLICATE KEY UPDATE settings_json = VALUES(settings_json)
            ");
            $stmt->execute([':settings_json' => json_encode($input['settings'])]);
            $totalUpserted++;
        }

        // Sync Users
        if (!empty($input['users']) && is_array($input['users'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `app_users` (id, username, password, full_name, role, site_access, is_active, phone, email, created_at, last_login)
                VALUES (:id, :username, :password, :full_name, :role, :site_access, :is_active, :phone, :email, :created_at, :last_login)
                ON DUPLICATE KEY UPDATE
                    full_name = VALUES(full_name),
                    role = VALUES(role),
                    site_access = VALUES(site_access),
                    is_active = VALUES(is_active),
                    last_login = VALUES(last_login)
            ");
            foreach ($input['users'] as $u) {
                $uid = $safeStr($u['id'] ?? '', '', 50);
                $uname = $safeStr($u['username'] ?? '', '', 100);
                if ($uid === '' || $uname === '') continue;
                $lastLoginVal = $u['lastLogin'] ?? $u['last_login'] ?? null;
                $stmt->execute([
                    ':id'          => $uid,
                    ':username'    => $uname,
                    ':password'    => $safeStr($u['password'] ?? '', '', 255),
                    ':full_name'   => $safeStr($u['fullName'] ?? $u['full_name'] ?? $uname, $uname, 150),
                    ':role'        => $safeStr($u['role'] ?? 'STAFF', 'STAFF', 50),
                    ':site_access' => $safeStr($u['siteAccess'] ?? $u['site_access'] ?? 'SEMUA GUDANG', 'SEMUA GUDANG', 100),
                    ':is_active'   => !empty($u['isActive'] ?? $u['is_active'] ?? true) ? 1 : 0,
                    ':phone'       => $safeStr($u['phone'] ?? '', '', 50),
                    ':email'       => $safeStr($u['email'] ?? '', '', 100),
                    ':created_at'  => $safeStr($u['createdAt'] ?? $u['created_at'] ?? date('c'), date('c'), 50),
                    ':last_login'  => ($lastLoginVal !== null && $lastLoginVal !== '') ? $safeStr($lastLoginVal, '', 50) : null,
                ]);
                $totalUpserted++;
            }
        }

        $pdo->commit();

        echo json_encode([
            'success' => true,
            'count'   => $totalUpserted,
            'message' => "$totalUpserted baris data berhasil disimpan ke MySQL phpMyAdmin!"
        ]);
        exit;
    }

    // 4. SYNC SINGLE ITEM (CRUD realtime)
    if ($action === 'sync-item') {
        $input = json_decode(file_get_contents('php://input'), true);
        $itemAction = $input['action'] ?? '';
        $key = $input['key'] ?? '';
        $data = $input['data'] ?? [];

        switch ($itemAction) {
            case 'saveProduct': {
                $stmt = $pdo->prepare("
                    INSERT INTO `master_produk` (sku_id, nama_produk, warna, ukuran, kategori, jenis_lengan, reorder_level, barcode_id, harga_hpp, harga_jual)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), warna=VALUES(warna), ukuran=VALUES(ukuran), kategori=VALUES(kategori),
                    jenis_lengan=VALUES(jenis_lengan), reorder_level=VALUES(reorder_level), barcode_id=VALUES(barcode_id),
                    harga_hpp=VALUES(harga_hpp), harga_jual=VALUES(harga_jual)
                ");
                $stmt->execute([
                    $data['SKU_ID'], $data['NAMA_PRODUK'], $data['WARNA'] ?? '', $data['UKURAN'] ?? '',
                    $data['KATEGORI'] ?? '', $data['JENIS_LENGAN'] ?? 'PENDEK', (int)($data['REORDER_LEVEL'] ?? 10),
                    $data['BARCODE_ID'] ?? null, (float)($data['HARGA_HPP'] ?? 0), (float)($data['HARGA_JUAL'] ?? 0)
                ]);
                break;
            }
            case 'deleteProduct': {
                $stmt = $pdo->prepare("DELETE FROM `master_produk` WHERE `sku_id` = ?");
                $stmt->execute([$key]);
                break;
            }
            case 'saveInventoryItem': {
                $id = $data['GUDANG_ID'] . '_' . $data['SKU_ID'];
                $stmt = $pdo->prepare("
                    INSERT INTO `inventori` (id, gudang_id, sku_id, nama_produk, jumlah_ready, reorder_level, reorder, order_date, warna, ukuran, kategori, jenis_lengan)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), jumlah_ready=VALUES(jumlah_ready), reorder_level=VALUES(reorder_level),
                    reorder=VALUES(reorder), order_date=VALUES(order_date), warna=VALUES(warna), ukuran=VALUES(ukuran),
                    kategori=VALUES(kategori), jenis_lengan=VALUES(jenis_lengan)
                ");
                $stmt->execute([
                    $id, $data['GUDANG_ID'], $data['SKU_ID'], $data['NAMA_PRODUK'],
                    (int)($data['JUMLAH_READY'] ?? 0), (int)($data['REORDER_LEVEL'] ?? 10),
                    $data['REORDER'] ?? 'NO', $data['ORDER_DATE'] ?? null, $data['WARNA'] ?? null,
                    $data['UKURAN'] ?? null, $data['KATEGORI'] ?? null, $data['JENIS_LENGAN'] ?? null
                ]);
                break;
            }
            case 'saveSale': {
                $stmt = $pdo->prepare("
                    INSERT INTO `transaksi_penjualan` (nomor_sale, tanggal, gudang_id, gudang_nama, username, pelanggan, pelanggan_id, tipe_pelanggan, kontak, alamat, metode, catatan, subtotal_nominal, diskon_nominal, total_nominal, status_pembayaran, jumlah_bayar, sisa_piutang, jatuh_tempo, items_json, riwayat_pelunasan_json, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), pelanggan=VALUES(pelanggan), metode=VALUES(metode),
                    subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal), total_nominal=VALUES(total_nominal),
                    status_pembayaran=VALUES(status_pembayaran), jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang),
                    items_json=VALUES(items_json), riwayat_pelunasan_json=VALUES(riwayat_pelunasan_json)
                ");
                $stmt->execute([
                    $data['nomorSale'], $data['tanggal'], $data['gudangId'], $data['gudangNama'],
                    $data['username'], $data['pelanggan'], $data['pelangganId'] ?? null, $data['tipePelanggan'] ?? null,
                    $data['kontak'] ?? '', $data['alamat'] ?? '', $data['metode'] ?? 'TUNAI', $data['catatan'] ?? '',
                    (float)($data['subtotalNominal'] ?? 0), (float)($data['diskonNominal'] ?? 0), (float)($data['totalNominal'] ?? 0),
                    $data['statusPembayaran'] ?? 'LUNAS', (float)($data['jumlahBayar'] ?? 0), (float)($data['sisaPiutang'] ?? 0),
                    $data['jatuhTempo'] ?? null, json_encode($data['items'] ?? []),
                    json_encode($data['riwayatPelunasan'] ?? []), $data['createdAt'] ?? $data['tanggal']
                ]);
                break;
            }
            case 'deleteSale': {
                $stmt = $pdo->prepare("DELETE FROM `transaksi_penjualan` WHERE `nomor_sale` = ?");
                $stmt->execute([$key]);
                break;
            }
            case 'saveOrder': {
                $stmt = $pdo->prepare("
                    INSERT INTO `order_po` (nomor_order, tanggal, gudang_id, gudang_nama, username, supplier, kontak, alamat, metode, catatan, subtotal_nominal, diskon_nominal, total_nominal, status_pembayaran, jumlah_bayar, sisa_piutang, jatuh_tempo, tampilkan_nominal, items_json, signature_admin_json, signature_supervisor_json, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), supplier=VALUES(supplier), total_nominal=VALUES(total_nominal),
                    status_pembayaran=VALUES(status_pembayaran), items_json=VALUES(items_json)
                ");
                $stmt->execute([
                    $data['nomorOrder'], $data['tanggal'], $data['gudangId'], $data['gudangNama'],
                    $data['username'], $data['supplier'], $data['kontak'] ?? '', $data['alamat'] ?? '',
                    $data['metode'] ?? '', $data['catatan'] ?? '', (float)($data['subtotalNominal'] ?? 0),
                    (float)($data['diskonNominal'] ?? 0), (float)($data['totalNominal'] ?? 0),
                    $data['statusPembayaran'] ?? 'LUNAS', (float)($data['jumlahBayar'] ?? 0),
                    (float)($data['sisaPiutang'] ?? 0), $data['jatuhTempo'] ?? null,
                    !empty($data['tampilkanNominal']) ? 1 : 0, json_encode($data['items'] ?? []),
                    json_encode($data['signatureAdmin'] ?? null), json_encode($data['signatureSupervisor'] ?? null),
                    $data['createdAt'] ?? $data['tanggal']
                ]);
                break;
            }
            case 'deleteOrder': {
                $stmt = $pdo->prepare("DELETE FROM `order_po` WHERE `nomor_order` = ?");
                $stmt->execute([$key]);
                break;
            }
            case 'saveSuratJalan': {
                $stmt = $pdo->prepare("
                    INSERT INTO `surat_jalan` (nomor_sj, tanggal, gudang_id, gudang_nama, username, tujuan, penerima, driver, kendaraan, catatan, tampilkan_nominal, total_nominal, items_json, signature_pengirim_json, signature_driver_json, signature_penerima_json, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), tujuan=VALUES(tujuan), penerima=VALUES(penerima), items_json=VALUES(items_json)
                ");
                $stmt->execute([
                    $data['nomorSJ'], $data['tanggal'], $data['gudangId'], $data['gudangNama'],
                    $data['username'], $data['tujuan'], $data['penerima'], $data['driver'] ?? '',
                    $data['kendaraan'] ?? '', $data['catatan'] ?? '', !empty($data['tampilkanNominal']) ? 1 : 0,
                    (float)($data['totalNominal'] ?? 0), json_encode($data['items'] ?? []),
                    json_encode($data['signaturePengirim'] ?? null), json_encode($data['signatureDriver'] ?? null),
                    json_encode($data['signaturePenerima'] ?? null), $data['createdAt'] ?? $data['tanggal']
                ]);
                break;
            }
            case 'deleteSuratJalan': {
                $stmt = $pdo->prepare("DELETE FROM `surat_jalan` WHERE `nomor_sj` = ?");
                $stmt->execute([$key]);
                break;
            }
            case 'saveCustomer': {
                $stmt = $pdo->prepare("
                    INSERT INTO `pelanggan` (id, nama, telepon, alamat, kota, tipe, plafon_piutang, catatan, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                    nama=VALUES(nama), telepon=VALUES(telepon), alamat=VALUES(alamat), kota=VALUES(kota),
                    tipe=VALUES(tipe), plafon_piutang=VALUES(plafon_piutang), catatan=VALUES(catatan)
                ");
                $stmt->execute([
                    $data['id'], $data['nama'], $data['telepon'] ?? '', $data['alamat'] ?? '',
                    $data['kota'] ?? '', $data['tipe'] ?? 'UMUM', (float)($data['plafonPiutang'] ?? 0),
                    $data['catatan'] ?? '', $data['createdAt'] ?? date('c')
                ]);
                break;
            }
            case 'deleteCustomer': {
                $stmt = $pdo->prepare("DELETE FROM `pelanggan` WHERE `id` = ?");
                $stmt->execute([$key]);
                break;
            }
            case 'saveWarehouse': {
                $stmt = $pdo->prepare("
                    INSERT INTO `master_gudang` (gudang_id, nama_gudang, lokasi, penanggung_jawab, is_active, is_default, telepon, keterangan)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                    nama_gudang=VALUES(nama_gudang), lokasi=VALUES(lokasi), penanggung_jawab=VALUES(penanggung_jawab),
                    is_active=VALUES(is_active), is_default=VALUES(is_default), telepon=VALUES(telepon), keterangan=VALUES(keterangan)
                ");
                $stmt->execute([
                    $data['GUDANG_ID'], $data['NAMA_GUDANG'], $data['LOKASI'] ?? '', $data['PENANGGUNG_JAWAB'] ?? '',
                    !empty($data['IS_ACTIVE']) ? 1 : 0, !empty($data['IS_DEFAULT']) ? 1 : 0,
                    $data['TELEPON'] ?? '', $data['KETERANGAN'] ?? ''
                ]);
                break;
            }
            case 'saveLog': {
                $stmt = $pdo->prepare("
                    INSERT INTO `log_transaksi` (timestamp, transaksi_id, sku_id, gudang_id, jumlah, tipe_transaksi, users, keterangan)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $data['TIMESTAMP'], $data['TRANSAKSI_ID'], $data['SKU_ID'], $data['GUDANG_ID'],
                    (int)($data['JUMLAH'] ?? 0), $data['TIPE_TRANSAKSI'], $data['USERS'], $data['KETERANGAN'] ?? ''
                ]);
                break;
            }
            case 'deleteLog': {
                $stmt = $pdo->prepare("DELETE FROM `log_transaksi` WHERE `transaksi_id` = ?");
                $stmt->execute([$key]);
                break;
            }
            case 'saveSettings': {
                $stmt = $pdo->prepare("
                    INSERT INTO `app_settings` (id, settings_json)
                    VALUES ('default', ?)
                    ON DUPLICATE KEY UPDATE settings_json=VALUES(settings_json)
                ");
                $stmt->execute([json_encode($data)]);
                break;
            }
        }

        echo json_encode(['success' => true]);
        exit;
    }

    // 5. CLEAR DATA (Hapus seluruh data operasional di phpMyAdmin, pertahankan user, gudang & pengaturan)
    if ($action === 'clear-data') {
        $pdo->beginTransaction();
        $tablesToClear = [
            'inventori',
            'master_produk',
            'pelanggan',
            'transaksi_penjualan',
            'order_po',
            'surat_jalan',
            'log_transaksi',
        ];
        foreach ($tablesToClear as $tbl) {
            $pdo->exec("DELETE FROM `$tbl`");
        }
        $pdo->commit();

        echo json_encode([
            'success' => true,
            'cleared' => $tablesToClear,
            'message' => 'Seluruh data produk, stok, penjualan, PO, surat jalan, pelanggan, dan log di MySQL berhasil dihapus!'
        ]);
        exit;
    }

    echo json_encode(['error' => 'Action tidak dikenali']);

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode([
        'connected' => false,
        'error'     => $e->getMessage()
    ]);
}
