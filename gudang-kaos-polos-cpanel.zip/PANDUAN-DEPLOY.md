# 📦 Panduan Deploy Gudang Kaos Polos ke cPanel (Tanpa Node.js)

Paket ini berisi **frontend React hasil build** + **backend PHP** yang menggantikan
`server.ts` (Node.js), sehingga bisa berjalan di shared hosting cPanel mana pun
dengan database **MySQL / phpMyAdmin**.

## 🗂️ Isi Paket (`dist/`)

| File | Fungsi |
|---|---|
| `index.html`, `assets/` | Frontend React hasil build (tidak perlu diubah) |
| `api.php` | Backend pengganti server.ts — melayani semua `/api/db/*` |
| `db-schema.php` | Auto-pembuatan tabel MySQL + sinkronisasi data |
| `config.php` | Kredensial database MySQL cPanel (**WAJIB DIEDIT**) |
| `.htaccess` | Routing API → api.php, routing SPA, proteksi file sensitif |
| `seed-data.json` | Snapshot backup Anda (28 Okt 2026) — dimuat HANYA secara eksplisit (tombol "Muat Seed Bawaan") |
| `database_kaospolos.sql` | Dump SQL manual (opsional, bila ingin import via phpMyAdmin) |

## 🚀 Langkah Deploy

### 1. Buat Database & User MySQL di cPanel
1. Login cPanel → **MySQL® Databases**.
2. Buat database, misal `db_kaospolos` → nama final: `USERNAMECPANEL_db_kaospolos`.
3. Buat user MySQL, misal `USERNAMECPANEL_db_user` + password kuat.
4. **Add User To Database** → pilih keduanya → centang **ALL PRIVILEGES** → Save.

### 2. Edit `config.php`
Buka file `config.php` dengan File Manager/editor, ganti 3 nilai:
```php
define('DB_USER', 'USERNAMECPANEL_db_user');   // user dari langkah 1
define('DB_PASS', 'PasswordAndaDisini');       // password user tsb
define('DB_NAME', 'USERNAMECPANEL_db_kaospolos'); // nama DB tsb
```
> `DB_HOST` biarkan `localhost`. Opsional: isi `SECRET_TOKEN` untuk mengunci endpoint tulis.

### 3. Upload ke `public_html`
1. cPanel → **File Manager** → buka `public_html`.
2. Hapus file bawaan cPanel (`default.html` / `cgi-bin` tidak masalah dibiarkan).
3. Upload **seluruh isi folder `dist/`** (bisa zip dulu lalu **Extract** di File Manager).
   Struktur akhir harus: `public_html/index.html`, `public_html/api.php`, dst.

### 4. Verifikasi Koneksi
Buka di browser:
```
https://domainanda.com/api.php?action=status
```
Harus muncul `"connected": true`. Jika error koneksi, periksa kredensial di `config.php`.

### 5. Muat Data Backup (EKSPISIT — bukan otomatis)
> ⚠️ **BUG FIX PENTING**: Auto-seed sudah DIMATIKAN (`AUTO_SEED = false` di config.php).
> Data bawaan paket TIDAK akan pernah muncul sendiri. Ini memperbaiki dua bug lama:
> 1. Setelah pulihkan file backup, data kembali ke data bawaan paket (tercampur seed).
> 2. DB dikosongkan via phpMyAdmin, tapi aplikasi tetap menampilkan data (karena auto-seed).

Sekarang perilakunya: **DB kosong = aplikasi kosong**, dan restore backup menjadi
cermin persis isi file backup (baris lama yang tidak ada di backup ikut dihapus dari MySQL).

Cara mengisi data awal (pilih salah satu):
- **Pulihkan file backup Anda** lewat menu **Backup & Restore** di aplikasi (data langsung tersinkron cermin ke MySQL) — *cara yang disarankan*, atau
- Import SQL: buka phpMyAdmin → pilih database → tab **Import** → unggah `database_kaospolos.sql` dari paket ini → reload aplikasi, atau
- Seed bawaan via terminal/URL: `curl -X POST https://domainanda.com/api.php?action=seed-now`

> ℹ️ **CATATAN VERSI INI**: Tombol header "MySQL / phpMyAdmin" beserta modalnya sudah **DIHAPUS** karena menyebabkan halaman blank. Semua fungsi penting tetap tersedia lewat menu Backup & Restore (pulihkan cadangan) dan import phpMyAdmin manual.

### 6. Buka Aplikasi
Akses `https://domainanda.com/` → aplikasi tampil dengan data lengkap.
Setiap perubahan dari aplikasi (CRUD produk/stok/penjualan/dst.) langsung tersimpan
ke MySQL melalui `api.php` — realtime (`sync-item`) maupun penuh (`push-all`).

## 🔁 Alur Sync Frontend ↔ PHP
```
React app ──fetch('/api/db/...')──▶ .htaccess rewrite ──▶ api.php ──PDO──▶ MySQL (phpMyAdmin)
```
Kode frontend **tidak diubah sama sekali**; `.htaccess` yang menerjemahkan
endpoint Node.js lama ke PHP.

## 🛠️ Troubleshooting

| Gejala | Penyebab & Solusi |
|---|---|
| `status` menampilkan `connected:false` | Kredensial `config.php` salah / user belum punya ALL PRIVILEGES atas DB |
| Error 500 saat upload besar | Naikkan `memory_limit`/`max_execution_time` di MultiPHP INI Editor, atau gunakan mode sync item (default sudah hemat) |
| `.htaccess` diabaikan | Pastikan "Show Hidden Files" aktif saat upload; cek AllowOverride hosting (standar cPanel: aktif) |
| Data lama tak muncul | Ini BY DESIGN sekarang: auto-seed dimatikan. Pulihkan file backup lewat menu Backup&Restore, atau import database_kaospolos.sql via phpMyAdmin |
| Ingin reset total | Hapus/TRUNCATE semua tabel via phpMyAdmin → reload aplikasi (tampilan ikut kosong, sesuai isi DB). Untuk mengisi ulang, gunakan seed eksplisit/restore |

## 🔐 Keamanan
- `config.php`, `db-schema.php`, `seed-data.json` **ditolak aksesnya** lewat `.htaccess` (FilesMatch deny).
- Aktifkan `SECRET_TOKEN` di `config.php` bila ingin memproteksi endpoint tulis.
- Selalu pakai HTTPS (AutoSSL cPanel).
