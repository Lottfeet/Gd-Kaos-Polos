<?php
/**
 * =========================================================================
 * GUDANG KAOS POLOS - CPANEL PHP BACKEND (API)
 * =========================================================================
 * Pengganti server.ts (Node.js/Express) untuk hosting cPanel tanpa Node.js.
 * Semua request /api/db/* dari frontend hasil build diarahkan ke file ini
 * lewat rewrite rule .htaccess, sehingga kode React TIDAK perlu diubah.
 *
 * Endpoint yang dilayani:
 *   GET  /api/db/status          -> cek koneksi + jumlah baris tiap tabel
 *   GET  /api/db/pull-all        -> tarik semua data (format frontend camelCase)
 *   POST /api/db/push-all        -> simpan semua data (mode delta/full)
 *   POST /api/db/sync-item       -> simpan/hapus satu entitas (realtime)
 *   POST /api/db/configure       -> tidak didukung di cPanel (info saja)
 *   GET  /api/db/import-backup   -> import file backup JSON aplikasi
 *   GET  /api/db/download-bridge -> download salinan api.php lama (kompatibel)
 *   GET  /api/db/healthz         -> health check
 * =========================================================================
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db-schema.php';

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Sync-Token');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(200);
    exit;
}

@set_time_limit(300);
@ini_set('memory_limit', '512M');

$action = isset($_GET['action']) ? $_GET['action'] : 'status';

// ---------------- helper output & input ----------------
function sendJson($payload, $code = 200)
{
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function readBody()
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        // mendukung form POST biasa
        return $_POST ?: [];
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        return $_POST ?: [];
    }
    return $decoded;
}

function checkToken()
{
    if (SECRET_TOKEN === '') return;            // tidak dikunci
    $sent = isset($_SERVER['HTTP_X_SYNC_TOKEN']) ? $_SERVER['HTTP_X_SYNC_TOKEN']
        : (isset($_GET['token']) ? $_GET['token'] : '');
    if (!hash_equals(SECRET_TOKEN, (string)$sent)) {
        sendJson(['success' => false, 'error' => 'Token sinkronisasi tidak valid (X-Sync-Token).'], 401);
    }
}

function num($v)      { return is_numeric($v) ? $v + 0 : 0; }
function strv($v)     { return $v === null || $v === false ? '' : (string)$v; }
function boolToInt($v){ return !empty($v) ? 1 : 0; }
function jenc($v)     { return json_encode($v === null ? [] : $v, JSON_UNESCAPED_UNICODE); }
function jdec($v, $fallback = []) {
    if ($v === null || $v === '') return $fallback;
    $d = json_decode((string)$v, true);
    return $d === null ? $fallback : $d;
}

// ---------------- router ----------------
try {
    $pdo = kp_pdo();
    kp_create_tables($pdo);

    // ---------- 0. HEALTH ----------
    if ($action === 'healthz' || $action === 'health') {
        sendJson(['ok' => true, 'time' => date('c')]);
    }

    /** Hapus baris di tabel yang TIDAK ada dalam daftar key (dipotong per 500 agar query pendek).
 *  Key kosong = kosongkan seluruh tabel. */
function kp_prune_table(PDO $pdo, $table, array $keys, $pk)
{
    if (!$keys) {
        $pdo->exec('DELETE FROM `' . $table . '`');
        return;
    }
    foreach (array_chunk($keys, 500) as $chunk) {
        $del = $pdo->prepare('DELETE FROM `' . $table . '` WHERE `' . $pk . '` NOT IN (' .
            implode(',', array_fill(0, count($chunk), '?')) . ')');
        $del->execute($chunk);
    }
}

// ---------- 1. STATUS ----------
    if ($action === 'status') {
        $counts = [];
        foreach (array_keys(KP_TABLES) as $key) {
            try {
                $stmt = $pdo->query('SELECT COUNT(*) FROM `' . KP_TABLES[$key] . '`');
                $counts[$key] = (int)$stmt->fetchColumn();
            } catch (Exception $e) {
                $counts[$key] = 0;
            }
        }
        sendJson([
            'connected'   => true,
            'type'        => 'bridge',
            'bridgeUrl'   => '',
            'host'        => DB_HOST,
            'port'        => DB_PORT,
            'user'        => DB_USER,
            'database'    => DB_NAME,
            'tableCounts' => $counts,
            'server'      => 'PHP/' . PHP_VERSION . ' (cPanel)',
            'server_time' => date('Y-m-d H:i:s'),
            'message'     => 'Koneksi PHP ke database phpMyAdmin berhasil!',
            'error'       => null,
        ]);
    }

    // ---------- 2. CONFIGURE (tidak didukung, info) ----------
    if ($action === 'configure') {
        sendJson([
            'success' => false,
            'connected' => true,
            'message' => 'Pada deploy cPanel, konfigurasi DB dilakukan di file config.php (bukan dari browser).',
        ], 200);
    }

    // ---------- 3. PULL ALL ----------
    if ($action === 'pull-all') {
        // PENTING: TIDAK ada auto-seed di sini.
        // Data bawaan (seed-data.json) HANYA dimuat lewat aksi eksplisit:
        // tombol "Muat Seed" (seed-now) atau import-backup. Dengan begitu,
        // saat DB dikosongkan, aplikasi benar-benar menampilkan data kosong
        // dan restore backup tidak tercampur data bawaan paket.

        $rowsOf = function ($table) use ($pdo) {
            try {
                return $pdo->query('SELECT * FROM `' . $table . '`')->fetchAll();
            } catch (Exception $e) {
                return [];
            }
        };

        // master_produk -> MasterProduk (UPPER_SNAKE seperti tipe frontend)
        $products = array_map(function ($r) {
            return [
                'SKU_ID'        => strv($r['sku_id']),
                'NAMA_PRODUK'   => strv($r['nama_produk']),
                'WARNA'         => strv($r['warna']),
                'UKURAN'        => strv($r['ukuran']),
                'KATEGORI'      => strv($r['kategori']),
                'JENIS_LENGAN'  => $r['jenis_lengan'] !== null && $r['jenis_lengan'] !== '' ? $r['jenis_lengan'] : 'PENDEK',
                'REORDER_LEVEL' => (int)($r['reorder_level'] ?? 10),
                'BARCODE_ID'    => strv($r['barcode_id']),
                'HARGA_HPP'     => (float)($r['harga_hpp'] ?? 0),
                'HARGA_JUAL'    => (float)($r['harga_jual'] ?? 0),
            ];
        }, $rowsOf('master_produk'));

        // inventori -> InventoryItem
        $inventory = array_map(function ($r) {
            return [
                'id'            => strv($r['id']),
                'GUDANG_ID'     => strv($r['gudang_id']),
                'SKU_ID'        => strv($r['sku_id']),
                'SKU'           => strv($r['sku_id']),
                'NAMA_PRODUK'   => strv($r['nama_produk']),
                'JUMLAH_READY'  => (int)($r['jumlah_ready'] ?? 0),
                'REORDER_LEVEL' => (int)($r['reorder_level'] ?? 10),
                'REORDER'       => strv($r['reorder'] !== null && $r['reorder'] !== '' ? $r['reorder'] : 'NO'),
                'ORDER_DATE'    => strv($r['order_date']),
                'WARNA'         => strv($r['warna']),
                'UKURAN'        => strv($r['ukuran']),
                'KATEGORI'      => strv($r['kategori']),
                'JENIS_LENGAN'  => strv($r['jenis_lengan']),
            ];
        }, $rowsOf('inventori'));

        // master_gudang -> MasterGudang
        $warehouses = array_map(function ($r) {
            return [
                'GUDANG_ID'        => strv($r['gudang_id']),
                'NAMA_GUDANG'      => strv($r['nama_gudang']),
                'LOKASI'           => strv($r['lokasi']),
                'PENANGGUNG_JAWAB' => strv($r['penanggung_jawab']),
                'IS_ACTIVE'        => (bool)$r['is_active'],
                'IS_DEFAULT'       => (bool)$r['is_default'],
                'TELEPON'          => strv($r['telepon']),
                'KETERANGAN'       => strv($r['keterangan']),
            ];
        }, $rowsOf('master_gudang'));

        // pelanggan -> Pelanggan (camelCase)
        $customers = array_map(function ($r) {
            return [
                'id'            => strv($r['id']),
                'nama'          => strv($r['nama']),
                'telepon'       => strv($r['telepon']),
                'alamat'        => strv($r['alamat']),
                'kota'          => strv($r['kota']),
                'tipe'          => strv($r['tipe'] !== null && $r['tipe'] !== '' ? $r['tipe'] : 'UMUM'),
                'plafonPiutang' => (float)($r['plafon_piutang'] ?? 0),
                'catatan'       => strv($r['catatan']),
                'createdAt'     => strv($r['created_at']),
            ];
        }, $rowsOf('pelanggan'));

        // transaksi_penjualan -> SaleDocument (camelCase)
        $sales = array_map(function ($r) {
            return [
                'nomorSale'         => strv($r['nomor_sale']),
                'tanggal'           => strv($r['tanggal']),
                'gudangId'          => strv($r['gudang_id']),
                'gudangNama'        => strv($r['gudang_nama']),
                'username'          => strv($r['username']),
                'pelanggan'         => strv($r['pelanggan']),
                'pelangganId'       => strv($r['pelanggan_id']),
                'tipePelanggan'     => strv($r['tipe_pelanggan']),
                'kontak'            => strv($r['kontak']),
                'alamat'            => strv($r['alamat']),
                'metode'            => strv($r['metode']),
                'catatan'           => strv($r['catatan']),
                'subtotalNominal'   => (float)($r['subtotal_nominal'] ?? 0),
                'diskonNominal'     => (float)($r['diskon_nominal'] ?? 0),
                'totalNominal'      => (float)($r['total_nominal'] ?? 0),
                'statusPembayaran'  => strv($r['status_pembayaran']),
                'jumlahBayar'       => (float)($r['jumlah_bayar'] ?? 0),
                'sisaPiutang'       => (float)($r['sisa_piutang'] ?? 0),
                'jatuhTempo'        => strv($r['jatuh_tempo']),
                'items'             => jdec($r['items_json'] ?? null),
                'riwayatPelunasan'  => jdec($r['riwayat_pelunasan_json'] ?? null),
                'signaturePenjual'  => jdec($r['signature_penjual_json'] ?? null, null),
                'signaturePembeli'  => jdec($r['signature_pembeli_json'] ?? null, null),
                'createdAt'         => strv($r['created_at']),
            ];
        }, $rowsOf('transaksi_penjualan'));

        // order_po -> OrderDocument
        $orders = array_map(function ($r) {
            return [
                'nomorOrder'          => strv($r['nomor_order']),
                'tanggal'             => strv($r['tanggal']),
                'gudangId'            => strv($r['gudang_id']),
                'gudangNama'          => strv($r['gudang_nama']),
                'username'            => strv($r['username']),
                'supplier'            => strv($r['supplier']),
                'kontak'              => strv($r['kontak']),
                'alamat'              => strv($r['alamat']),
                'metode'              => strv($r['metode']),
                'catatan'             => strv($r['catatan']),
                'subtotalNominal'     => (float)($r['subtotal_nominal'] ?? 0),
                'diskonNominal'       => (float)($r['diskon_nominal'] ?? 0),
                'totalNominal'        => (float)($r['total_nominal'] ?? 0),
                'statusPembayaran'    => strv($r['status_pembayaran']),
                'jumlahBayar'         => (float)($r['jumlah_bayar'] ?? 0),
                'sisaPiutang'         => (float)($r['sisa_piutang'] ?? 0),
                'jatuhTempo'          => strv($r['jatuh_tempo']),
                'tampilkanNominal'    => (bool)($r['tampilkan_nominal'] ?? 1),
                'items'               => jdec($r['items_json'] ?? null),
                'signatureAdmin'      => jdec($r['signature_admin_json'] ?? null, null),
                'signatureSupervisor' => jdec($r['signature_supervisor_json'] ?? null, null),
                'createdAt'           => strv($r['created_at']),
            ];
        }, $rowsOf('order_po'));

        // surat_jalan -> SuratJalanDocument
        $suratJalanList = array_map(function ($r) {
            return [
                'nomorSJ'            => strv($r['nomor_sj']),
                'tanggal'            => strv($r['tanggal']),
                'gudangId'           => strv($r['gudang_id']),
                'gudangNama'         => strv($r['gudang_nama']),
                'username'           => strv($r['username']),
                'tujuan'             => strv($r['tujuan']),
                'penerima'           => strv($r['penerima']),
                'driver'             => strv($r['driver']),
                'kendaraan'          => strv($r['kendaraan']),
                'catatan'            => strv($r['catatan']),
                'tampilkanNominal'   => (bool)($r['tampilkan_nominal'] ?? 0),
                'totalNominal'       => (float)($r['total_nominal'] ?? 0),
                'items'              => jdec($r['items_json'] ?? null),
                'signaturePengirim'  => jdec($r['signature_pengirim_json'] ?? null, null),
                'signatureDriver'    => jdec($r['signature_driver_json'] ?? null, null),
                'signaturePenerima'  => jdec($r['signature_penerima_json'] ?? null, null),
                'createdAt'          => strv($r['created_at']),
            ];
        }, $rowsOf('surat_jalan'));

        // log_transaksi -> LogTransaksi (UPPER_SNAKE)
        $logs = array_map(function ($r) {
            return [
                'id'             => strv($r['id']),
                'TIMESTAMP'      => strv($r['timestamp']),
                'TRANSAKSI_ID'   => strv($r['transaksi_id']),
                'SKU_ID'         => strv($r['sku_id']),
                'GUDANG_ID'      => strv($r['gudang_id']),
                'JUMLAH'         => (int)($r['jumlah'] ?? 0),
                'TIPE_TRANSAKSI' => strv($r['tipe_transaksi']),
                'USERS'          => strv($r['users']),
                'KETERANGAN'     => strv($r['keterangan']),
            ];
        }, $rowsOf('log_transaksi'));

        // app_users -> UserAccount (camelCase)
        $users = array_map(function ($r) {
            return [
                'id'         => strv($r['id']),
                'username'   => strv($r['username']),
                'password'   => strv($r['password']),
                'fullName'   => strv($r['full_name']),
                'role'       => strv($r['role']),
                'siteAccess' => strv($r['site_access']),
                'isActive'   => (bool)$r['is_active'],
                'phone'      => strv($r['phone']),
                'email'      => strv($r['email']),
                'createdAt'  => strv($r['created_at']),
                'lastLogin'  => $r['last_login'] ? strv($r['last_login']) : null,
            ];
        }, $rowsOf('app_users'));

        // app_settings -> AppSystemSettings
        $settings = null;
        try {
            $st = $pdo->query("SELECT settings_json FROM `app_settings` WHERE id = 'default' LIMIT 1");
            $row = $st->fetch();
            if ($row && !empty($row['settings_json'])) {
                $settings = json_decode($row['settings_json'], true);
            }
        } catch (Exception $e) { /* ignore */ }

        $data = [
            'products'       => $products,
            'inventory'      => $inventory,
            'warehouses'     => $warehouses,
            'customers'      => $customers,
            'sales'          => $sales,
            'orders'         => $orders,
            'suratJalanList' => $suratJalanList,
            'logs'           => $logs,
            'users'          => $users,
        ];
        if (is_array($settings) && $settings) {
            $data['settings'] = $settings;
        }

        sendJson([
            'success' => true,
            'source'  => 'cpanel-php',
            'counts'  => [
                'products'       => count($products),
                'inventory'      => count($inventory),
                'warehouses'     => count($warehouses),
                'customers'      => count($customers),
                'sales'          => count($sales),
                'orders'         => count($orders),
                'suratJalanList' => count($suratJalanList),
                'logs'           => count($logs),
                'users'          => count($users),
            ],
            'data' => $data,
        ]);
    }

    // ---------- 4. PUSH ALL ----------
    if ($action === 'push-all' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        checkToken();
        $input = readBody();
        // buang key internal sebelum diproses
        $internalMode = isset($input['__mode']) ? strtolower(strv($input['__mode'])) : '';
        $internalReplace = !empty($input['__replace']);
        unset($input['__mode'], $input['__replace']);
        if (!$input || !is_array($input)) sendJson(['success' => false, 'error' => 'Data input kosong'], 400);

        // Mode replace penuh: dikirim frontend saat sinkron total / restore,
        // atau dipaksa lewat config SYNC_MODE='full'. Semua baris yang TIDAK
        // ada dalam payload akan dihapus dari MySQL sehingga DB menjadi cermin
        // persis data lokal (termasuk saat data lokal kosong = pengosongan DB).
        $replace = $internalMode === 'replace' || $internalReplace || SYNC_MODE === 'full';

        $count = 0;
        $mode  = $replace ? 'full' : 'delta';

        $pdo->beginTransaction();

        // ---- Produk (terima UPPER_SNAKE maupun lowercase) ----
        $products = isset($input['products']) && is_array($input['products']) ? $input['products'] : [];
        if ($products) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `master_produk`
                    (sku_id, nama_produk, warna, ukuran, kategori, jenis_lengan, reorder_level, barcode_id, harga_hpp, harga_jual)
                 VALUES (:sku_id, :nama_produk, :warna, :ukuran, :kategori, :jenis_lengan, :reorder_level, :barcode_id, :harga_hpp, :harga_jual)
                 ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), warna=VALUES(warna), ukuran=VALUES(ukuran),
                    kategori=VALUES(kategori), jenis_lengan=VALUES(jenis_lengan), reorder_level=VALUES(reorder_level),
                    barcode_id=VALUES(barcode_id), harga_hpp=VALUES(harga_hpp), harga_jual=VALUES(harga_jual)'
            ) : 
                'INSERT INTO `master_produk`
                    (sku_id, nama_produk, warna, ukuran, kategori, jenis_lengan, reorder_level, barcode_id, harga_hpp, harga_jual)
                 VALUES (:sku_id, :nama_produk, :warna, :ukuran, :kategori, :jenis_lengan, :reorder_level, :barcode_id, :harga_hpp, :harga_jual)
                 ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), warna=VALUES(warna), ukuran=VALUES(ukuran),
                    kategori=VALUES(kategori), jenis_lengan=VALUES(jenis_lengan), reorder_level=VALUES(reorder_level),
                    barcode_id=VALUES(barcode_id), harga_hpp=VALUES(harga_hpp), harga_jual=VALUES(harga_jual)'
            );
            $seen = [];
            foreach ($products as $p) {
                $sku = strv(isset($p['SKU_ID']) ? $p['SKU_ID'] : ($p['sku_id'] ?? ''));
                if ($sku === '') continue;
                $stmt->execute([
                    ':sku_id'        => $sku,
                    ':nama_produk'   => strv(isset($p['NAMA_PRODUK']) ? $p['NAMA_PRODUK'] : ($p['nama_produk'] ?? '')),
                    ':warna'         => strv(isset($p['WARNA']) ? $p['WARNA'] : ($p['warna'] ?? '')),
                    ':ukuran'        => strv(isset($p['UKURAN']) ? $p['UKURAN'] : ($p['ukuran'] ?? '')),
                    ':kategori'      => strv(isset($p['KATEGORI']) ? $p['KATEGORI'] : ($p['kategori'] ?? '')),
                    ':jenis_lengan'  => strv(isset($p['JENIS_LENGAN']) ? $p['JENIS_LENGAN'] : ($p['jenis_lengan'] ?? 'PENDEK')),
                    ':reorder_level' => (int)num(isset($p['REORDER_LEVEL']) ? $p['REORDER_LEVEL'] : ($p['reorder_level'] ?? 10)),
                    ':barcode_id'    => strv(isset($p['BARCODE_ID']) ? $p['BARCODE_ID'] : ($p['barcode_id'] ?? '')),
                    ':harga_hpp'     => (float)num(isset($p['HARGA_HPP']) ? $p['HARGA_HPP'] : ($p['harga_hpp'] ?? 0)),
                    ':harga_jual'    => (float)num(isset($p['HARGA_JUAL']) ? $p['HARGA_JUAL'] : ($p['harga_jual'] ?? 0)),
                ]);
                $seen[] = $sku;
                $count++;
            }
            // PRUNE: hapus baris yang tidak ada di payload (mode replace/full),
            // termasuk saat $seen kosong (= data lokal kosong -> tabel dikosongkan)
            if ($replace) {
                if ($seen) {
                    $del = $pdo->prepare('DELETE FROM `master_produk` WHERE sku_id NOT IN (' .
                        implode(',', array_fill(0, count($seen), '?')) . ')');
                    $del->execute($seen);
                } else {
                    $pdo->exec('DELETE FROM `master_produk`');
                }
            }
        } elseif ($replace) {
            $pdo->exec('DELETE FROM `master_produk`');
        }

        // ---- Gudang ----
        $warehouses = isset($input['warehouses']) && is_array($input['warehouses']) ? $input['warehouses'] : [];
        $seenGudang = [];
        if ($warehouses) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `master_gudang`
                    (gudang_id, nama_gudang, lokasi, penanggung_jawab, is_active, is_default, telepon, keterangan)
                 VALUES (:gid, :nama, :lokasi, :pj, :aktif, :def, :telp, :ket)
                 ON DUPLICATE KEY UPDATE
                    nama_gudang=VALUES(nama_gudang), lokasi=VALUES(lokasi), penanggung_jawab=VALUES(penanggung_jawab),
                    is_active=VALUES(is_active), is_default=VALUES(is_default), telepon=VALUES(telepon), keterangan=VALUES(keterangan)'
            ) : 
                'INSERT INTO `master_gudang`
                    (gudang_id, nama_gudang, lokasi, penanggung_jawab, is_active, is_default, telepon, keterangan)
                 VALUES (:gid, :nama, :lokasi, :pj, :aktif, :def, :telp, :ket)
                 ON DUPLICATE KEY UPDATE
                    nama_gudang=VALUES(nama_gudang), lokasi=VALUES(lokasi), penanggung_jawab=VALUES(penanggung_jawab),
                    is_active=VALUES(is_active), is_default=VALUES(is_default), telepon=VALUES(telepon), keterangan=VALUES(keterangan)'
            );
            foreach ($warehouses as $w) {
                $gid = strv(isset($w['GUDANG_ID']) ? $w['GUDANG_ID'] : ($w['gudang_id'] ?? ''));
                if ($gid === '') continue;
                $stmt->execute([
                    ':gid'   => $gid,
                    ':nama'  => strv(isset($w['NAMA_GUDANG']) ? $w['NAMA_GUDANG'] : ($w['nama_gudang'] ?? '')),
                    ':lokasi'=> strv(isset($w['LOKASI']) ? $w['LOKASI'] : ($w['lokasi'] ?? '')),
                    ':pj'    => strv(isset($w['PENANGGUNG_JAWAB']) ? $w['PENANGGUNG_JAWAB'] : ($w['penanggung_jawab'] ?? '')),
                    ':aktif' => boolToInt(isset($w['IS_ACTIVE']) ? $w['IS_ACTIVE'] : ($w['is_active'] ?? 1)),
                    ':def'   => boolToInt(isset($w['IS_DEFAULT']) ? $w['IS_DEFAULT'] : ($w['is_default'] ?? 0)),
                    ':telp'  => strv(isset($w['TELEPON']) ? $w['TELEPON'] : ($w['telepon'] ?? '')),
                    ':ket'   => strv(isset($w['KETERANGAN']) ? $w['KETERANGAN'] : ($w['keterangan'] ?? '')),
                ]);
                $seenGudang[] = $gid;
                $count++;
            }
        }
        if ($replace) kp_prune_table($pdo, 'master_gudang', $seenGudang, 'gudang_id');

        // ---- Inventori ----
        $inventory = isset($input['inventory']) && is_array($input['inventory']) ? $input['inventory'] : [];
        $seenInv = [];
        if ($inventory) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `inventori`
                    (id, gudang_id, sku_id, nama_produk, jumlah_ready, reorder_level, reorder, order_date, warna, ukuran, kategori, jenis_lengan)
                 VALUES (:id, :gid, :sku, :nama, :qty, :rol, :ro, :od, :warna, :ukuran, :kat, :jl)
                 ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), jumlah_ready=VALUES(jumlah_ready), reorder_level=VALUES(reorder_level),
                    reorder=VALUES(reorder), order_date=VALUES(order_date), warna=VALUES(warna),
                    ukuran=VALUES(ukuran), kategori=VALUES(kategori), jenis_lengan=VALUES(jenis_lengan)'
            ) : 
                'INSERT INTO `inventori`
                    (id, gudang_id, sku_id, nama_produk, jumlah_ready, reorder_level, reorder, order_date, warna, ukuran, kategori, jenis_lengan)
                 VALUES (:id, :gid, :sku, :nama, :qty, :rol, :ro, :od, :warna, :ukuran, :kat, :jl)
                 ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), jumlah_ready=VALUES(jumlah_ready), reorder_level=VALUES(reorder_level),
                    reorder=VALUES(reorder), order_date=VALUES(order_date), warna=VALUES(warna),
                    ukuran=VALUES(ukuran), kategori=VALUES(kategori), jenis_lengan=VALUES(jenis_lengan)'
            );
            foreach ($inventory as $inv) {
                $gid = strv(isset($inv['GUDANG_ID']) ? $inv['GUDANG_ID'] : ($inv['gudang_id'] ?? ''));
                $sku = strv(isset($inv['SKU_ID']) ? $inv['SKU_ID'] : (isset($inv['SKU']) ? $inv['SKU'] : ($inv['sku_id'] ?? '')));
                if ($gid === '' || $sku === '') continue;
                $id = strv($inv['id'] ?? '');
                if ($id === '') $id = $gid . '_' . $sku;
                $stmt->execute([
                    ':id'    => $id,
                    ':gid'   => $gid,
                    ':sku'   => $sku,
                    ':nama'  => strv(isset($inv['NAMA_PRODUK']) ? $inv['NAMA_PRODUK'] : ($inv['nama_produk'] ?? '')),
                    ':qty'   => (int)num(isset($inv['JUMLAH_READY']) ? $inv['JUMLAH_READY'] : ($inv['jumlah_ready'] ?? 0)),
                    ':rol'   => (int)num(isset($inv['REORDER_LEVEL']) ? $inv['REORDER_LEVEL'] : ($inv['reorder_level'] ?? 10)),
                    ':ro'    => strv(isset($inv['REORDER']) ? $inv['REORDER'] : ($inv['reorder'] ?? 'NO')),
                    ':od'    => strv(isset($inv['ORDER_DATE']) ? $inv['ORDER_DATE'] : ($inv['order_date'] ?? '')),
                    ':warna' => strv(isset($inv['WARNA']) ? $inv['WARNA'] : ($inv['warna'] ?? '')),
                    ':ukuran'=> strv(isset($inv['UKURAN']) ? $inv['UKURAN'] : ($inv['ukuran'] ?? '')),
                    ':kat'   => strv(isset($inv['KATEGORI']) ? $inv['KATEGORI'] : ($inv['kategori'] ?? '')),
                    ':jl'    => strv(isset($inv['JENIS_LENGAN']) ? $inv['JENIS_LENGAN'] : ($inv['jenis_lengan'] ?? 'PENDEK')),
                ]);
                $seenInv[] = $id;
                $count++;
            }
        }
        if ($replace) kp_prune_table($pdo, 'inventori', $seenInv, 'id');

        // ---- Pelanggan ----
        $customers = isset($input['customers']) && is_array($input['customers']) ? $input['customers'] : [];
        $seenCust = [];
        if ($customers) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `pelanggan` (id, nama, telepon, alamat, kota, tipe, plafon_piutang, catatan, created_at)
                 VALUES (:id, :nama, :telp, :alamat, :kota, :tipe, :plafon, :catatan, :created)
                 ON DUPLICATE KEY UPDATE
                    nama=VALUES(nama), telepon=VALUES(telepon), alamat=VALUES(alamat), kota=VALUES(kota),
                    tipe=VALUES(tipe), plafon_piutang=VALUES(plafon_piutang), catatan=VALUES(catatan)'
            ) : 
                'INSERT INTO `pelanggan` (id, nama, telepon, alamat, kota, tipe, plafon_piutang, catatan, created_at)
                 VALUES (:id, :nama, :telp, :alamat, :kota, :tipe, :plafon, :catatan, :created)
                 ON DUPLICATE KEY UPDATE
                    nama=VALUES(nama), telepon=VALUES(telepon), alamat=VALUES(alamat), kota=VALUES(kota),
                    tipe=VALUES(tipe), plafon_piutang=VALUES(plafon_piutang), catatan=VALUES(catatan)'
            );
            foreach ($customers as $c) {
                $cid = strv($c['id'] ?? '');
                if ($cid === '') continue;
                $stmt->execute([
                    ':id'      => $cid,
                    ':nama'    => strv($c['nama'] ?? ''),
                    ':telp'    => strv($c['telepon'] ?? ''),
                    ':alamat'  => strv($c['alamat'] ?? ''),
                    ':kota'    => strv($c['kota'] ?? ''),
                    ':tipe'    => strv($c['tipe'] ?? 'UMUM'),
                    ':plafon'  => (float)num($c['plafonPiutang'] ?? ($c['plafon_piutang'] ?? 0)),
                    ':catatan' => strv($c['catatan'] ?? ''),
                    ':created' => strv($c['createdAt'] ?? ($c['created_at'] ?? date('Y-m-d H:i:s'))),
                ]);
                $seenCust[] = $cid;
                $count++;
            }
        }
        if ($replace) kp_prune_table($pdo, 'pelanggan', $seenCust, 'id');

        // ---- Penjualan ----
        $sales = isset($input['sales']) && is_array($input['sales']) ? $input['sales'] : [];
        $seenSales = [];
        if ($sales) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `transaksi_penjualan`
                    (nomor_sale, tanggal, gudang_id, gudang_nama, username, pelanggan, pelanggan_id, tipe_pelanggan,
                     kontak, alamat, metode, catatan, subtotal_nominal, diskon_nominal, total_nominal,
                     status_pembayaran, jumlah_bayar, sisa_piutang, jatuh_tempo, items_json,
                     riwayat_pelunasan_json, signature_penjual_json, signature_pembeli_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17,:a18,:a19,:a20,:a21,:a22,:a23,:a24)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    pelanggan=VALUES(pelanggan), pelanggan_id=VALUES(pelanggan_id), tipe_pelanggan=VALUES(tipe_pelanggan),
                    kontak=VALUES(kontak), alamat=VALUES(alamat), metode=VALUES(metode), catatan=VALUES(catatan),
                    subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal),
                    total_nominal=VALUES(total_nominal), status_pembayaran=VALUES(status_pembayaran),
                    jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang), jatuh_tempo=VALUES(jatuh_tempo),
                    items_json=VALUES(items_json), riwayat_pelunasan_json=VALUES(riwayat_pelunasan_json),
                    signature_penjual_json=VALUES(signature_penjual_json), signature_pembeli_json=VALUES(signature_pembeli_json)'
            ) : 
                'INSERT INTO `transaksi_penjualan`
                    (nomor_sale, tanggal, gudang_id, gudang_nama, username, pelanggan, pelanggan_id, tipe_pelanggan,
                     kontak, alamat, metode, catatan, subtotal_nominal, diskon_nominal, total_nominal,
                     status_pembayaran, jumlah_bayar, sisa_piutang, jatuh_tempo, items_json,
                     riwayat_pelunasan_json, signature_penjual_json, signature_pembeli_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17,:a18,:a19,:a20,:a21,:a22,:a23,:a24)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    pelanggan=VALUES(pelanggan), pelanggan_id=VALUES(pelanggan_id), tipe_pelanggan=VALUES(tipe_pelanggan),
                    kontak=VALUES(kontak), alamat=VALUES(alamat), metode=VALUES(metode), catatan=VALUES(catatan),
                    subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal),
                    total_nominal=VALUES(total_nominal), status_pembayaran=VALUES(status_pembayaran),
                    jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang), jatuh_tempo=VALUES(jatuh_tempo),
                    items_json=VALUES(items_json), riwayat_pelunasan_json=VALUES(riwayat_pelunasan_json),
                    signature_penjual_json=VALUES(signature_penjual_json), signature_pembeli_json=VALUES(signature_pembeli_json)'
            );
            foreach ($sales as $s) {
                $no = strv(isset($s['nomorSale']) ? $s['nomorSale'] : ($s['nomor_sale'] ?? ''));
                if ($no === '') continue;
                $stmt->execute([
                    ':a1' => $no,
                    ':a2' => strv($s['tanggal'] ?? ''),
                    ':a3' => strv(isset($s['gudangId']) ? $s['gudangId'] : ($s['gudang_id'] ?? '')),
                    ':a4' => strv(isset($s['gudangNama']) ? $s['gudangNama'] : ($s['gudang_nama'] ?? '')),
                    ':a5' => strv($s['username'] ?? ''),
                    ':a6' => strv($s['pelanggan'] ?? ''),
                    ':a7' => strv($s['pelangganId'] ?? ''),
                    ':a8' => strv($s['tipePelanggan'] ?? ''),
                    ':a9' => strv($s['kontak'] ?? ''),
                    ':a10'=> strv($s['alamat'] ?? ''),
                    ':a11'=> strv($s['metode'] ?? 'TUNAI'),
                    ':a12'=> strv($s['catatan'] ?? ''),
                    ':a13'=> (float)num($s['subtotalNominal'] ?? 0),
                    ':a14'=> (float)num($s['diskonNominal'] ?? 0),
                    ':a15'=> (float)num($s['totalNominal'] ?? 0),
                    ':a16'=> strv($s['statusPembayaran'] ?? 'LUNAS'),
                    ':a17'=> (float)num($s['jumlahBayar'] ?? 0),
                    ':a18'=> (float)num($s['sisaPiutang'] ?? 0),
                    ':a19'=> strv($s['jatuhTempo'] ?? ''),
                    ':a20'=> jenc($s['items'] ?? []),
                    ':a21'=> jenc($s['riwayatPelunasan'] ?? []),
                    ':a22'=> json_encode($s['signaturePenjual'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a23'=> json_encode($s['signaturePembeli'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a24'=> strv($s['createdAt'] ?? ($s['tanggal'] ?? date('Y-m-d H:i:s'))),
                ]);
                $seenSales[] = $no;
                $count++;
            }
        }
        if ($replace) kp_prune_table($pdo, 'transaksi_penjualan', $seenSales, 'nomor_sale');

        // ---- Purchase Order ----
        $orders = isset($input['orders']) && is_array($input['orders']) ? $input['orders'] : [];
        $seenOrders = [];
        if ($orders) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `order_po`
                    (nomor_order, tanggal, gudang_id, gudang_nama, username, supplier, kontak, alamat, metode, catatan,
                     subtotal_nominal, diskon_nominal, total_nominal, status_pembayaran, jumlah_bayar, sisa_piutang,
                     jatuh_tempo, tampilkan_nominal, items_json, signature_admin_json, signature_supervisor_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17,:a18,:a19,:a20,:a21,:a22)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    supplier=VALUES(supplier), kontak=VALUES(kontak), alamat=VALUES(alamat), metode=VALUES(metode),
                    catatan=VALUES(catatan), subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal),
                    total_nominal=VALUES(total_nominal), status_pembayaran=VALUES(status_pembayaran),
                    jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang), jatuh_tempo=VALUES(jatuh_tempo),
                    tampilkan_nominal=VALUES(tampilkan_nominal), items_json=VALUES(items_json),
                    signature_admin_json=VALUES(signature_admin_json), signature_supervisor_json=VALUES(signature_supervisor_json)'
            ) : 
                'INSERT INTO `order_po`
                    (nomor_order, tanggal, gudang_id, gudang_nama, username, supplier, kontak, alamat, metode, catatan,
                     subtotal_nominal, diskon_nominal, total_nominal, status_pembayaran, jumlah_bayar, sisa_piutang,
                     jatuh_tempo, tampilkan_nominal, items_json, signature_admin_json, signature_supervisor_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17,:a18,:a19,:a20,:a21,:a22)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    supplier=VALUES(supplier), kontak=VALUES(kontak), alamat=VALUES(alamat), metode=VALUES(metode),
                    catatan=VALUES(catatan), subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal),
                    total_nominal=VALUES(total_nominal), status_pembayaran=VALUES(status_pembayaran),
                    jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang), jatuh_tempo=VALUES(jatuh_tempo),
                    tampilkan_nominal=VALUES(tampilkan_nominal), items_json=VALUES(items_json),
                    signature_admin_json=VALUES(signature_admin_json), signature_supervisor_json=VALUES(signature_supervisor_json)'
            );
            foreach ($orders as $o) {
                $no = strv(isset($o['nomorOrder']) ? $o['nomorOrder'] : ($o['nomor_order'] ?? ''));
                if ($no === '') continue;
                $stmt->execute([
                    ':a1' => $no,
                    ':a2' => strv($o['tanggal'] ?? ''),
                    ':a3' => strv($o['gudangId'] ?? ''),
                    ':a4' => strv($o['gudangNama'] ?? ''),
                    ':a5' => strv($o['username'] ?? ''),
                    ':a6' => strv($o['supplier'] ?? ''),
                    ':a7' => strv($o['kontak'] ?? ''),
                    ':a8' => strv($o['alamat'] ?? ''),
                    ':a9' => strv($o['metode'] ?? ''),
                    ':a10'=> strv($o['catatan'] ?? ''),
                    ':a11'=> (float)num($o['subtotalNominal'] ?? 0),
                    ':a12'=> (float)num($o['diskonNominal'] ?? 0),
                    ':a13'=> (float)num($o['totalNominal'] ?? 0),
                    ':a14'=> strv($o['statusPembayaran'] ?? 'LUNAS'),
                    ':a15'=> (float)num($o['jumlahBayar'] ?? 0),
                    ':a16'=> (float)num($o['sisaPiutang'] ?? 0),
                    ':a17'=> strv($o['jatuhTempo'] ?? ''),
                    ':a18'=> boolToInt($o['tampilkanNominal'] ?? 1),
                    ':a19'=> jenc($o['items'] ?? []),
                    ':a20'=> json_encode($o['signatureAdmin'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a21'=> json_encode($o['signatureSupervisor'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a22'=> strv($o['createdAt'] ?? ($o['tanggal'] ?? date('Y-m-d H:i:s'))),
                ]);
                $seenOrders[] = $no;
                $count++;
            }
        }
        if ($replace) kp_prune_table($pdo, 'order_po', $seenOrders, 'nomor_order');

        // ---- Surat Jalan ----
        $sjList = isset($input['suratJalanList']) && is_array($input['suratJalanList']) ? $input['suratJalanList'] : [];
        $seenSj = [];
        if ($sjList) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `surat_jalan`
                    (nomor_sj, tanggal, gudang_id, gudang_nama, username, tujuan, penerima, driver, kendaraan, catatan,
                     tampilkan_nominal, total_nominal, items_json, signature_pengirim_json, signature_driver_json,
                     signature_penerima_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    tujuan=VALUES(tujuan), penerima=VALUES(penerima), driver=VALUES(driver), kendaraan=VALUES(kendaraan),
                    catatan=VALUES(catatan), tampilkan_nominal=VALUES(tampilkan_nominal), total_nominal=VALUES(total_nominal),
                    items_json=VALUES(items_json), signature_pengirim_json=VALUES(signature_pengirim_json),
                    signature_driver_json=VALUES(signature_driver_json), signature_penerima_json=VALUES(signature_penerima_json)'
            ) : 
                'INSERT INTO `surat_jalan`
                    (nomor_sj, tanggal, gudang_id, gudang_nama, username, tujuan, penerima, driver, kendaraan, catatan,
                     tampilkan_nominal, total_nominal, items_json, signature_pengirim_json, signature_driver_json,
                     signature_penerima_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    tujuan=VALUES(tujuan), penerima=VALUES(penerima), driver=VALUES(driver), kendaraan=VALUES(kendaraan),
                    catatan=VALUES(catatan), tampilkan_nominal=VALUES(tampilkan_nominal), total_nominal=VALUES(total_nominal),
                    items_json=VALUES(items_json), signature_pengirim_json=VALUES(signature_pengirim_json),
                    signature_driver_json=VALUES(signature_driver_json), signature_penerima_json=VALUES(signature_penerima_json)'
            );
            foreach ($sjList as $sj) {
                $no = strv(isset($sj['nomorSJ']) ? $sj['nomorSJ'] : ($sj['nomor_sj'] ?? ''));
                if ($no === '') continue;
                $stmt->execute([
                    ':a1' => $no,
                    ':a2' => strv($sj['tanggal'] ?? ''),
                    ':a3' => strv($sj['gudangId'] ?? ''),
                    ':a4' => strv($sj['gudangNama'] ?? ''),
                    ':a5' => strv($sj['username'] ?? ''),
                    ':a6' => strv($sj['tujuan'] ?? ''),
                    ':a7' => strv($sj['penerima'] ?? ''),
                    ':a8' => strv($sj['driver'] ?? ''),
                    ':a9' => strv($sj['kendaraan'] ?? ''),
                    ':a10'=> strv($sj['catatan'] ?? ''),
                    ':a11'=> boolToInt($sj['tampilkanNominal'] ?? 0),
                    ':a12'=> (float)num($sj['totalNominal'] ?? 0),
                    ':a13'=> jenc($sj['items'] ?? []),
                    ':a14'=> json_encode($sj['signaturePengirim'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a15'=> json_encode($sj['signatureDriver'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a16'=> json_encode($sj['signaturePenerima'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a17'=> strv($sj['createdAt'] ?? ($sj['tanggal'] ?? date('Y-m-d H:i:s'))),
                ]);
                $seenSj[] = $no;
                $count++;
            }
        }
        if ($replace) kp_prune_table($pdo, 'surat_jalan', $seenSj, 'nomor_sj');

        // ---- Logs (mode replace: bersihkan total lalu tulis ulang; delta: append tanpa duplikat) ----
        $logs = isset($input['logs']) && is_array($input['logs']) ? $input['logs'] : [];
        if ($replace) {
            $pdo->exec('DELETE FROM `log_transaksi`');
        }
        if ($logs) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `log_transaksi`
                    (timestamp, transaksi_id, sku_id, gudang_id, jumlah, tipe_transaksi, users, keterangan)
                 VALUES (:ts, :tid, :sku, :gid, :jml, :tipe, :usr, :ket)'
            ) : 
                'INSERT INTO `log_transaksi`
                    (timestamp, transaksi_id, sku_id, gudang_id, jumlah, tipe_transaksi, users, keterangan)
                 VALUES (:ts, :tid, :sku, :gid, :jml, :tipe, :usr, :ket)'
            );
            $exists = null; // di mode replace, cek duplikat tidak diperlukan (tabel sudah dibersihkan)
            if (!$replace) {
                $exists = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                    'SELECT 1 FROM `log_transaksi` WHERE timestamp = ? AND transaksi_id = ? AND sku_id = ? AND tipe_transaksi = ? LIMIT 1'
                ) : 
                    'SELECT 1 FROM `log_transaksi` WHERE timestamp = ? AND transaksi_id = ? AND sku_id = ? AND tipe_transaksi = ? LIMIT 1'
                );
            }
            foreach ($logs as $l) {
                $ts   = strv(isset($l['TIMESTAMP']) ? $l['TIMESTAMP'] : ($l['timestamp'] ?? ''));
                $tid  = strv(isset($l['TRANSAKSI_ID']) ? $l['TRANSAKSI_ID'] : ($l['transaksi_id'] ?? ''));
                $sku  = strv(isset($l['SKU_ID']) ? $l['SKU_ID'] : ($l['sku_id'] ?? ''));
                if ($ts === '' || $tid === '') continue;
                if ($exists) {
                    $exists->execute([$ts, $tid, $sku, strv(isset($l['TIPE_TRANSAKSI']) ? $l['TIPE_TRANSAKSI'] : ($l['tipe_transaksi'] ?? ''))]);
                    if ($exists->fetch()) continue; // sudah ada, lewati
                }
                $stmt->execute([
                    ':ts'   => $ts,
                    ':tid'  => $tid,
                    ':sku'  => $sku,
                    ':gid'  => strv(isset($l['GUDANG_ID']) ? $l['GUDANG_ID'] : ($l['gudang_id'] ?? '')),
                    ':jml'  => (int)num(isset($l['JUMLAH']) ? $l['JUMLAH'] : ($l['jumlah'] ?? 0)),
                    ':tipe' => strv(isset($l['TIPE_TRANSAKSI']) ? $l['TIPE_TRANSAKSI'] : ($l['tipe_transaksi'] ?? '')),
                    ':usr'  => strv(isset($l['USERS']) ? $l['USERS'] : ($l['users'] ?? '')),
                    ':ket'  => strv(isset($l['KETERANGAN']) ? $l['KETERANGAN'] : ($l['keterangan'] ?? '')),
                ]);
                $count++;
            }
        }

        // ---- Users ----
        $users = isset($input['users']) && is_array($input['users']) ? $input['users'] : [];
        $seenUsers = [];
        if ($users) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `app_users`
                    (id, username, password, full_name, role, site_access, is_active, phone, email, created_at, last_login)
                 VALUES (:id, :usr, :pass, :nama, :role, :site, :aktif, :phone, :email, :created, :lastlogin)
                 ON DUPLICATE KEY UPDATE
                    password=VALUES(password), full_name=VALUES(full_name), role=VALUES(role),
                    site_access=VALUES(site_access), is_active=VALUES(is_active), phone=VALUES(phone),
                    email=VALUES(email), last_login=VALUES(last_login)'
            ) : 
                'INSERT INTO `app_users`
                    (id, username, password, full_name, role, site_access, is_active, phone, email, created_at, last_login)
                 VALUES (:id, :usr, :pass, :nama, :role, :site, :aktif, :phone, :email, :created, :lastlogin)
                 ON DUPLICATE KEY UPDATE
                    password=VALUES(password), full_name=VALUES(full_name), role=VALUES(role),
                    site_access=VALUES(site_access), is_active=VALUES(is_active), phone=VALUES(phone),
                    email=VALUES(email), last_login=VALUES(last_login)'
            );
            foreach ($users as $u) {
                $uid = strv($u['id'] ?? '');
                $uname = strv($u['username'] ?? '');
                if ($uid === '' || $uname === '') continue;
                $stmt->execute([
                    ':id'        => $uid,
                    ':usr'       => $uname,
                    ':pass'      => strv($u['password'] ?? ''),
                    ':nama'      => strv($u['fullName'] ?? ''),
                    ':role'      => strv($u['role'] ?? 'STAF'),
                    ':site'      => strv($u['siteAccess'] ?? 'GUDANG UTAMA'),
                    ':aktif'     => boolToInt($u['isActive'] ?? 1),
                    ':phone'     => strv($u['phone'] ?? ''),
                    ':email'     => strv($u['email'] ?? ''),
                    ':created'   => strv($u['createdAt'] ?? date('Y-m-d H:i:s')),
                    ':lastlogin' => strv($u['lastLogin'] ?? ''),
                ]);
                $seenUsers[] = $uid;
                $count++;
            }
        }
        if ($replace) kp_prune_table($pdo, 'app_users', $seenUsers, 'id');

        // ---- Settings ----
        if (isset($input['settings']) && is_array($input['settings']) && $input['settings']) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `app_settings` (id, settings_json) VALUES (:id, :json)
                 ON DUPLICATE KEY UPDATE settings_json=VALUES(settings_json)'
            ) : 
                'INSERT INTO `app_settings` (id, settings_json) VALUES (:id, :json)
                 ON DUPLICATE KEY UPDATE settings_json=VALUES(settings_json)'
            );
            $stmt->execute([':id' => 'default', ':json' => json_encode($input['settings'], JSON_UNESCAPED_UNICODE)]);
            $count++;
        }

        $pdo->commit();
        sendJson([
            'success' => true,
            'count'   => $count,
            'mode'    => $mode,
            'message' => "Sinkronisasi selesai: {$count} baris diproses ke MySQL ({$mode}).",
        ]);
    }

    // ---------- 5. SYNC ITEM (realtime per entitas) ----------
    if ($action === 'sync-item' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        checkToken();
        $body   = readBody();
        $act    = strv($body['action'] ?? '');
        $key    = strv($body['key'] ?? '');
        $data   = isset($body['data']) && is_array($body['data']) ? $body['data'] : [];
        $result = kp_sync_item($pdo, $act, $key, $data);
        sendJson($result, $result['success'] ? 200 : 500);
    }

    // ---------- 6. IMPORT BACKUP JSON ----------
    if ($action === 'import-backup') {
        checkToken();
        $file = strv($_GET['file'] ?? 'seed-data.json');
        $path = realpath(__DIR__ . '/' . basename($file));
        if (!$path || !is_file($path)) {
            sendJson(['success' => false, 'error' => "File backup tidak ditemukan: {$file}"], 404);
        }
        $json = json_decode(file_get_contents($path), true);
        if (!is_array($json) || !isset($json['products'])) {
            sendJson(['success' => false, 'error' => 'Format file backup tidak dikenali'], 400);
        }
        $payload = [
            'products'       => $json['products'] ?? [],
            'warehouses'     => $json['warehouses'] ?? [],
            'inventory'      => $json['inventory'] ?? [],
            'customers'      => $json['customers'] ?? [],
            'sales'          => $json['sales'] ?? [],
            'orders'         => $json['orders'] ?? [],
            'suratJalanList' => $json['suratJalanList'] ?? [],
            'logs'           => $json['logs'] ?? [],
            'users'          => $json['users'] ?? [],
            'settings'       => $json['settings'] ?? null,
        ];
        $count = kp_import_payload($pdo, $payload);
        sendJson(['success' => true, 'count' => $count, 'message' => "Import backup selesai: {$count} baris."]);
    }

    // ---------- 7. SEED NOW (paksa muat seed-data.json) ----------
    if ($action === 'seed-now') {
        checkToken();
        $count = kp_load_seed($pdo, true);
        sendJson(['success' => true, 'count' => $count, 'message' => "Seed dimuat paksa: {$count} baris."]);
    }

    // ---------- 8. DOWNLOAD BRIDGE (kompatibilitas tombol lama) ----------
    if ($action === 'download-bridge') {
        header('Content-Type: text/plain; charset=UTF-8');
        header('Content-Disposition: attachment; filename="api.php"');
        readfile(__DIR__ . '/api.php');
        exit;
    }

    sendJson(['success' => false, 'error' => 'Action tidak dikenali: ' . $action], 404);

} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        try { $pdo->rollBack(); } catch (Exception $ignored) {}
    }
    http_response_code(500);
    echo json_encode([
        'connected' => false,
        'success'   => false,
        'error'     => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE);
}
