<?php
/**
 * =========================================================================
 * KONFIGURASI DATABASE - GUDANG KAOS POLOS (cPanel / phpMyAdmin)
 * =========================================================================
 * Edit 4 nilai di bawah ini sesuai data yang Anda dapatkan di cPanel:
 *   cPanel -> MySQL Databases -> Database & User yang sudah dibuat
 *
 * DB_HOST hampir selalu 'localhost' pada hosting cPanel (jangan pakai IP publik).
 * =========================================================================
 */

// Opsional untuk pengujian lokal tanpa MySQL (mis. `php -S`):
//   define('DB_DRIVER', 'sqlite');  -> pakai file /tmp/kaospolos-test.sqlite
if (!defined('DB_DRIVER')) define('DB_DRIVER', getenv('KP_DB_DRIVER') ?: 'mysql');

define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('DB_USER', 'USERNAME_CPANEL_db_kaospolos');      // <-- ganti: nama user MySQL di cPanel
define('DB_PASS', 'PASSWORD_MYSQL_ANDA');               // <-- ganti: password user MySQL tersebut
define('DB_NAME', 'USERNAME_CPANEL_db_kaospolos');      // <-- ganti: nama database di cPanel (prefix username__)
define('DB_SQLITE_PATH', '/tmp/kaospolos-test.sqlite'); // hanya dipakai bila DB_DRIVER = sqlite

/**
 * Token keamanan (opsional).
 * Jika diisi, maka semua request tulis (push-all / sync-item) wajib mengirim
 * header  X-Sync-Token  dengan nilai yang sama, atau query string ?token=...
 * Biarkan '' untuk menonaktifkan.
 */
define('SECRET_TOKEN', '');

/**
 * Seed data awal (snapshot backup KaosPolos_CHK-20261028-151107).
 * BUG FIX: harus selalu false pada deploy ini. Auto-seed membuat DB yang
 * dikosongkan terisi ulang oleh data bawaan paket, dan hasil restore backup
 * tercampur data bawaan. Data bawaan kini HANYA dimuat secara eksplisit
 * lewat tombol "Muat Seed Bawaan ke MySQL" di aplikasi.
 */
define('AUTO_SEED', false);
define('SEED_FILE', __DIR__ . '/seed-data.json');

/** Mode sinkronisasi penuh (bisa berat bila data banyak): 'full' | 'delta' */
define('SYNC_MODE', 'delta');

/** Zona waktu tampilan di log/status */
date_default_timezone_set('Asia/Jakarta');
