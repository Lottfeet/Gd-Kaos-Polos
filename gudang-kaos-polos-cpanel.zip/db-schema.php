<?php
/**
 * =========================================================================
 * STRUKTUR TABEL MYSQL + SEED DATA - GUDANG KAOS POLOS
 * =========================================================================
 * Dipakai oleh api.php. Kolom sengaja dibuat SUPERSET dari schema lama
 * (public/database_kaospolos.sql) agar kompatibel dengan phpMyAdmin dump
 * maupun snapshot JSON aplikasi.
 * =========================================================================
 */

/** Peta entitas frontend -> nama tabel MySQL */
const KP_TABLES = [
    'products'       => 'master_produk',
    'inventory'      => 'inventori',
    'warehouses'     => 'master_gudang',
    'customers'      => 'pelanggan',
    'sales'          => 'transaksi_penjualan',
    'orders'         => 'order_po',
    'suratJalanList' => 'surat_jalan',
    'logs'           => 'log_transaksi',
    'users'          => 'app_users',
];

/** Koneksi PDO singletons */
function kp_is_sqlite_driver()
{
    return defined('DB_DRIVER') && DB_DRIVER === 'sqlite';
}

function kp_pdo()
{
    static $pdo = null;
    if ($pdo === null) {
        if (defined('DB_DRIVER') && DB_DRIVER === 'sqlite') {
            // Hanya untuk pengujian lokal tanpa MySQL (tidak dipakai di cPanel)
            $pdo = new PDO('sqlite:' . DB_SQLITE_PATH, null, null, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            $pdo->exec('PRAGMA journal_mode=WAL');
        } else {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        }
    }
    return $pdo;
}

/** Translasi DDL MySQL -> SQLite (khusus mode uji lokal) */
function kp_translate_ddl_sqlite($sql)
{
    $sql = str_ireplace('ON UPDATE CURRENT_TIMESTAMP', '', $sql);
    $sql = preg_replace('/ENGINE=\w+[^;)]*/i', '', $sql);
    $sql = preg_replace('/\bTINYINT\(\d+\)/i', 'INTEGER', $sql);
    $sql = preg_replace('/\bINT\b/i', 'INTEGER', $sql);
    $sql = preg_replace('/\bVARCHAR\(\d+\)/i', 'TEXT', $sql);
    $sql = preg_replace('/\bDECIMAL\(\d+,\d+\)/i', 'REAL', $sql);
    $sql = preg_replace('/\bLONGTEXT\b/i', 'TEXT', $sql);
    $sql = preg_replace('/AUTO_INCREMENT/i', 'AUTOINCREMENT', $sql);
    // SQLite: AUTOINCREMENT harus ditulis SETELAH PRIMARY KEY dan tipenya INTEGER.
    // Bentuk hasil translasi awal: `id` INTEGER AUTOINCREMENT NOT NULL PRIMARY KEY
    // Bentuk yang benar untuk SQLite: `id` INTEGER PRIMARY KEY AUTOINCREMENT
    $sql = preg_replace('/\bINTEGER\s+AUTOINCREMENT\s+(?:NOT\s+NULL\s+)?PRIMARY\s+KEY\b/i', 'INTEGER PRIMARY KEY AUTOINCREMENT', $sql);
    $sql = preg_replace('/DEFAULT\s+(CURRENT_TIMESTAMP|NULL)\b/i', 'DEFAULT \1', $sql);
    // SQLite tidak mendukung UNIQUE KEY / KEY inline -> ubah jadi constraint sederhana
    $sql = preg_replace('/,\s*UNIQUE KEY `\w+`\s*\(([^)]*)\)/i', ', UNIQUE (\1)', $sql);
    $sql = preg_replace('/,\s*(KEY|INDEX)\s+`\w+`\s*\([^)]*\)/i', '', $sql);
    return $sql;
}

/** Konversi query UPSERT MySQL (ON DUPLICATE KEY UPDATE ... VALUES(col))
 *  menjadi UPSERT SQLite (ON CONFLICT DO UPDATE SET col=excluded.col).
 *  Hanya dipakai saat DB_DRIVER=sqlite untuk pengujian lokal;
 *  di cPanel (MySQL) query asli tetap digunakan apa adanya. */
function kp_upsert_to_sqlite($sql)
{
    if (stripos($sql, 'ON DUPLICATE KEY UPDATE') === false) return $sql;
    $parts = preg_split('/\bON\s+DUPLICATE\s+KEY\s+UPDATE\b/i', $sql, 2);
    $head  = $parts[0];
    $upd   = rtrim(trim($parts[1]), ';');
    // daftar kolom target dari clause INSERT ... (col_a, col_b, ...)
    if (!preg_match('/\(([^)]*)\)\s*VALUES/i', $head, $m)) return $sql;
    $cols = array_map(function ($c) { return trim(str_replace('`', '', $c)); }, explode(',', $m[1]));
    $sets = [];
    foreach ($cols as $col) {
        $sets[] = '`' . $col . '`=excluded.`' . $col . '`';
    }
    return $head . 'ON CONFLICT DO UPDATE SET ' . implode(', ', $sets);
}

/** Buat semua tabel bila belum ada (idempotent) */
function kp_create_tables(PDO $pdo)
{
    static $done = false;
    if ($done) return;
    $done = true;

    $sql = "
    CREATE TABLE IF NOT EXISTS `master_gudang` (
        `gudang_id` VARCHAR(50) NOT NULL PRIMARY KEY,
        `nama_gudang` VARCHAR(100) NOT NULL,
        `lokasi` VARCHAR(255) DEFAULT NULL,
        `penanggung_jawab` VARCHAR(100) DEFAULT NULL,
        `is_active` TINYINT(1) DEFAULT 1,
        `is_default` TINYINT(1) DEFAULT 0,
        `telepon` VARCHAR(50) DEFAULT NULL,
        `keterangan` TEXT DEFAULT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS `master_produk` (
        `sku_id` VARCHAR(100) NOT NULL PRIMARY KEY,
        `nama_produk` VARCHAR(255) NOT NULL,
        `warna` VARCHAR(100) DEFAULT NULL,
        `ukuran` VARCHAR(50) DEFAULT NULL,
        `kategori` VARCHAR(100) DEFAULT NULL,
        `jenis_lengan` VARCHAR(50) DEFAULT 'PENDEK',
        `reorder_level` INT DEFAULT 10,
        `barcode_id` VARCHAR(100) DEFAULT NULL,
        `harga_hpp` DECIMAL(15,2) DEFAULT 0.00,
        `harga_jual` DECIMAL(15,2) DEFAULT 0.00,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS `inventori` (
        `id` VARCHAR(150) NOT NULL PRIMARY KEY,
        `gudang_id` VARCHAR(50) NOT NULL,
        `sku_id` VARCHAR(100) NOT NULL,
        `nama_produk` VARCHAR(255) NOT NULL,
        `jumlah_ready` INT DEFAULT 0,
        `reorder_level` INT DEFAULT 10,
        `reorder` VARCHAR(10) DEFAULT 'NO',
        `order_date` VARCHAR(50) DEFAULT NULL,
        `warna` VARCHAR(100) DEFAULT NULL,
        `ukuran` VARCHAR(50) DEFAULT NULL,
        `kategori` VARCHAR(100) DEFAULT NULL,
        `jenis_lengan` VARCHAR(50) DEFAULT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY `uk_gudang_sku` (`gudang_id`, `sku_id`),
        KEY `idx_sku` (`sku_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS `pelanggan` (
        `id` VARCHAR(50) NOT NULL PRIMARY KEY,
        `nama` VARCHAR(150) NOT NULL,
        `telepon` VARCHAR(50) DEFAULT NULL,
        `alamat` TEXT DEFAULT NULL,
        `kota` VARCHAR(100) DEFAULT NULL,
        `tipe` VARCHAR(50) DEFAULT 'UMUM',
        `plafon_piutang` DECIMAL(15,2) DEFAULT 0.00,
        `catatan` TEXT DEFAULT NULL,
        `created_at` VARCHAR(50) DEFAULT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS `transaksi_penjualan` (
        `nomor_sale` VARCHAR(50) NOT NULL PRIMARY KEY,
        `tanggal` VARCHAR(50) NOT NULL,
        `gudang_id` VARCHAR(50) NOT NULL,
        `gudang_nama` VARCHAR(100) NOT NULL,
        `username` VARCHAR(100) NOT NULL,
        `pelanggan` VARCHAR(150) NOT NULL,
        `pelanggan_id` VARCHAR(50) DEFAULT NULL,
        `tipe_pelanggan` VARCHAR(50) DEFAULT NULL,
        `kontak` VARCHAR(50) DEFAULT NULL,
        `alamat` TEXT DEFAULT NULL,
        `metode` VARCHAR(50) DEFAULT NULL,
        `catatan` TEXT DEFAULT NULL,
        `subtotal_nominal` DECIMAL(15,2) DEFAULT 0.00,
        `diskon_nominal` DECIMAL(15,2) DEFAULT 0.00,
        `total_nominal` DECIMAL(15,2) DEFAULT 0.00,
        `status_pembayaran` VARCHAR(30) DEFAULT 'LUNAS',
        `jumlah_bayar` DECIMAL(15,2) DEFAULT 0.00,
        `sisa_piutang` DECIMAL(15,2) DEFAULT 0.00,
        `jatuh_tempo` VARCHAR(50) DEFAULT NULL,
        `items_json` LONGTEXT DEFAULT NULL,
        `riwayat_pelunasan_json` LONGTEXT DEFAULT NULL,
        `signature_penjual_json` LONGTEXT DEFAULT NULL,
        `signature_pembeli_json` LONGTEXT DEFAULT NULL,
        `created_at` VARCHAR(50) DEFAULT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS `order_po` (
        `nomor_order` VARCHAR(50) NOT NULL PRIMARY KEY,
        `tanggal` VARCHAR(50) NOT NULL,
        `gudang_id` VARCHAR(50) NOT NULL,
        `gudang_nama` VARCHAR(100) NOT NULL,
        `username` VARCHAR(100) NOT NULL,
        `supplier` VARCHAR(150) NOT NULL,
        `kontak` VARCHAR(50) DEFAULT NULL,
        `alamat` TEXT DEFAULT NULL,
        `metode` VARCHAR(50) DEFAULT NULL,
        `catatan` TEXT DEFAULT NULL,
        `subtotal_nominal` DECIMAL(15,2) DEFAULT 0.00,
        `diskon_nominal` DECIMAL(15,2) DEFAULT 0.00,
        `total_nominal` DECIMAL(15,2) DEFAULT 0.00,
        `status_pembayaran` VARCHAR(30) DEFAULT 'LUNAS',
        `jumlah_bayar` DECIMAL(15,2) DEFAULT 0.00,
        `sisa_piutang` DECIMAL(15,2) DEFAULT 0.00,
        `jatuh_tempo` VARCHAR(50) DEFAULT NULL,
        `tampilkan_nominal` TINYINT(1) DEFAULT 1,
        `items_json` LONGTEXT DEFAULT NULL,
        `signature_admin_json` LONGTEXT DEFAULT NULL,
        `signature_supervisor_json` LONGTEXT DEFAULT NULL,
        `created_at` VARCHAR(50) DEFAULT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS `surat_jalan` (
        `nomor_sj` VARCHAR(50) NOT NULL PRIMARY KEY,
        `tanggal` VARCHAR(50) NOT NULL,
        `gudang_id` VARCHAR(50) NOT NULL,
        `gudang_nama` VARCHAR(100) NOT NULL,
        `username` VARCHAR(100) NOT NULL,
        `tujuan` VARCHAR(150) NOT NULL,
        `penerima` VARCHAR(150) NOT NULL,
        `driver` VARCHAR(150) DEFAULT NULL,
        `kendaraan` VARCHAR(100) DEFAULT NULL,
        `catatan` TEXT DEFAULT NULL,
        `tampilkan_nominal` TINYINT(1) DEFAULT 0,
        `total_nominal` DECIMAL(15,2) DEFAULT 0.00,
        `items_json` LONGTEXT DEFAULT NULL,
        `signature_pengirim_json` LONGTEXT DEFAULT NULL,
        `signature_driver_json` LONGTEXT DEFAULT NULL,
        `signature_penerima_json` LONGTEXT DEFAULT NULL,
        `created_at` VARCHAR(50) DEFAULT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS `log_transaksi` (
        `id` INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
        `timestamp` VARCHAR(50) NOT NULL,
        `transaksi_id` VARCHAR(50) NOT NULL,
        `sku_id` VARCHAR(100) NOT NULL,
        `gudang_id` VARCHAR(50) NOT NULL,
        `jumlah` INT NOT NULL DEFAULT 0,
        `tipe_transaksi` VARCHAR(50) NOT NULL,
        `users` VARCHAR(100) NOT NULL,
        `keterangan` TEXT DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY `idx_tx` (`transaksi_id`),
        KEY `idx_ts` (`timestamp`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS `app_settings` (
        `id` VARCHAR(50) NOT NULL PRIMARY KEY,
        `settings_json` LONGTEXT NOT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS `app_users` (
        `id` VARCHAR(50) NOT NULL PRIMARY KEY,
        `username` VARCHAR(100) NOT NULL,
        `password` VARCHAR(255) NOT NULL,
        `full_name` VARCHAR(150) NOT NULL,
        `role` VARCHAR(50) NOT NULL,
        `site_access` VARCHAR(100) NOT NULL,
        `is_active` TINYINT(1) DEFAULT 1,
        `phone` VARCHAR(50) DEFAULT NULL,
        `email` VARCHAR(100) DEFAULT NULL,
        `created_at` VARCHAR(50) DEFAULT NULL,
        `last_login` VARCHAR(50) DEFAULT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY `uk_username` (`username`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ";

    // Jalankan per statement (sebagian hosting tidak mengizinkan multi-query)
    $isSqlite = defined('DB_DRIVER') && DB_DRIVER === 'sqlite';
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmtSql) {
        if ($stmtSql === '') continue;
        if ($isSqlite) $stmtSql = kp_translate_ddl_sqlite($stmtSql);
        $pdo->exec($stmtSql);
    }
}

/** Ambil seluruh isi seed-data.json (snapshot backup aplikasi) */
function kp_seed_payload()
{
    static $payload = null;
    if ($payload !== null) return $payload;
    if (!defined('SEED_FILE') || !is_file(SEED_FILE)) return null;
    $json = json_decode(file_get_contents(SEED_FILE), true);
    if (!is_array($json) || empty($json['products'])) return null;
    $payload = [
        'products'       => $json['products'] ?? [],
        'warehouses'     => $json['warehouses'] ?? [],
        'inventory'      => $json['inventory'] ?? [],
        'customers'      => $json['customers'] ?? [],
        'sales'          => $json['sales'] ?? [],
        'orders'         => $json['orders'] ?? [],
        'suratJalanList' => $json['suratJalanList'] ?? [],
        'logs'           => $json['logs'] ?? [],
        'users'          => $json['users'] ?? [],
        'settings'       => $json['settings'] ?? null,
    ];
    return $payload;
}

/** Muat seed ke database. $force=true menimpa data yang ada (delta/upsert). */
function kp_load_seed(PDO $pdo, $force = false)
{
    $payload = kp_seed_payload();
    if (!$payload) return 0;
    return kp_import_payload($pdo, $payload);
}

/** Seed otomatis HANYA bila semua tabel masih kosong */
function kp_seed_if_empty(PDO $pdo)
{
    if (!defined('AUTO_SEED') || !AUTO_SEED) return 0;
    try {
        $total = 0;
        foreach (KP_TABLES as $key => $table) {
            $total += (int)$pdo->query('SELECT COUNT(*) FROM `' . $table . '`')->fetchColumn();
        }
        if ($total > 0) return 0;
    } catch (Exception $e) {
        return 0;
    }
    return kp_load_seed($pdo, false);
}

/**
 * Import payload (bentuk data seperti push-all) ke MySQL.
 * Menerima format UPPER_SNAKE (state aplikasi) maupun lowercase (dump SQL lama).
 */
function kp_import_payload(PDO $pdo, array $input)
{
    $count = 0;
    $pdo->beginTransaction();
    try {
        // ---- Produk ----
        if (!empty($input['products']) && is_array($input['products'])) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `master_produk`
                    (sku_id, nama_produk, warna, ukuran, kategori, jenis_lengan, reorder_level, barcode_id, harga_hpp, harga_jual)
                 VALUES (:sku,:nama,:warna,:ukuran,:kat,:jl,:rol,:bc,:hpp,:jual)
                 ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), warna=VALUES(warna), ukuran=VALUES(ukuran), kategori=VALUES(kategori),
                    jenis_lengan=VALUES(jenis_lengan), reorder_level=VALUES(reorder_level), barcode_id=VALUES(barcode_id),
                    harga_hpp=VALUES(harga_hpp), harga_jual=VALUES(harga_jual)'
            ) : 
                'INSERT INTO `master_produk`
                    (sku_id, nama_produk, warna, ukuran, kategori, jenis_lengan, reorder_level, barcode_id, harga_hpp, harga_jual)
                 VALUES (:sku,:nama,:warna,:ukuran,:kat,:jl,:rol,:bc,:hpp,:jual)
                 ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), warna=VALUES(warna), ukuran=VALUES(ukuran), kategori=VALUES(kategori),
                    jenis_lengan=VALUES(jenis_lengan), reorder_level=VALUES(reorder_level), barcode_id=VALUES(barcode_id),
                    harga_hpp=VALUES(harga_hpp), harga_jual=VALUES(harga_jual)'
            );
            foreach ($input['products'] as $p) {
                $sku = kp_str($p, ['SKU_ID', 'sku_id']);
                if ($sku === '') continue;
                $stmt->execute([
                    ':sku'    => $sku,
                    ':nama'   => kp_str($p, ['NAMA_PRODUK', 'nama_produk']),
                    ':warna'  => kp_str($p, ['WARNA', 'warna']),
                    ':ukuran' => kp_str($p, ['UKURAN', 'ukuran']),
                    ':kat'    => kp_str($p, ['KATEGORI', 'kategori']),
                    ':jl'     => kp_str($p, ['JENIS_LENGAN', 'jenis_lengan'], 'PENDEK'),
                    ':rol'    => (int)kp_num($p, ['REORDER_LEVEL', 'reorder_level'], 10),
                    ':bc'     => kp_str($p, ['BARCODE_ID', 'barcode_id']),
                    ':hpp'    => (float)kp_num($p, ['HARGA_HPP', 'harga_hpp']),
                    ':jual'   => (float)kp_num($p, ['HARGA_JUAL', 'harga_jual']),
                ]);
                $count++;
            }
        }

        // ---- Gudang ----
        if (!empty($input['warehouses']) && is_array($input['warehouses'])) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `master_gudang`
                    (gudang_id, nama_gudang, lokasi, penanggung_jawab, is_active, is_default, telepon, keterangan)
                 VALUES (:gid,:nama,:lokasi,:pj,:aktif,:def,:telp,:ket)
                 ON DUPLICATE KEY UPDATE
                    nama_gudang=VALUES(nama_gudang), lokasi=VALUES(lokasi), penanggung_jawab=VALUES(penanggung_jawab),
                    is_active=VALUES(is_active), is_default=VALUES(is_default), telepon=VALUES(telepon), keterangan=VALUES(keterangan)'
            ) : 
                'INSERT INTO `master_gudang`
                    (gudang_id, nama_gudang, lokasi, penanggung_jawab, is_active, is_default, telepon, keterangan)
                 VALUES (:gid,:nama,:lokasi,:pj,:aktif,:def,:telp,:ket)
                 ON DUPLICATE KEY UPDATE
                    nama_gudang=VALUES(nama_gudang), lokasi=VALUES(lokasi), penanggung_jawab=VALUES(penanggung_jawab),
                    is_active=VALUES(is_active), is_default=VALUES(is_default), telepon=VALUES(telepon), keterangan=VALUES(keterangan)'
            );
            foreach ($input['warehouses'] as $w) {
                $gid = kp_str($w, ['GUDANG_ID', 'gudang_id']);
                if ($gid === '') continue;
                $stmt->execute([
                    ':gid'    => $gid,
                    ':nama'   => kp_str($w, ['NAMA_GUDANG', 'nama_gudang']),
                    ':lokasi' => kp_str($w, ['LOKASI', 'lokasi']),
                    ':pj'     => kp_str($w, ['PENANGGUNG_JAWAB', 'penanggung_jawab']),
                    ':aktif'  => kp_bool($w, ['IS_ACTIVE', 'is_active']) ? 1 : 0,
                    ':def'    => kp_bool($w, ['IS_DEFAULT', 'is_default']) ? 1 : 0,
                    ':telp'   => kp_str($w, ['TELEPON', 'telepon']),
                    ':ket'    => kp_str($w, ['KETERANGAN', 'keterangan']),
                ]);
                $count++;
            }
        }

        // ---- Inventori ----
        if (!empty($input['inventory']) && is_array($input['inventory'])) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `inventori`
                    (id, gudang_id, sku_id, nama_produk, jumlah_ready, reorder_level, reorder, order_date, warna, ukuran, kategori, jenis_lengan)
                 VALUES (:id,:gid,:sku,:nama,:qty,:rol,:ro,:od,:warna,:ukuran,:kat,:jl)
                 ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), jumlah_ready=VALUES(jumlah_ready), reorder_level=VALUES(reorder_level),
                    reorder=VALUES(reorder), order_date=VALUES(order_date), warna=VALUES(warna), ukuran=VALUES(ukuran),
                    kategori=VALUES(kategori), jenis_lengan=VALUES(jenis_lengan)'
            ) : 
                'INSERT INTO `inventori`
                    (id, gudang_id, sku_id, nama_produk, jumlah_ready, reorder_level, reorder, order_date, warna, ukuran, kategori, jenis_lengan)
                 VALUES (:id,:gid,:sku,:nama,:qty,:rol,:ro,:od,:warna,:ukuran,:kat,:jl)
                 ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), jumlah_ready=VALUES(jumlah_ready), reorder_level=VALUES(reorder_level),
                    reorder=VALUES(reorder), order_date=VALUES(order_date), warna=VALUES(warna), ukuran=VALUES(ukuran),
                    kategori=VALUES(kategori), jenis_lengan=VALUES(jenis_lengan)'
            );
            foreach ($input['inventory'] as $inv) {
                $gid = kp_str($inv, ['GUDANG_ID', 'gudang_id']);
                $sku = kp_str($inv, ['SKU_ID', 'SKU', 'sku_id']);
                if ($gid === '' || $sku === '') continue;
                $id = kp_str($inv, ['id']);
                if ($id === '') $id = $gid . '_' . $sku;
                $stmt->execute([
                    ':id'     => $id,
                    ':gid'    => $gid,
                    ':sku'    => $sku,
                    ':nama'   => kp_str($inv, ['NAMA_PRODUK', 'nama_produk']),
                    ':qty'    => (int)kp_num($inv, ['JUMLAH_READY', 'jumlah_ready']),
                    ':rol'    => (int)kp_num($inv, ['REORDER_LEVEL', 'reorder_level'], 10),
                    ':ro'     => kp_str($inv, ['REORDER', 'reorder'], 'NO'),
                    ':od'     => kp_str($inv, ['ORDER_DATE', 'order_date']),
                    ':warna'  => kp_str($inv, ['WARNA', 'warna']),
                    ':ukuran' => kp_str($inv, ['UKURAN', 'ukuran']),
                    ':kat'    => kp_str($inv, ['KATEGORI', 'kategori']),
                    ':jl'     => kp_str($inv, ['JENIS_LENGAN', 'jenis_lengan']),
                ]);
                $count++;
            }
        }

        // ---- Pelanggan ----
        if (!empty($input['customers']) && is_array($input['customers'])) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `pelanggan` (id, nama, telepon, alamat, kota, tipe, plafon_piutang, catatan, created_at)
                 VALUES (:id,:nama,:telp,:alamat,:kota,:tipe,:plafon,:catatan,:created)
                 ON DUPLICATE KEY UPDATE
                    nama=VALUES(nama), telepon=VALUES(telepon), alamat=VALUES(alamat), kota=VALUES(kota),
                    tipe=VALUES(tipe), plafon_piutang=VALUES(plafon_piutang), catatan=VALUES(catatan)'
            ) : 
                'INSERT INTO `pelanggan` (id, nama, telepon, alamat, kota, tipe, plafon_piutang, catatan, created_at)
                 VALUES (:id,:nama,:telp,:alamat,:kota,:tipe,:plafon,:catatan,:created)
                 ON DUPLICATE KEY UPDATE
                    nama=VALUES(nama), telepon=VALUES(telepon), alamat=VALUES(alamat), kota=VALUES(kota),
                    tipe=VALUES(tipe), plafon_piutang=VALUES(plafon_piutang), catatan=VALUES(catatan)'
            );
            foreach ($input['customers'] as $c) {
                $cid = kp_str($c, ['id']);
                if ($cid === '') continue;
                $stmt->execute([
                    ':id'      => $cid,
                    ':nama'    => kp_str($c, ['nama']),
                    ':telp'    => kp_str($c, ['telepon']),
                    ':alamat'  => kp_str($c, ['alamat']),
                    ':kota'    => kp_str($c, ['kota']),
                    ':tipe'    => kp_str($c, ['tipe'], 'UMUM'),
                    ':plafon'  => (float)kp_num($c, ['plafonPiutang', 'plafon_piutang']),
                    ':catatan' => kp_str($c, ['catatan']),
                    ':created' => kp_str($c, ['createdAt', 'created_at'], date('Y-m-d H:i:s')),
                ]);
                $count++;
            }
        }

        // ---- Penjualan ----
        if (!empty($input['sales']) && is_array($input['sales'])) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `transaksi_penjualan`
                    (nomor_sale, tanggal, gudang_id, gudang_nama, username, pelanggan, pelanggan_id, tipe_pelanggan,
                     kontak, alamat, metode, catatan, subtotal_nominal, diskon_nominal, total_nominal,
                     status_pembayaran, jumlah_bayar, sisa_piutang, jatuh_tempo, items_json,
                     riwayat_pelunasan_json, signature_penjual_json, signature_pembeli_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17,:a18,:a19,:a20,:a21,:a22,:a23,:a24)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    pelanggan=VALUES(pelanggan), pelanggan_id=VALUES(pelanggan_id), tipe_pelanggan=VALUES(tipe_pelanggan),
                    kontak=VALUES(kontak), alamat=VALUES(alamat), metode=VALUES(metode), catatan=VALUES(catatan),
                    subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal),
                    total_nominal=VALUES(total_nominal), status_pembayaran=VALUES(status_pembayaran),
                    jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang), jatuh_tempo=VALUES(jatuh_tempo),
                    items_json=VALUES(items_json), riwayat_pelunasan_json=VALUES(riwayat_pelunasan_json),
                    signature_penjual_json=VALUES(signature_penjual_json), signature_pembeli_json=VALUES(signature_pembeli_json)'
            ) : 
                'INSERT INTO `transaksi_penjualan`
                    (nomor_sale, tanggal, gudang_id, gudang_nama, username, pelanggan, pelanggan_id, tipe_pelanggan,
                     kontak, alamat, metode, catatan, subtotal_nominal, diskon_nominal, total_nominal,
                     status_pembayaran, jumlah_bayar, sisa_piutang, jatuh_tempo, items_json,
                     riwayat_pelunasan_json, signature_penjual_json, signature_pembeli_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17,:a18,:a19,:a20,:a21,:a22,:a23,:a24)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    pelanggan=VALUES(pelanggan), pelanggan_id=VALUES(pelanggan_id), tipe_pelanggan=VALUES(tipe_pelanggan),
                    kontak=VALUES(kontak), alamat=VALUES(alamat), metode=VALUES(metode), catatan=VALUES(catatan),
                    subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal),
                    total_nominal=VALUES(total_nominal), status_pembayaran=VALUES(status_pembayaran),
                    jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang), jatuh_tempo=VALUES(jatuh_tempo),
                    items_json=VALUES(items_json), riwayat_pelunasan_json=VALUES(riwayat_pelunasan_json),
                    signature_penjual_json=VALUES(signature_penjual_json), signature_pembeli_json=VALUES(signature_pembeli_json)'
            );
            foreach ($input['sales'] as $s) {
                $no = kp_str($s, ['nomorSale', 'nomor_sale']);
                if ($no === '') continue;
                $stmt->execute([
                    ':a1' => $no,
                    ':a2' => kp_str($s, ['tanggal']),
                    ':a3' => kp_str($s, ['gudangId', 'gudang_id']),
                    ':a4' => kp_str($s, ['gudangNama', 'gudang_nama']),
                    ':a5' => kp_str($s, ['username']),
                    ':a6' => kp_str($s, ['pelanggan']),
                    ':a7' => kp_str($s, ['pelangganId', 'pelanggan_id']),
                    ':a8' => kp_str($s, ['tipePelanggan', 'tipe_pelanggan']),
                    ':a9' => kp_str($s, ['kontak']),
                    ':a10'=> kp_str($s, ['alamat']),
                    ':a11'=> kp_str($s, ['metode'], 'TUNAI'),
                    ':a12'=> kp_str($s, ['catatan']),
                    ':a13'=> (float)kp_num($s, ['subtotalNominal', 'subtotal_nominal']),
                    ':a14'=> (float)kp_num($s, ['diskonNominal', 'diskon_nominal']),
                    ':a15'=> (float)kp_num($s, ['totalNominal', 'total_nominal']),
                    ':a16'=> kp_str($s, ['statusPembayaran', 'status_pembayaran'], 'LUNAS'),
                    ':a17'=> (float)kp_num($s, ['jumlahBayar', 'jumlah_bayar']),
                    ':a18'=> (float)kp_num($s, ['sisaPiutang', 'sisa_piutang']),
                    ':a19'=> kp_str($s, ['jatuhTempo', 'jatuh_tempo']),
                    ':a20'=> json_encode($s['items'] ?? [], JSON_UNESCAPED_UNICODE),
                    ':a21'=> json_encode($s['riwayatPelunasan'] ?? ($s['riwayat_pelunasan'] ?? []), JSON_UNESCAPED_UNICODE),
                    ':a22'=> json_encode($s['signaturePenjual'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a23'=> json_encode($s['signaturePembeli'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a24'=> kp_str($s, ['createdAt', 'created_at'], kp_str($s, ['tanggal'])),
                ]);
                $count++;
            }
        }

        // ---- Purchase Order ----
        if (!empty($input['orders']) && is_array($input['orders'])) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `order_po`
                    (nomor_order, tanggal, gudang_id, gudang_nama, username, supplier, kontak, alamat, metode, catatan,
                     subtotal_nominal, diskon_nominal, total_nominal, status_pembayaran, jumlah_bayar, sisa_piutang,
                     jatuh_tempo, tampilkan_nominal, items_json, signature_admin_json, signature_supervisor_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17,:a18,:a19,:a20,:a21,:a22)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    supplier=VALUES(supplier), kontak=VALUES(kontak), alamat=VALUES(alamat), metode=VALUES(metode),
                    catatan=VALUES(catatan), subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal),
                    total_nominal=VALUES(total_nominal), status_pembayaran=VALUES(status_pembayaran),
                    jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang), jatuh_tempo=VALUES(jatuh_tempo),
                    tampilkan_nominal=VALUES(tampilkan_nominal), items_json=VALUES(items_json),
                    signature_admin_json=VALUES(signature_admin_json), signature_supervisor_json=VALUES(signature_supervisor_json)'
            ) : 
                'INSERT INTO `order_po`
                    (nomor_order, tanggal, gudang_id, gudang_nama, username, supplier, kontak, alamat, metode, catatan,
                     subtotal_nominal, diskon_nominal, total_nominal, status_pembayaran, jumlah_bayar, sisa_piutang,
                     jatuh_tempo, tampilkan_nominal, items_json, signature_admin_json, signature_supervisor_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17,:a18,:a19,:a20,:a21,:a22)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    supplier=VALUES(supplier), kontak=VALUES(kontak), alamat=VALUES(alamat), metode=VALUES(metode),
                    catatan=VALUES(catatan), subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal),
                    total_nominal=VALUES(total_nominal), status_pembayaran=VALUES(status_pembayaran),
                    jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang), jatuh_tempo=VALUES(jatuh_tempo),
                    tampilkan_nominal=VALUES(tampilkan_nominal), items_json=VALUES(items_json),
                    signature_admin_json=VALUES(signature_admin_json), signature_supervisor_json=VALUES(signature_supervisor_json)'
            );
            foreach ($input['orders'] as $o) {
                $no = kp_str($o, ['nomorOrder', 'nomor_order']);
                if ($no === '') continue;
                $stmt->execute([
                    ':a1' => $no,
                    ':a2' => kp_str($o, ['tanggal']),
                    ':a3' => kp_str($o, ['gudangId', 'gudang_id']),
                    ':a4' => kp_str($o, ['gudangNama', 'gudang_nama']),
                    ':a5' => kp_str($o, ['username']),
                    ':a6' => kp_str($o, ['supplier']),
                    ':a7' => kp_str($o, ['kontak']),
                    ':a8' => kp_str($o, ['alamat']),
                    ':a9' => kp_str($o, ['metode']),
                    ':a10'=> kp_str($o, ['catatan']),
                    ':a11'=> (float)kp_num($o, ['subtotalNominal', 'subtotal_nominal']),
                    ':a12'=> (float)kp_num($o, ['diskonNominal', 'diskon_nominal']),
                    ':a13'=> (float)kp_num($o, ['totalNominal', 'total_nominal']),
                    ':a14'=> kp_str($o, ['statusPembayaran', 'status_pembayaran'], 'LUNAS'),
                    ':a15'=> (float)kp_num($o, ['jumlahBayar', 'jumlah_bayar']),
                    ':a16'=> (float)kp_num($o, ['sisaPiutang', 'sisa_piutang']),
                    ':a17'=> kp_str($o, ['jatuhTempo', 'jatuh_tempo']),
                    ':a18'=> kp_bool($o, ['tampilkanNominal', 'tampilkan_nominal'], true) ? 1 : 0,
                    ':a19'=> json_encode($o['items'] ?? [], JSON_UNESCAPED_UNICODE),
                    ':a20'=> json_encode($o['signatureAdmin'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a21'=> json_encode($o['signatureSupervisor'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a22'=> kp_str($o, ['createdAt', 'created_at'], kp_str($o, ['tanggal'])),
                ]);
                $count++;
            }
        }

        // ---- Surat Jalan ----
        if (!empty($input['suratJalanList']) && is_array($input['suratJalanList'])) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `surat_jalan`
                    (nomor_sj, tanggal, gudang_id, gudang_nama, username, tujuan, penerima, driver, kendaraan, catatan,
                     tampilkan_nominal, total_nominal, items_json, signature_pengirim_json, signature_driver_json,
                     signature_penerima_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    tujuan=VALUES(tujuan), penerima=VALUES(penerima), driver=VALUES(driver), kendaraan=VALUES(kendaraan),
                    catatan=VALUES(catatan), tampilkan_nominal=VALUES(tampilkan_nominal), total_nominal=VALUES(total_nominal),
                    items_json=VALUES(items_json), signature_pengirim_json=VALUES(signature_pengirim_json),
                    signature_driver_json=VALUES(signature_driver_json), signature_penerima_json=VALUES(signature_penerima_json)'
            ) : 
                'INSERT INTO `surat_jalan`
                    (nomor_sj, tanggal, gudang_id, gudang_nama, username, tujuan, penerima, driver, kendaraan, catatan,
                     tampilkan_nominal, total_nominal, items_json, signature_pengirim_json, signature_driver_json,
                     signature_penerima_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    tujuan=VALUES(tujuan), penerima=VALUES(penerima), driver=VALUES(driver), kendaraan=VALUES(kendaraan),
                    catatan=VALUES(catatan), tampilkan_nominal=VALUES(tampilkan_nominal), total_nominal=VALUES(total_nominal),
                    items_json=VALUES(items_json), signature_pengirim_json=VALUES(signature_pengirim_json),
                    signature_driver_json=VALUES(signature_driver_json), signature_penerima_json=VALUES(signature_penerima_json)'
            );
            foreach ($input['suratJalanList'] as $sj) {
                $no = kp_str($sj, ['nomorSJ', 'nomor_sj']);
                if ($no === '') continue;
                $stmt->execute([
                    ':a1' => $no,
                    ':a2' => kp_str($sj, ['tanggal']),
                    ':a3' => kp_str($sj, ['gudangId', 'gudang_id']),
                    ':a4' => kp_str($sj, ['gudangNama', 'gudang_nama']),
                    ':a5' => kp_str($sj, ['username']),
                    ':a6' => kp_str($sj, ['tujuan']),
                    ':a7' => kp_str($sj, ['penerima']),
                    ':a8' => kp_str($sj, ['driver']),
                    ':a9' => kp_str($sj, ['kendaraan']),
                    ':a10'=> kp_str($sj, ['catatan']),
                    ':a11'=> kp_bool($sj, ['tampilkanNominal', 'tampilkan_nominal'], false) ? 1 : 0,
                    ':a12'=> (float)kp_num($sj, ['totalNominal', 'total_nominal']),
                    ':a13'=> json_encode($sj['items'] ?? [], JSON_UNESCAPED_UNICODE),
                    ':a14'=> json_encode($sj['signaturePengirim'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a15'=> json_encode($sj['signatureDriver'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a16'=> json_encode($sj['signaturePenerima'] ?? null, JSON_UNESCAPED_UNICODE),
                    ':a17'=> kp_str($sj, ['createdAt', 'created_at'], kp_str($sj, ['tanggal'])),
                ]);
                $count++;
            }
        }

        // ---- Logs (hindari duplikat) ----
        if (!empty($input['logs']) && is_array($input['logs'])) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `log_transaksi`
                    (timestamp, transaksi_id, sku_id, gudang_id, jumlah, tipe_transaksi, users, keterangan)
                 VALUES (:ts,:tid,:sku,:gid,:jml,:tipe,:usr,:ket)'
            ) : 
                'INSERT INTO `log_transaksi`
                    (timestamp, transaksi_id, sku_id, gudang_id, jumlah, tipe_transaksi, users, keterangan)
                 VALUES (:ts,:tid,:sku,:gid,:jml,:tipe,:usr,:ket)'
            );
            $exists = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'SELECT 1 FROM `log_transaksi` WHERE timestamp=? AND transaksi_id=? AND sku_id=? AND tipe_transaksi=? LIMIT 1'
            ) : 
                'SELECT 1 FROM `log_transaksi` WHERE timestamp=? AND transaksi_id=? AND sku_id=? AND tipe_transaksi=? LIMIT 1'
            );
            foreach ($input['logs'] as $l) {
                $ts  = kp_str($l, ['TIMESTAMP', 'timestamp']);
                $tid = kp_str($l, ['TRANSAKSI_ID', 'transaksi_id']);
                if ($ts === '' || $tid === '') continue;
                $tipe = kp_str($l, ['TIPE_TRANSAKSI', 'tipe_transaksi']);
                $exists->execute([$ts, $tid, kp_str($l, ['SKU_ID', 'sku_id']), $tipe]);
                if ($exists->fetch()) continue;
                $stmt->execute([
                    ':ts'   => $ts,
                    ':tid'  => $tid,
                    ':sku'  => kp_str($l, ['SKU_ID', 'sku_id']),
                    ':gid'  => kp_str($l, ['GUDANG_ID', 'gudang_id']),
                    ':jml'  => (int)kp_num($l, ['JUMLAH', 'jumlah']),
                    ':tipe' => $tipe,
                    ':usr'  => kp_str($l, ['USERS', 'users']),
                    ':ket'  => kp_str($l, ['KETERANGAN', 'keterangan']),
                ]);
                $count++;
            }
        }

        // ---- Users ----
        if (!empty($input['users']) && is_array($input['users'])) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `app_users`
                    (id, username, password, full_name, role, site_access, is_active, phone, email, created_at, last_login)
                 VALUES (:id,:usr,:pass,:nama,:role,:site,:aktif,:phone,:email,:created,:lastlogin)
                 ON DUPLICATE KEY UPDATE
                    password=VALUES(password), full_name=VALUES(full_name), role=VALUES(role), site_access=VALUES(site_access),
                    is_active=VALUES(is_active), phone=VALUES(phone), email=VALUES(email), last_login=VALUES(last_login)'
            ) : 
                'INSERT INTO `app_users`
                    (id, username, password, full_name, role, site_access, is_active, phone, email, created_at, last_login)
                 VALUES (:id,:usr,:pass,:nama,:role,:site,:aktif,:phone,:email,:created,:lastlogin)
                 ON DUPLICATE KEY UPDATE
                    password=VALUES(password), full_name=VALUES(full_name), role=VALUES(role), site_access=VALUES(site_access),
                    is_active=VALUES(is_active), phone=VALUES(phone), email=VALUES(email), last_login=VALUES(last_login)'
            );
            foreach ($input['users'] as $u) {
                $uid = kp_str($u, ['id']);
                $uname = kp_str($u, ['username']);
                if ($uid === '' || $uname === '') continue;
                $stmt->execute([
                    ':id'        => $uid,
                    ':usr'       => $uname,
                    ':pass'      => kp_str($u, ['password']),
                    ':nama'      => kp_str($u, ['fullName', 'full_name']),
                    ':role'      => kp_str($u, ['role'], 'STAF'),
                    ':site'      => kp_str($u, ['siteAccess', 'site_access'], 'GUDANG UTAMA'),
                    ':aktif'     => kp_bool($u, ['isActive', 'is_active'], true) ? 1 : 0,
                    ':phone'     => kp_str($u, ['phone']),
                    ':email'     => kp_str($u, ['email']),
                    ':created'   => kp_str($u, ['createdAt', 'created_at'], date('Y-m-d H:i:s')),
                    ':lastlogin' => kp_str($u, ['lastLogin', 'last_login']),
                ]);
                $count++;
            }
        }

        // ---- Settings ----
        if (isset($input['settings']) && is_array($input['settings']) && $input['settings']) {
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `app_settings` (id, settings_json) VALUES (:id,:json)
                 ON DUPLICATE KEY UPDATE settings_json=VALUES(settings_json)'
            ) : 
                'INSERT INTO `app_settings` (id, settings_json) VALUES (:id,:json)
                 ON DUPLICATE KEY UPDATE settings_json=VALUES(settings_json)'
            );
            $stmt->execute([':id' => 'default', ':json' => json_encode($input['settings'], JSON_UNESCAPED_UNICODE)]);
            $count++;
        }

        $pdo->commit();
        return $count;
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// ---------------- helper akses data ----------------
function kp_str($row, $keys, $default = '')
{
    foreach ((array)$keys as $k) {
        if (isset($row[$k]) && $row[$k] !== null && $row[$k] !== '') {
            return is_scalar($row[$k]) ? (string)$row[$k] : $default;
        }
    }
    return $default;
}

function kp_num($row, $keys, $default = 0)
{
    foreach ((array)$keys as $k) {
        if (isset($row[$k]) && is_numeric($row[$k])) return $row[$k] + 0;
    }
    return $default;
}

function kp_bool($row, $keys, $default = false)
{
    foreach ((array)$keys as $k) {
        if (array_key_exists($k, $row) && $row[$k] !== null) {
            return filter_var($row[$k], FILTER_VALIDATE_BOOLEAN, ['NULL_ON_FAILURE' => true]) ?? $default;
        }
    }
    return $default;
}

// =============================================================
// SYNC ITEM REALTIME (dipanggil api.php action=sync-item)
// Meniru perilaku /api/db/sync-item pada server.ts versi Node
// =============================================================
function kp_sync_item(PDO $pdo, $action, $key, array $data)
{
    switch ($action) {
        case 'saveProduct':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `master_produk`
                    (sku_id, nama_produk, warna, ukuran, kategori, jenis_lengan, reorder_level, barcode_id, harga_hpp, harga_jual)
                 VALUES (:sku,:nama,:warna,:ukuran,:kat,:jl,:rol,:bc,:hpp,:jual)
                 ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), warna=VALUES(warna), ukuran=VALUES(ukuran), kategori=VALUES(kategori),
                    jenis_lengan=VALUES(jenis_lengan), reorder_level=VALUES(reorder_level), barcode_id=VALUES(barcode_id),
                    harga_hpp=VALUES(harga_hpp), harga_jual=VALUES(harga_jual)'
            ) : 
                'INSERT INTO `master_produk`
                    (sku_id, nama_produk, warna, ukuran, kategori, jenis_lengan, reorder_level, barcode_id, harga_hpp, harga_jual)
                 VALUES (:sku,:nama,:warna,:ukuran,:kat,:jl,:rol,:bc,:hpp,:jual)
                 ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), warna=VALUES(warna), ukuran=VALUES(ukuran), kategori=VALUES(kategori),
                    jenis_lengan=VALUES(jenis_lengan), reorder_level=VALUES(reorder_level), barcode_id=VALUES(barcode_id),
                    harga_hpp=VALUES(harga_hpp), harga_jual=VALUES(harga_jual)'
            )->execute([
                ':sku'    => kp_str($data, ['SKU_ID', 'sku_id'], $key),
                ':nama'   => kp_str($data, ['NAMA_PRODUK', 'nama_produk']),
                ':warna'  => kp_str($data, ['WARNA', 'warna']),
                ':ukuran' => kp_str($data, ['UKURAN', 'ukuran']),
                ':kat'    => kp_str($data, ['KATEGORI', 'kategori']),
                ':jl'     => kp_str($data, ['JENIS_LENGAN', 'jenis_lengan'], 'PENDEK'),
                ':rol'    => (int)kp_num($data, ['REORDER_LEVEL', 'reorder_level'], 10),
                ':bc'     => kp_str($data, ['BARCODE_ID', 'barcode_id']),
                ':hpp'    => (float)kp_num($data, ['HARGA_HPP', 'harga_hpp']),
                ':jual'   => (float)kp_num($data, ['HARGA_JUAL', 'harga_jual']),
            ]);
            break;

        case 'deleteProduct':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite('DELETE FROM `master_produk` WHERE sku_id = ?') : 'DELETE FROM `master_produk` WHERE sku_id = ?')->execute([$key]);
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite('DELETE FROM `inventori` WHERE sku_id = ?') : 'DELETE FROM `inventori` WHERE sku_id = ?')->execute([$key]);
            break;

        case 'saveInventoryItem':
            $gid = kp_str($data, ['GUDANG_ID', 'gudang_id']);
            $sku = kp_str($data, ['SKU_ID', 'SKU', 'sku_id']);
            $id  = kp_str($data, ['id']);
            if ($id === '') $id = $gid . '_' . $sku;
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `inventori`
                    (id, gudang_id, sku_id, nama_produk, jumlah_ready, reorder_level, reorder, order_date, warna, ukuran, kategori, jenis_lengan)
                 VALUES (:id,:gid,:sku,:nama,:qty,:rol,:ro,:od,:warna,:ukuran,:kat,:jl)
                 ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), jumlah_ready=VALUES(jumlah_ready), reorder_level=VALUES(reorder_level),
                    reorder=VALUES(reorder), order_date=VALUES(order_date), warna=VALUES(warna), ukuran=VALUES(ukuran),
                    kategori=VALUES(kategori), jenis_lengan=VALUES(jenis_lengan)'
            ) : 
                'INSERT INTO `inventori`
                    (id, gudang_id, sku_id, nama_produk, jumlah_ready, reorder_level, reorder, order_date, warna, ukuran, kategori, jenis_lengan)
                 VALUES (:id,:gid,:sku,:nama,:qty,:rol,:ro,:od,:warna,:ukuran,:kat,:jl)
                 ON DUPLICATE KEY UPDATE
                    nama_produk=VALUES(nama_produk), jumlah_ready=VALUES(jumlah_ready), reorder_level=VALUES(reorder_level),
                    reorder=VALUES(reorder), order_date=VALUES(order_date), warna=VALUES(warna), ukuran=VALUES(ukuran),
                    kategori=VALUES(kategori), jenis_lengan=VALUES(jenis_lengan)'
            )->execute([
                ':id'     => $id,
                ':gid'    => $gid,
                ':sku'    => $sku,
                ':nama'   => kp_str($data, ['NAMA_PRODUK', 'nama_produk']),
                ':qty'    => (int)kp_num($data, ['JUMLAH_READY', 'jumlah_ready']),
                ':rol'    => (int)kp_num($data, ['REORDER_LEVEL', 'reorder_level'], 10),
                ':ro'     => kp_str($data, ['REORDER', 'reorder'], 'NO'),
                ':od'     => kp_str($data, ['ORDER_DATE', 'order_date']),
                ':warna'  => kp_str($data, ['WARNA', 'warna']),
                ':ukuran' => kp_str($data, ['UKURAN', 'ukuran']),
                ':kat'    => kp_str($data, ['KATEGORI', 'kategori']),
                ':jl'     => kp_str($data, ['JENIS_LENGAN', 'jenis_lengan']),
            ]);
            break;

        case 'deleteInventoryItem':
            // key bisa berupa id atau "GUDANG|SKU"
            if (strpos($key, '|') !== false) {
                list($g, $s) = explode('|', $key, 2);
                $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite('DELETE FROM `inventori` WHERE gudang_id = ? AND sku_id = ?') : 'DELETE FROM `inventori` WHERE gudang_id = ? AND sku_id = ?')->execute([$g, $s]);
            } else {
                $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite('DELETE FROM `inventori` WHERE id = ? OR CONCAT(gudang_id, \'_\', sku_id) = ?') : 'DELETE FROM `inventori` WHERE id = ? OR CONCAT(gudang_id, \'_\', sku_id) = ?')->execute([$key, $key]);
            }
            break;

        case 'saveSale':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `transaksi_penjualan`
                    (nomor_sale, tanggal, gudang_id, gudang_nama, username, pelanggan, pelanggan_id, tipe_pelanggan,
                     kontak, alamat, metode, catatan, subtotal_nominal, diskon_nominal, total_nominal,
                     status_pembayaran, jumlah_bayar, sisa_piutang, jatuh_tempo, items_json,
                     riwayat_pelunasan_json, signature_penjual_json, signature_pembeli_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17,:a18,:a19,:a20,:a21,:a22,:a23,:a24)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    pelanggan=VALUES(pelanggan), pelanggan_id=VALUES(pelanggan_id), tipe_pelanggan=VALUES(tipe_pelanggan),
                    kontak=VALUES(kontak), alamat=VALUES(alamat), metode=VALUES(metode), catatan=VALUES(catatan),
                    subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal),
                    total_nominal=VALUES(total_nominal), status_pembayaran=VALUES(status_pembayaran),
                    jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang), jatuh_tempo=VALUES(jatuh_tempo),
                    items_json=VALUES(items_json), riwayat_pelunasan_json=VALUES(riwayat_pelunasan_json),
                    signature_penjual_json=VALUES(signature_penjual_json), signature_pembeli_json=VALUES(signature_pembeli_json)'
            ) : 
                'INSERT INTO `transaksi_penjualan`
                    (nomor_sale, tanggal, gudang_id, gudang_nama, username, pelanggan, pelanggan_id, tipe_pelanggan,
                     kontak, alamat, metode, catatan, subtotal_nominal, diskon_nominal, total_nominal,
                     status_pembayaran, jumlah_bayar, sisa_piutang, jatuh_tempo, items_json,
                     riwayat_pelunasan_json, signature_penjual_json, signature_pembeli_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17,:a18,:a19,:a20,:a21,:a22,:a23,:a24)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    pelanggan=VALUES(pelanggan), pelanggan_id=VALUES(pelanggan_id), tipe_pelanggan=VALUES(tipe_pelanggan),
                    kontak=VALUES(kontak), alamat=VALUES(alamat), metode=VALUES(metode), catatan=VALUES(catatan),
                    subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal),
                    total_nominal=VALUES(total_nominal), status_pembayaran=VALUES(status_pembayaran),
                    jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang), jatuh_tempo=VALUES(jatuh_tempo),
                    items_json=VALUES(items_json), riwayat_pelunasan_json=VALUES(riwayat_pelunasan_json),
                    signature_penjual_json=VALUES(signature_penjual_json), signature_pembeli_json=VALUES(signature_pembeli_json)'
            )->execute([
                ':a1' => kp_str($data, ['nomorSale', 'nomor_sale'], $key),
                ':a2' => kp_str($data, ['tanggal']),
                ':a3' => kp_str($data, ['gudangId', 'gudang_id']),
                ':a4' => kp_str($data, ['gudangNama', 'gudang_nama']),
                ':a5' => kp_str($data, ['username']),
                ':a6' => kp_str($data, ['pelanggan']),
                ':a7' => kp_str($data, ['pelangganId', 'pelanggan_id']),
                ':a8' => kp_str($data, ['tipePelanggan', 'tipe_pelanggan']),
                ':a9' => kp_str($data, ['kontak']),
                ':a10'=> kp_str($data, ['alamat']),
                ':a11'=> kp_str($data, ['metode'], 'TUNAI'),
                ':a12'=> kp_str($data, ['catatan']),
                ':a13'=> (float)kp_num($data, ['subtotalNominal', 'subtotal_nominal']),
                ':a14'=> (float)kp_num($data, ['diskonNominal', 'diskon_nominal']),
                ':a15'=> (float)kp_num($data, ['totalNominal', 'total_nominal']),
                ':a16'=> kp_str($data, ['statusPembayaran', 'status_pembayaran'], 'LUNAS'),
                ':a17'=> (float)kp_num($data, ['jumlahBayar', 'jumlah_bayar']),
                ':a18'=> (float)kp_num($data, ['sisaPiutang', 'sisa_piutang']),
                ':a19'=> kp_str($data, ['jatuhTempo', 'jatuh_tempo']),
                ':a20'=> json_encode($data['items'] ?? [], JSON_UNESCAPED_UNICODE),
                ':a21'=> json_encode($data['riwayatPelunasan'] ?? ($data['riwayat_pelunasan'] ?? []), JSON_UNESCAPED_UNICODE),
                ':a22'=> json_encode($data['signaturePenjual'] ?? null, JSON_UNESCAPED_UNICODE),
                ':a23'=> json_encode($data['signaturePembeli'] ?? null, JSON_UNESCAPED_UNICODE),
                ':a24'=> kp_str($data, ['createdAt', 'created_at'], kp_str($data, ['tanggal'])),
            ]);
            break;

        case 'deleteSale':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite('DELETE FROM `transaksi_penjualan` WHERE nomor_sale = ?') : 'DELETE FROM `transaksi_penjualan` WHERE nomor_sale = ?')->execute([$key]);
            break;

        case 'saveOrder':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `order_po`
                    (nomor_order, tanggal, gudang_id, gudang_nama, username, supplier, kontak, alamat, metode, catatan,
                     subtotal_nominal, diskon_nominal, total_nominal, status_pembayaran, jumlah_bayar, sisa_piutang,
                     jatuh_tempo, tampilkan_nominal, items_json, signature_admin_json, signature_supervisor_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17,:a18,:a19,:a20,:a21,:a22)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    supplier=VALUES(supplier), kontak=VALUES(kontak), alamat=VALUES(alamat), metode=VALUES(metode),
                    catatan=VALUES(catatan), subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal),
                    total_nominal=VALUES(total_nominal), status_pembayaran=VALUES(status_pembayaran),
                    jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang), jatuh_tempo=VALUES(jatuh_tempo),
                    tampilkan_nominal=VALUES(tampilkan_nominal), items_json=VALUES(items_json),
                    signature_admin_json=VALUES(signature_admin_json), signature_supervisor_json=VALUES(signature_supervisor_json)'
            ) : 
                'INSERT INTO `order_po`
                    (nomor_order, tanggal, gudang_id, gudang_nama, username, supplier, kontak, alamat, metode, catatan,
                     subtotal_nominal, diskon_nominal, total_nominal, status_pembayaran, jumlah_bayar, sisa_piutang,
                     jatuh_tempo, tampilkan_nominal, items_json, signature_admin_json, signature_supervisor_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17,:a18,:a19,:a20,:a21,:a22)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    supplier=VALUES(supplier), kontak=VALUES(kontak), alamat=VALUES(alamat), metode=VALUES(metode),
                    catatan=VALUES(catatan), subtotal_nominal=VALUES(subtotal_nominal), diskon_nominal=VALUES(diskon_nominal),
                    total_nominal=VALUES(total_nominal), status_pembayaran=VALUES(status_pembayaran),
                    jumlah_bayar=VALUES(jumlah_bayar), sisa_piutang=VALUES(sisa_piutang), jatuh_tempo=VALUES(jatuh_tempo),
                    tampilkan_nominal=VALUES(tampilkan_nominal), items_json=VALUES(items_json),
                    signature_admin_json=VALUES(signature_admin_json), signature_supervisor_json=VALUES(signature_supervisor_json)'
            )->execute([
                ':a1' => kp_str($data, ['nomorOrder', 'nomor_order'], $key),
                ':a2' => kp_str($data, ['tanggal']),
                ':a3' => kp_str($data, ['gudangId', 'gudang_id']),
                ':a4' => kp_str($data, ['gudangNama', 'gudang_nama']),
                ':a5' => kp_str($data, ['username']),
                ':a6' => kp_str($data, ['supplier']),
                ':a7' => kp_str($data, ['kontak']),
                ':a8' => kp_str($data, ['alamat']),
                ':a9' => kp_str($data, ['metode']),
                ':a10'=> kp_str($data, ['catatan']),
                ':a11'=> (float)kp_num($data, ['subtotalNominal', 'subtotal_nominal']),
                ':a12'=> (float)kp_num($data, ['diskonNominal', 'diskon_nominal']),
                ':a13'=> (float)kp_num($data, ['totalNominal', 'total_nominal']),
                ':a14'=> kp_str($data, ['statusPembayaran', 'status_pembayaran'], 'LUNAS'),
                ':a15'=> (float)kp_num($data, ['jumlahBayar', 'jumlah_bayar']),
                ':a16'=> (float)kp_num($data, ['sisaPiutang', 'sisa_piutang']),
                ':a17'=> kp_str($data, ['jatuhTempo', 'jatuh_tempo']),
                ':a18'=> kp_bool($data, ['tampilkanNominal', 'tampilkan_nominal'], true) ? 1 : 0,
                ':a19'=> json_encode($data['items'] ?? [], JSON_UNESCAPED_UNICODE),
                ':a20'=> json_encode($data['signatureAdmin'] ?? null, JSON_UNESCAPED_UNICODE),
                ':a21'=> json_encode($data['signatureSupervisor'] ?? null, JSON_UNESCAPED_UNICODE),
                ':a22'=> kp_str($data, ['createdAt', 'created_at'], kp_str($data, ['tanggal'])),
            ]);
            break;

        case 'deleteOrder':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite('DELETE FROM `order_po` WHERE nomor_order = ?') : 'DELETE FROM `order_po` WHERE nomor_order = ?')->execute([$key]);
            break;

        case 'saveSuratJalan':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `surat_jalan`
                    (nomor_sj, tanggal, gudang_id, gudang_nama, username, tujuan, penerima, driver, kendaraan, catatan,
                     tampilkan_nominal, total_nominal, items_json, signature_pengirim_json, signature_driver_json,
                     signature_penerima_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    tujuan=VALUES(tujuan), penerima=VALUES(penerima), driver=VALUES(driver), kendaraan=VALUES(kendaraan),
                    catatan=VALUES(catatan), tampilkan_nominal=VALUES(tampilkan_nominal), total_nominal=VALUES(total_nominal),
                    items_json=VALUES(items_json), signature_pengirim_json=VALUES(signature_pengirim_json),
                    signature_driver_json=VALUES(signature_driver_json), signature_penerima_json=VALUES(signature_penerima_json)'
            ) : 
                'INSERT INTO `surat_jalan`
                    (nomor_sj, tanggal, gudang_id, gudang_nama, username, tujuan, penerima, driver, kendaraan, catatan,
                     tampilkan_nominal, total_nominal, items_json, signature_pengirim_json, signature_driver_json,
                     signature_penerima_json, created_at)
                 VALUES (:a1,:a2,:a3,:a4,:a5,:a6,:a7,:a8,:a9,:a10,:a11,:a12,:a13,:a14,:a15,:a16,:a17)
                 ON DUPLICATE KEY UPDATE
                    tanggal=VALUES(tanggal), gudang_id=VALUES(gudang_id), gudang_nama=VALUES(gudang_nama),
                    tujuan=VALUES(tujuan), penerima=VALUES(penerima), driver=VALUES(driver), kendaraan=VALUES(kendaraan),
                    catatan=VALUES(catatan), tampilkan_nominal=VALUES(tampilkan_nominal), total_nominal=VALUES(total_nominal),
                    items_json=VALUES(items_json), signature_pengirim_json=VALUES(signature_pengirim_json),
                    signature_driver_json=VALUES(signature_driver_json), signature_penerima_json=VALUES(signature_penerima_json)'
            )->execute([
                ':a1' => kp_str($data, ['nomorSJ', 'nomor_sj'], $key),
                ':a2' => kp_str($data, ['tanggal']),
                ':a3' => kp_str($data, ['gudangId', 'gudang_id']),
                ':a4' => kp_str($data, ['gudangNama', 'gudang_nama']),
                ':a5' => kp_str($data, ['username']),
                ':a6' => kp_str($data, ['tujuan']),
                ':a7' => kp_str($data, ['penerima']),
                ':a8' => kp_str($data, ['driver']),
                ':a9' => kp_str($data, ['kendaraan']),
                ':a10'=> kp_str($data, ['catatan']),
                ':a11'=> kp_bool($data, ['tampilkanNominal', 'tampilkan_nominal'], false) ? 1 : 0,
                ':a12'=> (float)kp_num($data, ['totalNominal', 'total_nominal']),
                ':a13'=> json_encode($data['items'] ?? [], JSON_UNESCAPED_UNICODE),
                ':a14'=> json_encode($data['signaturePengirim'] ?? null, JSON_UNESCAPED_UNICODE),
                ':a15'=> json_encode($data['signatureDriver'] ?? null, JSON_UNESCAPED_UNICODE),
                ':a16'=> json_encode($data['signaturePenerima'] ?? null, JSON_UNESCAPED_UNICODE),
                ':a17'=> kp_str($data, ['createdAt', 'created_at'], kp_str($data, ['tanggal'])),
            ]);
            break;

        case 'deleteSuratJalan':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite('DELETE FROM `surat_jalan` WHERE nomor_sj = ?') : 'DELETE FROM `surat_jalan` WHERE nomor_sj = ?')->execute([$key]);
            break;

        case 'saveCustomer':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `pelanggan` (id, nama, telepon, alamat, kota, tipe, plafon_piutang, catatan, created_at)
                 VALUES (:id,:nama,:telp,:alamat,:kota,:tipe,:plafon,:catatan,:created)
                 ON DUPLICATE KEY UPDATE
                    nama=VALUES(nama), telepon=VALUES(telepon), alamat=VALUES(alamat), kota=VALUES(kota),
                    tipe=VALUES(tipe), plafon_piutang=VALUES(plafon_piutang), catatan=VALUES(catatan)'
            ) : 
                'INSERT INTO `pelanggan` (id, nama, telepon, alamat, kota, tipe, plafon_piutang, catatan, created_at)
                 VALUES (:id,:nama,:telp,:alamat,:kota,:tipe,:plafon,:catatan,:created)
                 ON DUPLICATE KEY UPDATE
                    nama=VALUES(nama), telepon=VALUES(telepon), alamat=VALUES(alamat), kota=VALUES(kota),
                    tipe=VALUES(tipe), plafon_piutang=VALUES(plafon_piutang), catatan=VALUES(catatan)'
            )->execute([
                ':id'      => kp_str($data, ['id'], $key),
                ':nama'    => kp_str($data, ['nama']),
                ':telp'    => kp_str($data, ['telepon']),
                ':alamat'  => kp_str($data, ['alamat']),
                ':kota'    => kp_str($data, ['kota']),
                ':tipe'    => kp_str($data, ['tipe'], 'UMUM'),
                ':plafon'  => (float)kp_num($data, ['plafonPiutang', 'plafon_piutang']),
                ':catatan' => kp_str($data, ['catatan']),
                ':created' => kp_str($data, ['createdAt', 'created_at'], date('Y-m-d H:i:s')),
            ]);
            break;

        case 'deleteCustomer':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite('DELETE FROM `pelanggan` WHERE id = ?') : 'DELETE FROM `pelanggan` WHERE id = ?')->execute([$key]);
            break;

        case 'saveWarehouse':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `master_gudang`
                    (gudang_id, nama_gudang, lokasi, penanggung_jawab, is_active, is_default, telepon, keterangan)
                 VALUES (:gid,:nama,:lokasi,:pj,:aktif,:def,:telp,:ket)
                 ON DUPLICATE KEY UPDATE
                    nama_gudang=VALUES(nama_gudang), lokasi=VALUES(lokasi), penanggung_jawab=VALUES(penanggung_jawab),
                    is_active=VALUES(is_active), is_default=VALUES(is_default), telepon=VALUES(telepon), keterangan=VALUES(keterangan)'
            ) : 
                'INSERT INTO `master_gudang`
                    (gudang_id, nama_gudang, lokasi, penanggung_jawab, is_active, is_default, telepon, keterangan)
                 VALUES (:gid,:nama,:lokasi,:pj,:aktif,:def,:telp,:ket)
                 ON DUPLICATE KEY UPDATE
                    nama_gudang=VALUES(nama_gudang), lokasi=VALUES(lokasi), penanggung_jawab=VALUES(penanggung_jawab),
                    is_active=VALUES(is_active), is_default=VALUES(is_default), telepon=VALUES(telepon), keterangan=VALUES(keterangan)'
            )->execute([
                ':gid'    => kp_str($data, ['GUDANG_ID', 'gudang_id'], $key),
                ':nama'   => kp_str($data, ['NAMA_GUDANG', 'nama_gudang']),
                ':lokasi' => kp_str($data, ['LOKASI', 'lokasi']),
                ':pj'     => kp_str($data, ['PENANGGUNG_JAWAB', 'penanggung_jawab']),
                ':aktif'  => kp_bool($data, ['IS_ACTIVE', 'is_active'], true) ? 1 : 0,
                ':def'    => kp_bool($data, ['IS_DEFAULT', 'is_default'], false) ? 1 : 0,
                ':telp'   => kp_str($data, ['TELEPON', 'telepon']),
                ':ket'    => kp_str($data, ['KETERANGAN', 'keterangan']),
            ]);
            break;

        case 'deleteWarehouse':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite('DELETE FROM `master_gudang` WHERE gudang_id = ?') : 'DELETE FROM `master_gudang` WHERE gudang_id = ?')->execute([$key]);
            break;

        case 'saveLog':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `log_transaksi`
                    (timestamp, transaksi_id, sku_id, gudang_id, jumlah, tipe_transaksi, users, keterangan)
                 VALUES (:ts,:tid,:sku,:gid,:jml,:tipe,:usr,:ket)'
            ) : 
                'INSERT INTO `log_transaksi`
                    (timestamp, transaksi_id, sku_id, gudang_id, jumlah, tipe_transaksi, users, keterangan)
                 VALUES (:ts,:tid,:sku,:gid,:jml,:tipe,:usr,:ket)'
            )->execute([
                ':ts'   => kp_str($data, ['TIMESTAMP', 'timestamp']),
                ':tid'  => kp_str($data, ['TRANSAKSI_ID', 'transaksi_id'], $key),
                ':sku'  => kp_str($data, ['SKU_ID', 'sku_id']),
                ':gid'  => kp_str($data, ['GUDANG_ID', 'gudang_id']),
                ':jml'  => (int)kp_num($data, ['JUMLAH', 'jumlah']),
                ':tipe' => kp_str($data, ['TIPE_TRANSAKSI', 'tipe_transaksi']),
                ':usr'  => kp_str($data, ['USERS', 'users']),
                ':ket'  => kp_str($data, ['KETERANGAN', 'keterangan']),
            ]);
            break;

        case 'deleteLog':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite('DELETE FROM `log_transaksi` WHERE transaksi_id = ?') : 'DELETE FROM `log_transaksi` WHERE transaksi_id = ?')->execute([$key]);
            break;

        case 'saveUser':
        case 'saveUsers':
            $list = isset($data[0]) && is_array($data[0]) ? $data : [$data];
            $stmt = $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `app_users`
                    (id, username, password, full_name, role, site_access, is_active, phone, email, created_at, last_login)
                 VALUES (:id,:usr,:pass,:nama,:role,:site,:aktif,:phone,:email,:created,:lastlogin)
                 ON DUPLICATE KEY UPDATE
                    password=VALUES(password), full_name=VALUES(full_name), role=VALUES(role), site_access=VALUES(site_access),
                    is_active=VALUES(is_active), phone=VALUES(phone), email=VALUES(email), last_login=VALUES(last_login)'
            ) : 
                'INSERT INTO `app_users`
                    (id, username, password, full_name, role, site_access, is_active, phone, email, created_at, last_login)
                 VALUES (:id,:usr,:pass,:nama,:role,:site,:aktif,:phone,:email,:created,:lastlogin)
                 ON DUPLICATE KEY UPDATE
                    password=VALUES(password), full_name=VALUES(full_name), role=VALUES(role), site_access=VALUES(site_access),
                    is_active=VALUES(is_active), phone=VALUES(phone), email=VALUES(email), last_login=VALUES(last_login)'
            );
            foreach ($list as $u) {
                $uid = kp_str($u, ['id'], $key);
                $uname = kp_str($u, ['username']);
                if ($uid === '' || $uname === '') continue;
                $stmt->execute([
                    ':id'        => $uid,
                    ':usr'       => $uname,
                    ':pass'      => kp_str($u, ['password']),
                    ':nama'      => kp_str($u, ['fullName', 'full_name']),
                    ':role'      => kp_str($u, ['role'], 'STAF'),
                    ':site'      => kp_str($u, ['siteAccess', 'site_access'], 'GUDANG UTAMA'),
                    ':aktif'     => kp_bool($u, ['isActive', 'is_active'], true) ? 1 : 0,
                    ':phone'     => kp_str($u, ['phone']),
                    ':email'     => kp_str($u, ['email']),
                    ':created'   => kp_str($u, ['createdAt', 'created_at'], date('Y-m-d H:i:s')),
                    ':lastlogin' => kp_str($u, ['lastLogin', 'last_login']),
                ]);
            }
            break;

        case 'deleteUser':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite('DELETE FROM `app_users` WHERE id = ? OR username = ?') : 'DELETE FROM `app_users` WHERE id = ? OR username = ?')->execute([$key, $key]);
            break;

        case 'saveSettings':
            $pdo->prepare(kp_is_sqlite_driver() ? kp_upsert_to_sqlite(
                'INSERT INTO `app_settings` (id, settings_json) VALUES (:id,:json)
                 ON DUPLICATE KEY UPDATE settings_json=VALUES(settings_json)'
            ) : 
                'INSERT INTO `app_settings` (id, settings_json) VALUES (:id,:json)
                 ON DUPLICATE KEY UPDATE settings_json=VALUES(settings_json)'
            )->execute([':id' => 'default', ':json' => json_encode($data, JSON_UNESCAPED_UNICODE)]);
            break;

        default:
            return ['success' => true, 'ignored' => true, 'message' => 'Action tidak dikenal, diabaikan: ' . $action];
    }

    return ['success' => true];
}
