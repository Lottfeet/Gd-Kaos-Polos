<?php
/**
 * =========================================================================
 * KAOS POLOS MANAGEMENT - PHP & MYSQL SYNC BRIDGE
 * =========================================================================
 * File ini dipasang di hosting cPanel Anda (di dalam folder public_html).
 * 
 * Keuntungan:
 * 1. Tidak diblokir Firewall / Port 3306 karena berjalan internal via localhost!
 * 2. Menggunakan koneksi HTTPS/HTTP standar (Port 443 / 80).
 * 3. Langsung membaca & menulis ke phpMyAdmin secara realtime.
 * =========================================================================
 */

// Izinkan CORS dari aplikasi Anda
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Sync-Token");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// -------------------------------------------------------------
// KONFIGURASI DATABASE HOSTING CPANEL ANDA
// -------------------------------------------------------------
// Karena file ini berjalan di server hosting Anda sendiri,
// DB_HOST WAJIB menggunakan 'localhost'!
define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('DB_USER', 'hump6894_kaospolos');
define('DB_PASS', '10203040@kaospolos');
define('DB_NAME', 'hump6894_Gd_kaospolos');

// Token keamanan (opsional, disesuaikan)
define('SECRET_TOKEN', 'kaospolos_sync_secret_2026');

// -------------------------------------------------------------
// KONEKSI DATABASE PDO
// -------------------------------------------------------------
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    }
    return $pdo;
}

// -------------------------------------------------------------
// INISIALISASI TABEL OTOMATIS (JIKA BELUM ADA)
// -------------------------------------------------------------
function initTables($pdo) {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `master_gudang` (
            `gudang_id` VARCHAR(50) NOT NULL PRIMARY KEY,
            `nama_gudang` VARCHAR(100) NOT NULL,
            `lokasi` VARCHAR(255) DEFAULT NULL,
            `penanggung_jawab` VARCHAR(100) DEFAULT NULL,
            `is_active` TINYINT(1) DEFAULT 1,
            `is_default` TINYINT(1) DEFAULT 0,
            `telepon` VARCHAR(50) DEFAULT NULL,
            `keterangan` TEXT DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `master_produk` (
            `sku_id` VARCHAR(100) NOT NULL PRIMARY KEY,
            `nama_produk` VARCHAR(255) NOT NULL,
            `warna` VARCHAR(100) DEFAULT NULL,
            `ukuran` VARCHAR(50) DEFAULT NULL,
            `kategori` VARCHAR(100) DEFAULT NULL,
            `jenis_lengan` VARCHAR(50) DEFAULT 'PENDEK',
            `reorder_level` INT DEFAULT 10,
            `barcode_id` VARCHAR(100) DEFAULT NULL,
            `harga_hpp` DECIMAL(15,2) DEFAULT 0.00,
            `harga_jual` DECIMAL(15,2) DEFAULT 0.00,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `inventori` (
            `id` VARCHAR(150) NOT NULL PRIMARY KEY,
            `gudang_id` VARCHAR(50) NOT NULL,
            `sku_id` VARCHAR(100) NOT NULL,
            `nama_produk` VARCHAR(255) NOT NULL,
            `jumlah_ready` INT DEFAULT 0,
            `reorder_level` INT DEFAULT 10,
            `reorder` VARCHAR(10) DEFAULT 'NO',
            `order_date` VARCHAR(50) DEFAULT NULL,
            `warna` VARCHAR(100) DEFAULT NULL,
            `ukuran` VARCHAR(50) DEFAULT NULL,
            `kategori` VARCHAR(100) DEFAULT NULL,
            `jenis_lengan` VARCHAR(50) DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY `uk_gudang_sku` (`gudang_id`, `sku_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `pelanggan` (
            `id` VARCHAR(50) NOT NULL PRIMARY KEY,
            `nama` VARCHAR(150) NOT NULL,
            `telepon` VARCHAR(50) DEFAULT NULL,
            `alamat` TEXT DEFAULT NULL,
            `kota` VARCHAR(100) DEFAULT NULL,
            `tipe` VARCHAR(50) DEFAULT 'UMUM',
            `plafon_piutang` DECIMAL(15,2) DEFAULT 0.00,
            `catatan` TEXT DEFAULT NULL,
            `created_at` VARCHAR(50) DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `transaksi_penjualan` (
            `nomor_sale` VARCHAR(50) NOT NULL PRIMARY KEY,
            `tanggal` VARCHAR(50) NOT NULL,
            `gudang_id` VARCHAR(50) NOT NULL,
            `gudang_nama` VARCHAR(100) NOT NULL,
            `username` VARCHAR(100) NOT NULL,
            `pelanggan` VARCHAR(150) NOT NULL,
            `pelanggan_id` VARCHAR(50) DEFAULT NULL,
            `tipe_pelanggan` VARCHAR(50) DEFAULT NULL,
            `kontak` VARCHAR(50) DEFAULT NULL,
            `alamat` TEXT DEFAULT NULL,
            `metode` VARCHAR(50) DEFAULT NULL,
            `catatan` TEXT DEFAULT NULL,
            `subtotal_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `diskon_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `total_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `status_pembayaran` VARCHAR(30) DEFAULT 'LUNAS',
            `jumlah_bayar` DECIMAL(15,2) DEFAULT 0.00,
            `sisa_piutang` DECIMAL(15,2) DEFAULT 0.00,
            `jatuh_tempo` VARCHAR(50) DEFAULT NULL,
            `items_json` LONGTEXT DEFAULT NULL,
            `riwayat_pelunasan_json` LONGTEXT DEFAULT NULL,
            `created_at` VARCHAR(50) DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `order_po` (
            `nomor_order` VARCHAR(50) NOT NULL PRIMARY KEY,
            `tanggal` VARCHAR(50) NOT NULL,
            `gudang_id` VARCHAR(50) NOT NULL,
            `gudang_nama` VARCHAR(100) NOT NULL,
            `username` VARCHAR(100) NOT NULL,
            `supplier` VARCHAR(150) NOT NULL,
            `kontak` VARCHAR(50) DEFAULT NULL,
            `alamat` TEXT DEFAULT NULL,
            `metode` VARCHAR(50) DEFAULT NULL,
            `catatan` TEXT DEFAULT NULL,
            `subtotal_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `diskon_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `total_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `status_pembayaran` VARCHAR(30) DEFAULT 'LUNAS',
            `jumlah_bayar` DECIMAL(15,2) DEFAULT 0.00,
            `sisa_piutang` DECIMAL(15,2) DEFAULT 0.00,
            `jatuh_tempo` VARCHAR(50) DEFAULT NULL,
            `tampilkan_nominal` TINYINT(1) DEFAULT 1,
            `items_json` LONGTEXT DEFAULT NULL,
            `signature_admin_json` LONGTEXT DEFAULT NULL,
            `signature_supervisor_json` LONGTEXT DEFAULT NULL,
            `created_at` VARCHAR(50) DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `surat_jalan` (
            `nomor_sj` VARCHAR(50) NOT NULL PRIMARY KEY,
            `tanggal` VARCHAR(50) NOT NULL,
            `gudang_id` VARCHAR(50) NOT NULL,
            `gudang_nama` VARCHAR(100) NOT NULL,
            `username` VARCHAR(100) NOT NULL,
            `tujuan` VARCHAR(150) NOT NULL,
            `penerima` VARCHAR(150) NOT NULL,
            `driver` VARCHAR(150) DEFAULT NULL,
            `kendaraan` VARCHAR(100) DEFAULT NULL,
            `catatan` TEXT DEFAULT NULL,
            `tampilkan_nominal` TINYINT(1) DEFAULT 0,
            `total_nominal` DECIMAL(15,2) DEFAULT 0.00,
            `items_json` LONGTEXT DEFAULT NULL,
            `signature_pengirim_json` LONGTEXT DEFAULT NULL,
            `signature_driver_json` LONGTEXT DEFAULT NULL,
            `signature_penerima_json` LONGTEXT DEFAULT NULL,
            `created_at` VARCHAR(50) DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `log_transaksi` (
            `id` INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
            `timestamp` VARCHAR(50) NOT NULL,
            `transaksi_id` VARCHAR(50) NOT NULL,
            `sku_id` VARCHAR(100) NOT NULL,
            `gudang_id` VARCHAR(50) NOT NULL,
            `jumlah` INT NOT NULL,
            `tipe_transaksi` VARCHAR(50) NOT NULL,
            `users` VARCHAR(100) NOT NULL,
            `keterangan` TEXT DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `app_settings` (
            `id` VARCHAR(50) NOT NULL PRIMARY KEY,
            `settings_json` LONGTEXT NOT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `app_users` (
            `id` VARCHAR(50) NOT NULL PRIMARY KEY,
            `username` VARCHAR(100) NOT NULL,
            `password` VARCHAR(255) NOT NULL,
            `full_name` VARCHAR(150) NOT NULL,
            `role` VARCHAR(50) NOT NULL,
            `site_access` VARCHAR(100) NOT NULL,
            `is_active` TINYINT(1) DEFAULT 1,
            `phone` VARCHAR(50) DEFAULT NULL,
            `email` VARCHAR(100) DEFAULT NULL,
            `created_at` VARCHAR(50) DEFAULT NULL,
            `last_login` VARCHAR(50) DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY `uk_username` (`username`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
}

// -------------------------------------------------------------
// ROUTER AKSI
// -------------------------------------------------------------
$action = isset($_GET['action']) ? $_GET['action'] : 'status';

try {
    $pdo = getDB();
    initTables($pdo);

    // 1. STATUS KONEKSI & HITUNG DATA
    if ($action === 'status') {
        $countQuery = function($table) use ($pdo) {
            try {
                $stmt = $pdo->query("SELECT COUNT(*) FROM `$table`");
                return (int)$stmt->fetchColumn();
            } catch (Exception $e) {
                return 0;
            }
        };

        $tableCounts = [
            'products'       => $countQuery('master_produk'),
            'inventory'      => $countQuery('inventori'),
            'warehouses'     => $countQuery('master_gudang'),
            'customers'      => $countQuery('pelanggan'),
            'sales'          => $countQuery('transaksi_penjualan'),
            'orders'         => $countQuery('order_po'),
            'suratJalanList' => $countQuery('surat_jalan'),
            'logs'           => $countQuery('log_transaksi'),
            'users'          => $countQuery('app_users'),
        ];

        echo json_encode([
            'connected'   => true,
            'bridge'      => 'php_bridge',
            'host'        => DB_HOST,
            'database'    => DB_NAME,
            'user'        => DB_USER,
            'tableCounts' => $tableCounts,
            'server_time' => date('Y-m-d H:i:s'),
            'message'     => 'Koneksi PHP Bridge ke phpMyAdmin berhasil!'
        ]);
        exit;
    }

    // 2. PULL ALL DATA (Tarik semua data dari phpMyAdmin ke aplikasi)
    if ($action === 'pull-all') {
        $getRows = function($table) use ($pdo) {
            $stmt = $pdo->query("SELECT * FROM `$table`");
            return $stmt->fetchAll();
        };

        $products = array_map(function($r) {
            return [
                'sku_id'        => $r['sku_id'],
                'nama_produk'   => $r['nama_produk'],
                'warna'         => $r['warna'] ?? '',
                'ukuran'        => $r['ukuran'] ?? '',
                'kategori'      => $r['kategori'] ?? '',
                'jenis_lengan'  => $r['jenis_lengan'] ?? 'PENDEK',
                'reorder_level' => (int)($r['reorder_level'] ?? 10),
                'barcode_id'    => $r['barcode_id'] ?? '',
                'harga_hpp'     => (float)($r['harga_hpp'] ?? 0),
                'harga_jual'    => (float)($r['harga_jual'] ?? 0),
            ];
        }, $getRows('master_produk'));

        $inventory = array_map(function($r) {
            return [
                'id'            => $r['id'],
                'GUDANG_ID'     => $r['gudang_id'],
                'SKU'           => $r['sku_id'],
                'NAMA_PRODUK'   => $r['nama_produk'],
                'JUMLAH_READY'  => (int)($r['jumlah_ready'] ?? 0),
                'REORDER_LEVEL' => (int)($r['reorder_level'] ?? 10),
                'REORDER'       => $r['reorder'] ?? 'NO',
                'ORDER_DATE'    => $r['order_date'] ?? '',
                'WARNA'         => $r['warna'] ?? '',
                'UKURAN'        => $r['ukuran'] ?? '',
                'KATEGORI'      => $r['kategori'] ?? '',
                'JENIS_LENGAN'  => $r['jenis_lengan'] ?? 'PENDEK',
            ];
        }, $getRows('inventori'));

        $warehouses = array_map(function($r) {
            return [
                'gudang_id'        => $r['gudang_id'],
                'nama_gudang'      => $r['nama_gudang'],
                'lokasi'           => $r['lokasi'] ?? '',
                'penanggung_jawab' => $r['penanggung_jawab'] ?? '',
                'is_active'        => (bool)$r['is_active'],
                'is_default'       => (bool)$r['is_default'],
                'telepon'          => $r['telepon'] ?? '',
                'keterangan'       => $r['keterangan'] ?? '',
            ];
        }, $getRows('master_gudang'));

        $customers = array_map(function($r) {
            return [
                'id'             => $r['id'],
                'nama'           => $r['nama'],
                'telepon'        => $r['telepon'] ?? '',
                'alamat'         => $r['alamat'] ?? '',
                'kota'           => $r['kota'] ?? '',
                'tipe'           => $r['tipe'] ?? 'UMUM',
                'plafon_piutang' => (float)($r['plafon_piutang'] ?? 0),
                'catatan'        => $r['catatan'] ?? '',
                'created_at'     => $r['created_at'] ?? '',
            ];
        }, $getRows('pelanggan'));

        $sales = array_map(function($r) {
            return [
                'nomor_sale'        => $r['nomor_sale'],
                'tanggal'           => $r['tanggal'],
                'gudang_id'         => $r['gudang_id'],
                'gudang_nama'       => $r['gudang_nama'],
                'username'          => $r['username'],
                'pelanggan'         => $r['pelanggan'],
                'pelanggan_id'      => $r['pelanggan_id'] ?? '',
                'tipe_pelanggan'    => $r['tipe_pelanggan'] ?? 'UMUM',
                'kontak'            => $r['kontak'] ?? '',
                'alamat'            => $r['alamat'] ?? '',
                'metode'            => $r['metode'] ?? 'CASH',
                'catatan'           => $r['catatan'] ?? '',
                'subtotal_nominal'  => (float)($r['subtotal_nominal'] ?? 0),
                'diskon_nominal'    => (float)($r['diskon_nominal'] ?? 0),
                'total_nominal'     => (float)($r['total_nominal'] ?? 0),
                'status_pembayaran' => $r['status_pembayaran'] ?? 'LUNAS',
                'jumlah_bayar'      => (float)($r['jumlah_bayar'] ?? 0),
                'sisa_piutang'      => (float)($r['sisa_piutang'] ?? 0),
                'jatuh_tempo'       => $r['jatuh_tempo'] ?? '',
                'items'             => json_decode($r['items_json'] ?? '[]', true) ?: [],
                'riwayat_pelunasan' => json_decode($r['riwayat_pelunasan_json'] ?? '[]', true) ?: [],
                'created_at'        => $r['created_at'] ?? '',
            ];
        }, $getRows('transaksi_penjualan'));

        $orders = array_map(function($r) {
            return [
                'nomor_order'        => $r['nomor_order'],
                'tanggal'            => $r['tanggal'],
                'gudang_id'          => $r['gudang_id'],
                'gudang_nama'        => $r['gudang_nama'],
                'username'           => $r['username'],
                'supplier'           => $r['supplier'],
                'kontak'             => $r['kontak'] ?? '',
                'alamat'             => $r['alamat'] ?? '',
                'metode'             => $r['metode'] ?? 'CASH',
                'catatan'            => $r['catatan'] ?? '',
                'subtotal_nominal'   => (float)($r['subtotal_nominal'] ?? 0),
                'diskon_nominal'     => (float)($r['diskon_nominal'] ?? 0),
                'total_nominal'      => (float)($r['total_nominal'] ?? 0),
                'status_pembayaran'  => $r['status_pembayaran'] ?? 'LUNAS',
                'jumlah_bayar'       => (float)($r['jumlah_bayar'] ?? 0),
                'sisa_piutang'       => (float)($r['sisa_piutang'] ?? 0),
                'jatuh_tempo'        => $r['jatuh_tempo'] ?? '',
                'tampilkan_nominal'  => (bool)($r['tampilkan_nominal'] ?? 1),
                'items'              => json_decode($r['items_json'] ?? '[]', true) ?: [],
                'signature_admin'    => json_decode($r['signature_admin_json'] ?? 'null', true),
                'signature_supervisor'=> json_decode($r['signature_supervisor_json'] ?? 'null', true),
                'created_at'         => $r['created_at'] ?? '',
            ];
        }, $getRows('order_po'));

        $suratJalanList = array_map(function($r) {
            return [
                'nomor_sj'           => $r['nomor_sj'],
                'tanggal'            => $r['tanggal'],
                'gudang_id'          => $r['gudang_id'],
                'gudang_nama'        => $r['gudang_nama'],
                'username'           => $r['username'],
                'tujuan'             => $r['tujuan'],
                'penerima'           => $r['penerima'],
                'driver'             => $r['driver'] ?? '',
                'kendaraan'          => $r['kendaraan'] ?? '',
                'catatan'            => $r['catatan'] ?? '',
                'tampilkan_nominal'  => (bool)($r['tampilkan_nominal'] ?? 0),
                'total_nominal'      => (float)($r['total_nominal'] ?? 0),
                'items'              => json_decode($r['items_json'] ?? '[]', true) ?: [],
                'signature_pengirim' => json_decode($r['signature_pengirim_json'] ?? 'null', true),
                'signature_driver'   => json_decode($r['signature_driver_json'] ?? 'null', true),
                'signature_penerima' => json_decode($r['signature_penerima_json'] ?? 'null', true),
                'created_at'         => $r['created_at'] ?? '',
            ];
        }, $getRows('surat_jalan'));

        $logs = array_map(function($r) {
            return [
                'id'              => (string)$r['id'],
                'timestamp'       => $r['timestamp'],
                'transaksi_id'    => $r['transaksi_id'],
                'sku_id'          => $r['sku_id'],
                'gudang_id'       => $r['gudang_id'],
                'jumlah'          => (int)$r['jumlah'],
                'tipe_transaksi'  => $r['tipe_transaksi'],
                'users'           => $r['users'],
                'keterangan'      => $r['keterangan'] ?? '',
            ];
        }, $getRows('log_transaksi'));

        echo json_encode([
            'success' => true,
            'data' => [
                'products'       => $products,
                'inventory'      => $inventory,
                'warehouses'     => $warehouses,
                'customers'      => $customers,
                'sales'          => $sales,
                'orders'         => $orders,
                'suratJalanList' => $suratJalanList,
                'logs'           => $logs,
            ]
        ]);
        exit;
    }

    // 3. PUSH ALL DATA (Simpan semua data dari aplikasi ke phpMyAdmin)
    if ($action === 'push-all') {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) {
            throw new Exception("Data input kosong");
        }

        $pdo->beginTransaction();

        // Sync Produk
        if (!empty($input['products']) && is_array($input['products'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `master_produk` (sku_id, nama_produk, warna, ukuran, kategori, jenis_lengan, reorder_level, barcode_id, harga_hpp, harga_jual)
                VALUES (:sku_id, :nama_produk, :warna, :ukuran, :kategori, :jenis_lengan, :reorder_level, :barcode_id, :harga_hpp, :harga_jual)
                ON DUPLICATE KEY UPDATE 
                    nama_produk = VALUES(nama_produk),
                    warna = VALUES(warna),
                    ukuran = VALUES(ukuran),
                    kategori = VALUES(kategori),
                    jenis_lengan = VALUES(jenis_lengan),
                    reorder_level = VALUES(reorder_level),
                    barcode_id = VALUES(barcode_id),
                    harga_hpp = VALUES(harga_hpp),
                    harga_jual = VALUES(harga_jual)
            ");
            foreach ($input['products'] as $p) {
                $stmt->execute([
                    ':sku_id'        => $p['sku_id'],
                    ':nama_produk'   => $p['nama_produk'],
                    ':warna'         => $p['warna'] ?? '',
                    ':ukuran'        => $p['ukuran'] ?? '',
                    ':kategori'      => $p['kategori'] ?? '',
                    ':jenis_lengan'  => $p['jenis_lengan'] ?? 'PENDEK',
                    ':reorder_level' => (int)($p['reorder_level'] ?? 10),
                    ':barcode_id'    => $p['barcode_id'] ?? '',
                    ':harga_hpp'     => (float)($p['harga_hpp'] ?? 0),
                    ':harga_jual'    => (float)($p['harga_jual'] ?? 0),
                ]);
            }
        }

        // Sync Gudang
        if (!empty($input['warehouses']) && is_array($input['warehouses'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `master_gudang` (gudang_id, nama_gudang, lokasi, penanggung_jawab, is_active, is_default, telepon, keterangan)
                VALUES (:gudang_id, :nama_gudang, :lokasi, :penanggung_jawab, :is_active, :is_default, :telepon, :keterangan)
                ON DUPLICATE KEY UPDATE
                    nama_gudang = VALUES(nama_gudang),
                    lokasi = VALUES(lokasi),
                    penanggung_jawab = VALUES(penanggung_jawab),
                    is_active = VALUES(is_active),
                    is_default = VALUES(is_default),
                    telepon = VALUES(telepon),
                    keterangan = VALUES(keterangan)
            ");
            foreach ($input['warehouses'] as $w) {
                $stmt->execute([
                    ':gudang_id'        => $w['gudang_id'],
                    ':nama_gudang'      => $w['nama_gudang'],
                    ':lokasi'           => $w['lokasi'] ?? '',
                    ':penanggung_jawab' => $w['penanggung_jawab'] ?? '',
                    ':is_active'        => !empty($w['is_active']) ? 1 : 0,
                    ':is_default'       => !empty($w['is_default']) ? 1 : 0,
                    ':telepon'          => $w['telepon'] ?? '',
                    ':keterangan'       => $w['keterangan'] ?? '',
                ]);
            }
        }

        // Sync Inventory
        if (!empty($input['inventory']) && is_array($input['inventory'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `inventori` (id, gudang_id, sku_id, nama_produk, jumlah_ready, reorder_level, reorder, order_date, warna, ukuran, kategori, jenis_lengan)
                VALUES (:id, :gudang_id, :sku_id, :nama_produk, :jumlah_ready, :reorder_level, :reorder, :order_date, :warna, :ukuran, :kategori, :jenis_lengan)
                ON DUPLICATE KEY UPDATE
                    nama_produk = VALUES(nama_produk),
                    jumlah_ready = VALUES(jumlah_ready),
                    reorder_level = VALUES(reorder_level),
                    reorder = VALUES(reorder),
                    order_date = VALUES(order_date),
                    warna = VALUES(warna),
                    ukuran = VALUES(ukuran),
                    kategori = VALUES(kategori),
                    jenis_lengan = VALUES(jenis_lengan)
            ");
            foreach ($input['inventory'] as $inv) {
                $id = !empty($inv['id']) ? $inv['id'] : ($inv['GUDANG_ID'] . '_' . $inv['SKU']);
                $stmt->execute([
                    ':id'            => $id,
                    ':gudang_id'     => $inv['GUDANG_ID'],
                    ':sku_id'        => $inv['SKU'],
                    ':nama_produk'   => $inv['NAMA_PRODUK'] ?? '',
                    ':jumlah_ready'  => (int)($inv['JUMLAH_READY'] ?? 0),
                    ':reorder_level' => (int)($inv['REORDER_LEVEL'] ?? 10),
                    ':reorder'       => $inv['REORDER'] ?? 'NO',
                    ':order_date'    => $inv['ORDER_DATE'] ?? '',
                    ':warna'         => $inv['WARNA'] ?? '',
                    ':ukuran'        => $inv['UKURAN'] ?? '',
                    ':kategori'      => $inv['KATEGORI'] ?? '',
                    ':jenis_lengan'  => $inv['JENIS_LENGAN'] ?? 'PENDEK',
                ]);
            }
        }

        // Sync Pelanggan
        if (!empty($input['customers']) && is_array($input['customers'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `pelanggan` (id, nama, telepon, alamat, kota, tipe, plafon_piutang, catatan, created_at)
                VALUES (:id, :nama, :telepon, :alamat, :kota, :tipe, :plafon_piutang, :catatan, :created_at)
                ON DUPLICATE KEY UPDATE
                    nama = VALUES(nama),
                    telepon = VALUES(telepon),
                    alamat = VALUES(alamat),
                    kota = VALUES(kota),
                    tipe = VALUES(tipe),
                    plafon_piutang = VALUES(plafon_piutang),
                    catatan = VALUES(catatan)
            ");
            foreach ($input['customers'] as $c) {
                $stmt->execute([
                    ':id'             => $c['id'],
                    ':nama'           => $c['nama'],
                    ':telepon'        => $c['telepon'] ?? '',
                    ':alamat'         => $c['alamat'] ?? '',
                    ':kota'           => $c['kota'] ?? '',
                    ':tipe'           => $c['tipe'] ?? 'UMUM',
                    ':plafon_piutang' => (float)($c['plafon_piutang'] ?? 0),
                    ':catatan'        => $c['catatan'] ?? '',
                    ':created_at'     => $c['created_at'] ?? date('Y-m-d H:i:s'),
                ]);
            }
        }

        // Sync Penjualan
        if (!empty($input['sales']) && is_array($input['sales'])) {
            $stmt = $pdo->prepare("
                INSERT INTO `transaksi_penjualan` (
                    nomor_sale, tanggal, gudang_id, gudang_nama, username, pelanggan, pelanggan_id,
                    tipe_pelanggan, kontak, alamat, metode, catatan, subtotal_nominal, diskon_nominal,
                    total_nominal, status_pembayaran, jumlah_bayar, sisa_piutang, jatuh_tempo,
                    items_json, riwayat_pelunasan_json, created_at
                ) VALUES (
                    :nomor_sale, :tanggal, :gudang_id, :gudang_nama, :username, :pelanggan, :pelanggan_id,
                    :tipe_pelanggan, :kontak, :alamat, :metode, :catatan, :subtotal_nominal, :diskon_nominal,
                    :total_nominal, :status_pembayaran, :jumlah_bayar, :sisa_piutang, :jatuh_tempo,
                    :items_json, :riwayat_pelunasan_json, :created_at
                ) ON DUPLICATE KEY UPDATE
                    gudang_id = VALUES(gudang_id),
                    gudang_nama = VALUES(gudang_nama),
                    pelanggan = VALUES(pelanggan),
                    pelanggan_id = VALUES(pelanggan_id),
                    tipe_pelanggan = VALUES(tipe_pelanggan),
                    kontak = VALUES(kontak),
                    alamat = VALUES(alamat),
                    metode = VALUES(metode),
                    catatan = VALUES(catatan),
                    subtotal_nominal = VALUES(subtotal_nominal),
                    diskon_nominal = VALUES(diskon_nominal),
                    total_nominal = VALUES(total_nominal),
                    status_pembayaran = VALUES(status_pembayaran),
                    jumlah_bayar = VALUES(jumlah_bayar),
                    sisa_piutang = VALUES(sisa_piutang),
                    jatuh_tempo = VALUES(jatuh_tempo),
                    items_json = VALUES(items_json),
                    riwayat_pelunasan_json = VALUES(riwayat_pelunasan_json)
            ");
            foreach ($input['sales'] as $s) {
                $stmt->execute([
                    ':nomor_sale'              => $s['nomor_sale'],
                    ':tanggal'                 => $s['tanggal'],
                    ':gudang_id'               => $s['gudang_id'],
                    ':gudang_nama'             => $s['gudang_nama'],
                    ':username'                => $s['username'],
                    ':pelanggan'               => $s['pelanggan'],
                    ':pelanggan_id'            => $s['pelanggan_id'] ?? '',
                    ':tipe_pelanggan'          => $s['tipe_pelanggan'] ?? 'UMUM',
                    ':kontak'                  => $s['kontak'] ?? '',
                    ':alamat'                  => $s['alamat'] ?? '',
                    ':metode'                  => $s['metode'] ?? 'CASH',
                    ':catatan'                 => $s['catatan'] ?? '',
                    ':subtotal_nominal'        => (float)($s['subtotal_nominal'] ?? 0),
                    ':diskon_nominal'          => (float)($s['diskon_nominal'] ?? 0),
                    ':total_nominal'           => (float)($s['total_nominal'] ?? 0),
                    ':status_pembayaran'       => $s['status_pembayaran'] ?? 'LUNAS',
                    ':jumlah_bayar'            => (float)($s['jumlah_bayar'] ?? 0),
                    ':sisa_piutang'            => (float)($s['sisa_piutang'] ?? 0),
                    ':jatuh_tempo'             => $s['jatuh_tempo'] ?? '',
                    ':items_json'              => json_encode($s['items'] ?? []),
                    ':riwayat_pelunasan_json'  => json_encode($s['riwayat_pelunasan'] ?? []),
                    ':created_at'              => $s['created_at'] ?? date('Y-m-d H:i:s'),
                ]);
            }
        }

        $pdo->commit();

        echo json_encode([
            'success' => true,
            'message' => 'Semua data berhasil disimpan ke MySQL phpMyAdmin!'
        ]);
        exit;
    }

    echo json_encode(['error' => 'Action tidak dikenali']);

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode([
        'connected' => false,
        'error'     => $e->getMessage()
    ]);
}
