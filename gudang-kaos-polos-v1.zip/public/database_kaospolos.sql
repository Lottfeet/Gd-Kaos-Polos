-- phpMyAdmin SQL Dump
-- Versi Aplikasi: Sistem Manajemen Inventori & Penjualan Kaos Polos
-- Target Server: MySQL / MariaDB (phpMyAdmin Compatible)
-- Database: `db_kaospolos`

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+07:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_kaospolos`
--
CREATE DATABASE IF NOT EXISTS `db_kaospolos` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `db_kaospolos`;

-- --------------------------------------------------------

--
-- Struktur tabel `master_gudang`
--
DROP TABLE IF EXISTS `master_gudang`;
CREATE TABLE `master_gudang` (
  `gudang_id` VARCHAR(50) NOT NULL,
  `nama_gudang` VARCHAR(100) NOT NULL,
  `lokasi` VARCHAR(255) DEFAULT NULL,
  `penanggung_jawab` VARCHAR(100) DEFAULT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `is_default` TINYINT(1) DEFAULT 0,
  `telepon` VARCHAR(50) DEFAULT NULL,
  `keterangan` TEXT DEFAULT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`gudang_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data awal `master_gudang`
--
INSERT INTO `master_gudang` (`gudang_id`, `nama_gudang`, `lokasi`, `penanggung_jawab`, `is_active`, `is_default`, `telepon`, `keterangan`) VALUES
('GDG-01-ERVO', 'GUDANG UTAMA', 'Pusat Distribusi Utama - Blok A', 'Admin Gudang Utama', 1, 1, '0812-3456-7891', 'Gudang pusat penerimaan kain dan konveksi'),
('GDG-02-TOKO', 'GUDANG TOKO', 'Outlet Ritel & Display - Lantai 1', 'Admin Toko', 1, 0, '0812-3456-7892', 'Gudang display dan etalase toko fisik');

-- --------------------------------------------------------

--
-- Struktur tabel `master_produk`
--
DROP TABLE IF EXISTS `master_produk`;
CREATE TABLE `master_produk` (
  `sku_id` VARCHAR(100) NOT NULL,
  `nama_produk` VARCHAR(255) NOT NULL,
  `warna` VARCHAR(100) DEFAULT NULL,
  `ukuran` VARCHAR(50) DEFAULT NULL,
  `kategori` VARCHAR(100) DEFAULT NULL,
  `jenis_lengan` VARCHAR(50) DEFAULT 'PENDEK',
  `reorder_level` INT DEFAULT 10,
  `barcode_id` VARCHAR(100) DEFAULT NULL,
  `harga_hpp` DECIMAL(15,2) DEFAULT 0.00,
  `harga_jual` DECIMAL(15,2) DEFAULT 0.00,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data awal `master_produk`
--
INSERT INTO `master_produk` (`sku_id`, `nama_produk`, `warna`, `ukuran`, `kategori`, `jenis_lengan`, `reorder_level`, `barcode_id`, `harga_hpp`, `harga_jual`) VALUES
('KPCM-30S-HTM-M-PDK', 'Kaos Polos Cotton Combed 30s Hitam M Pendek', 'HITAM', 'M', 'COTTON COMBED 30S', 'PENDEK', 15, '8991001001', 28000.00, 45000.00),
('KPCM-30S-HTM-L-PDK', 'Kaos Polos Cotton Combed 30s Hitam L Pendek', 'HITAM', 'L', 'COTTON COMBED 30S', 'PENDEK', 20, '8991001002', 30000.00, 48000.00),
('KPCM-30S-HTM-XL-PDK', 'Kaos Polos Cotton Combed 30s Hitam XL Pendek', 'HITAM', 'XL', 'COTTON COMBED 30S', 'PENDEK', 15, '8991001003', 32000.00, 52000.00),
('KPCM-30S-PTH-M-PDK', 'Kaos Polos Cotton Combed 30s Putih M Pendek', 'PUTIH', 'M', 'COTTON COMBED 30S', 'PENDEK', 15, '8991001004', 28000.00, 45000.00),
('KPCM-30S-PTH-L-PDK', 'Kaos Polos Cotton Combed 30s Putih L Pendek', 'PUTIH', 'L', 'COTTON COMBED 30S', 'PENDEK', 20, '8991001005', 30000.00, 48000.00),
('KPCM-30S-NVY-L-PDK', 'Kaos Polos Cotton Combed 30s Navy L Pendek', 'NAVY', 'L', 'COTTON COMBED 30S', 'PENDEK', 15, '8991001006', 30000.00, 48000.00),
('KPCM-30S-MRH-M-PDK', 'Kaos Polos Cotton Combed 30s Merah Cabe M Pendek', 'MERAH CABE', 'M', 'COTTON COMBED 30S', 'PENDEK', 10, '8991001007', 28000.00, 45000.00),
('KPCM-24S-HTM-L-PDK', 'Kaos Polos Cotton Combed 24s Heavyweight Hitam L', 'HITAM', 'L', 'COTTON COMBED 24S', 'PENDEK', 12, '8991001008', 35000.00, 58000.00),
('KPCM-30S-HTM-L-PJG', 'Kaos Polos Cotton Combed 30s Hitam L Lengan Panjang', 'HITAM', 'L', 'COTTON COMBED 30S', 'PANJANG', 10, '8991001009', 36000.00, 58000.00);

-- --------------------------------------------------------

--
-- Struktur tabel `inventori`
--
DROP TABLE IF EXISTS `inventori`;
CREATE TABLE `inventori` (
  `id` VARCHAR(150) NOT NULL,
  `gudang_id` VARCHAR(50) NOT NULL,
  `sku_id` VARCHAR(100) NOT NULL,
  `nama_produk` VARCHAR(255) NOT NULL,
  `jumlah_ready` INT DEFAULT 0,
  `reorder_level` INT DEFAULT 10,
  `reorder` VARCHAR(10) DEFAULT 'NO',
  `order_date` VARCHAR(50) DEFAULT NULL,
  `warna` VARCHAR(100) DEFAULT NULL,
  `ukuran` VARCHAR(50) DEFAULT NULL,
  `kategori` VARCHAR(100) DEFAULT NULL,
  `jenis_lengan` VARCHAR(50) DEFAULT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gudang_sku` (`gudang_id`, `sku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data awal `inventori`
--
INSERT INTO `inventori` (`id`, `gudang_id`, `sku_id`, `nama_produk`, `jumlah_ready`, `reorder_level`, `reorder`, `order_date`, `warna`, `ukuran`, `kategori`, `jenis_lengan`) VALUES
('GDG-01-ERVO_KPCM-30S-HTM-M-PDK', 'GDG-01-ERVO', 'KPCM-30S-HTM-M-PDK', 'Kaos Polos Cotton Combed 30s Hitam M Pendek', 120, 15, 'NO', NULL, 'HITAM', 'M', 'COTTON COMBED 30S', 'PENDEK'),
('GDG-01-ERVO_KPCM-30S-HTM-L-PDK', 'GDG-01-ERVO', 'KPCM-30S-HTM-L-PDK', 'Kaos Polos Cotton Combed 30s Hitam L Pendek', 85, 20, 'NO', NULL, 'HITAM', 'L', 'COTTON COMBED 30S', 'PENDEK'),
('GDG-01-ERVO_KPCM-30S-HTM-XL-PDK', 'GDG-01-ERVO', 'KPCM-30S-HTM-XL-PDK', 'Kaos Polos Cotton Combed 30s Hitam XL Pendek', 40, 15, 'NO', NULL, 'HITAM', 'XL', 'COTTON COMBED 30S', 'PENDEK'),
('GDG-01-ERVO_KPCM-30S-PTH-M-PDK', 'GDG-01-ERVO', 'KPCM-30S-PTH-M-PDK', 'Kaos Polos Cotton Combed 30s Putih M Pendek', 95, 15, 'NO', NULL, 'PUTIH', 'M', 'COTTON COMBED 30S', 'PENDEK'),
('GDG-01-ERVO_KPCM-30S-PTH-L-PDK', 'GDG-01-ERVO', 'KPCM-30S-PTH-L-PDK', 'Kaos Polos Cotton Combed 30s Putih L Pendek', 110, 20, 'NO', NULL, 'PUTIH', 'L', 'COTTON COMBED 30S', 'PENDEK'),
('GDG-02-TOKO_KPCM-30S-HTM-M-PDK', 'GDG-02-TOKO', 'KPCM-30S-HTM-M-PDK', 'Kaos Polos Cotton Combed 30s Hitam M Pendek', 35, 15, 'NO', NULL, 'HITAM', 'M', 'COTTON COMBED 30S', 'PENDEK'),
('GDG-02-TOKO_KPCM-30S-HTM-L-PDK', 'GDG-02-TOKO', 'KPCM-30S-HTM-L-PDK', 'Kaos Polos Cotton Combed 30s Hitam L Pendek', 28, 20, 'NO', NULL, 'HITAM', 'L', 'COTTON COMBED 30S', 'PENDEK'),
('GDG-02-TOKO_KPCM-30S-NVY-L-PDK', 'GDG-02-TOKO', 'KPCM-30S-NVY-L-PDK', 'Kaos Polos Cotton Combed 30s Navy L Pendek', 18, 15, 'NO', NULL, 'NAVY', 'L', 'COTTON COMBED 30S', 'PENDEK');

-- --------------------------------------------------------

--
-- Struktur tabel `pelanggan`
--
DROP TABLE IF EXISTS `pelanggan`;
CREATE TABLE `pelanggan` (
  `id` VARCHAR(50) NOT NULL,
  `nama` VARCHAR(150) NOT NULL,
  `telepon` VARCHAR(50) DEFAULT NULL,
  `alamat` TEXT DEFAULT NULL,
  `kota` VARCHAR(100) DEFAULT NULL,
  `tipe` VARCHAR(50) DEFAULT 'UMUM',
  `plafon_piutang` DECIMAL(15,2) DEFAULT 0.00,
  `catatan` TEXT DEFAULT NULL,
  `created_at` VARCHAR(50) DEFAULT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data awal `pelanggan`
--
INSERT INTO `pelanggan` (`id`, `nama`, `telepon`, `alamat`, `kota`, `tipe`, `plafon_piutang`, `catatan`, `created_at`) VALUES
('CUST-001', 'Distro Bandung Kreatif', '0812-8888-7777', 'Jl. Riau No. 45', 'Bandung', 'GROSIR', 20000000.00, 'Langganan grosir distro kaos distro premium', '2026-01-10T00:00:00.000Z'),
('CUST-002', 'Konveksi Sablon Jaya', '0813-1122-3344', 'Jl. Pajajaran No. 12', 'Bandung', 'KONVEKSI', 15000000.00, 'Order rutin polosan untuk sablon partai', '2026-01-15T00:00:00.000Z'),
('CUST-003', 'Pelanggan Walk-In Toko', '0800-0000-0000', 'Outlet Toko Ritel', 'Bandung', 'UMUM', 0.00, 'Pelanggan ritel langsung tunai', '2026-01-01T00:00:00.000Z');

-- --------------------------------------------------------

--
-- Struktur tabel `transaksi_penjualan`
--
DROP TABLE IF EXISTS `transaksi_penjualan`;
CREATE TABLE `transaksi_penjualan` (
  `nomor_sale` VARCHAR(50) NOT NULL,
  `tanggal` VARCHAR(50) NOT NULL,
  `gudang_id` VARCHAR(50) NOT NULL,
  `gudang_nama` VARCHAR(100) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `pelanggan` VARCHAR(150) NOT NULL,
  `pelanggan_id` VARCHAR(50) DEFAULT NULL,
  `tipe_pelanggan` VARCHAR(50) DEFAULT NULL,
  `kontak` VARCHAR(50) DEFAULT NULL,
  `alamat` TEXT DEFAULT NULL,
  `metode` VARCHAR(50) DEFAULT NULL,
  `catatan` TEXT DEFAULT NULL,
  `subtotal_nominal` DECIMAL(15,2) DEFAULT 0.00,
  `diskon_nominal` DECIMAL(15,2) DEFAULT 0.00,
  `total_nominal` DECIMAL(15,2) DEFAULT 0.00,
  `status_pembayaran` VARCHAR(30) DEFAULT 'LUNAS',
  `jumlah_bayar` DECIMAL(15,2) DEFAULT 0.00,
  `sisa_piutang` DECIMAL(15,2) DEFAULT 0.00,
  `jatuh_tempo` VARCHAR(50) DEFAULT NULL,
  `items_json` LONGTEXT DEFAULT NULL,
  `riwayat_pelunasan_json` LONGTEXT DEFAULT NULL,
  `created_at` VARCHAR(50) DEFAULT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`nomor_sale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur tabel `order_po`
--
DROP TABLE IF EXISTS `order_po`;
CREATE TABLE `order_po` (
  `nomor_order` VARCHAR(50) NOT NULL,
  `tanggal` VARCHAR(50) NOT NULL,
  `gudang_id` VARCHAR(50) NOT NULL,
  `gudang_nama` VARCHAR(100) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `supplier` VARCHAR(150) NOT NULL,
  `kontak` VARCHAR(50) DEFAULT NULL,
  `alamat` TEXT DEFAULT NULL,
  `metode` VARCHAR(50) DEFAULT NULL,
  `catatan` TEXT DEFAULT NULL,
  `subtotal_nominal` DECIMAL(15,2) DEFAULT 0.00,
  `diskon_nominal` DECIMAL(15,2) DEFAULT 0.00,
  `total_nominal` DECIMAL(15,2) DEFAULT 0.00,
  `status_pembayaran` VARCHAR(30) DEFAULT 'LUNAS',
  `jumlah_bayar` DECIMAL(15,2) DEFAULT 0.00,
  `sisa_piutang` DECIMAL(15,2) DEFAULT 0.00,
  `jatuh_tempo` VARCHAR(50) DEFAULT NULL,
  `tampilkan_nominal` TINYINT(1) DEFAULT 1,
  `items_json` LONGTEXT DEFAULT NULL,
  `signature_admin_json` LONGTEXT DEFAULT NULL,
  `signature_supervisor_json` LONGTEXT DEFAULT NULL,
  `created_at` VARCHAR(50) DEFAULT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`nomor_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur tabel `surat_jalan`
--
DROP TABLE IF EXISTS `surat_jalan`;
CREATE TABLE `surat_jalan` (
  `nomor_sj` VARCHAR(50) NOT NULL,
  `tanggal` VARCHAR(50) NOT NULL,
  `gudang_id` VARCHAR(50) NOT NULL,
  `gudang_nama` VARCHAR(100) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `tujuan` VARCHAR(150) NOT NULL,
  `penerima` VARCHAR(150) NOT NULL,
  `driver` VARCHAR(150) DEFAULT NULL,
  `kendaraan` VARCHAR(100) DEFAULT NULL,
  `catatan` TEXT DEFAULT NULL,
  `tampilkan_nominal` TINYINT(1) DEFAULT 0,
  `total_nominal` DECIMAL(15,2) DEFAULT 0.00,
  `items_json` LONGTEXT DEFAULT NULL,
  `signature_pengirim_json` LONGTEXT DEFAULT NULL,
  `signature_driver_json` LONGTEXT DEFAULT NULL,
  `signature_penerima_json` LONGTEXT DEFAULT NULL,
  `created_at` VARCHAR(50) DEFAULT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`nomor_sj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur tabel `log_transaksi`
--
DROP TABLE IF EXISTS `log_transaksi`;
CREATE TABLE `log_transaksi` (
  `id` INT AUTO_INCREMENT NOT NULL,
  `timestamp` VARCHAR(50) NOT NULL,
  `transaksi_id` VARCHAR(50) NOT NULL,
  `sku_id` VARCHAR(100) NOT NULL,
  `gudang_id` VARCHAR(50) NOT NULL,
  `jumlah` INT NOT NULL,
  `tipe_transaksi` VARCHAR(50) NOT NULL,
  `users` VARCHAR(100) NOT NULL,
  `keterangan` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_transaksi_id` (`transaksi_id`),
  KEY `idx_sku_id` (`sku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur tabel `app_settings`
--
DROP TABLE IF EXISTS `app_settings`;
CREATE TABLE `app_settings` (
  `id` VARCHAR(50) NOT NULL,
  `settings_json` LONGTEXT NOT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data awal `app_settings`
--
INSERT INTO `app_settings` (`id`, `settings_json`) VALUES
('default', '{"brandName":"DISTRO KAOS POLOS PREMIUM","companySubtitle":"Spesialis Grosir & Eceran Cotton Combed Berkualitas","companyAddress":"Jl. Terusan Buah Batu No. 120, Kota Bandung, Jawa Barat 40287","companyPhone":"0812-3456-7890 / (022) 7501234","companyEmail":"info@distrokaospolos.com","defaultReorderLevel":15,"skuPrefix":"KPCM","barcodeFormat":"CODE128","labelPaperSize":"A4_40_LABELS","enableAutoBarcode":true,"enableStockWarningSound":true,"invoiceHeaderColor":"#7e22ce"}');

-- --------------------------------------------------------

--
-- Struktur tabel `app_users`
--
DROP TABLE IF EXISTS `app_users`;
CREATE TABLE `app_users` (
  `id` VARCHAR(50) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(150) NOT NULL,
  `role` VARCHAR(50) NOT NULL,
  `site_access` VARCHAR(100) NOT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `phone` VARCHAR(50) DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `created_at` VARCHAR(50) DEFAULT NULL,
  `last_login` VARCHAR(50) DEFAULT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data awal `app_users`
--
INSERT INTO `app_users` (`id`, `username`, `password`, `full_name`, `role`, `site_access`, `is_active`, `phone`, `email`, `created_at`, `last_login`) VALUES
('USR-000', 'owner', 'owner123', 'Ko Gunawan (Owner / Pemilik)', 'OWNER', 'SEMUA GUDANG', 1, '0812-9999-8888', 'owner@distrokaos.com', '2026-01-01T07:00:00.000Z', '2026-03-17T10:00:00.000Z'),
('USR-001', 'admin1', 'admin1', 'Budi Santoso (Admin Gudang Utama)', 'ADMIN', 'GUDANG UTAMA', 1, '0812-1111-2222', 'admin1@distrokaos.com', '2026-01-10T08:00:00.000Z', '2026-03-17T09:15:00.000Z'),
('USR-002', 'admin2', 'admin2', 'Siti Rahmawati (Admin Toko)', 'ADMIN', 'GUDANG TOKO', 1, '0812-3333-4444', 'admin2@distrokaos.com', '2026-01-12T08:30:00.000Z', '2026-03-17T08:45:00.000Z'),
('USR-003', 'supervisor', 'super123', 'Hendra Gunawan (Manager Logistik)', 'SUPERVISOR', 'SEMUA GUDANG', 1, '0812-5555-6666', 'supervisor@distrokaos.com', '2026-01-05T07:00:00.000Z', '2026-03-16T17:00:00.000Z'),
('USR-004', 'staff1', 'staff1', 'Dedi Kurniawan (Staff Gudang)', 'STAFF', 'GUDANG UTAMA', 1, '0812-7777-8888', 'staff1@distrokaos.com', '2026-01-20T08:00:00.000Z', '2026-03-16T16:30:00.000Z');

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
