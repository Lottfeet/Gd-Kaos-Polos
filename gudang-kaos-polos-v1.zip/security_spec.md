# Security Specification: Inventory & Point-of-Sale System

## 1. System Invariants & RBAC Architecture
- **Identity & Verification**: Only authenticated users with verified Google or system credentials can perform mutations on production business records.
- **Admin Privilege Escalation Guard**: Roles cannot be self-assigned. Administrative privileges (`isAdmin()`) are verified via trusted database lookups in `/admins/$(request.auth.uid)` or verified bootstrap admin (`ervoprint@gmail.com`).
- **Data Immortality & Integrity**: Critical identifiers (`SKU_ID`, `GUDANG_ID`, `nomorSale`, `nomorOrder`, `nomorSJ`, `id`) and creation timestamps are immutable post-creation.
- **Relational Consistency**: Sales invoices and inventory logs must reference valid warehouse and item records.

## 2. The "Dirty Dozen" Payloads (Must Return PERMISSION_DENIED)
1. **Unauthenticated Read on Admin Collection**: An unauthenticated user attempts to read `/admins/xyz`.
2. **Unauthenticated Write on Products**: An unauthenticated client attempts `create` on `/products/SKU-MALICIOUS`.
3. **Ghost Field Injection (Shadow Update)**: A standard user attempts to patch `/products/SKU-001` with an unapproved key `{ isSuperAdmin: true }`.
4. **Self-Promotion to Admin**: A non-admin user attempts `setDoc` on `/admins/$(request.auth.uid)`.
5. **ID Poisoning Attack**: An attacker sends a 1500-byte string as a document ID containing path traversal characters (`../`).
6. **Negative Inventory Manipulation**: An attacker attempts to write negative `JUMLAH_READY: -999999` to cause an integer underflow.
7. **Negative Price / Fraudulent Sale**: An attacker writes `totalNominal: -500000` to simulate a fraudulent refund or credit extraction.
8. **Tampering with Past Invoices**: Attempting to alter `nomorSale` or `createdAt` on an existing sales invoice.
9. **Email Spoofing without Verification**: A user with unverified email attempts to issue write operations relying on the admin email token claim.
10. **Overwriting System Settings by Non-Admin**: A standard authenticated user attempts to overwrite `/app_settings/main`.
11. **Malicious Log Erasure**: An attacker attempts `deleteDoc` on an audit trail log in `/logs/{logId}`.
12. **Customer Identity Hijack**: A standard user attempts to alter the primary ID key of another registered customer profile.

## 3. Red Team Validation Strategy
Every rule must enforce:
- `request.auth != null`
- Document ID regex matching `^[a-zA-Z0-9_\-]+$` and length constraints (<= 128 chars).
- Validation helpers for every entity preventing extra ghost keys and type/boundary violations.
- Immutable field guards during updates.
- Complete restriction on deleting audit logs (`allow delete: if false`).
