import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Database configuration with environment variables and defaults for XAMPP / phpMyAdmin
const configFilePath = path.join(__dirname, '.dbconfig.json');
let savedConfig: any = {};
try {
  if (fs.existsSync(configFilePath)) {
    savedConfig = JSON.parse(fs.readFileSync(configFilePath, 'utf-8'));
  }
} catch {}

let dbConfig = {
  host: savedConfig.host || process.env.DB_HOST || 'localhost',
  port: parseInt(savedConfig.port || process.env.DB_PORT || '3306', 10),
  user: savedConfig.user || process.env.DB_USER || 'root',
  password: savedConfig.password !== undefined ? savedConfig.password : (process.env.DB_PASSWORD || ''),
  database: savedConfig.database || process.env.DB_NAME || 'db_kaospolos',
  bridgeUrl: savedConfig.bridgeUrl || process.env.DB_BRIDGE_URL || '',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  connectTimeout: 4000,
};

let pool: mysql.Pool | null = null;
let lastDbError: string | null = null;
let isDbConnected = false;

function getPool(): mysql.Pool {
  if (!pool) {
    pool = mysql.createPool(dbConfig);
  }
  return pool;
}

// Automatically create database and tables if MySQL is running
async function initDatabaseSchema() {
  try {
    // 1. First connect without database name to ensure DB exists
    const rootConn = await mysql.createConnection({
      host: dbConfig.host,
      port: dbConfig.port,
      user: dbConfig.user,
      password: dbConfig.password,
      connectTimeout: 4000,
    });

    await rootConn.query(
      `CREATE DATABASE IF NOT EXISTS \`${dbConfig.database}\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`
    );
    await rootConn.end();

    // 2. Connect to the database and ensure tables exist
    const p = getPool();
    await p.query(`
      CREATE TABLE IF NOT EXISTS \`master_gudang\` (
        \`gudang_id\` VARCHAR(50) NOT NULL PRIMARY KEY,
        \`nama_gudang\` VARCHAR(100) NOT NULL,
        \`lokasi\` VARCHAR(255) DEFAULT NULL,
        \`penanggung_jawab\` VARCHAR(100) DEFAULT NULL,
        \`is_active\` TINYINT(1) DEFAULT 1,
        \`is_default\` TINYINT(1) DEFAULT 0,
        \`telepon\` VARCHAR(50) DEFAULT NULL,
        \`keterangan\` TEXT DEFAULT NULL,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await p.query(`
      CREATE TABLE IF NOT EXISTS \`master_produk\` (
        \`sku_id\` VARCHAR(100) NOT NULL PRIMARY KEY,
        \`nama_produk\` VARCHAR(255) NOT NULL,
        \`warna\` VARCHAR(100) DEFAULT NULL,
        \`ukuran\` VARCHAR(50) DEFAULT NULL,
        \`kategori\` VARCHAR(100) DEFAULT NULL,
        \`jenis_lengan\` VARCHAR(50) DEFAULT 'PENDEK',
        \`reorder_level\` INT DEFAULT 10,
        \`barcode_id\` VARCHAR(100) DEFAULT NULL,
        \`harga_hpp\` DECIMAL(15,2) DEFAULT 0.00,
        \`harga_jual\` DECIMAL(15,2) DEFAULT 0.00,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await p.query(`
      CREATE TABLE IF NOT EXISTS \`inventori\` (
        \`id\` VARCHAR(150) NOT NULL PRIMARY KEY,
        \`gudang_id\` VARCHAR(50) NOT NULL,
        \`sku_id\` VARCHAR(100) NOT NULL,
        \`nama_produk\` VARCHAR(255) NOT NULL,
        \`jumlah_ready\` INT DEFAULT 0,
        \`reorder_level\` INT DEFAULT 10,
        \`reorder\` VARCHAR(10) DEFAULT 'NO',
        \`order_date\` VARCHAR(50) DEFAULT NULL,
        \`warna\` VARCHAR(100) DEFAULT NULL,
        \`ukuran\` VARCHAR(50) DEFAULT NULL,
        \`kategori\` VARCHAR(100) DEFAULT NULL,
        \`jenis_lengan\` VARCHAR(50) DEFAULT NULL,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY \`uk_gudang_sku\` (\`gudang_id\`, \`sku_id\`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await p.query(`
      CREATE TABLE IF NOT EXISTS \`pelanggan\` (
        \`id\` VARCHAR(50) NOT NULL PRIMARY KEY,
        \`nama\` VARCHAR(150) NOT NULL,
        \`telepon\` VARCHAR(50) DEFAULT NULL,
        \`alamat\` TEXT DEFAULT NULL,
        \`kota\` VARCHAR(100) DEFAULT NULL,
        \`tipe\` VARCHAR(50) DEFAULT 'UMUM',
        \`plafon_piutang\` DECIMAL(15,2) DEFAULT 0.00,
        \`catatan\` TEXT DEFAULT NULL,
        \`created_at\` VARCHAR(50) DEFAULT NULL,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await p.query(`
      CREATE TABLE IF NOT EXISTS \`transaksi_penjualan\` (
        \`nomor_sale\` VARCHAR(50) NOT NULL PRIMARY KEY,
        \`tanggal\` VARCHAR(50) NOT NULL,
        \`gudang_id\` VARCHAR(50) NOT NULL,
        \`gudang_nama\` VARCHAR(100) NOT NULL,
        \`username\` VARCHAR(100) NOT NULL,
        \`pelanggan\` VARCHAR(150) NOT NULL,
        \`pelanggan_id\` VARCHAR(50) DEFAULT NULL,
        \`tipe_pelanggan\` VARCHAR(50) DEFAULT NULL,
        \`kontak\` VARCHAR(50) DEFAULT NULL,
        \`alamat\` TEXT DEFAULT NULL,
        \`metode\` VARCHAR(50) DEFAULT NULL,
        \`catatan\` TEXT DEFAULT NULL,
        \`subtotal_nominal\` DECIMAL(15,2) DEFAULT 0.00,
        \`diskon_nominal\` DECIMAL(15,2) DEFAULT 0.00,
        \`total_nominal\` DECIMAL(15,2) DEFAULT 0.00,
        \`status_pembayaran\` VARCHAR(30) DEFAULT 'LUNAS',
        \`jumlah_bayar\` DECIMAL(15,2) DEFAULT 0.00,
        \`sisa_piutang\` DECIMAL(15,2) DEFAULT 0.00,
        \`jatuh_tempo\` VARCHAR(50) DEFAULT NULL,
        \`items_json\` LONGTEXT DEFAULT NULL,
        \`riwayat_pelunasan_json\` LONGTEXT DEFAULT NULL,
        \`created_at\` VARCHAR(50) DEFAULT NULL,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await p.query(`
      CREATE TABLE IF NOT EXISTS \`order_po\` (
        \`nomor_order\` VARCHAR(50) NOT NULL PRIMARY KEY,
        \`tanggal\` VARCHAR(50) NOT NULL,
        \`gudang_id\` VARCHAR(50) NOT NULL,
        \`gudang_nama\` VARCHAR(100) NOT NULL,
        \`username\` VARCHAR(100) NOT NULL,
        \`supplier\` VARCHAR(150) NOT NULL,
        \`kontak\` VARCHAR(50) DEFAULT NULL,
        \`alamat\` TEXT DEFAULT NULL,
        \`metode\` VARCHAR(50) DEFAULT NULL,
        \`catatan\` TEXT DEFAULT NULL,
        \`subtotal_nominal\` DECIMAL(15,2) DEFAULT 0.00,
        \`diskon_nominal\` DECIMAL(15,2) DEFAULT 0.00,
        \`total_nominal\` DECIMAL(15,2) DEFAULT 0.00,
        \`status_pembayaran\` VARCHAR(30) DEFAULT 'LUNAS',
        \`jumlah_bayar\` DECIMAL(15,2) DEFAULT 0.00,
        \`sisa_piutang\` DECIMAL(15,2) DEFAULT 0.00,
        \`jatuh_tempo\` VARCHAR(50) DEFAULT NULL,
        \`tampilkan_nominal\` TINYINT(1) DEFAULT 1,
        \`items_json\` LONGTEXT DEFAULT NULL,
        \`signature_admin_json\` LONGTEXT DEFAULT NULL,
        \`signature_supervisor_json\` LONGTEXT DEFAULT NULL,
        \`created_at\` VARCHAR(50) DEFAULT NULL,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await p.query(`
      CREATE TABLE IF NOT EXISTS \`surat_jalan\` (
        \`nomor_sj\` VARCHAR(50) NOT NULL PRIMARY KEY,
        \`tanggal\` VARCHAR(50) NOT NULL,
        \`gudang_id\` VARCHAR(50) NOT NULL,
        \`gudang_nama\` VARCHAR(100) NOT NULL,
        \`username\` VARCHAR(100) NOT NULL,
        \`tujuan\` VARCHAR(150) NOT NULL,
        \`penerima\` VARCHAR(150) NOT NULL,
        \`driver\` VARCHAR(150) DEFAULT NULL,
        \`kendaraan\` VARCHAR(100) DEFAULT NULL,
        \`catatan\` TEXT DEFAULT NULL,
        \`tampilkan_nominal\` TINYINT(1) DEFAULT 0,
        \`total_nominal\` DECIMAL(15,2) DEFAULT 0.00,
        \`items_json\` LONGTEXT DEFAULT NULL,
        \`signature_pengirim_json\` LONGTEXT DEFAULT NULL,
        \`signature_driver_json\` LONGTEXT DEFAULT NULL,
        \`signature_penerima_json\` LONGTEXT DEFAULT NULL,
        \`created_at\` VARCHAR(50) DEFAULT NULL,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await p.query(`
      CREATE TABLE IF NOT EXISTS \`log_transaksi\` (
        \`id\` INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
        \`timestamp\` VARCHAR(50) NOT NULL,
        \`transaksi_id\` VARCHAR(50) NOT NULL,
        \`sku_id\` VARCHAR(100) NOT NULL,
        \`gudang_id\` VARCHAR(50) NOT NULL,
        \`jumlah\` INT NOT NULL,
        \`tipe_transaksi\` VARCHAR(50) NOT NULL,
        \`users\` VARCHAR(100) NOT NULL,
        \`keterangan\` TEXT DEFAULT NULL,
        \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await p.query(`
      CREATE TABLE IF NOT EXISTS \`app_settings\` (
        \`id\` VARCHAR(50) NOT NULL PRIMARY KEY,
        \`settings_json\` LONGTEXT NOT NULL,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await p.query(`
      CREATE TABLE IF NOT EXISTS \`app_users\` (
        \`id\` VARCHAR(50) NOT NULL PRIMARY KEY,
        \`username\` VARCHAR(100) NOT NULL,
        \`password\` VARCHAR(255) NOT NULL,
        \`full_name\` VARCHAR(150) NOT NULL,
        \`role\` VARCHAR(50) NOT NULL,
        \`site_access\` VARCHAR(100) NOT NULL,
        \`is_active\` TINYINT(1) DEFAULT 1,
        \`phone\` VARCHAR(50) DEFAULT NULL,
        \`email\` VARCHAR(100) DEFAULT NULL,
        \`created_at\` VARCHAR(50) DEFAULT NULL,
        \`last_login\` VARCHAR(50) DEFAULT NULL,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY \`uk_username\` (\`username\`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    isDbConnected = true;
    lastDbError = null;
    return true;
  } catch (err: any) {
    isDbConnected = false;
    lastDbError = err.message || 'Gagal tersambung ke MySQL';
    return false;
  }
}

// -------------------------------------------------------------
// REST API ROUTES
// -------------------------------------------------------------

// Health check
app.get('/healthz', (_req, res) => {
  res.status(200).send('OK');
});

// MySQL Connection Status & Table Counts
app.get('/api/db/status', async (_req, res) => {
  // 1. If PHP bridge is configured, try bridge first
  if (dbConfig.bridgeUrl) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);
      const bridgeRes = await fetch(`${dbConfig.bridgeUrl}${dbConfig.bridgeUrl.includes('?') ? '&' : '?'}action=status`, {
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (bridgeRes.ok) {
        const bridgeData: any = await bridgeRes.json();
        return res.json({
          connected: true,
          type: 'bridge',
          bridgeUrl: dbConfig.bridgeUrl,
          host: dbConfig.host,
          port: dbConfig.port,
          user: dbConfig.user,
          database: dbConfig.database,
          tableCounts: bridgeData.tableCounts || {},
          error: null,
          message: 'Terhubung melalui PHP Web Bridge (cPanel phpMyAdmin)',
        });
      }
    } catch (bridgeErr: any) {
      console.warn('Bridge check failed, falling back to direct MySQL:', bridgeErr.message);
    }
  }

  // 2. Direct MySQL connection
  try {
    const isReady = await initDatabaseSchema();
    if (!isReady) {
      return res.json({
        connected: false,
        type: 'direct',
        host: dbConfig.host,
        port: dbConfig.port,
        user: dbConfig.user,
        database: dbConfig.database,
        bridgeUrl: dbConfig.bridgeUrl,
        error: lastDbError,
        tableCounts: {},
      });
    }

    const p = getPool();
    const countTable = async (table: string): Promise<number> => {
      try {
        const [rows]: any = await p.query(`SELECT COUNT(*) as cnt FROM \`${table}\``);
        return rows[0]?.cnt || 0;
      } catch {
        return 0;
      }
    };

    const tableCounts = {
      products: await countTable('master_produk'),
      inventory: await countTable('inventori'),
      warehouses: await countTable('master_gudang'),
      customers: await countTable('pelanggan'),
      sales: await countTable('transaksi_penjualan'),
      orders: await countTable('order_po'),
      suratJalanList: await countTable('surat_jalan'),
      logs: await countTable('log_transaksi'),
      users: await countTable('app_users'),
    };

    res.json({
      connected: true,
      type: 'direct',
      host: dbConfig.host,
      port: dbConfig.port,
      user: dbConfig.user,
      database: dbConfig.database,
      bridgeUrl: dbConfig.bridgeUrl,
      tableCounts,
      error: null,
    });
  } catch (err: any) {
    res.json({
      connected: false,
      type: 'direct',
      host: dbConfig.host,
      port: dbConfig.port,
      user: dbConfig.user,
      database: dbConfig.database,
      bridgeUrl: dbConfig.bridgeUrl,
      error: err.message,
      tableCounts: {},
    });
  }
});

// Configure MySQL parameters dynamically
app.post('/api/db/configure', async (req, res) => {
  const { host, port: pPort, user, password, database, bridgeUrl } = req.body;
  if (host) dbConfig.host = host;
  if (pPort) dbConfig.port = parseInt(pPort, 10);
  if (user !== undefined) dbConfig.user = user;
  if (password !== undefined) dbConfig.password = password;
  if (database) dbConfig.database = database;
  if (bridgeUrl !== undefined) dbConfig.bridgeUrl = bridgeUrl.trim();

  // Save to persistent file
  try {
    fs.writeFileSync(
      configFilePath,
      JSON.stringify(
        {
          host: dbConfig.host,
          port: dbConfig.port,
          user: dbConfig.user,
          password: dbConfig.password,
          database: dbConfig.database,
          bridgeUrl: dbConfig.bridgeUrl,
        },
        null,
        2
      )
    );
  } catch (e) {
    console.warn('Failed to persist db config:', e);
  }

  // If bridgeUrl is provided, test it
  if (dbConfig.bridgeUrl) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);
      const bridgeRes = await fetch(`${dbConfig.bridgeUrl}${dbConfig.bridgeUrl.includes('?') ? '&' : '?'}action=status`, {
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (bridgeRes.ok) {
        const bridgeData: any = await bridgeRes.json();
        return res.json({
          connected: true,
          type: 'bridge',
          bridgeUrl: dbConfig.bridgeUrl,
          host: dbConfig.host,
          port: dbConfig.port,
          user: dbConfig.user,
          database: dbConfig.database,
          tableCounts: bridgeData.tableCounts || {},
          error: null,
          message: 'Berhasil terhubung melalui PHP Web Bridge!',
        });
      }
    } catch (bErr: any) {
      console.warn('Bridge configure test failed:', bErr.message);
    }
  }

  // Reset pool for direct MySQL
  if (pool) {
    await pool.end().catch(() => {});
    pool = null;
  }

  const ok = await initDatabaseSchema();
  res.json({
    connected: ok,
    type: 'direct',
    host: dbConfig.host,
    port: dbConfig.port,
    user: dbConfig.user,
    database: dbConfig.database,
    bridgeUrl: dbConfig.bridgeUrl,
    error: lastDbError,
  });
});

// Download SQL dump for phpMyAdmin
app.get('/api/db/download-sql', (_req, res) => {
  const sqlPath = path.join(__dirname, 'public', 'database_kaospolos.sql');
  if (fs.existsSync(sqlPath)) {
    res.setHeader('Content-Disposition', 'attachment; filename="database_kaospolos.sql"');
    res.setHeader('Content-Type', 'application/sql');
    return fs.createReadStream(sqlPath).pipe(res);
  }
  res.status(404).json({ error: 'File SQL tidak ditemukan' });
});

// Download PHP Bridge for cPanel
app.get('/api/db/download-bridge', (_req, res) => {
  const bridgePath = path.join(__dirname, 'public', 'api.php');
  if (fs.existsSync(bridgePath)) {
    res.setHeader('Content-Disposition', 'attachment; filename="api.php"');
    res.setHeader('Content-Type', 'application/x-httpd-php');
    return fs.createReadStream(bridgePath).pipe(res);
  }
  res.status(404).json({ error: 'File api.php tidak ditemukan' });
});

// Pull all data from MySQL tables to sync frontend
app.get('/api/db/pull-all', async (_req, res) => {
  // If bridgeUrl is configured and direct MySQL is not ready, try bridge
  if (dbConfig.bridgeUrl) {
    try {
      const bridgeRes = await fetch(`${dbConfig.bridgeUrl}${dbConfig.bridgeUrl.includes('?') ? '&' : '?'}action=pull-all`, {
        signal: AbortSignal.timeout(10000),
      });
      if (bridgeRes.ok) {
        const bridgeData: any = await bridgeRes.json();
        if (bridgeData.success && bridgeData.data) {
          return res.json({
            success: true,
            source: 'bridge',
            counts: {
              products: bridgeData.data.products?.length || 0,
              inventory: bridgeData.data.inventory?.length || 0,
              warehouses: bridgeData.data.warehouses?.length || 0,
              customers: bridgeData.data.customers?.length || 0,
              sales: bridgeData.data.sales?.length || 0,
              orders: bridgeData.data.orders?.length || 0,
              suratJalanList: bridgeData.data.suratJalanList?.length || 0,
              logs: bridgeData.data.logs?.length || 0,
            },
            data: bridgeData.data,
          });
        }
      }
    } catch (bErr: any) {
      console.warn('Bridge pull-all failed, trying direct MySQL:', bErr.message);
    }
  }

  try {
    const isReady = await initDatabaseSchema();
    if (!isReady) {
      return res.status(503).json({
        success: false,
        error: `Database MySQL tidak aktif (${lastDbError || 'Gagal koneksi'}). Pastikan MySQL berjalan di phpMyAdmin / hosting.`,
      });
    }

    const p = getPool();

    // 1. Products
    const [productsRows]: any = await p.query('SELECT * FROM `master_produk`');
    const products = productsRows.map((r: any) => ({
      SKU_ID: r.sku_id,
      NAMA_PRODUK: r.nama_produk,
      WARNA: r.warna,
      UKURAN: r.ukuran,
      KATEGORI: r.kategori,
      JENIS_LENGAN: r.jenis_lengan,
      REORDER_LEVEL: Number(r.reorder_level) || 0,
      BARCODE_ID: r.barcode_id || undefined,
      HARGA_HPP: r.harga_hpp ? Number(r.harga_hpp) : 0,
      HARGA_JUAL: r.harga_jual ? Number(r.harga_jual) : 0,
    }));

    // 2. Inventory
    const [invRows]: any = await p.query('SELECT * FROM `inventori`');
    const inventory = invRows.map((r: any) => ({
      GUDANG_ID: r.gudang_id,
      SKU_ID: r.sku_id,
      NAMA_PRODUK: r.nama_produk,
      JUMLAH_READY: Number(r.jumlah_ready) || 0,
      REORDER_LEVEL: Number(r.reorder_level) || 0,
      REORDER: (r.reorder || 'NO') as 'YES' | 'NO',
      ORDER_DATE: r.order_date || undefined,
      WARNA: r.warna || undefined,
      UKURAN: r.ukuran || undefined,
      KATEGORI: r.kategori || undefined,
      JENIS_LENGAN: r.jenis_lengan || undefined,
    }));

    // 3. Warehouses
    const [whRows]: any = await p.query('SELECT * FROM `master_gudang`');
    const warehouses = whRows.map((r: any) => ({
      GUDANG_ID: r.gudang_id,
      NAMA_GUDANG: r.nama_gudang,
      LOKASI: r.lokasi || '',
      PENANGGUNG_JAWAB: r.penanggung_jawab || '',
      IS_ACTIVE: Boolean(r.is_active),
      IS_DEFAULT: Boolean(r.is_default),
      TELEPON: r.telepon || '',
      KETERANGAN: r.keterangan || '',
    }));

    // 4. Customers
    const [custRows]: any = await p.query('SELECT * FROM `pelanggan`');
    const customers = custRows.map((r: any) => ({
      id: r.id,
      nama: r.nama,
      telepon: r.telepon || '',
      alamat: r.alamat || '',
      kota: r.kota || '',
      tipe: r.tipe || 'UMUM',
      plafonPiutang: r.plafon_piutang ? Number(r.plafon_piutang) : 0,
      catatan: r.catatan || '',
      createdAt: r.created_at || new Date().toISOString(),
    }));

    // 5. Sales
    const [salesRows]: any = await p.query('SELECT * FROM `transaksi_penjualan` ORDER BY `created_at` DESC');
    const sales = salesRows.map((r: any) => {
      let items = [];
      let riwayatPelunasan = [];
      try {
        items = r.items_json ? JSON.parse(r.items_json) : [];
      } catch {}
      try {
        riwayatPelunasan = r.riwayat_pelunasan_json ? JSON.parse(r.riwayat_pelunasan_json) : [];
      } catch {}

      return {
        nomorSale: r.nomor_sale,
        tanggal: r.tanggal,
        gudangId: r.gudang_id,
        gudangNama: r.gudang_nama,
        username: r.username,
        pelanggan: r.pelanggan,
        pelangganId: r.pelanggan_id || undefined,
        tipePelanggan: r.tipe_pelanggan || undefined,
        kontak: r.kontak || '',
        alamat: r.alamat || '',
        metode: r.metode || 'TUNAI',
        catatan: r.catatan || '',
        subtotalNominal: r.subtotal_nominal ? Number(r.subtotal_nominal) : 0,
        diskonNominal: r.diskon_nominal ? Number(r.diskon_nominal) : 0,
        totalNominal: r.total_nominal ? Number(r.total_nominal) : 0,
        statusPembayaran: r.status_pembayaran || 'LUNAS',
        jumlahBayar: r.jumlah_bayar ? Number(r.jumlah_bayar) : 0,
        sisaPiutang: r.sisa_piutang ? Number(r.sisa_piutang) : 0,
        jatuhTempo: r.jatuh_tempo || undefined,
        items,
        riwayatPelunasan,
        createdAt: r.created_at || r.tanggal,
      };
    });

    // 6. Orders (PO)
    const [orderRows]: any = await p.query('SELECT * FROM `order_po` ORDER BY `created_at` DESC');
    const orders = orderRows.map((r: any) => {
      let items = [];
      let signatureAdmin = undefined;
      let signatureSupervisor = undefined;
      try {
        items = r.items_json ? JSON.parse(r.items_json) : [];
      } catch {}
      try {
        signatureAdmin = r.signature_admin_json ? JSON.parse(r.signature_admin_json) : undefined;
      } catch {}
      try {
        signatureSupervisor = r.signature_supervisor_json ? JSON.parse(r.signature_supervisor_json) : undefined;
      } catch {}

      return {
        nomorOrder: r.nomor_order,
        tanggal: r.tanggal,
        gudangId: r.gudang_id,
        gudangNama: r.gudang_nama,
        username: r.username,
        supplier: r.supplier,
        kontak: r.kontak || '',
        alamat: r.alamat || '',
        metode: r.metode || '',
        catatan: r.catatan || '',
        subtotalNominal: r.subtotal_nominal ? Number(r.subtotal_nominal) : 0,
        diskonNominal: r.diskon_nominal ? Number(r.diskon_nominal) : 0,
        totalNominal: r.total_nominal ? Number(r.total_nominal) : 0,
        statusPembayaran: r.status_pembayaran || 'LUNAS',
        jumlahBayar: r.jumlah_bayar ? Number(r.jumlah_bayar) : 0,
        sisaPiutang: r.sisa_piutang ? Number(r.sisa_piutang) : 0,
        jatuhTempo: r.jatuh_tempo || undefined,
        tampilkanNominal: Boolean(r.tampilkan_nominal),
        items,
        signatureAdmin,
        signatureSupervisor,
        createdAt: r.created_at || r.tanggal,
      };
    });

    // 7. Surat Jalan
    const [sjRows]: any = await p.query('SELECT * FROM `surat_jalan` ORDER BY `created_at` DESC');
    const suratJalanList = sjRows.map((r: any) => {
      let items = [];
      let signaturePengirim = undefined;
      let signatureDriver = undefined;
      let signaturePenerima = undefined;
      try {
        items = r.items_json ? JSON.parse(r.items_json) : [];
      } catch {}
      try {
        signaturePengirim = r.signature_pengirim_json ? JSON.parse(r.signature_pengirim_json) : undefined;
      } catch {}
      try {
        signatureDriver = r.signature_driver_json ? JSON.parse(r.signature_driver_json) : undefined;
      } catch {}
      try {
        signaturePenerima = r.signature_penerima_json ? JSON.parse(r.signature_penerima_json) : undefined;
      } catch {}

      return {
        nomorSJ: r.nomor_sj,
        tanggal: r.tanggal,
        gudangId: r.gudang_id,
        gudangNama: r.gudang_nama,
        username: r.username,
        tujuan: r.tujuan,
        penerima: r.penerima,
        driver: r.driver || '',
        kendaraan: r.kendaraan || '',
        catatan: r.catatan || '',
        tampilkanNominal: Boolean(r.tampilkan_nominal),
        totalNominal: r.total_nominal ? Number(r.total_nominal) : 0,
        items,
        signaturePengirim,
        signatureDriver,
        signaturePenerima,
        createdAt: r.created_at || r.tanggal,
      };
    });

    // 8. Logs
    const [logsRows]: any = await p.query('SELECT * FROM `log_transaksi` ORDER BY `id` DESC LIMIT 500');
    const logs = logsRows.map((r: any) => ({
      TIMESTAMP: r.timestamp,
      TRANSAKSI_ID: r.transaksi_id,
      SKU_ID: r.sku_id,
      GUDANG_ID: r.gudang_id,
      JUMLAH: Number(r.jumlah) || 0,
      TIPE_TRANSAKSI: r.tipe_transaksi,
      USERS: r.users,
      KETERANGAN: r.keterangan || '',
    }));

    // 9. Settings
    const [settingsRows]: any = await p.query('SELECT `settings_json` FROM `app_settings` WHERE `id` = "default" LIMIT 1');
    let settings = null;
    if (settingsRows.length > 0 && settingsRows[0].settings_json) {
      try {
        settings = JSON.parse(settingsRows[0].settings_json);
      } catch {}
    }

    // 10. Users
    const [userRows]: any = await p.query('SELECT * FROM `app_users`');
    const users = userRows.map((r: any) => ({
      id: r.id,
      username: r.username,
      password: r.password,
      fullName: r.full_name,
      role: r.role,
      siteAccess: r.site_access,
      isActive: Boolean(r.is_active),
      phone: r.phone || '',
      email: r.email || '',
      createdAt: r.created_at,
      lastLogin: r.last_login || undefined,
    }));

    const counts = {
      products: products.length,
      inventory: inventory.length,
      warehouses: warehouses.length,
      customers: customers.length,
      sales: sales.length,
      orders: orders.length,
      suratJalanList: suratJalanList.length,
      logs: logs.length,
      users: users.length,
    };

    res.json({
      success: true,
      counts,
      data: {
        products,
        inventory,
        warehouses,
        customers,
        sales,
        orders,
        suratJalanList,
        logs,
        settings: settings || undefined,
        users,
      },
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: err.message,
    });
  }
});

// Bulk Push all data from frontend into MySQL tables
app.post('/api/db/push-all', async (req, res) => {
  // If bridgeUrl is configured and direct MySQL is not ready, push via bridge
  if (dbConfig.bridgeUrl) {
    try {
      const bridgeRes = await fetch(`${dbConfig.bridgeUrl}${dbConfig.bridgeUrl.includes('?') ? '&' : '?'}action=push-all`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
        signal: AbortSignal.timeout(15000),
      });
      if (bridgeRes.ok) {
        const bridgeData: any = await bridgeRes.json();
        return res.json(bridgeData);
      }
    } catch (bErr: any) {
      console.warn('Bridge push-all failed, trying direct MySQL:', bErr.message);
    }
  }

  try {
    const isReady = await initDatabaseSchema();
    if (!isReady) {
      return res.status(503).json({
        success: false,
        error: `Database MySQL tidak aktif (${lastDbError || 'Gagal koneksi'}).`,
      });
    }

    const {
      products = [],
      inventory = [],
      warehouses = [],
      customers = [],
      sales = [],
      orders = [],
      suratJalanList = [],
      logs = [],
      settings = null,
      users = [],
    } = req.body;

    const p = getPool();
    let totalUpserted = 0;

    // 1. Warehouses
    for (const w of warehouses) {
      await p.query(
        `INSERT INTO \`master_gudang\` (\`gudang_id\`, \`nama_gudang\`, \`lokasi\`, \`penanggung_jawab\`, \`is_active\`, \`is_default\`, \`telepon\`, \`keterangan\`)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
         \`nama_gudang\`=VALUES(\`nama_gudang\`), \`lokasi\`=VALUES(\`lokasi\`), \`penanggung_jawab\`=VALUES(\`penanggung_jawab\`), \`is_active\`=VALUES(\`is_active\`), \`is_default\`=VALUES(\`is_default\`), \`telepon\`=VALUES(\`telepon\`), \`keterangan\`=VALUES(\`keterangan\`)`,
        [w.GUDANG_ID, w.NAMA_GUDANG, w.LOKASI || '', w.PENANGGUNG_JAWAB || '', w.IS_ACTIVE ? 1 : 0, w.IS_DEFAULT ? 1 : 0, w.TELEPON || '', w.KETERANGAN || '']
      );
      totalUpserted++;
    }

    // 2. Products
    for (const prod of products) {
      await p.query(
        `INSERT INTO \`master_produk\` (\`sku_id\`, \`nama_produk\`, \`warna\`, \`ukuran\`, \`kategori\`, \`jenis_lengan\`, \`reorder_level\`, \`barcode_id\`, \`harga_hpp\`, \`harga_jual\`)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
         \`nama_produk\`=VALUES(\`nama_produk\`), \`warna\`=VALUES(\`warna\`), \`ukuran\`=VALUES(\`ukuran\`), \`kategori\`=VALUES(\`kategori\`), \`jenis_lengan\`=VALUES(\`jenis_lengan\`), \`reorder_level\`=VALUES(\`reorder_level\`), \`barcode_id\`=VALUES(\`barcode_id\`), \`harga_hpp\`=VALUES(\`harga_hpp\`), \`harga_jual\`=VALUES(\`harga_jual\`)`,
        [prod.SKU_ID, prod.NAMA_PRODUK, prod.WARNA || '', prod.UKURAN || '', prod.KATEGORI || '', prod.JENIS_LENGAN || 'PENDEK', prod.REORDER_LEVEL || 10, prod.BARCODE_ID || null, prod.HARGA_HPP || 0, prod.HARGA_JUAL || 0]
      );
      totalUpserted++;
    }

    // 3. Inventory
    for (const inv of inventory) {
      const id = `${inv.GUDANG_ID}_${inv.SKU_ID}`;
      await p.query(
        `INSERT INTO \`inventori\` (\`id\`, \`gudang_id\`, \`sku_id\`, \`nama_produk\`, \`jumlah_ready\`, \`reorder_level\`, \`reorder\`, \`order_date\`, \`warna\`, \`ukuran\`, \`kategori\`, \`jenis_lengan\`)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
         \`nama_produk\`=VALUES(\`nama_produk\`), \`jumlah_ready\`=VALUES(\`jumlah_ready\`), \`reorder_level\`=VALUES(\`reorder_level\`), \`reorder\`=VALUES(\`reorder\`), \`order_date\`=VALUES(\`order_date\`), \`warna\`=VALUES(\`warna\`), \`ukuran\`=VALUES(\`ukuran\`), \`kategori\`=VALUES(\`kategori\`), \`jenis_lengan\`=VALUES(\`jenis_lengan\`)`,
        [id, inv.GUDANG_ID, inv.SKU_ID, inv.NAMA_PRODUK, inv.JUMLAH_READY || 0, inv.REORDER_LEVEL || 10, inv.REORDER || 'NO', inv.ORDER_DATE || null, inv.WARNA || null, inv.UKURAN || null, inv.KATEGORI || null, inv.JENIS_LENGAN || null]
      );
      totalUpserted++;
    }

    // 4. Customers
    for (const cust of customers) {
      await p.query(
        `INSERT INTO \`pelanggan\` (\`id\`, \`nama\`, \`telepon\`, \`alamat\`, \`kota\`, \`tipe\`, \`plafon_piutang\`, \`catatan\`, \`created_at\`)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
         \`nama\`=VALUES(\`nama\`), \`telepon\`=VALUES(\`telepon\`), \`alamat\`=VALUES(\`alamat\`), \`kota\`=VALUES(\`kota\`), \`tipe\`=VALUES(\`tipe\`), \`plafon_piutang\`=VALUES(\`plafon_piutang\`), \`catatan\`=VALUES(\`catatan\`)`,
        [cust.id, cust.nama, cust.telepon || '', cust.alamat || '', cust.kota || '', cust.tipe || 'UMUM', cust.plafonPiutang || 0, cust.catatan || '', cust.createdAt || new Date().toISOString()]
      );
      totalUpserted++;
    }

    // 5. Sales
    for (const s of sales) {
      await p.query(
        `INSERT INTO \`transaksi_penjualan\` (\`nomor_sale\`, \`tanggal\`, \`gudang_id\`, \`gudang_nama\`, \`username\`, \`pelanggan\`, \`pelanggan_id\`, \`tipe_pelanggan\`, \`kontak\`, \`alamat\`, \`metode\`, \`catatan\`, \`subtotal_nominal\`, \`diskon_nominal\`, \`total_nominal\`, \`status_pembayaran\`, \`jumlah_bayar\`, \`sisa_piutang\`, \`jatuh_tempo\`, \`items_json\`, \`riwayat_pelunasan_json\`, \`created_at\`)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
         \`tanggal\`=VALUES(\`tanggal\`), \`pelanggan\`=VALUES(\`pelanggan\`), \`metode\`=VALUES(\`metode\`), \`subtotal_nominal\`=VALUES(\`subtotal_nominal\`), \`diskon_nominal\`=VALUES(\`diskon_nominal\`), \`total_nominal\`=VALUES(\`total_nominal\`), \`status_pembayaran\`=VALUES(\`status_pembayaran\`), \`jumlah_bayar\`=VALUES(\`jumlah_bayar\`), \`sisa_piutang\`=VALUES(\`sisa_piutang\`), \`items_json\`=VALUES(\`items_json\`), \`riwayat_pelunasan_json\`=VALUES(\`riwayat_pelunasan_json\`)`,
        [
          s.nomorSale,
          s.tanggal,
          s.gudangId,
          s.gudangNama,
          s.username,
          s.pelanggan,
          s.pelangganId || null,
          s.tipePelanggan || null,
          s.kontak || '',
          s.alamat || '',
          s.metode || 'TUNAI',
          s.catatan || '',
          s.subtotalNominal || 0,
          s.diskonNominal || 0,
          s.totalNominal || 0,
          s.statusPembayaran || 'LUNAS',
          s.jumlahBayar || 0,
          s.sisaPiutang || 0,
          s.jatuhTempo || null,
          JSON.stringify(s.items || []),
          JSON.stringify(s.riwayatPelunasan || []),
          s.createdAt || s.tanggal,
        ]
      );
      totalUpserted++;
    }

    // 6. Orders
    for (const o of orders) {
      await p.query(
        `INSERT INTO \`order_po\` (\`nomor_order\`, \`tanggal\`, \`gudang_id\`, \`gudang_nama\`, \`username\`, \`supplier\`, \`kontak\`, \`alamat\`, \`metode\`, \`catatan\`, \`subtotal_nominal\`, \`diskon_nominal\`, \`total_nominal\`, \`status_pembayaran\`, \`jumlah_bayar\`, \`sisa_piutang\`, \`jatuh_tempo\`, \`tampilkan_nominal\`, \`items_json\`, \`signature_admin_json\`, \`signature_supervisor_json\`, \`created_at\`)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
         \`tanggal\`=VALUES(\`tanggal\`), \`supplier\`=VALUES(\`supplier\`), \`total_nominal\`=VALUES(\`total_nominal\`), \`status_pembayaran\`=VALUES(\`status_pembayaran\`), \`items_json\`=VALUES(\`items_json\`)`,
        [
          o.nomorOrder,
          o.tanggal,
          o.gudangId,
          o.gudangNama,
          o.username,
          o.supplier,
          o.kontak || '',
          o.alamat || '',
          o.metode || '',
          o.catatan || '',
          o.subtotalNominal || 0,
          o.diskonNominal || 0,
          o.totalNominal || 0,
          o.statusPembayaran || 'LUNAS',
          o.jumlahBayar || 0,
          o.sisaPiutang || 0,
          o.jatuhTempo || null,
          o.tampilkanNominal ? 1 : 0,
          JSON.stringify(o.items || []),
          JSON.stringify(o.signatureAdmin || null),
          JSON.stringify(o.signatureSupervisor || null),
          o.createdAt || o.tanggal,
        ]
      );
      totalUpserted++;
    }

    // 7. Surat Jalan
    for (const sj of suratJalanList) {
      await p.query(
        `INSERT INTO \`surat_jalan\` (\`nomor_sj\`, \`tanggal\`, \`gudang_id\`, \`gudang_nama\`, \`username\`, \`tujuan\`, \`penerima\`, \`driver\`, \`kendaraan\`, \`catatan\`, \`tampilkan_nominal\`, \`total_nominal\`, \`items_json\`, \`signature_pengirim_json\`, \`signature_driver_json\`, \`signature_penerima_json\`, \`created_at\`)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
         \`tanggal\`=VALUES(\`tanggal\`), \`tujuan\`=VALUES(\`tujuan\`), \`penerima\`=VALUES(\`penerima\`), \`items_json\`=VALUES(\`items_json\`)`,
        [
          sj.nomorSJ,
          sj.tanggal,
          sj.gudangId,
          sj.gudangNama,
          sj.username,
          sj.tujuan,
          sj.penerima,
          sj.driver || '',
          sj.kendaraan || '',
          sj.catatan || '',
          sj.tampilkanNominal ? 1 : 0,
          sj.totalNominal || 0,
          JSON.stringify(sj.items || []),
          JSON.stringify(sj.signaturePengirim || null),
          JSON.stringify(sj.signatureDriver || null),
          JSON.stringify(sj.signaturePenerima || null),
          sj.createdAt || sj.tanggal,
        ]
      );
      totalUpserted++;
    }

    // 8. Settings
    if (settings) {
      await p.query(
        `INSERT INTO \`app_settings\` (\`id\`, \`settings_json\`)
         VALUES ('default', ?)
         ON DUPLICATE KEY UPDATE \`settings_json\`=VALUES(\`settings_json\`)`,
        [JSON.stringify(settings)]
      );
      totalUpserted++;
    }

    // 9. Users
    for (const u of users) {
      await p.query(
        `INSERT INTO \`app_users\` (\`id\`, \`username\`, \`password\`, \`full_name\`, \`role\`, \`site_access\`, \`is_active\`, \`phone\`, \`email\`, \`created_at\`, \`last_login\`)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
         \`full_name\`=VALUES(\`full_name\`), \`role\`=VALUES(\`role\`), \`site_access\`=VALUES(\`site_access\`), \`is_active\`=VALUES(\`is_active\`), \`last_login\`=VALUES(\`last_login\`)`,
        [u.id, u.username, u.password || '', u.fullName, u.role, u.siteAccess, u.isActive ? 1 : 0, u.phone || '', u.email || '', u.createdAt || new Date().toISOString(), u.lastLogin || null]
      );
      totalUpserted++;
    }

    res.json({
      success: true,
      count: totalUpserted,
      message: `${totalUpserted} baris data berhasil disinkronkan ke database MySQL / phpMyAdmin!`,
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: err.message,
    });
  }
});

// Sync single item operation (CRUD)
app.post('/api/db/sync-item', async (req, res) => {
  try {
    const isReady = await initDatabaseSchema();
    if (!isReady) {
      return res.status(503).json({ success: false, error: 'Database belum terhubung' });
    }

    const { action, key, data } = req.body;
    const p = getPool();

    switch (action) {
      case 'saveProduct': {
        await p.query(
          `INSERT INTO \`master_produk\` (\`sku_id\`, \`nama_produk\`, \`warna\`, \`ukuran\`, \`kategori\`, \`jenis_lengan\`, \`reorder_level\`, \`barcode_id\`, \`harga_hpp\`, \`harga_jual\`)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
           \`nama_produk\`=VALUES(\`nama_produk\`), \`warna\`=VALUES(\`warna\`), \`ukuran\`=VALUES(\`ukuran\`), \`kategori\`=VALUES(\`kategori\`), \`jenis_lengan\`=VALUES(\`jenis_lengan\`), \`reorder_level\`=VALUES(\`reorder_level\`), \`barcode_id\`=VALUES(\`barcode_id\`), \`harga_hpp\`=VALUES(\`harga_hpp\`), \`harga_jual\`=VALUES(\`harga_jual\`)`,
          [data.SKU_ID, data.NAMA_PRODUK, data.WARNA || '', data.UKURAN || '', data.KATEGORI || '', data.JENIS_LENGAN || 'PENDEK', data.REORDER_LEVEL || 10, data.BARCODE_ID || null, data.HARGA_HPP || 0, data.HARGA_JUAL || 0]
        );
        break;
      }
      case 'deleteProduct': {
        await p.query('DELETE FROM `master_produk` WHERE `sku_id` = ?', [key]);
        break;
      }
      case 'saveInventoryItem': {
        const id = `${data.GUDANG_ID}_${data.SKU_ID}`;
        await p.query(
          `INSERT INTO \`inventori\` (\`id\`, \`gudang_id\`, \`sku_id\`, \`nama_produk\`, \`jumlah_ready\`, \`reorder_level\`, \`reorder\`, \`order_date\`, \`warna\`, \`ukuran\`, \`kategori\`, \`jenis_lengan\`)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
           \`nama_produk\`=VALUES(\`nama_produk\`), \`jumlah_ready\`=VALUES(\`jumlah_ready\`), \`reorder_level\`=VALUES(\`reorder_level\`), \`reorder\`=VALUES(\`reorder\`), \`order_date\`=VALUES(\`order_date\`), \`warna\`=VALUES(\`warna\`), \`ukuran\`=VALUES(\`ukuran\`), \`kategori\`=VALUES(\`kategori\`), \`jenis_lengan\`=VALUES(\`jenis_lengan\`)`,
          [id, data.GUDANG_ID, data.SKU_ID, data.NAMA_PRODUK, data.JUMLAH_READY || 0, data.REORDER_LEVEL || 10, data.REORDER || 'NO', data.ORDER_DATE || null, data.WARNA || null, data.UKURAN || null, data.KATEGORI || null, data.JENIS_LENGAN || null]
        );
        break;
      }
      case 'saveSale': {
        await p.query(
          `INSERT INTO \`transaksi_penjualan\` (\`nomor_sale\`, \`tanggal\`, \`gudang_id\`, \`gudang_nama\`, \`username\`, \`pelanggan\`, \`pelanggan_id\`, \`tipe_pelanggan\`, \`kontak\`, \`alamat\`, \`metode\`, \`catatan\`, \`subtotal_nominal\`, \`diskon_nominal\`, \`total_nominal\`, \`status_pembayaran\`, \`jumlah_bayar\`, \`sisa_piutang\`, \`jatuh_tempo\`, \`items_json\`, \`riwayat_pelunasan_json\`, \`created_at\`)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
           \`tanggal\`=VALUES(\`tanggal\`), \`pelanggan\`=VALUES(\`pelanggan\`), \`metode\`=VALUES(\`metode\`), \`subtotal_nominal\`=VALUES(\`subtotal_nominal\`), \`diskon_nominal\`=VALUES(\`diskon_nominal\`), \`total_nominal\`=VALUES(\`total_nominal\`), \`status_pembayaran\`=VALUES(\`status_pembayaran\`), \`jumlah_bayar\`=VALUES(\`jumlah_bayar\`), \`sisa_piutang\`=VALUES(\`sisa_piutang\`), \`items_json\`=VALUES(\`items_json\`), \`riwayat_pelunasan_json\`=VALUES(\`riwayat_pelunasan_json\`)`,
          [
            data.nomorSale,
            data.tanggal,
            data.gudangId,
            data.gudangNama,
            data.username,
            data.pelanggan,
            data.pelangganId || null,
            data.tipePelanggan || null,
            data.kontak || '',
            data.alamat || '',
            data.metode || 'TUNAI',
            data.catatan || '',
            data.subtotalNominal || 0,
            data.diskonNominal || 0,
            data.totalNominal || 0,
            data.statusPembayaran || 'LUNAS',
            data.jumlahBayar || 0,
            data.sisaPiutang || 0,
            data.jatuhTempo || null,
            JSON.stringify(data.items || []),
            JSON.stringify(data.riwayatPelunasan || []),
            data.createdAt || data.tanggal,
          ]
        );
        break;
      }
      case 'deleteSale': {
        await p.query('DELETE FROM `transaksi_penjualan` WHERE `nomor_sale` = ?', [key]);
        break;
      }
      case 'saveOrder': {
        await p.query(
          `INSERT INTO \`order_po\` (\`nomor_order\`, \`tanggal\`, \`gudang_id\`, \`gudang_nama\`, \`username\`, \`supplier\`, \`kontak\`, \`alamat\`, \`metode\`, \`catatan\`, \`subtotal_nominal\`, \`diskon_nominal\`, \`total_nominal\`, \`status_pembayaran\`, \`jumlah_bayar\`, \`sisa_piutang\`, \`jatuh_tempo\`, \`tampilkan_nominal\`, \`items_json\`, \`signature_admin_json\`, \`signature_supervisor_json\`, \`created_at\`)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
           \`tanggal\`=VALUES(\`tanggal\`), \`supplier\`=VALUES(\`supplier\`), \`total_nominal\`=VALUES(\`total_nominal\`), \`status_pembayaran\`=VALUES(\`status_pembayaran\`), \`items_json\`=VALUES(\`items_json\`)`,
          [
            data.nomorOrder,
            data.tanggal,
            data.gudangId,
            data.gudangNama,
            data.username,
            data.supplier,
            data.kontak || '',
            data.alamat || '',
            data.metode || '',
            data.catatan || '',
            data.subtotalNominal || 0,
            data.diskonNominal || 0,
            data.totalNominal || 0,
            data.statusPembayaran || 'LUNAS',
            data.jumlahBayar || 0,
            data.sisaPiutang || 0,
            data.jatuhTempo || null,
            data.tampilkanNominal ? 1 : 0,
            JSON.stringify(data.items || []),
            JSON.stringify(data.signatureAdmin || null),
            JSON.stringify(data.signatureSupervisor || null),
            data.createdAt || data.tanggal,
          ]
        );
        break;
      }
      case 'deleteOrder': {
        await p.query('DELETE FROM `order_po` WHERE `nomor_order` = ?', [key]);
        break;
      }
      case 'saveSuratJalan': {
        await p.query(
          `INSERT INTO \`surat_jalan\` (\`nomor_sj\`, \`tanggal\`, \`gudang_id\`, \`gudang_nama\`, \`username\`, \`tujuan\`, \`penerima\`, \`driver\`, \`kendaraan\`, \`catatan\`, \`tampilkan_nominal\`, \`total_nominal\`, \`items_json\`, \`signature_pengirim_json\`, \`signature_driver_json\`, \`signature_penerima_json\`, \`created_at\`)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
           \`tanggal\`=VALUES(\`tanggal\`), \`tujuan\`=VALUES(\`tujuan\`), \`penerima\`=VALUES(\`penerima\`), \`items_json\`=VALUES(\`items_json\`)`,
          [
            data.nomorSJ,
            data.tanggal,
            data.gudangId,
            data.gudangNama,
            data.username,
            data.tujuan,
            data.penerima,
            data.driver || '',
            data.kendaraan || '',
            data.catatan || '',
            data.tampilkanNominal ? 1 : 0,
            data.totalNominal || 0,
            JSON.stringify(data.items || []),
            JSON.stringify(data.signaturePengirim || null),
            JSON.stringify(data.signatureDriver || null),
            JSON.stringify(data.signaturePenerima || null),
            data.createdAt || data.tanggal,
          ]
        );
        break;
      }
      case 'deleteSuratJalan': {
        await p.query('DELETE FROM `surat_jalan` WHERE `nomor_sj` = ?', [key]);
        break;
      }
      case 'saveCustomer': {
        await p.query(
          `INSERT INTO \`pelanggan\` (\`id\`, \`nama\`, \`telepon\`, \`alamat\`, \`kota\`, \`tipe\`, \`plafon_piutang\`, \`catatan\`, \`created_at\`)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
           \`nama\`=VALUES(\`nama\`), \`telepon\`=VALUES(\`telepon\`), \`alamat\`=VALUES(\`alamat\`), \`kota\`=VALUES(\`kota\`), \`tipe\`=VALUES(\`tipe\`), \`plafon_piutang\`=VALUES(\`plafon_piutang\`), \`catatan\`=VALUES(\`catatan\`)`,
          [data.id, data.nama, data.telepon || '', data.alamat || '', data.kota || '', data.tipe || 'UMUM', data.plafonPiutang || 0, data.catatan || '', data.createdAt || new Date().toISOString()]
        );
        break;
      }
      case 'deleteCustomer': {
        await p.query('DELETE FROM `pelanggan` WHERE `id` = ?', [key]);
        break;
      }
      case 'saveWarehouse': {
        await p.query(
          `INSERT INTO \`master_gudang\` (\`gudang_id\`, \`nama_gudang\`, \`lokasi\`, \`penanggung_jawab\`, \`is_active\`, \`is_default\`, \`telepon\`, \`keterangan\`)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
           \`nama_gudang\`=VALUES(\`nama_gudang\`), \`lokasi\`=VALUES(\`lokasi\`), \`penanggung_jawab\`=VALUES(\`penanggung_jawab\`), \`is_active\`=VALUES(\`is_active\`), \`is_default\`=VALUES(\`is_default\`), \`telepon\`=VALUES(\`telepon\`), \`keterangan\`=VALUES(\`keterangan\`)`,
          [data.GUDANG_ID, data.NAMA_GUDANG, data.LOKASI || '', data.PENANGGUNG_JAWAB || '', data.IS_ACTIVE ? 1 : 0, data.IS_DEFAULT ? 1 : 0, data.TELEPON || '', data.KETERANGAN || '']
        );
        break;
      }
      case 'saveLog': {
        await p.query(
          `INSERT INTO \`log_transaksi\` (\`timestamp\`, \`transaksi_id\`, \`sku_id\`, \`gudang_id\`, \`jumlah\`, \`tipe_transaksi\`, \`users\`, \`keterangan\`)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [data.TIMESTAMP, data.TRANSAKSI_ID, data.SKU_ID, data.GUDANG_ID, data.JUMLAH || 0, data.TIPE_TRANSAKSI, data.USERS, data.KETERANGAN || '']
        );
        break;
      }
      case 'deleteLog': {
        await p.query('DELETE FROM `log_transaksi` WHERE `transaksi_id` = ?', [key]);
        break;
      }
      case 'saveSettings': {
        await p.query(
          `INSERT INTO \`app_settings\` (\`id\`, \`settings_json\`)
           VALUES ('default', ?)
           ON DUPLICATE KEY UPDATE \`settings_json\`=VALUES(\`settings_json\`)`,
          [JSON.stringify(data)]
        );
        break;
      }
      default:
        break;
    }

    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// -------------------------------------------------------------
// Vite middleware in dev or static files in production
// -------------------------------------------------------------
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  // Pre-probe MySQL connection
  initDatabaseSchema().then((connected) => {
    if (connected) {
      console.log(`[MySQL] Berhasil tersambung ke database '${dbConfig.database}' di ${dbConfig.host}:${dbConfig.port}`);
    } else {
      console.log(`[MySQL] Belum terhubung ke ${dbConfig.host}:${dbConfig.port} (${lastDbError}). Sistem tetap berjalan dengan mode offline / LocalStorage.`);
    }
  });

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${port}`);
  });
}

startServer();
