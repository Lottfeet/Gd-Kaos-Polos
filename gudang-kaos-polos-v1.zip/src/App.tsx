import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  InventoryItem,
  LogTransaksi,
  MasterGudang,
  MasterProduk,
  OrderDocument,
  SaleDocument,
  SuratJalanDocument,
  StockOpnameSession,
  User,
  UserAccount,
  AppSystemSettings,
  Pelanggan,
} from './types';
import {
  INITIAL_GUDANG,
  INITIAL_INVENTORY,
  INITIAL_LOGS,
  INITIAL_PRODUK,
  INITIAL_USERS,
  INITIAL_ORDERS,
  INITIAL_SURAT_JALAN,
  INITIAL_SALES,
  INITIAL_PELANGGAN,
  DEFAULT_SYSTEM_SETTINGS,
} from './data/initialData';
import { getWarnaHex, renderShirtPath } from './utils/tshirtSvg';
import { formatRupiah, formatNumber } from './utils/formatters';
import { BarcodeScannerModal } from './components/BarcodeScannerModal';
import { DigitalSignatureModal } from './components/DigitalSignatureModal';
import { OrderModal } from './components/OrderModal';
import { SuratJalanModal } from './components/SuratJalanModal';
import { SaleModal } from './components/SaleModal';
import { ProductModal } from './components/ProductModal';
import { LabelPrintModal } from './components/LabelPrintModal';
import { QuickScannerLookupModal } from './components/QuickScannerLookupModal';
import { GasCodeModal } from './components/GasCodeModal';
import { SettingsView } from './components/SettingsView';
import { StockOpnameView } from './components/StockOpnameView';
import { RekapitulasiView } from './components/RekapitulasiView';
import { PelangganView } from './components/PelangganView';
import { PhpMyAdminModal } from './components/PhpMyAdminModal';
import { OfflineSyncModal } from './components/OfflineSyncModal';
import { BackupCheckpointModal } from './components/BackupCheckpointModal';
import { NotificationModal } from './components/NotificationModal';
import { MysqlSyncService } from './services/mysqlSyncService';
import { OfflineSyncService, SyncStatusState } from './services/offlineSyncService';
import { CheckpointService, AppStateSnapshot } from './services/checkpointService';
import { PushNotificationService } from './services/notificationService';
import {
  Factory,
  Package,
  LogIn,
  LogOut,
  Search,
  RotateCcw,
  ArrowDownToLine,
  Tag,
  ClipboardList,
  ClipboardCheck,
  FileSpreadsheet,
  Truck,
  ShoppingBag,
  Camera,
  QrCode,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  ShieldCheck,
  Building2,
  SlidersHorizontal,
  ChevronRight,
  TrendingUp,
  X,
  Glasses,
  BookOpen,
  Eye,
  Sun,
  Moon,
  Settings,
  Users,
  Lock,
  Cloud,
  CloudOff,
  RefreshCw,
  Database,
  Bell,
} from 'lucide-react';

const STORAGE_KEYS = {
  PRODUCTS: 'inv_kaos_products_v2',
  INVENTORY: 'inv_kaos_inventory_v2',
  LOGS: 'inv_kaos_logs_v2',
  USER: 'inv_kaos_user_v2',
  THEME_MODE: 'inv_kaos_theme_mode',
  WAREHOUSES: 'inv_kaos_warehouses_v2',
  USERS: 'inv_kaos_users_v2',
  SETTINGS: 'inv_kaos_settings_v2',
  ORDERS: 'inv_kaos_order_docs_v2',
  SURAT_JALAN: 'inv_kaos_surat_jalan_docs_v2',
  SALES: 'inv_kaos_sale_docs_v2',
  CUSTOMERS: 'inv_kaos_customers_v2',
};

export default function App() {
  // Application Data States (LocalStorage persisted)
  const [products, setProducts] = useState<MasterProduk[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
    return saved ? JSON.parse(saved) : INITIAL_PRODUK;
  });

  const [warehouses, setWarehouses] = useState<MasterGudang[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.WAREHOUSES);
    if (saved) {
      try {
        const parsed: MasterGudang[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((w) => {
            if (w.GUDANG_ID === 'GDG-01-ERVO' || w.NAMA_GUDANG.toUpperCase().includes('ERVO')) {
              return {
                ...w,
                NAMA_GUDANG: 'GUDANG UTAMA',
                PENANGGUNG_JAWAB: w.PENANGGUNG_JAWAB?.includes('Ervo')
                  ? 'Admin Gudang Utama'
                  : w.PENANGGUNG_JAWAB,
              };
            }
            return w;
          });
        }
      } catch {
        return INITIAL_GUDANG;
      }
    }
    return INITIAL_GUDANG;
  });

  const [customers, setCustomers] = useState<Pelanggan[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
    if (saved) {
      try {
        const parsed: Pelanggan[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((c) => {
            let nama = c.nama;
            if (nama === 'Andi Pratama (Reseller Cimahi)') {
              nama = 'Andi Pratama';
            }
            // Jika dulunya otomatis di-set RESELLER oleh bug sebelumnya, normalkan ke UMUM
            let tipe = c.tipe;
            if (tipe === 'RESELLER' && c.catatan?.toLowerCase().includes('otomatis')) {
              tipe = 'UMUM';
            }
            return {
              ...c,
              nama,
              tipe,
            };
          });
        }
      } catch {
        return INITIAL_PELANGGAN;
      }
    }
    return INITIAL_PELANGGAN;
  });

  const [users, setUsers] = useState<UserAccount[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USERS);
    if (saved) {
      try {
        let parsed: UserAccount[] = JSON.parse(saved);
        if (!parsed.some((u) => u.username === 'owner' || u.role === 'OWNER')) {
          const ownerAccount = INITIAL_USERS.find((u) => u.username === 'owner');
          if (ownerAccount) parsed = [ownerAccount, ...parsed];
        }
        return parsed.map((u) => {
          if (u.siteAccess?.toUpperCase().includes('ERVO')) {
            return {
              ...u,
              siteAccess: 'GUDANG UTAMA',
              fullName: u.fullName?.replace('Admin Ervo', 'Admin Gudang Utama') || u.fullName,
            };
          }
          return u;
        });
      } catch {
        return INITIAL_USERS;
      }
    }
    return INITIAL_USERS;
  });

  const [settings, setSettings] = useState<AppSystemSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return saved ? JSON.parse(saved) : DEFAULT_SYSTEM_SETTINGS;
  });

  const [inventory, setInventory] = useState<InventoryItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.INVENTORY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.error('Error parsing inventory from storage:', e);
      }
    }
    return INITIAL_INVENTORY;
  });

  // Selected warehouse for Admin Inventory view ('ALL' for consolidated or specific GUDANG_ID)
  const [adminSelectedGudang, setAdminSelectedGudang] = useState<string>('ALL');

  const [logs, setLogs] = useState<LogTransaksi[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LOGS);
    return saved ? JSON.parse(saved) : INITIAL_LOGS;
  });

  // Dokumen PO, Surat Jalan & Penjualan (LocalStorage Persisted untuk Halaman Rekapitulasi)
  const [orders, setOrders] = useState<OrderDocument[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ORDERS);
    if (saved) {
      try {
        const parsed: OrderDocument[] = JSON.parse(saved);
        return parsed.map((o) =>
          o.gudangNama?.toUpperCase().includes('ERVO') ? { ...o, gudangNama: 'GUDANG UTAMA' } : o
        );
      } catch {
        return INITIAL_ORDERS;
      }
    }
    return INITIAL_ORDERS;
  });

  const [suratJalanList, setSuratJalanList] = useState<SuratJalanDocument[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SURAT_JALAN);
    if (saved) {
      try {
        const parsed: SuratJalanDocument[] = JSON.parse(saved);
        return parsed.map((s) =>
          s.gudangNama?.toUpperCase().includes('ERVO') ? { ...s, gudangNama: 'GUDANG UTAMA' } : s
        );
      } catch {
        return INITIAL_SURAT_JALAN;
      }
    }
    return INITIAL_SURAT_JALAN;
  });

  const [sales, setSales] = useState<SaleDocument[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SALES);
    return saved ? JSON.parse(saved) : INITIAL_SALES;
  });

  // Active documents being viewed or edited in modals
  const [activeViewingSale, setActiveViewingSale] = useState<SaleDocument | null>(null);
  const [activeViewingOrder, setActiveViewingOrder] = useState<OrderDocument | null>(null);
  const [activeViewingSuratJalan, setActiveViewingSuratJalan] = useState<SuratJalanDocument | null>(null);

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    if (saved) {
      try {
        const parsed: User = JSON.parse(saved);
        if (parsed.siteAccess?.toUpperCase().includes('ERVO')) {
          parsed.siteAccess = 'GUDANG UTAMA';
          if (parsed.fullName?.includes('Admin Ervo')) {
            parsed.fullName = parsed.fullName.replace('Admin Ervo', 'Admin Gudang Utama');
          }
        }
        return parsed;
      } catch {
        return null;
      }
    }
    return null;
  });

  // Active Admin View Tab (Termasuk Tab Rekapitulasi & Pelanggan)
  const [adminTab, setAdminTab] = useState<'inventory' | 'masuk' | 'opname' | 'rekap' | 'pelanggan' | 'produk' | 'logs' | 'settings'>('inventory');

  // Filter States (Public & Admin)
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedWarna, setSelectedWarna] = useState('');
  const [selectedUkuran, setSelectedUkuran] = useState('');
  const [selectedLengan, setSelectedLengan] = useState('');
  const [selectedFilterGudang, setSelectedFilterGudang] = useState('');
  const [inventoryTableSearch, setInventoryTableSearch] = useState('');

  // Barang Masuk Form State
  const [txSku, setTxSku] = useState('');
  const [txJumlah, setTxJumlah] = useState<number>(50);
  const [txHargaHpp, setTxHargaHpp] = useState<number>(30000);
  const [txHargaJual, setTxHargaJual] = useState<number>(45000);
  const [txKeterangan, setTxKeterangan] = useState('');
  const [txGudangId, setTxGudangId] = useState<string>('GDG-01-ERVO');

  // Pastikan txGudangId selalu mengarah ke gudang yang aktif
  useEffect(() => {
    const active = warehouses.filter((w) => w.IS_ACTIVE !== false);
    if (active.length > 0 && !active.some((w) => w.GUDANG_ID === txGudangId)) {
      setTxGudangId(active[0].GUDANG_ID);
    }
  }, [warehouses, txGudangId]);

  const handleSelectTxSku = (sku: string) => {
    setTxSku(sku);
    const prod = products.find((p) => p.SKU_ID === sku);
    if (prod) {
      if (prod.HARGA_HPP !== undefined) setTxHargaHpp(prod.HARGA_HPP);
      if (prod.HARGA_JUAL !== undefined) setTxHargaJual(prod.HARGA_JUAL);
    }
  };

  // Stock Direct Correction Modal
  const [correctionItem, setCorrectionItem] = useState<{ gudangId: string; skuId: string; current: number } | null>(null);
  const [correctionNewQty, setCorrectionNewQty] = useState<number>(0);
  const [correctionHpp, setCorrectionHpp] = useState<number>(0);
  const [correctionJual, setCorrectionJual] = useState<number>(0);
  const [correctionReason, setCorrectionReason] = useState<string>('');

  // Modals Visibility
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showSuratJalanModal, setShowSuratJalanModal] = useState(false);
  const [showSaleModal, setShowSaleModal] = useState(false);
  const [showQuickLookupModal, setShowQuickLookupModal] = useState(false);
  const [showGasModal, setShowGasModal] = useState(false);
  const [showPhpMyAdminModal, setShowPhpMyAdminModal] = useState(false);
  const [showOfflineSyncModal, setShowOfflineSyncModal] = useState(false);
  const [showBackupModal, setShowBackupModal] = useState(false);
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  const [unreadNotifCount, setUnreadNotifCount] = useState<number>(() =>
    PushNotificationService.getUnreadCount()
  );
  const [isMysqlOnline, setIsMysqlOnline] = useState<boolean | null>(null);
  const [isInitialLoadingDb, setIsInitialLoadingDb] = useState<boolean>(true);
  const [syncStatus, setSyncStatus] = useState<SyncStatusState>(() => OfflineSyncService.getStatus());

  // Subscribe ke status antrean offline & sinkronisasi MySQL
  useEffect(() => {
    const unsub = OfflineSyncService.subscribe((newStatus) => {
      setSyncStatus(newStatus);
    });
    return () => unsub();
  }, []);

  // Background Auto-Sync Worker:
  // Otomatis mengupload antrean transaksi lokal ke MySQL ketika online
  useEffect(() => {
    const attemptAutoSync = async () => {
      const queue = OfflineSyncService.getQueue();
      if (queue.length === 0) return;
      if (!navigator.onLine) return;

      try {
        const res = await MysqlSyncService.processPendingQueue();
        if (res.processed > 0) {
          showToast(
            `Auto-Sync: ${res.processed} transaksi offline berhasil disinkronkan ke MySQL!`,
            'success'
          );
        }
      } catch (err) {
        console.warn('Background auto-sync attempt error:', err);
      }
    };

    // Trigger saat jaringan kembali online
    const handleOnline = () => {
      setIsMysqlOnline(true);
      attemptAutoSync();
    };
    const handleOffline = () => {
      setIsMysqlOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Jalankan interval berkala setiap 30 detik di latar belakang
    const intervalId = setInterval(attemptAutoSync, 30000);

    // Coba upload 3 detik setelah boot jika ada antrean tertunda
    const initTimer = setTimeout(attemptAutoSync, 3000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(intervalId);
      clearTimeout(initTimer);
    };
  }, []);

  // Background Interval for Automatic Checkpoints
  useEffect(() => {
    const chkConfig = settings.checkpointSettings;
    if (!chkConfig || !chkConfig.autoCheckpointEnabled) return;

    const intervalMinutes = Math.max(5, chkConfig.intervalMinutes || 30);
    const intervalMs = intervalMinutes * 60 * 1000;

    const timer = setInterval(() => {
      try {
        const stateSnapshot: AppStateSnapshot = {
          products,
          warehouses,
          inventory,
          logs,
          users,
          settings,
          orders,
          suratJalanList,
          sales,
          customers,
        };
        CheckpointService.createCheckpoint(
          'AUTO_INTERVAL',
          `Checkpoint Otomatis (${new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })})`,
          'Sistem Otomatis',
          stateSnapshot,
          `Snapshot berkala setiap ${intervalMinutes} menit`,
          chkConfig
        );
      } catch (err) {
        console.warn('Auto checkpoint interval error:', err);
      }
    }, intervalMs);

    return () => clearInterval(timer);
  }, [
    settings,
    products,
    warehouses,
    inventory,
    logs,
    users,
    orders,
    suratJalanList,
    sales,
    customers,
  ]);

  // Mandatory Startup Connection Probe & Automatic Cloud Hydration
  // Mandatory Startup Connection Probe & Automatic Database Hydration
  // Mengunduh otomatis data terbaru dari MySQL / phpMyAdmin saat pertama kali membuka aplikasi di perangkat mana pun
  useEffect(() => {
    let isMounted = true;

    const initDbData = async () => {
      try {
        setIsInitialLoadingDb(true);
        const status = await MysqlSyncService.testConnection();
        if (isMounted) setIsMysqlOnline(status.connected);

        if (status.connected) {
          // Tarik data aktual dari MySQL
          const res = await MysqlSyncService.pullAllDataFromDatabase();
          if (isMounted && res.success && res.data) {
            const totalDocs = Object.values(res.counts || {}).reduce((a, b) => a + b, 0);
            if (totalDocs > 0) {
              handleImportAllData(res.data);
              showToast(
                `🐬 MySQL Terhubung: ${totalDocs} data aktual berhasil dimuat dari database!`,
                'success'
              );
            } else {
              // Jika database MySQL masih kosong: otomatis unggah data lokal saat ini
              const uploadRes = await MysqlSyncService.migrateLocalDataToDatabase({
                products,
                inventory,
                warehouses,
                customers,
                sales,
                orders,
                suratJalanList,
                logs,
                settings,
              });
              if (uploadRes.success && uploadRes.count > 0) {
                showToast(
                  `🐬 Sinkronisasi Awal: ${uploadRes.count} baris data berhasil disimpan ke MySQL!`,
                  'success'
                );
              }
            }
          }
        }
      } catch (err) {
        console.warn('Startup MySQL sync probe:', err);
      } finally {
        if (isMounted) {
          setIsInitialLoadingDb(false);
        }
      }
    };

    initDbData();

    // Subscribe ke notifikasi pusat push notifikasi
    const unsubNotif = PushNotificationService.subscribe(() => {
      if (isMounted) {
        setUnreadNotifCount(PushNotificationService.getUnreadCount());
      }
    });

    // Real-time / Polling Background Sync: sinkronisasi berkala dari database MySQL
    const unsubSync = MysqlSyncService.subscribeToDatabaseChanges({
      onSyncUpdated: (newData) => {
        if (isMounted && newData) {
          handleImportAllData(newData);
        }
      },
    });

    return () => {
      isMounted = false;
      unsubNotif();
      unsubSync();
    };
  }, []);

  // Barcode Scanner Modal for Stock In
  const [showTxScanner, setShowTxScanner] = useState(false);

  // Product Add / Edit Modal
  const [editingProduct, setEditingProduct] = useState<MasterProduk | null | undefined>(undefined);

  // Label Print Modal
  const [labelProduct, setLabelProduct] = useState<MasterProduk | null>(null);

  // User Authorization Helper: Check if active user is Owner or SPV
  const isSpvOrOwner = Boolean(
    currentUser && (
      currentUser.role === 'OWNER' ||
      currentUser.role === 'SUPERVISOR' ||
      (currentUser.role as string) === 'SPV' ||
      currentUser.username.toLowerCase() === 'owner' ||
      currentUser.username.toLowerCase() === 'supervisor' ||
      currentUser.username.toLowerCase() === 'spv'
    )
  );

  // Theme Mode: Hanya ada Mode Gelap ('dark') dan Mode Terang ('light')
  const [themeMode, setThemeMode] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem('inv_kaos_theme_mode');
    return saved === 'light' ? 'light' : 'dark';
  });

  const toggleTheme = () => {
    setThemeMode((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      localStorage.setItem('inv_kaos_theme_mode', next);
      showToast(`Beralih ke ${next === 'light' ? 'Mode Terang' : 'Mode Gelap'}`, 'info');
      return next;
    });
  };

  // Sinkronisasi kelas & warna background pada html & body agar tidak ada blank/black bar saat scroll di mobile
  useEffect(() => {
    if (themeMode === 'light') {
      document.documentElement.classList.add('theme-light');
      document.documentElement.classList.remove('theme-dark');
      document.body.classList.add('theme-light');
      document.body.classList.remove('theme-dark');
      document.body.style.backgroundColor = '#f8fafc';
      document.body.style.color = '#0f172a';
    } else {
      document.documentElement.classList.add('theme-dark');
      document.documentElement.classList.remove('theme-light');
      document.body.classList.add('theme-dark');
      document.body.classList.remove('theme-light');
      document.body.style.backgroundColor = '#0F0F10';
      document.body.style.color = '#E0E0E0';
    }
  }, [themeMode]);

  // Notification Toast
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 3800);
  };

  // Persist Data Changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.WAREHOUSES, JSON.stringify(warehouses));
  }, [warehouses]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(inventory));
  }, [inventory]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SURAT_JALAN, JSON.stringify(suratJalanList));
  }, [suratJalanList]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(sales));
  }, [sales]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(STORAGE_KEYS.USER);
    }
  }, [currentUser]);

  // Validasi sesi aktif: jika username tidak terdaftar di Manajemen Pengguna atau dinonaktifkan, otomatis logout
  useEffect(() => {
    if (currentUser) {
      const activeAccount = users.find(
        (u) => u.username.toLowerCase() === currentUser.username.toLowerCase()
      );
      if (!activeAccount || activeAccount.isActive === false) {
        setCurrentUser(null);
        localStorage.removeItem(STORAGE_KEYS.USER);
      }
    }
  }, [users, currentUser]);

  // Derived Statistics
  const summaryStats = useMemo(() => {
    const totalSku = products.length;
    const totalStock = inventory.reduce((sum, item) => sum + (Number(item.JUMLAH_READY) || 0), 0);
    const needReorderCount = inventory.filter((item) => item.REORDER === 'YES' || item.JUMLAH_READY <= item.REORDER_LEVEL).length;

    const todayStr = new Date().toDateString();
    const txToday = logs.filter((log) => new Date(log.TIMESTAMP).toDateString() === todayStr).length;

    return {
      totalSku,
      totalStock,
      needReorderCount,
      txToday,
    };
  }, [products, inventory, logs]);

  // Unique Colors from Master
  const uniqueColors = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      if (p.WARNA) set.add(p.WARNA.toUpperCase());
    });
    return Array.from(set).sort();
  }, [products]);

  // Helper to extract clean uppercase warehouse short name
  const getWarehouseShortName = (namaGudang: string): string => {
    if (!namaGudang) return 'GDG';
    const clean = namaGudang.trim().replace(/^(gudang|warehouse|gdg)\s+/i, '');
    return clean ? clean.toUpperCase() : namaGudang.trim().toUpperCase();
  };

  // Grouped Products for Public Catalog Card Grid (Adaptive Multi-Warehouse)
  const publicCatalogCards = useMemo(() => {
    return products
      .map((p) => {
        // Collect warehouse breakdown dynamically based on current active warehouses
        const warehouseStocks = warehouses.map((wh, idx) => {
          const invItem = inventory.find((i) => i.SKU_ID === p.SKU_ID && i.GUDANG_ID === wh.GUDANG_ID);
          const qty = invItem ? invItem.JUMLAH_READY : 0;
          const isReorder = invItem ? invItem.REORDER === 'YES' || qty <= (p.REORDER_LEVEL || 10) : false;

          return {
            gudangId: wh.GUDANG_ID,
            gudangNama: wh.NAMA_GUDANG,
            shortName: getWarehouseShortName(wh.NAMA_GUDANG),
            lokasi: wh.LOKASI,
            qty,
            isReorder,
            colorIndex: idx % 6,
          };
        });

        const totalStock = warehouseStocks.reduce((sum, ws) => sum + ws.qty, 0);
        const hasReorder = warehouseStocks.some((ws) => ws.isReorder);

        // Backward compatibility properties
        const stokErvo = warehouseStocks.find((ws) => ws.gudangId.includes('ERVO'))?.qty ?? 0;
        const stokToko = warehouseStocks.find((ws) => ws.gudangId.includes('TOKO'))?.qty ?? 0;

        return {
          ...p,
          warehouseStocks,
          totalStock,
          hasReorder,
          stokErvo,
          stokToko,
        };
      })
      .filter((item) => {
        const q = searchQuery.toLowerCase().trim();
        const matchSearch =
          !q ||
          item.SKU_ID.toLowerCase().includes(q) ||
          item.NAMA_PRODUK.toLowerCase().includes(q) ||
          item.WARNA.toLowerCase().includes(q);

        const matchWarna = !selectedWarna || item.WARNA.toUpperCase() === selectedWarna;
        const matchUkuran = !selectedUkuran || item.UKURAN.toUpperCase() === selectedUkuran;
        const matchLengan = !selectedLengan || item.JENIS_LENGAN.toUpperCase() === selectedLengan;

        // If warehouse filter is selected, ensure it has stock in that warehouse (or filter appropriately)
        const matchGudang =
          !selectedFilterGudang ||
          item.warehouseStocks.some((ws) => ws.gudangId === selectedFilterGudang);

        return matchSearch && matchWarna && matchUkuran && matchLengan && matchGudang;
      });
  }, [products, inventory, warehouses, searchQuery, selectedWarna, selectedUkuran, selectedLengan, selectedFilterGudang]);

  // Helper to ensure all products have inventory slots across all active warehouses
  const syncInventorySlots = useCallback(() => {
    setInventory((prev) => {
      const base = prev && prev.length > 0 ? [...prev] : [...INITIAL_INVENTORY];
      let countAdded = 0;
      warehouses.forEach((wh) => {
        products.forEach((p) => {
          const exists = base.some((i) => i.GUDANG_ID === wh.GUDANG_ID && i.SKU_ID === p.SKU_ID);
          if (!exists) {
            base.push({
              GUDANG_ID: wh.GUDANG_ID,
              SKU_ID: p.SKU_ID,
              NAMA_PRODUK: p.NAMA_PRODUK,
              JUMLAH_READY: 0,
              REORDER_LEVEL: p.REORDER_LEVEL || settings.defaultReorderLevel || 10,
              REORDER: 'YES',
              WARNA: p.WARNA,
              UKURAN: p.UKURAN,
              KATEGORI: p.KATEGORI,
              JENIS_LENGAN: p.JENIS_LENGAN,
            });
            countAdded++;
          }
        });
      });
      localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(base));
      return base;
    });
  }, [warehouses, products, settings.defaultReorderLevel]);

  // Auto-heal inventory slots if any active warehouse or product is missing records
  useEffect(() => {
    if (warehouses.length > 0 && products.length > 0) {
      const isMissingAny = warehouses.some((wh) =>
        products.some((p) => !inventory.some((i) => i.GUDANG_ID === wh.GUDANG_ID && i.SKU_ID === p.SKU_ID))
      );
      if (isMissingAny) {
        syncInventorySlots();
      }
    }
  }, [warehouses, products, inventory, syncInventorySlots]);

  // Auto-sync selected warehouse when user logs in
  useEffect(() => {
    if (!currentUser) return;
    const isAll =
      currentUser.siteAccess.toUpperCase().includes('SEMUA') ||
      currentUser.role === 'OWNER' ||
      currentUser.role === 'SUPERVISOR';
    if (!isAll) {
      const matched = warehouses.find(
        (w) =>
          w.GUDANG_ID.toUpperCase() === currentUser.siteAccess.toUpperCase() ||
          w.NAMA_GUDANG.toUpperCase() === currentUser.siteAccess.toUpperCase() ||
          currentUser.siteAccess.toUpperCase().includes(w.NAMA_GUDANG.toUpperCase()) ||
          currentUser.siteAccess.toUpperCase().includes(w.GUDANG_ID.toUpperCase())
      );
      if (matched) {
        setAdminSelectedGudang(matched.GUDANG_ID);
      }
    }
  }, [currentUser, warehouses]);

  // Active warehouse name displayed in Header & Badges
  const activeHeaderWarehouse = useMemo(() => {
    let name = '';
    if (adminSelectedGudang && adminSelectedGudang !== 'ALL') {
      const wh = warehouses.find((w) => w.GUDANG_ID === adminSelectedGudang);
      if (wh) name = wh.NAMA_GUDANG;
    }
    if (!name && currentUser?.siteAccess && !currentUser.siteAccess.toUpperCase().includes('SEMUA')) {
      const matched = warehouses.find(
        (w) =>
          w.GUDANG_ID.toUpperCase() === currentUser.siteAccess.toUpperCase() ||
          w.NAMA_GUDANG.toUpperCase() === currentUser.siteAccess.toUpperCase() ||
          currentUser.siteAccess.toUpperCase().includes(w.NAMA_GUDANG.toUpperCase()) ||
          currentUser.siteAccess.toUpperCase().includes(w.GUDANG_ID.toUpperCase())
      );
      if (matched) name = matched.NAMA_GUDANG;
      else name = currentUser.siteAccess;
    }
    if (!name) name = warehouses[0]?.NAMA_GUDANG || 'GUDANG UTAMA';
    if (name.toUpperCase().includes('ERVO')) return 'GUDANG UTAMA';
    return name;
  }, [adminSelectedGudang, warehouses, currentUser]);

  // Filtered Inventory for Admin Warehouse view
  const adminInventoryFiltered = useMemo(() => {
    if (!currentUser) return [];

    const isAllAccess =
      currentUser.siteAccess.toUpperCase().includes('SEMUA') ||
      currentUser.role === 'OWNER' ||
      currentUser.role === 'SUPERVISOR';

    // Cari gudang default jika user terikat ke 1 gudang
    const userMatchedWh = warehouses.find(
      (w) =>
        w.GUDANG_ID.toUpperCase() === currentUser.siteAccess.toUpperCase() ||
        w.NAMA_GUDANG.toUpperCase() === currentUser.siteAccess.toUpperCase() ||
        currentUser.siteAccess.toUpperCase().includes(w.NAMA_GUDANG.toUpperCase()) ||
        currentUser.siteAccess.toUpperCase().includes(w.GUDANG_ID.toUpperCase())
    );
    const fallbackUserGudangId = userMatchedWh
      ? userMatchedWh.GUDANG_ID
      : currentUser.siteAccess.toUpperCase().includes('TOKO')
      ? 'GDG-02-TOKO'
      : (warehouses[0]?.GUDANG_ID || 'GDG-01-ERVO');

    // Tentukan gudang yang aktif di-filter
    const activeFilter = isAllAccess ? adminSelectedGudang : (adminSelectedGudang || fallbackUserGudangId);

    // Kumpulkan item dari inventory yang ada
    let resultItems: (InventoryItem & {
      NAMA_GUDANG: string;
      WARNA: string;
      UKURAN: string;
      KATEGORI: string;
      JENIS_LENGAN: string;
      HARGA_HPP: number;
      HARGA_JUAL: number;
    })[] = [];

    // Jika filter spesifik gudang
    if (activeFilter && activeFilter !== 'ALL') {
      const wh = warehouses.find((w) => w.GUDANG_ID === activeFilter);
      const whName = wh?.NAMA_GUDANG || activeFilter;

      // Pastikan SEMUA produk di Master Produk tercakup (konsisten dengan Stok Opname)
      resultItems = products.map((prod) => {
        const inv = inventory.find((i) => i.GUDANG_ID === activeFilter && i.SKU_ID === prod.SKU_ID);
        const qtyReady = inv ? inv.JUMLAH_READY : 0;
        const reorderLvl = inv?.REORDER_LEVEL ?? prod.REORDER_LEVEL ?? 10;
        const isReorder = inv ? inv.REORDER : (qtyReady <= reorderLvl ? 'YES' : 'NO');

        return {
          GUDANG_ID: activeFilter,
          SKU_ID: prod.SKU_ID,
          NAMA_PRODUK: prod.NAMA_PRODUK,
          JUMLAH_READY: qtyReady,
          REORDER_LEVEL: reorderLvl,
          REORDER: isReorder,
          NAMA_GUDANG: whName,
          WARNA: prod.WARNA || '—',
          UKURAN: prod.UKURAN || '—',
          KATEGORI: prod.KATEGORI || 'COMBED',
          JENIS_LENGAN: prod.JENIS_LENGAN || 'PENDEK',
          HARGA_HPP: prod.HARGA_HPP || 30000,
          HARGA_JUAL: prod.HARGA_JUAL || 45000,
        };
      });
    } else {
      // Jika 'ALL' (Semua Gudang): Tampilkan per gudang aktif
      const targetWarehouses = warehouses.length > 0 ? warehouses : INITIAL_GUDANG;
      targetWarehouses.forEach((wh) => {
        products.forEach((prod) => {
          const inv = inventory.find((i) => i.GUDANG_ID === wh.GUDANG_ID && i.SKU_ID === prod.SKU_ID);
          const qtyReady = inv ? inv.JUMLAH_READY : 0;
          const reorderLvl = inv?.REORDER_LEVEL ?? prod.REORDER_LEVEL ?? 10;
          const isReorder = inv ? inv.REORDER : (qtyReady <= reorderLvl ? 'YES' : 'NO');

          resultItems.push({
            GUDANG_ID: wh.GUDANG_ID,
            SKU_ID: prod.SKU_ID,
            NAMA_PRODUK: prod.NAMA_PRODUK,
            JUMLAH_READY: qtyReady,
            REORDER_LEVEL: reorderLvl,
            REORDER: isReorder,
            NAMA_GUDANG: wh.NAMA_GUDANG,
            WARNA: prod.WARNA || '—',
            UKURAN: prod.UKURAN || '—',
            KATEGORI: prod.KATEGORI || 'COMBED',
            JENIS_LENGAN: prod.JENIS_LENGAN || 'PENDEK',
            HARGA_HPP: prod.HARGA_HPP || 30000,
            HARGA_JUAL: prod.HARGA_JUAL || 45000,
          });
        });
      });
    }

    // Filter berdasarkan query pencarian
    const q = inventoryTableSearch.toLowerCase().trim();
    if (!q) return resultItems;

    return resultItems.filter((item) => {
      return (
        item.SKU_ID.toLowerCase().includes(q) ||
        item.NAMA_PRODUK.toLowerCase().includes(q) ||
        (item.WARNA && item.WARNA.toLowerCase().includes(q)) ||
        (item.UKURAN && item.UKURAN.toLowerCase().includes(q)) ||
        (item.GUDANG_ID && item.GUDANG_ID.toLowerCase().includes(q)) ||
        (item.NAMA_GUDANG && item.NAMA_GUDANG.toLowerCase().includes(q))
      );
    });
  }, [currentUser, adminSelectedGudang, inventory, products, warehouses, inventoryTableSearch]);

  // Warehouse Configuration Handler
  const handleUpdateWarehouses = (newWarehouses: MasterGudang[]) => {
    setWarehouses(newWarehouses);
    newWarehouses.forEach((wh) => {
      MysqlSyncService.saveWarehouse(wh).catch((err) =>
        console.error('Firestore save warehouse error:', err)
      );
    });
    // Ensure all products have inventory rows for each active warehouse
    setInventory((prev) => {
      let updated = [...prev];
      newWarehouses.forEach((wh) => {
        products.forEach((p) => {
          const exists = updated.some((i) => i.GUDANG_ID === wh.GUDANG_ID && i.SKU_ID === p.SKU_ID);
          if (!exists) {
            updated.push({
              GUDANG_ID: wh.GUDANG_ID,
              SKU_ID: p.SKU_ID,
              NAMA_PRODUK: p.NAMA_PRODUK,
              JUMLAH_READY: 0,
              REORDER_LEVEL: p.REORDER_LEVEL || settings.defaultReorderLevel,
              REORDER: 'YES',
              WARNA: p.WARNA,
              UKURAN: p.UKURAN,
              KATEGORI: p.KATEGORI,
              JENIS_LENGAN: p.JENIS_LENGAN,
            });
          }
        });
      });
      return updated;
    });
  };

  // Auth Functions
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    const u = loginUsername.trim().toLowerCase();
    const p = loginPassword.trim();

    if (!u || !p) {
      setLoginError('Username atau password tidak boleh kosong.');
      return;
    }

    // 1. Verifikasi apakah username terdaftar di Manajemen Pengguna (users)
    const matched = users.find((user) => user.username.toLowerCase() === u);

    if (!matched) {
      setLoginError('Username tidak terdaftar di Manajemen Pengguna. Silakan hubungi Administrator / Owner.');
      return;
    }

    // 2. Cek apakah status akun aktif
    if (matched.isActive === false) {
      setLoginError('Akun ini telah dinonaktifkan oleh administrator.');
      return;
    }

    // 3. Verifikasi kesesuaian password
    if (matched.password && matched.password !== p) {
      setLoginError('Password yang Anda masukkan salah. Silakan coba lagi.');
      return;
    }

    // 4. Login berhasil: set sesi pengguna
    setCurrentUser({
      username: matched.username,
      role: matched.role,
      siteAccess: matched.siteAccess,
      fullName: matched.fullName,
    });

    // Update timestamp lastLogin di daftar users
    setUsers((prev) =>
      prev.map((user) => (user.id === matched.id ? { ...user, lastLogin: new Date().toISOString() } : user))
    );

    setShowLoginModal(false);
    setLoginUsername('');
    setLoginPassword('');
    setLoginError('');
    showToast(`Selamat datang, ${matched.fullName || matched.username}! (${matched.role})`, 'success');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    showToast('Anda telah keluar dari mode admin.', 'info');
  };

  // Reset demo data with Safety Rollback Checkpoint
  const handleResetData = () => {
    if (confirm('Kembalikan seluruh data master produk dan inventori ke data demo awal?')) {
      // Auto safety checkpoint before reset
      if (settings.checkpointSettings?.autoBeforeRestore !== false) {
        CheckpointService.createCheckpoint(
          'AUTO_RESTORE',
          'Safety Rollback sebelum Reset Data Pabrik',
          currentUser?.fullName || currentUser?.username || 'Sistem',
          {
            products,
            warehouses,
            inventory,
            logs,
            users,
            settings,
            orders,
            suratJalanList,
            sales,
            customers,
          },
          'Dibuat otomatis sebelum reset data pabrik dilakukan.',
          settings.checkpointSettings
        );
      }

      setProducts(INITIAL_PRODUK);
      setWarehouses(INITIAL_GUDANG);
      setInventory(INITIAL_INVENTORY);
      setLogs(INITIAL_LOGS);
      setUsers(INITIAL_USERS);
      setSettings(DEFAULT_SYSTEM_SETTINGS);
      localStorage.removeItem(STORAGE_KEYS.PRODUCTS);
      localStorage.removeItem(STORAGE_KEYS.WAREHOUSES);
      localStorage.removeItem(STORAGE_KEYS.INVENTORY);
      localStorage.removeItem(STORAGE_KEYS.LOGS);
      localStorage.removeItem(STORAGE_KEYS.USERS);
      localStorage.removeItem(STORAGE_KEYS.SETTINGS);
      showToast('Data berhasil di-reset ke kondisi awal. Safety checkpoint telah disimpan jika ingin dikembalikan.', 'success');
    }
  };

  // Full System Import / Restore / Rollback
  const handleImportAllData = (data: {
    warehouses?: MasterGudang[];
    users?: UserAccount[];
    settings?: AppSystemSettings;
    products?: MasterProduk[];
    inventory?: InventoryItem[];
    logs?: LogTransaksi[];
    orders?: OrderDocument[];
    suratJalanList?: SuratJalanDocument[];
    sales?: SaleDocument[];
    customers?: Pelanggan[];
    soHistory?: StockOpnameSession[];
  }) => {
    if (data.warehouses && Array.isArray(data.warehouses)) {
      setWarehouses(data.warehouses);
      localStorage.setItem(STORAGE_KEYS.WAREHOUSES, JSON.stringify(data.warehouses));
    }
    if (data.users && Array.isArray(data.users)) {
      setUsers(data.users);
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(data.users));
    }
    if (data.settings && typeof data.settings === 'object') {
      setSettings(data.settings);
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(data.settings));
    }
    if (data.products && Array.isArray(data.products)) {
      setProducts(data.products);
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(data.products));
    }
    if (data.inventory && Array.isArray(data.inventory)) {
      setInventory(data.inventory);
      localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(data.inventory));
    }
    if (data.logs && Array.isArray(data.logs)) {
      setLogs(data.logs);
      localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(data.logs));
    }
    if (data.orders && Array.isArray(data.orders)) {
      setOrders(data.orders);
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(data.orders));
    }
    if (data.suratJalanList && Array.isArray(data.suratJalanList)) {
      setSuratJalanList(data.suratJalanList);
      localStorage.setItem(STORAGE_KEYS.SURAT_JALAN, JSON.stringify(data.suratJalanList));
    }
    if (data.sales && Array.isArray(data.sales)) {
      setSales(data.sales);
      localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(data.sales));
    }
    if (data.customers && Array.isArray(data.customers)) {
      setCustomers(data.customers);
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(data.customers));
    }
    if (data.soHistory && Array.isArray(data.soHistory)) {
      try {
        localStorage.setItem('INVENTORY_SO_HISTORY', JSON.stringify(data.soHistory));
      } catch (err) {
        console.error('Failed to restore SO history:', err);
      }
    }
  };

  // Direct Stock Correction Handler
  const handleSaveCorrection = () => {
    if (!correctionItem) return;

    const isSpvOrOwner = Boolean(
      currentUser && (
        currentUser.role === 'OWNER' ||
        currentUser.role === 'SUPERVISOR' ||
        (currentUser.role as string) === 'SPV' ||
        currentUser.username.toLowerCase() === 'owner' ||
        currentUser.username.toLowerCase() === 'supervisor' ||
        currentUser.username.toLowerCase() === 'spv'
      )
    );

    // Kuantitas stok hanya dapat diubah oleh SPV atau Owner; jika bukan, pertahankan stok fisik saat ini
    const newQty = isSpvOrOwner ? Math.max(0, Number(correctionNewQty)) : correctionItem.current;
    const newHpp = Math.max(0, Number(correctionHpp) || 0);
    const newJual = Math.max(0, Number(correctionJual) || 0);

    if (isSpvOrOwner && newQty !== correctionItem.current) {
      let targetInv: InventoryItem | null = null;
      const existingItem = inventory.find((item) => item.GUDANG_ID === correctionItem.gudangId && item.SKU_ID === correctionItem.skuId);
      if (existingItem) {
        const isReorder = newQty <= existingItem.REORDER_LEVEL ? 'YES' : 'NO';
        targetInv = {
          ...existingItem,
          JUMLAH_READY: newQty,
          REORDER: isReorder,
          ...(isReorder === 'YES' ? { ORDER_DATE: new Date().toISOString() } : {}),
        };
        if (isReorder !== 'YES') {
          delete targetInv.ORDER_DATE;
        }
      } else {
        const prod = products.find((p) => p.SKU_ID === correctionItem.skuId);
        targetInv = {
          GUDANG_ID: correctionItem.gudangId,
          SKU_ID: correctionItem.skuId,
          NAMA_PRODUK: prod?.NAMA_PRODUK || correctionItem.skuId,
          JUMLAH_READY: newQty,
          REORDER_LEVEL: prod?.REORDER_LEVEL || settings.defaultReorderLevel || 10,
          REORDER: newQty <= (prod?.REORDER_LEVEL || 10) ? 'YES' : 'NO',
          WARNA: prod?.WARNA,
          UKURAN: prod?.UKURAN,
          KATEGORI: prod?.KATEGORI,
          JENIS_LENGAN: prod?.JENIS_LENGAN,
        };
      }

      setInventory((prev) => {
        const exists = prev.some((item) => item.GUDANG_ID === correctionItem.gudangId && item.SKU_ID === correctionItem.skuId);
        if (exists) {
          return prev.map((item) => {
            if (item.GUDANG_ID === correctionItem.gudangId && item.SKU_ID === correctionItem.skuId) {
              return targetInv!;
            }
            return item;
          });
        }
        return [...prev, targetInv!];
      });

      if (targetInv) {
        MysqlSyncService.saveInventoryItem(targetInv).catch((err) => console.error('Firestore inv sync:', err));
      }
    }

    // Update master product HPP and Jual
    setProducts((prev) =>
      prev.map((p) => {
        if (p.SKU_ID === correctionItem.skuId) {
          const updatedProd = { ...p, HARGA_HPP: newHpp, HARGA_JUAL: newJual };
          MysqlSyncService.saveProduct(updatedProd).catch((err) => console.error('Firestore prod sync:', err));
          return updatedProd;
        }
        return p;
      })
    );

    // Record log
    const diff = newQty - correctionItem.current;
    const txId = `TX${String(logs.length + 1).padStart(4, '0')}`;
    const reasonText = correctionReason.trim() ? ` [Alasan: ${correctionReason.trim()}]` : '';
    const newLog: LogTransaksi = {
      TIMESTAMP: new Date().toISOString(),
      TRANSAKSI_ID: txId,
      SKU_ID: correctionItem.skuId,
      GUDANG_ID: correctionItem.gudangId,
      JUMLAH: diff,
      TIPE_TRANSAKSI: 'KOREKSI',
      USERS: currentUser?.username || 'admin',
      KETERANGAN: isSpvOrOwner && diff !== 0
        ? `Koreksi manual stok: ${correctionItem.current} → ${newQty} pcs (${diff > 0 ? '+' : ''}${diff} pcs) | HPP: ${formatRupiah(newHpp)} | Jual: ${formatRupiah(newJual)}${reasonText}`
        : `Pembaruan harga produk: HPP ${formatRupiah(newHpp)} | Jual ${formatRupiah(newJual)}${reasonText}`,
    };

    setLogs((prev) => [newLog, ...prev]);
    MysqlSyncService.saveLog(newLog).catch((err) => console.error('Firestore log sync:', err));
    
    if (isSpvOrOwner && diff !== 0) {
      showToast(`Stok ${correctionItem.skuId} dikoreksi menjadi ${newQty} pcs. HPP: ${formatRupiah(newHpp)} | Jual: ${formatRupiah(newJual)}.`, 'success');
    } else {
      showToast(`Harga produk ${correctionItem.skuId} berhasil diperbarui (HPP: ${formatRupiah(newHpp)} | Jual: ${formatRupiah(newJual)}).`, 'success');
    }
    setCorrectionItem(null);
    setCorrectionReason('');
  };

  // Delete single transaction log (Khusus akses Owner & SPV)
  const handleDeleteLog = (transaksiId: string) => {
    if (!isSpvOrOwner) {
      showToast('Akses Ditolak: Hanya user Owner dan SPV yang berhak menghapus riwayat log transaksi.', 'error');
      return;
    }

    if (confirm(`Yakin ingin menghapus baris riwayat transaksi "${transaksiId}"? Tindakan ini tidak dapat dibatalkan.`)) {
      setLogs((prev) => prev.filter((l) => l.TRANSAKSI_ID !== transaksiId));
      MysqlSyncService.deleteLog(transaksiId).catch((err) =>
        console.error('Firestore delete log error:', err)
      );
      showToast(`Log transaksi "${transaksiId}" berhasil dihapus.`, 'info');
    }
  };

  // Clear all transaction logs (Khusus akses Owner & SPV)
  const handleClearAllLogs = () => {
    if (!isSpvOrOwner) {
      showToast('Akses Ditolak: Hanya user Owner dan SPV yang berhak membersihkan seluruh log transaksi.', 'error');
      return;
    }

    if (confirm(`Yakin ingin mengosongkan seluruh riwayat log transaksi (${logs.length} baris)? Seluruh data log akan dihapus.`)) {
      setLogs([]);
      showToast('Seluruh riwayat log transaksi berhasil dibersihkan.', 'info');
    }
  };

  // Submit Stock In (Barang Masuk)
  const handleSubmitStockIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!txSku.trim()) {
      showToast('Pilih atau pindai SKU produk terlebih dahulu.', 'error');
      return;
    }
    const qty = Math.abs(Number(txJumlah));
    if (qty <= 0) {
      showToast('Jumlah barang masuk harus lebih dari 0.', 'error');
      return;
    }

    const activeWarehouses = warehouses.filter((w) => w.IS_ACTIVE !== false);
    const targetGudangId = txGudangId || activeWarehouses[0]?.GUDANG_ID || 'GDG-01-ERVO';
    const targetGudangObj = warehouses.find((w) => w.GUDANG_ID === targetGudangId);
    const targetGudangNama = targetGudangObj?.NAMA_GUDANG || targetGudangId;

    const hpp = Math.max(0, Number(txHargaHpp) || 0);
    const jual = Math.max(0, Number(txHargaJual) || 0);
    const totalNilai = qty * hpp;

    // 1. Update or Insert inventory item
    const existingInv = inventory.find((i) => i.GUDANG_ID === targetGudangId && i.SKU_ID === txSku);
    let targetInvItem: InventoryItem;
    if (existingInv) {
      const newStock = existingInv.JUMLAH_READY + qty;
      const isReorder = newStock <= existingInv.REORDER_LEVEL ? 'YES' : 'NO';
      targetInvItem = {
        ...existingInv,
        JUMLAH_READY: newStock,
        REORDER: isReorder,
        ...(isReorder === 'YES' && existingInv.ORDER_DATE ? { ORDER_DATE: existingInv.ORDER_DATE } : {}),
      };
      if (isReorder !== 'YES') {
        delete targetInvItem.ORDER_DATE;
      }
    } else {
      const prod = products.find((p) => p.SKU_ID === txSku);
      targetInvItem = {
        GUDANG_ID: targetGudangId,
        SKU_ID: txSku,
        NAMA_PRODUK: prod?.NAMA_PRODUK || txSku,
        JUMLAH_READY: qty,
        REORDER_LEVEL: prod?.REORDER_LEVEL || 10,
        REORDER: qty <= (prod?.REORDER_LEVEL || 10) ? 'YES' : 'NO',
        WARNA: prod?.WARNA,
        UKURAN: prod?.UKURAN,
        KATEGORI: prod?.KATEGORI,
        JENIS_LENGAN: prod?.JENIS_LENGAN,
      };
    }

    setInventory((prev) => {
      const idx = prev.findIndex((i) => i.GUDANG_ID === targetGudangId && i.SKU_ID === txSku);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = targetInvItem;
        return updated;
      }
      return [...prev, targetInvItem];
    });

    MysqlSyncService.saveInventoryItem(targetInvItem).catch((err) =>
      console.error('Firestore inv stock in sync error:', err)
    );

    // 2. Update Master Product with new HPP & Selling Price
    const currentProd = products.find((p) => p.SKU_ID === txSku);
    if (currentProd) {
      const updatedProd: MasterProduk = {
        ...currentProd,
        HARGA_HPP: hpp,
        HARGA_JUAL: jual,
      };
      setProducts((prev) => prev.map((p) => (p.SKU_ID === txSku ? updatedProd : p)));
      MysqlSyncService.saveProduct(updatedProd).catch((err) =>
        console.error('Firestore prod stock in sync error:', err)
      );
    }

    // 3. Record Log
    const txId = `TX${String(logs.length + 1).padStart(4, '0')}`;
    const descParts = [
      txKeterangan.trim() || 'Barang masuk / restock konveksi',
      `Gudang: ${targetGudangNama}`,
      `HPP: ${formatRupiah(hpp)}`,
      `Jual: ${formatRupiah(jual)}`,
      `Total Nilai: ${formatRupiah(totalNilai)}`,
    ];
    const newLog: LogTransaksi = {
      TIMESTAMP: new Date().toISOString(),
      TRANSAKSI_ID: txId,
      SKU_ID: txSku,
      GUDANG_ID: targetGudangId,
      JUMLAH: qty,
      TIPE_TRANSAKSI: 'MASUK',
      USERS: currentUser.username,
      KETERANGAN: descParts.join(' | '),
    };

    setLogs((prev) => [newLog, ...prev]);
    MysqlSyncService.saveLog(newLog).catch((err) =>
      console.error('Firestore log stock in sync error:', err)
    );
    showToast(
      `✅ Barang Masuk ${txSku} (+${qty} pcs) disimpan ke gudang ${targetGudangNama} (${targetGudangId}). HPP: ${formatRupiah(hpp)} | Jual: ${formatRupiah(jual)}`,
      'success'
    );
    PushNotificationService.sendNotification(
      '📦 Barang Masuk Diterima',
      `+${qty} pcs SKU ${txSku} berhasil dimasukkan ke gudang ${targetGudangNama}.`,
      'STOK'
    );
    setTxJumlah(50);
    setTxKeterangan('');
  };

  // Handle Apply Stock Opname Adjustments
  const handleApplyOpnameAdjustment = (
    session: StockOpnameSession,
    adjustments: {
      gudangId: string;
      skuId: string;
      newStock: number;
      oldStock: number;
      diff: number;
      reason: string;
    }[]
  ) => {
    // Auto Checkpoint before applying Stock Opname adjustments
    if (settings.checkpointSettings?.autoBeforeOpname !== false) {
      CheckpointService.createCheckpoint(
        'AUTO_OPNAME',
        `Sebelum Berita Acara Opname ${session.nomorOpname}`,
        session.auditor || currentUser?.username || 'Sistem',
        {
          products,
          warehouses,
          inventory,
          logs,
          users,
          settings,
          orders,
          suratJalanList,
          sales,
          customers,
        },
        `Snapshot otomatis sebelum penyesuaian ${adjustments.length} SKU opname fisik`,
        settings.checkpointSettings
      );
    }

    // 1. Update inventory
    setInventory((prev) => {
      const updated = [...prev];
      adjustments.forEach((adj) => {
        const idx = updated.findIndex((i) => i.GUDANG_ID === adj.gudangId && i.SKU_ID === adj.skuId);
        if (idx >= 0) {
          const isReorder = adj.newStock <= updated[idx].REORDER_LEVEL ? 'YES' : 'NO';
          const updatedItem: InventoryItem = {
            ...updated[idx],
            JUMLAH_READY: adj.newStock,
            REORDER: isReorder,
            ...(isReorder === 'YES' ? { ORDER_DATE: new Date().toISOString() } : {}),
          };
          if (isReorder !== 'YES') {
            delete updatedItem.ORDER_DATE;
          }
          updated[idx] = updatedItem;
          MysqlSyncService.saveInventoryItem(updatedItem).catch((err) =>
            console.error('Firestore opname inv sync err:', err)
          );
        } else {
          const prod = products.find((p) => p.SKU_ID === adj.skuId);
          const newInvItem: InventoryItem = {
            GUDANG_ID: adj.gudangId,
            SKU_ID: adj.skuId,
            NAMA_PRODUK: prod?.NAMA_PRODUK || adj.skuId,
            JUMLAH_READY: adj.newStock,
            REORDER_LEVEL: prod?.REORDER_LEVEL || 10,
            REORDER: adj.newStock <= (prod?.REORDER_LEVEL || 10) ? 'YES' : 'NO',
            WARNA: prod?.WARNA,
            UKURAN: prod?.UKURAN,
            KATEGORI: prod?.KATEGORI,
            JENIS_LENGAN: prod?.JENIS_LENGAN,
          };
          updated.push(newInvItem);
          MysqlSyncService.saveInventoryItem(newInvItem).catch((err) =>
            console.error('Firestore opname inv sync err:', err)
          );
        }
      });
      return updated;
    });

    // 2. Append Log Transaksi for each discrepancy adjustment
    if (adjustments.length > 0) {
      const newLogs: LogTransaksi[] = adjustments.map((adj, i) => {
        const txId = `TX${String(logs.length + 1 + i).padStart(4, '0')}`;
        const logItem: LogTransaksi = {
          TIMESTAMP: new Date().toISOString(),
          TRANSAKSI_ID: txId,
          SKU_ID: adj.skuId,
          GUDANG_ID: adj.gudangId,
          JUMLAH: adj.diff,
          TIPE_TRANSAKSI: 'KOREKSI',
          USERS: session.auditor || currentUser?.username || 'admin',
          KETERANGAN: `[OPNAME ${session.nomorOpname}] Sistem: ${adj.oldStock} → Fisik: ${adj.newStock} (Selisih ${adj.diff > 0 ? '+' : ''}${adj.diff} pcs) | ${adj.reason}`,
        };
        MysqlSyncService.saveLog(logItem).catch((err) =>
          console.error('Firestore opname log sync err:', err)
        );
        return logItem;
      });
      setLogs((prev) => [...newLogs.reverse(), ...prev]);
    }

    // 3. Save completed session to history in localStorage
    try {
      const existingHistoryStr = localStorage.getItem('INVENTORY_SO_HISTORY');
      const existingHistory = existingHistoryStr ? JSON.parse(existingHistoryStr) : [];
      localStorage.setItem('INVENTORY_SO_HISTORY', JSON.stringify([session, ...existingHistory]));
    } catch (e) {
      console.error('Save SO history err:', e);
    }

    showToast(
      `✅ Berita Acara Stok Opname ${session.nomorOpname} berhasil diterapkan (${adjustments.length} SKU disesuaikan).`,
      'success'
    );
  };

  // Handle Save PO Order Document
  const handleSaveOrderDoc = (orderDoc: OrderDocument) => {
    setOrders((prev) => [orderDoc, ...prev.filter((o) => o.nomorOrder !== orderDoc.nomorOrder)]);

    const newLogs: LogTransaksi[] = orderDoc.items.map((item, idx) => {
      const txId = `TX${String(logs.length + 1 + idx).padStart(4, '0')}`;
      const ket = [
        `NO.ORDER:${orderDoc.nomorOrder}`,
        orderDoc.supplier ? `SUPPLIER:${orderDoc.supplier}` : '',
        item.keterangan || '',
        orderDoc.catatan || '',
      ]
        .filter(Boolean)
        .join(' | ');

      return {
        TIMESTAMP: new Date().toISOString(),
        TRANSAKSI_ID: txId,
        SKU_ID: item.SKU_ID,
        GUDANG_ID: orderDoc.gudangId,
        JUMLAH: item.jumlah,
        TIPE_TRANSAKSI: 'ORDER',
        USERS: orderDoc.username,
        KETERANGAN: ket,
      };
    });

    setLogs((prev) => [...newLogs.reverse(), ...prev]);
    showToast(`Order PO ${orderDoc.nomorOrder} berhasil disimpan ke log & rekapitulasi.`, 'success');
    PushNotificationService.sendNotification(
      '📋 Order Pembelian PO Baru',
      `PO ${orderDoc.nomorOrder} (${orderDoc.supplier || 'Pabrik'}) berhasil diterbitkan.`,
      'ORDER'
    );
    MysqlSyncService.saveOrder(orderDoc).catch((err) => console.error('Firestore order sync:', err));
  };

  // Handle Save Surat Jalan Document
  const handleSaveSuratJalanDoc = (sjDoc: SuratJalanDocument) => {
    const existingSJ = suratJalanList.find((s) => s.nomorSJ === sjDoc.nomorSJ);
    setSuratJalanList((prev) => [sjDoc, ...prev.filter((s) => s.nomorSJ !== sjDoc.nomorSJ)]);

    // Deduct stock for all items
    setInventory((prev) => {
      const updated = [...prev];
      if (existingSJ) {
        existingSJ.items.forEach((item) => {
          const idx = updated.findIndex((i) => i.GUDANG_ID === existingSJ.gudangId && i.SKU_ID === item.SKU_ID);
          if (idx >= 0) {
            updated[idx] = {
              ...updated[idx],
              JUMLAH_READY: updated[idx].JUMLAH_READY + item.jumlah,
            };
          }
        });
      }
      sjDoc.items.forEach((item) => {
        const idx = updated.findIndex((i) => i.GUDANG_ID === sjDoc.gudangId && i.SKU_ID === item.SKU_ID);
        if (idx >= 0) {
          const newStock = Math.max(0, updated[idx].JUMLAH_READY - item.jumlah);
          const isReorder = newStock <= updated[idx].REORDER_LEVEL ? 'YES' : 'NO';
          const updatedItem: InventoryItem = {
            ...updated[idx],
            JUMLAH_READY: newStock,
            REORDER: isReorder,
            ...(isReorder === 'YES' ? { ORDER_DATE: new Date().toISOString() } : {}),
          };
          if (isReorder !== 'YES') {
            delete updatedItem.ORDER_DATE;
          }
          updated[idx] = updatedItem;
          MysqlSyncService.saveInventoryItem(updatedItem).catch((err) => console.error('Firestore inv sync:', err));
        }
      });
      return updated;
    });

    // Record logs
    const newLogs: LogTransaksi[] = sjDoc.items.map((item, idx) => {
      const txId = `TX${String(logs.length + 1 + idx).padStart(4, '0')}`;
      const ket = [
        `NO.SJ:${sjDoc.nomorSJ}`,
        `TUJUAN:${sjDoc.tujuan}`,
        sjDoc.penerima ? `PENERIMA:${sjDoc.penerima}` : '',
        sjDoc.driver ? `DRIVER:${sjDoc.driver}` : '',
        sjDoc.kendaraan ? `KENDARAAN:${sjDoc.kendaraan}` : '',
        item.keterangan || '',
        sjDoc.catatan || '',
      ]
        .filter(Boolean)
        .join(' | ');

      return {
        TIMESTAMP: new Date().toISOString(),
        TRANSAKSI_ID: txId,
        SKU_ID: item.SKU_ID,
        GUDANG_ID: sjDoc.gudangId,
        JUMLAH: -item.jumlah,
        TIPE_TRANSAKSI: 'KELUAR',
        USERS: sjDoc.username,
        KETERANGAN: ket,
      };
    });

    setLogs((prev) => [...newLogs.reverse(), ...prev]);
    showToast(`Surat Jalan ${sjDoc.nomorSJ} disimpan & stok ${sjDoc.items.length} SKU terpotong.`, 'success');
    PushNotificationService.sendNotification(
      '🚚 Surat Jalan Terbit',
      `SJ ${sjDoc.nomorSJ} (${sjDoc.penerima || sjDoc.tujuan}) berhasil diterbitkan.`,
      'SJ'
    );
    MysqlSyncService.saveSuratJalan(sjDoc).catch((err) => console.error('Firestore SJ sync:', err));
  };

  // Handle Save Sale Document
  const handleSaveSaleDoc = (saleDoc: SaleDocument) => {
    // Otomatis daftarkan pelanggan jika diketik manual & belum terdaftar di Halaman Pelanggan
    const customerNameTrimmed = saleDoc.pelanggan?.trim();
    if (
      customerNameTrimmed &&
      customerNameTrimmed.toLowerCase() !== 'pelanggan umum' &&
      customerNameTrimmed.toLowerCase() !== 'umum' &&
      customerNameTrimmed.toLowerCase() !== 'walk-in'
    ) {
      const cleanPhone = (saleDoc.kontak || '').replace(/[^0-9]/g, '');
      const existingCustomer = customers.find((c) => {
        const cName = c.nama.trim().toLowerCase();
        const cPhone = (c.telepon || '').replace(/[^0-9]/g, '');
        const isMatchId = Boolean(saleDoc.pelangganId && c.id === saleDoc.pelangganId);
        const isMatchName = cName === customerNameTrimmed.toLowerCase();
        const isMatchPhone = Boolean(cleanPhone && cleanPhone.length >= 8 && cPhone && cPhone === cleanPhone);
        return isMatchId || isMatchName || isMatchPhone;
      });

      if (existingCustomer) {
        saleDoc.pelangganId = existingCustomer.id;
      } else {
        const nextSeq = customers.length + 1;
        let candidateId = saleDoc.pelangganId || `CUST-${String(nextSeq).padStart(3, '0')}`;
        let counter = nextSeq;
        while (customers.some((c) => c.id === candidateId)) {
          counter++;
          candidateId = `CUST-${String(counter).padStart(3, '0')}`;
        }

        const autoNewCustomer: Pelanggan = {
          id: candidateId,
          nama: customerNameTrimmed,
          telepon: saleDoc.kontak && saleDoc.kontak !== '-' ? saleDoc.kontak.trim() : '-',
          alamat: saleDoc.alamat?.trim() || undefined,
          kota: saleDoc.alamat?.trim() || undefined,
          tipe: saleDoc.tipePelanggan || 'UMUM',
          plafonPiutang: 5000000,
          catatan: `Otomatis terdaftar dari transaksi Nota ${saleDoc.nomorSale}`,
          createdAt: new Date().toISOString(),
        };

        handleSaveCustomer(autoNewCustomer);
        saleDoc.pelangganId = candidateId;
        showToast(`Pelanggan baru "${autoNewCustomer.nama}" otomatis ditambahkan ke Halaman Pelanggan!`, 'success');
      }
    }

    const existingSale = sales.find((s) => s.nomorSale === saleDoc.nomorSale);
    setSales((prev) => [saleDoc, ...prev.filter((s) => s.nomorSale !== saleDoc.nomorSale)]);

    // Hitung penyesuaian stok (Koreksi Edit Faktur vs Faktur Baru)
    // Map untuk menampung perubahan stok per {gudangId, skuId}
    // Nilai delta > 0 berarti stok BERTAMBAH (dikembalikan ke gudang)
    // Nilai delta < 0 berarti stok BERKURANG (dipotong dari gudang)
    const stockDeltas: { [key: string]: { gudangId: string; skuId: string; delta: number; reason: string } } = {};
    const newLogs: LogTransaksi[] = [];
    let logCounter = logs.length + 1;

    if (existingSale) {
      // 1. Periksa setiap item di faktur sebelumnya
      existingSale.items.forEach((oldItem) => {
        const oldQty = Number(oldItem.jumlah) || 0;
        if (oldQty <= 0) return;

        // Cari item yang bersesuaian di faktur yang baru diedit (gudang sama & SKU sama)
        const newItem =
          saleDoc.gudangId === existingSale.gudangId
            ? saleDoc.items.find((it) => it.SKU_ID === oldItem.SKU_ID)
            : null;

        if (!newItem) {
          // ITEM INI DIHAPUS DARI FAKTUR (atau gudang diubah): Kembalikan seluruh stok lama ke gudang asal!
          const key = `${existingSale.gudangId}__${oldItem.SKU_ID}`;
          stockDeltas[key] = {
            gudangId: existingSale.gudangId,
            skuId: oldItem.SKU_ID,
            delta: (stockDeltas[key]?.delta || 0) + oldQty,
            reason: `Item dihapus dari faktur (+${oldQty} pcs dikembalikan)`,
          };

          const txId = `TX${String(logCounter++).padStart(4, '0')}`;
          newLogs.push({
            TIMESTAMP: new Date().toISOString(),
            TRANSAKSI_ID: txId,
            SKU_ID: oldItem.SKU_ID,
            GUDANG_ID: existingSale.gudangId,
            JUMLAH: oldQty,
            TIPE_TRANSAKSI: 'MASUK',
            USERS: saleDoc.username || currentUser?.username || 'admin',
            KETERANGAN: `KOREKSI FAKTUR ${saleDoc.nomorSale}: Item ${oldItem.SKU_ID} dihapus dari faktur (+${oldQty} pcs dikembalikan ke gudang ${existingSale.gudangNama || existingSale.gudangId})`,
          });
        } else {
          // Item masih ada di faktur: Bandingkan kuantitas lama vs kuantitas baru
          const newQty = Number(newItem.jumlah) || 0;
          const diff = oldQty - newQty; // diff > 0: pengurangan qty nota (stok dikembalikan); diff < 0: penambahan qty (stok dipotong)
          if (diff !== 0) {
            const key = `${saleDoc.gudangId}__${oldItem.SKU_ID}`;
            stockDeltas[key] = {
              gudangId: saleDoc.gudangId,
              skuId: oldItem.SKU_ID,
              delta: (stockDeltas[key]?.delta || 0) + diff,
              reason: diff > 0
                ? `Pengurangan qty nota (+${diff} pcs dikembalikan)`
                : `Penambahan qty nota (${diff} pcs dipotong)`,
            };

            const txId = `TX${String(logCounter++).padStart(4, '0')}`;
            newLogs.push({
              TIMESTAMP: new Date().toISOString(),
              TRANSAKSI_ID: txId,
              SKU_ID: oldItem.SKU_ID,
              GUDANG_ID: saleDoc.gudangId,
              JUMLAH: diff,
              TIPE_TRANSAKSI: diff > 0 ? 'MASUK' : 'SALE',
              USERS: saleDoc.username || currentUser?.username || 'admin',
              KETERANGAN: diff > 0
                ? `KOREKSI FAKTUR ${saleDoc.nomorSale}: Pengurangan qty item ${oldItem.SKU_ID} dari ${oldQty} ke ${newQty} (+${diff} pcs dikembalikan ke gudang)`
                : `KOREKSI FAKTUR ${saleDoc.nomorSale}: Penambahan qty item ${oldItem.SKU_ID} dari ${oldQty} ke ${newQty} (${Math.abs(diff)} pcs dipotong dari gudang)`,
            });
          }
        }
      });

      // 2. Periksa item baru yang ditambahkan ke faktur pada saat koreksi
      saleDoc.items.forEach((newItem) => {
        const newQty = Number(newItem.jumlah) || 0;
        if (newQty <= 0) return;

        const wasInOld =
          saleDoc.gudangId === existingSale.gudangId &&
          existingSale.items.some((it) => it.SKU_ID === newItem.SKU_ID);

        if (!wasInOld) {
          const key = `${saleDoc.gudangId}__${newItem.SKU_ID}`;
          stockDeltas[key] = {
            gudangId: saleDoc.gudangId,
            skuId: newItem.SKU_ID,
            delta: (stockDeltas[key]?.delta || 0) - newQty,
            reason: `Item baru ditambahkan pada nota (-${newQty} pcs)`,
          };

          const txId = `TX${String(logCounter++).padStart(4, '0')}`;
          newLogs.push({
            TIMESTAMP: new Date().toISOString(),
            TRANSAKSI_ID: txId,
            SKU_ID: newItem.SKU_ID,
            GUDANG_ID: saleDoc.gudangId,
            JUMLAH: -newQty,
            TIPE_TRANSAKSI: 'SALE',
            USERS: saleDoc.username || currentUser?.username || 'admin',
            KETERANGAN: `KOREKSI FAKTUR ${saleDoc.nomorSale}: Penambahan item baru ${newItem.SKU_ID} (-${newQty} pcs dipotong dari gudang)`,
          });
        }
      });
    } else {
      // FAKTUR PENJUALAN BARU: Potong seluruh stok item dari gudang
      saleDoc.items.forEach((item) => {
        const qty = Number(item.jumlah) || 0;
        if (qty <= 0) return;
        const key = `${saleDoc.gudangId}__${item.SKU_ID}`;
        stockDeltas[key] = {
          gudangId: saleDoc.gudangId,
          skuId: item.SKU_ID,
          delta: (stockDeltas[key]?.delta || 0) - qty,
          reason: `Penjualan nota baru (-${qty} pcs)`,
        };

        const txId = `TX${String(logCounter++).padStart(4, '0')}`;
        const ket = [
          `NO.SALE:${saleDoc.nomorSale}`,
          saleDoc.pelanggan ? `PELANGGAN:${saleDoc.pelanggan}` : '',
          saleDoc.kontak ? `KONTAK:${saleDoc.kontak}` : '',
          saleDoc.metode ? `BAYAR:${saleDoc.metode}` : '',
          item.keterangan || '',
          saleDoc.catatan || '',
        ]
          .filter(Boolean)
          .join(' | ');

        newLogs.push({
          TIMESTAMP: new Date().toISOString(),
          TRANSAKSI_ID: txId,
          SKU_ID: item.SKU_ID,
          GUDANG_ID: saleDoc.gudangId,
          JUMLAH: -qty,
          TIPE_TRANSAKSI: 'SALE',
          USERS: saleDoc.username || currentUser?.username || 'admin',
          KETERANGAN: ket,
        });
      });
    }

    // Terapkan seluruh perubahan stok ke state inventory & sinkronkan ke Firebase
    setInventory((prev) => {
      const updated = [...prev];
      Object.values(stockDeltas).forEach(({ gudangId, skuId, delta }) => {
        if (delta === 0) return;
        const idx = updated.findIndex((i) => i.GUDANG_ID === gudangId && i.SKU_ID === skuId);
        if (idx >= 0) {
          const newStock = Math.max(0, updated[idx].JUMLAH_READY + delta);
          const isReorder = newStock <= updated[idx].REORDER_LEVEL ? 'YES' : 'NO';
          const updatedItem: InventoryItem = {
            ...updated[idx],
            JUMLAH_READY: newStock,
            REORDER: isReorder,
            ...(isReorder === 'YES' ? { ORDER_DATE: updated[idx].ORDER_DATE || new Date().toISOString() } : {}),
          };
          if (isReorder !== 'YES') {
            delete updatedItem.ORDER_DATE;
          }
          updated[idx] = updatedItem;
          MysqlSyncService.saveInventoryItem(updatedItem).catch((err) =>
            console.error('Firestore inv sync error:', err)
          );
        }
      });
      return updated;
    });

    if (newLogs.length > 0) {
      setLogs((prev) => [...newLogs.reverse(), ...prev]);
      newLogs.forEach((l) => {
        MysqlSyncService.saveLog(l).catch((err) => console.error('Firestore log sync error:', err));
      });
    }

    if (existingSale) {
      showToast(`Koreksi Faktur ${saleDoc.nomorSale} disimpan. Stok item yang dihapus/diubah telah disesuaikan ke gudang.`, 'success');
    } else {
      showToast(`Nota Sale ${saleDoc.nomorSale} disimpan & stok terpotong.`, 'success');
      PushNotificationService.sendNotification(
        '🛍️ Penjualan Baru Terbit',
        `Faktur ${saleDoc.nomorSale} (${saleDoc.pelanggan || 'Umum'}) - Total ${formatRupiah(saleDoc.totalNominal)}.`,
        'SALE'
      );
    }
    MysqlSyncService.saveSale(saleDoc).catch((err) => console.error('Firestore sale sync:', err));
  };

  // Rekapitulasi Handlers (Delete & Open Modal - Akses Khusus Owner & SPV)
  const handleDeleteSale = (nomorSale: string) => {
    if (!isSpvOrOwner) {
      showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan menghapus dokumen Sale!', 'error');
      return;
    }

    const targetSale = sales.find((s) => s.nomorSale === nomorSale);
    if (!targetSale) {
      showToast(`Faktur ${nomorSale} tidak ditemukan.`, 'error');
      return;
    }

    // 1. Kembalikan stok untuk seluruh item di faktur penjualan yang dihapus
    let totalPcsReturned = 0;
    setInventory((prev) => {
      const updated = [...prev];
      targetSale.items.forEach((item) => {
        const qty = Number(item.jumlah) || 0;
        if (qty <= 0) return;
        totalPcsReturned += qty;

        const idx = updated.findIndex((i) => i.GUDANG_ID === targetSale.gudangId && i.SKU_ID === item.SKU_ID);
        if (idx >= 0) {
          const newStock = updated[idx].JUMLAH_READY + qty;
          const isReorder = newStock <= updated[idx].REORDER_LEVEL ? 'YES' : 'NO';
          const updatedItem: InventoryItem = {
            ...updated[idx],
            JUMLAH_READY: newStock,
            REORDER: isReorder,
            ...(isReorder === 'YES' ? { ORDER_DATE: updated[idx].ORDER_DATE || new Date().toISOString() } : {}),
          };
          if (isReorder !== 'YES') {
            delete updatedItem.ORDER_DATE;
          }
          updated[idx] = updatedItem;
          MysqlSyncService.saveInventoryItem(updatedItem).catch((err) =>
            console.error('Firestore inv return sync error:', err)
          );
        }
      });
      return updated;
    });

    // 2. Catat Log Transaksi Pengembalian Stok ke Gudang
    const returnLogs: LogTransaksi[] = targetSale.items.map((item, idx) => {
      const txId = `TX${String(logs.length + 1 + idx).padStart(4, '0')}`;
      const qty = Number(item.jumlah) || 0;
      return {
        TIMESTAMP: new Date().toISOString(),
        TRANSAKSI_ID: txId,
        SKU_ID: item.SKU_ID,
        GUDANG_ID: targetSale.gudangId,
        JUMLAH: qty, // Positif karena stok dikembalikan
        TIPE_TRANSAKSI: 'MASUK',
        USERS: currentUser?.username || 'admin',
        KETERANGAN: `PENGEMBALIAN STOK (HAPUS FAKTUR): Faktur ${targetSale.nomorSale} dibatalkan/dihapus (+${qty} pcs dikembalikan ke gudang ${targetSale.gudangNama || targetSale.gudangId})`,
      };
    });

    if (returnLogs.length > 0) {
      setLogs((prev) => [...returnLogs.reverse(), ...prev]);
      returnLogs.forEach((l) => {
        MysqlSyncService.saveLog(l).catch((err) => console.error('Firestore log sync error:', err));
      });
    }

    // 3. Hapus Faktur dari State & Firebase
    setSales((prev) => prev.filter((s) => s.nomorSale !== nomorSale));
    MysqlSyncService.deleteSale(nomorSale).catch((err) => console.error('Firestore delete sale:', err));

    showToast(
      `Faktur ${nomorSale} berhasil dihapus & ${totalPcsReturned} pcs stok barang telah dikembalikan ke asalnya di gudang.`,
      'success'
    );
  };

  // Hapus salah satu item langsung dari faktur penjualan & kembalikan stoknya ke gudang
  const handleDeleteSaleItem = (nomorSale: string, itemId: string) => {
    if (!isSpvOrOwner) {
      showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan mengoreksi faktur!', 'error');
      return;
    }

    const targetSale = sales.find((s) => s.nomorSale === nomorSale);
    if (!targetSale) {
      showToast(`Faktur ${nomorSale} tidak ditemukan.`, 'error');
      return;
    }

    if (targetSale.items.length <= 1) {
      showToast('Faktur ini hanya memiliki 1 item barang. Gunakan tombol Hapus Faktur jika ingin membatalkan seluruh transaksi.', 'info');
      return;
    }

    const targetItem = targetSale.items.find((it) => it.id === itemId);
    if (!targetItem) {
      showToast('Item barang tidak ditemukan di dalam faktur.', 'error');
      return;
    }

    const qtyToReturn = Number(targetItem.jumlah) || 0;

    // 1. Kembalikan stok item ke gudang
    setInventory((prev) => {
      const updated = [...prev];
      const idx = updated.findIndex((i) => i.GUDANG_ID === targetSale.gudangId && i.SKU_ID === targetItem.SKU_ID);
      if (idx >= 0) {
        const newStock = updated[idx].JUMLAH_READY + qtyToReturn;
        const isReorder = newStock <= updated[idx].REORDER_LEVEL ? 'YES' : 'NO';
        const updatedItem: InventoryItem = {
          ...updated[idx],
          JUMLAH_READY: newStock,
          REORDER: isReorder,
          ...(isReorder === 'YES' ? { ORDER_DATE: updated[idx].ORDER_DATE || new Date().toISOString() } : {}),
        };
        if (isReorder !== 'YES') {
          delete updatedItem.ORDER_DATE;
        }
        updated[idx] = updatedItem;
        MysqlSyncService.saveInventoryItem(updatedItem).catch((err) =>
          console.error('Firestore inv return sync error:', err)
        );
      }
      return updated;
    });

    // 2. Catat Log Transaksi Pengembalian Stok
    const txId = `TX${String(logs.length + 1).padStart(4, '0')}`;
    const returnLog: LogTransaksi = {
      TIMESTAMP: new Date().toISOString(),
      TRANSAKSI_ID: txId,
      SKU_ID: targetItem.SKU_ID,
      GUDANG_ID: targetSale.gudangId,
      JUMLAH: qtyToReturn,
      TIPE_TRANSAKSI: 'MASUK',
      USERS: currentUser?.username || 'admin',
      KETERANGAN: `KOREKSI REKAPITULASI: Item ${targetItem.SKU_ID} dihapus dari Faktur ${targetSale.nomorSale} (+${qtyToReturn} pcs dikembalikan ke gudang ${targetSale.gudangNama || targetSale.gudangId})`,
    };
    setLogs((prev) => [returnLog, ...prev]);
    MysqlSyncService.saveLog(returnLog).catch((err) => console.error('Firestore log sync error:', err));

    // 3. Perbarui Dokumen Faktur (Keluarkan item & hitung ulang total nominal)
    const updatedItems = targetSale.items.filter((it) => it.id !== itemId);
    const newSubtotal = updatedItems.reduce(
      (acc, it) => acc + (it.subtotal || Number(it.jumlah) * Number(it.hargaSatuan)),
      0
    );
    const newTotal = Math.max(0, newSubtotal - (targetSale.diskonNominal || 0));
    const newSisa =
      targetSale.statusPembayaran === 'LUNAS' ? 0 : Math.max(0, newTotal - (targetSale.jumlahBayar || 0));

    const updatedSaleDoc: SaleDocument = {
      ...targetSale,
      items: updatedItems,
      subtotalNominal: newSubtotal,
      totalNominal: newTotal,
      sisaPiutang: newSisa,
    };

    setSales((prev) => prev.map((s) => (s.nomorSale === nomorSale ? updatedSaleDoc : s)));
    MysqlSyncService.saveSale(updatedSaleDoc).catch((err) => console.error('Firestore update sale error:', err));

    showToast(
      `Item ${targetItem.SKU_ID} (${qtyToReturn} pcs) berhasil dihapus dari Faktur & stok telah dikembalikan ke gudang.`,
      'success'
    );
  };

  const handleDeleteOrder = (nomorOrder: string) => {
    if (!isSpvOrOwner) {
      showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan menghapus Purchase Order!', 'error');
      return;
    }
    setOrders((prev) => prev.filter((o) => o.nomorOrder !== nomorOrder));
    MysqlSyncService.deleteOrder(nomorOrder).catch((err) => console.error('Firestore delete order:', err));
  };

  const handleDeleteSuratJalan = (nomorSJ: string) => {
    if (!isSpvOrOwner) {
      showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan menghapus Surat Jalan!', 'error');
      return;
    }

    const targetSJ = suratJalanList.find((s) => s.nomorSJ === nomorSJ);
    if (!targetSJ) {
      showToast(`Surat Jalan ${nomorSJ} tidak ditemukan.`, 'error');
      return;
    }

    // Kembalikan stok item surat jalan ke gudang asal
    let totalPcsReturned = 0;
    setInventory((prev) => {
      const updated = [...prev];
      targetSJ.items.forEach((item) => {
        const qty = Number(item.jumlah) || 0;
        if (qty <= 0) return;
        totalPcsReturned += qty;

        const idx = updated.findIndex((i) => i.GUDANG_ID === targetSJ.gudangId && i.SKU_ID === item.SKU_ID);
        if (idx >= 0) {
          const newStock = updated[idx].JUMLAH_READY + qty;
          const isReorder = newStock <= updated[idx].REORDER_LEVEL ? 'YES' : 'NO';
          const updatedItem: InventoryItem = {
            ...updated[idx],
            JUMLAH_READY: newStock,
            REORDER: isReorder,
            ...(isReorder === 'YES' ? { ORDER_DATE: updated[idx].ORDER_DATE || new Date().toISOString() } : {}),
          };
          if (isReorder !== 'YES') {
            delete updatedItem.ORDER_DATE;
          }
          updated[idx] = updatedItem;
          MysqlSyncService.saveInventoryItem(updatedItem).catch((err) =>
            console.error('Firestore inv return sync error:', err)
          );
        }
      });
      return updated;
    });

    const returnLogs: LogTransaksi[] = targetSJ.items.map((item, idx) => {
      const txId = `TX${String(logs.length + 1 + idx).padStart(4, '0')}`;
      const qty = Number(item.jumlah) || 0;
      return {
        TIMESTAMP: new Date().toISOString(),
        TRANSAKSI_ID: txId,
        SKU_ID: item.SKU_ID,
        GUDANG_ID: targetSJ.gudangId,
        JUMLAH: qty,
        TIPE_TRANSAKSI: 'MASUK',
        USERS: currentUser?.username || 'admin',
        KETERANGAN: `PENGEMBALIAN STOK (HAPUS SJ): Surat Jalan ${targetSJ.nomorSJ} dibatalkan/dihapus (+${qty} pcs dikembalikan ke gudang ${targetSJ.gudangNama || targetSJ.gudangId})`,
      };
    });

    if (returnLogs.length > 0) {
      setLogs((prev) => [...returnLogs.reverse(), ...prev]);
      returnLogs.forEach((l) => {
        MysqlSyncService.saveLog(l).catch((err) => console.error('Firestore log sync error:', err));
      });
    }

    setSuratJalanList((prev) => prev.filter((sj) => sj.nomorSJ !== nomorSJ));
    MysqlSyncService.deleteSuratJalan(nomorSJ).catch((err) => console.error('Firestore delete surat jalan:', err));

    showToast(`Surat Jalan ${nomorSJ} berhasil dihapus & ${totalPcsReturned} pcs stok dikembalikan ke gudang.`, 'success');
  };

  const handleOpenSaleModal = (doc?: SaleDocument) => {
    setActiveViewingSale(doc || null);
    setShowSaleModal(true);
  };

  const handleOpenOrderModal = (doc?: OrderDocument) => {
    setActiveViewingOrder(doc || null);
    setShowOrderModal(true);
  };

  const handleOpenSuratJalanModal = (doc?: SuratJalanDocument) => {
    setActiveViewingSuratJalan(doc || null);
    setShowSuratJalanModal(true);
  };

  // Customer & Receivables Handlers
  const handleSaveCustomer = (cust: Pelanggan) => {
    const existing = customers.find((c) => c.id === cust.id);
    const oldName = existing?.nama;

    setCustomers((prev) => {
      const idx = prev.findIndex((c) => c.id === cust.id);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = cust;
        return updated;
      }
      return [cust, ...prev];
    });

    // Cascade update to all sales associated with this customer
    // This guarantees that changing phone number, address, or spelling of the name
    // will NEVER cause transactions to become duplicate or separate!
    setSales((prevSales) =>
      prevSales.map((s) => {
        const isMatchById = Boolean(s.pelangganId && s.pelangganId === cust.id);
        const isMatchByOldName = Boolean(oldName && s.pelanggan && s.pelanggan.trim().toLowerCase() === oldName.trim().toLowerCase());
        const isMatchByNewName = Boolean(cust.nama && s.pelanggan && s.pelanggan.trim().toLowerCase() === cust.nama.trim().toLowerCase());

        if (isMatchById || isMatchByOldName || isMatchByNewName) {
          const updatedSaleItem = {
            ...s,
            pelangganId: cust.id,
            pelanggan: cust.nama,
            kontak: cust.telepon !== '-' ? cust.telepon : (s.kontak || ''),
            alamat: cust.alamat || cust.kota || (s.alamat || ''),
          };
          MysqlSyncService.saveSale(updatedSaleItem).catch((err) => console.error('Firestore sync sale:', err));
          return updatedSaleItem;
        }
        return s;
      })
    );

    MysqlSyncService.saveCustomer(cust).catch((err) => console.error('Firestore sync customer:', err));
  };

  const handleDeleteCustomer = (id: string) => {
    if (!isSpvOrOwner) {
      showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan menghapus data pelanggan!', 'error');
      return;
    }
    setCustomers((prev) => prev.filter((c) => c.id !== id));
    MysqlSyncService.deleteCustomer(id).catch((err) => console.error('Firestore delete customer:', err));
  };

  const handleUpdateSale = (updatedSale: SaleDocument) => {
    setSales((prev) => prev.map((s) => (s.nomorSale === updatedSale.nomorSale ? updatedSale : s)));
    MysqlSyncService.saveSale(updatedSale).catch((err) => console.error('Firestore update sale:', err));

    const latestPay = updatedSale.riwayatPelunasan?.[updatedSale.riwayatPelunasan.length - 1];
    if (latestPay) {
      const txId = `TX${String(logs.length + 1).padStart(4, '0')}`;
      const newLog: LogTransaksi = {
        TIMESTAMP: new Date().toISOString(),
        TRANSAKSI_ID: txId,
        SKU_ID: updatedSale.items[0]?.SKU_ID || 'PELUNASAN',
        GUDANG_ID: updatedSale.gudangId,
        JUMLAH: 0,
        TIPE_TRANSAKSI: 'SALE',
        USERS: currentUser?.username || 'admin',
        KETERANGAN: `Pelunasan Piutang ${updatedSale.nomorSale} (${updatedSale.pelanggan}): +${formatRupiah(latestPay.jumlahBayar)} via ${latestPay.metode}. Sisa: ${formatRupiah(updatedSale.sisaPiutang || 0)}`,
      };
      setLogs((prev) => [newLog, ...prev]);
      MysqlSyncService.saveLog(newLog).catch((err) => console.error('Firestore sync log:', err));
    }
  };

  const handleOpenSaleModalWithCustomer = (customer: Pelanggan) => {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const dateStr = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`;
    const randomSeq = String(Math.floor(1000 + Math.random() * 9000));

    const newDoc: SaleDocument = {
      nomorSale: `SALE-${dateStr}-${randomSeq}`,
      tanggal: `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`,
      gudangId: currentUser?.siteAccess?.includes('ERVO') ? 'GDG-01-ERVO' : 'GDG-02-TOKO',
      gudangNama: currentUser?.siteAccess || 'GUDANG TOKO',
      username: currentUser?.username || 'admin',
      pelanggan: customer.nama,
      pelangganId: customer.id,
      kontak: customer.telepon !== '-' ? customer.telepon : '',
      alamat: customer.alamat || customer.kota || '',
      metode: 'TUNAI',
      catatan: `Penjualan untuk ${customer.nama} (${customer.tipe})`,
      subtotalNominal: 0,
      diskonNominal: 0,
      totalNominal: 0,
      statusPembayaran: 'LUNAS',
      jumlahBayar: 0,
      sisaPiutang: 0,
      items: [
        {
          id: 'item-1',
          SKU_ID: products[0]?.SKU_ID || '',
          jumlah: 1,
          hargaSatuan: products[0]?.HARGA_JUAL || 45000,
          subtotal: products[0]?.HARGA_JUAL || 45000,
          keterangan: '',
        },
      ],
      createdAt: new Date().toISOString(),
    };
    setActiveViewingSale(newDoc);
    setShowSaleModal(true);
  };

  // Product CRUD Handlers
  const handleSaveProduct = (prodData: MasterProduk) => {
    setProducts((prev) => {
      const idx = prev.findIndex((p) => p.SKU_ID === prodData.SKU_ID);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = prodData;
        return updated;
      }
      return [prodData, ...prev];
    });
    MysqlSyncService.saveProduct(prodData).catch((err) => console.error('Firestore save product:', err));

    // Pastikan baris inventori ada di semua gudang aktif dan sinkron ke Firestore
    const activeWhs = warehouses.filter((w) => w.IS_ACTIVE !== false);
    const invItemsToSync: InventoryItem[] = [];

    setInventory((prev) => {
      let next = [...prev];
      activeWhs.forEach((wh) => {
        const idx = next.findIndex((i) => i.GUDANG_ID === wh.GUDANG_ID && i.SKU_ID === prodData.SKU_ID);
        if (idx < 0) {
          const newInv: InventoryItem = {
            GUDANG_ID: wh.GUDANG_ID,
            SKU_ID: prodData.SKU_ID,
            NAMA_PRODUK: prodData.NAMA_PRODUK,
            JUMLAH_READY: 0,
            REORDER_LEVEL: prodData.REORDER_LEVEL || settings.defaultReorderLevel || 10,
            REORDER: 'YES',
            WARNA: prodData.WARNA,
            UKURAN: prodData.UKURAN,
            KATEGORI: prodData.KATEGORI,
            JENIS_LENGAN: prodData.JENIS_LENGAN,
          };
          invItemsToSync.push(newInv);
          next.push(newInv);
        } else {
          const updated = {
            ...next[idx],
            NAMA_PRODUK: prodData.NAMA_PRODUK,
            WARNA: prodData.WARNA,
            UKURAN: prodData.UKURAN,
            KATEGORI: prodData.KATEGORI,
            JENIS_LENGAN: prodData.JENIS_LENGAN,
            REORDER_LEVEL: prodData.REORDER_LEVEL || next[idx].REORDER_LEVEL,
          };
          invItemsToSync.push(updated);
          next[idx] = updated;
        }
      });
      return next;
    });

    invItemsToSync.forEach((item) => {
      MysqlSyncService.saveInventoryItem(item).catch((err) =>
        console.error('Firestore prod inv sync error:', err)
      );
    });

    showToast(`Produk ${prodData.SKU_ID} berhasil disimpan & disinkronkan.`, 'success');
  };

  const handleDeleteProduct = (skuId: string) => {
    if (!isSpvOrOwner) {
      showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan menghapus master produk!', 'error');
      return;
    }
    if (confirm(`Yakin ingin menghapus produk "${skuId}" dari master data?`)) {
      setProducts((prev) => prev.filter((p) => p.SKU_ID !== skuId));
      MysqlSyncService.deleteProduct(skuId).catch((err) => console.error('Firestore delete product:', err));

      // Hapus seluruh baris inventori terkait produk ini
      setInventory((prev) => prev.filter((i) => i.SKU_ID !== skuId));
      warehouses.forEach((wh) => {
        const docId = `${wh.GUDANG_ID}_${skuId}`;
        MysqlSyncService.deleteInventoryItem(docId).catch(() => {});
      });

      showToast(`Produk ${skuId} telah dihapus dari cloud database & lokal.`, 'info');
    }
  };

  const handleUpdateSettings = (newSettings: AppSystemSettings) => {
    setSettings(newSettings);
    MysqlSyncService.saveSettings(newSettings).catch((err) =>
      console.error('Firestore save settings error:', err)
    );
  };

  return (
    <div
      className={`min-h-screen w-full max-w-full overflow-x-hidden flex flex-col antialiased pb-16 transition-colors duration-200 ${
        themeMode === 'light'
          ? 'theme-light bg-[#f8fafc] text-[#0f172a]'
          : 'theme-dark bg-[#0F0F10] text-[#E0E0E0]'
      }`}
    >

      {/* Toast Notification Container */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-right duration-200">
          <div
            className={`px-4 py-3 rounded-xl shadow-xl text-white font-medium text-xs sm:text-sm flex items-center gap-2.5 max-w-sm ${
              toastMessage.type === 'success'
                ? 'bg-emerald-600 shadow-emerald-600/25'
                : toastMessage.type === 'error'
                ? 'bg-rose-600 shadow-rose-600/25'
                : 'bg-[#1C1C20] border border-[#2B2B32] shadow-black/40'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 shrink-0" />
            ) : toastMessage.type === 'error' ? (
              <AlertTriangle className="w-5 h-5 shrink-0" />
            ) : (
              <Package className="w-5 h-5 shrink-0 text-[#F27D26]" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* HEADER NAVBAR */}
      <header className="sticky top-0 z-40 bg-[#121214] text-[#E0E0E0] shadow-xl border-b border-[#24242A] w-full max-w-full">
        <div className="w-full max-w-[1920px] mx-auto px-2 sm:px-6 2xl:px-8 h-14 sm:h-16 flex items-center justify-between gap-1.5 sm:gap-3">
          {/* Logo & Title */}
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-[#F27D26] flex items-center justify-center text-white shadow-md shadow-[#F27D26]/20 shrink-0">
              <Factory className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div className="min-w-0">
              <div className="font-extrabold text-sm sm:text-base lg:text-lg tracking-tight leading-none flex items-center gap-1.5 sm:gap-2 text-white truncate">
                <span className="truncate">Inventori Kaos</span>
                <span className="hidden xs:inline truncate">Polos</span>
                <span className="hidden md:inline-flex text-[10px] font-bold bg-[#F27D26]/20 text-[#F27D26] px-2 py-0.5 rounded-full border border-[#F27D26]/30 shrink-0">
                  v2.0 E-Signature
                </span>
              </div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span
                  title={`Gudang Aktif: ${activeHeaderWarehouse}`}
                  className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[9.5px] xs:text-[10px] font-bold bg-emerald-950/70 text-emerald-400 border border-emerald-800/50 shadow-xs shrink-0"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                  <span className="truncate max-w-[120px] xs:max-w-[170px] sm:max-w-none">{activeHeaderWarehouse}</span>
                </span>
                {isInitialLoadingDb ? (
                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[9.5px] xs:text-[10px] font-bold bg-amber-950/70 text-amber-400 border border-amber-800/50 shadow-xs shrink-0 animate-pulse">
                    <RefreshCw className="w-2.5 h-2.5 animate-spin shrink-0" />
                    <span>Sinkron MySQL...</span>
                  </span>
                ) : (
                  <p className="text-[10.5px] text-neutral-400 hidden sm:block truncate">
                    • {warehouses.length <= 3
                      ? warehouses.map((w) => w.NAMA_GUDANG?.toUpperCase().includes('ERVO') ? 'GUDANG UTAMA' : w.NAMA_GUDANG).join(' & ')
                      : `${warehouses.length} Gudang Aktif`}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Header Right Actions */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Quick Barcode Scanner Floating Tool */}
            <button
              type="button"
              onClick={() => setShowQuickLookupModal(true)}
              className="p-1.5 sm:px-3 sm:py-1.5 bg-[#F27D26]/15 hover:bg-[#F27D26] text-[#F27D26] hover:text-white border border-[#F27D26]/40 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              title="Pindai Barcode Cepat"
            >
              <QrCode className="w-4 h-4" />
              <span className="hidden lg:inline">Pindai Barcode</span>
            </button>

            {/* Quick Backup & Checkpoint Tool */}
            <button
              type="button"
              onClick={() => setShowBackupModal(true)}
              className="p-1.5 sm:px-2.5 sm:py-1.5 text-blue-300 hover:text-white bg-blue-950/40 hover:bg-blue-900/60 rounded-xl transition-colors border border-blue-800/60 flex items-center gap-1.5 cursor-pointer text-xs font-bold shadow-xs"
              title="Pusat Backup & Checkpoint Otomatis"
            >
              <Database className="w-4 h-4 text-blue-400" />
              <span className="hidden xl:inline">Backup & Checkpoint</span>
            </button>

            {/* Theme Toggle (Hanya Mode Gelap dan Mode Terang) */}
            <button
              type="button"
              onClick={toggleTheme}
              className={`p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer ${
                themeMode === 'light'
                  ? 'bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300'
                  : 'bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 hover:text-white border border-[#2B2B32]'
              }`}
              title={`Klik untuk beralih ke ${themeMode === 'dark' ? 'Mode Terang' : 'Mode Gelap'}`}
            >
              {themeMode === 'dark' ? (
                <>
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span className="hidden xl:inline">Mode Terang</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-indigo-600" />
                  <span className="hidden xl:inline">Mode Gelap</span>
                </>
              )}
            </button>

            {/* MySQL / phpMyAdmin Status Button */}
            <button
              type="button"
              onClick={() => setShowPhpMyAdminModal(true)}
              className="p-1.5 sm:px-2.5 sm:py-1.5 text-amber-300 hover:text-amber-200 bg-amber-950/40 hover:bg-amber-900/60 rounded-xl transition-colors border border-amber-800/60 flex items-center gap-1.5 cursor-pointer text-xs font-bold shadow-xs"
              title="Database MySQL / phpMyAdmin"
            >
              <Database className="w-4 h-4 text-amber-400" />
              <span className="hidden xl:inline">MySQL / phpMyAdmin</span>
              <span
                className={`w-2 h-2 rounded-full ${
                  isMysqlOnline ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
                }`}
              />
            </button>

            {/* Push Notification Center Tool */}
            <button
              type="button"
              onClick={() => setShowNotificationModal(true)}
              className="relative p-1.5 sm:px-2.5 sm:py-1.5 text-neutral-300 hover:text-white bg-[#1C1C20] hover:bg-[#28282E] rounded-xl transition-colors border border-[#2B2B32] flex items-center gap-1.5 cursor-pointer text-xs font-bold shadow-xs"
              title="Pusat Push Notifikasi Browser"
            >
              <Bell className="w-4 h-4 text-[#F27D26]" />
              <span className="hidden xl:inline">Push Notifikasi</span>
              {unreadNotifCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-extrabold bg-[#F27D26] text-white">
                  {unreadNotifCount}
                </span>
              )}
            </button>

            {/* Offline & Quota Auto-Sync Status Button */}
            <button
              type="button"
              onClick={() => setShowOfflineSyncModal(true)}
              className={`p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl border flex items-center gap-1.5 cursor-pointer text-xs font-bold shadow-xs transition-colors ${
                syncStatus.isQuotaLimited
                  ? 'bg-amber-950/60 hover:bg-amber-900/80 text-amber-300 border-amber-600/80 animate-pulse'
                  : syncStatus.pendingCount > 0
                  ? 'bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-300 border-indigo-600/80'
                  : 'bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 border-[#2B2B32]'
              }`}
              title="Pusat Sinkronisasi Offline & Kuota Database"
            >
              {syncStatus.isQuotaLimited ? (
                <AlertTriangle className="w-4 h-4 text-amber-400" />
              ) : syncStatus.isOffline ? (
                <CloudOff className="w-4 h-4 text-blue-400" />
              ) : (
                <RefreshCw className={`w-4 h-4 ${syncStatus.isSyncing ? 'animate-spin text-indigo-400' : 'text-neutral-400'}`} />
              )}
              <span className="hidden xl:inline">
                {syncStatus.isQuotaLimited
                  ? 'Limit Harian'
                  : syncStatus.isOffline
                  ? 'Mode Offline'
                  : 'Auto-Sync'}
              </span>
              {syncStatus.pendingCount > 0 ? (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-extrabold bg-amber-500 text-black">
                  {syncStatus.pendingCount}
                </span>
              ) : (
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              )}
            </button>

            {/* Google Apps Script Code Modal */}
            <button
              type="button"
              onClick={() => setShowGasModal(true)}
              className="p-1.5 sm:p-2 text-neutral-300 hover:text-white bg-[#1C1C20] hover:bg-[#28282E] rounded-xl transition-colors border border-[#2B2B32] cursor-pointer"
              title="Lihat Kode Apps Script (GAS Code.gs)"
            >
              <FileCode className="w-4 h-4" />
            </button>

            {/* Auth Indicator / Buttons */}
            {currentUser ? (
              <div className="user-profile-badge flex items-center gap-1 sm:gap-2 bg-[#1C1C20] py-1 px-1.5 sm:px-2.5 rounded-xl border border-[#2B2B32]">
                <div className="text-right hidden md:block">
                  <div className="user-profile-name text-xs font-bold text-white leading-tight truncate max-w-[85px]">{currentUser.username}</div>
                  <span className="user-profile-site text-[9.5px] font-bold text-[#F27D26] block truncate max-w-[85px]">
                    {currentUser.siteAccess?.toUpperCase().includes('ERVO') ? 'GUDANG UTAMA' : currentUser.siteAccess}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="p-1.5 sm:px-2 sm:py-1 bg-rose-600/90 hover:bg-rose-600 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                  title="Logout"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Logout</span>
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setLoginUsername('');
                  setLoginPassword('');
                  setLoginError('');
                  setShowLoginModal(true);
                }}
                className="header-login-btn px-2.5 sm:px-3.5 py-1.5 bg-white/10 hover:bg-white text-white hover:text-neutral-900 border border-white/20 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span className="hidden sm:inline">Login Admin</span>
              </button>
            )}
          </div>
        </div>

        {/* Admin Navigation Tabs (Visible when logged in) */}
        {currentUser && (
          <div className="border-t border-[#24242A] bg-[#121214]">
            <div className="w-full max-w-[1920px] mx-auto px-3 sm:px-6 2xl:px-8 flex items-center gap-1 overflow-x-auto">
              {[
                { id: 'inventory' as const, label: 'Inventori Gudang Anda', icon: Package },
                { id: 'masuk' as const, label: 'Barang Masuk (+Scan)', icon: ArrowDownToLine },
                { id: 'opname' as const, label: 'Stok Opname (Audit)', icon: ClipboardCheck },
                {
                  id: 'rekap' as const,
                  label: `Rekapitulasi (Sale, PO, SJ) [${sales.length + orders.length + suratJalanList.length}]`,
                  icon: FileSpreadsheet,
                },
                {
                  id: 'pelanggan' as const,
                  label: `Pelanggan & Piutang (${customers.length})`,
                  icon: Users,
                },
                { id: 'logs' as const, label: `Log Transaksi (${logs.length})`, icon: ClipboardList },
                { id: 'settings' as const, label: 'Pengaturan Sistem', icon: Settings },
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = adminTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setAdminTab(tab.id)}
                    className={`relative py-3 px-4 text-xs font-bold flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer ${
                      isActive ? 'text-[#F27D26]' : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    {isActive && (
                      <motion.div
                        layoutId="adminTabActiveIndicator"
                        className="absolute inset-0 bg-[#1C1C20] border-b-2 border-[#F27D26]"
                        transition={{ type: 'spring', stiffness: 500, damping: 38 }}
                      />
                    )}
                    <span className="relative z-10 flex items-center gap-2">
                      <Icon className="w-4 h-4" /> {tab.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </header>

      {/* FILTER & SEARCH BAR (Available for Public View) */}
      {!currentUser && (
        <div className="bg-[#121214] border-b border-[#24242A] py-3 shadow-xs">
          <div className="w-full max-w-[1920px] mx-auto px-3 sm:px-6 2xl:px-8 flex flex-wrap items-center gap-2.5">
            {/* Search Input */}
            <div className="relative flex-1 min-w-[220px]">
              <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="🔍 Cari nama produk, warna, atau SKU..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-[#F27D26] focus:outline-hidden"
              />
            </div>

            {/* Warna Filter */}
            <select
              value={selectedWarna}
              onChange={(e) => setSelectedWarna(e.target.value)}
              className="py-2 px-3 text-xs bg-[#0F0F10] border border-[#2B2B32] text-neutral-200 rounded-xl font-medium focus:border-[#F27D26] focus:outline-hidden min-w-[130px]"
            >
              <option value="">Semua Warna</option>
              {uniqueColors.map((w) => (
                <option key={w} value={w}>
                  {w}
                </option>
              ))}
            </select>

            {/* Ukuran Filter */}
            <select
              value={selectedUkuran}
              onChange={(e) => setSelectedUkuran(e.target.value)}
              className="py-2 px-3 text-xs bg-[#0F0F10] border border-[#2B2B32] text-neutral-200 rounded-xl font-medium focus:border-[#F27D26] focus:outline-hidden"
            >
              <option value="">Semua Ukuran</option>
              {['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL', '4XL', '5XL', '6XL'].map((s) => (
                <option key={s} value={s}>
                  Ukuran {s}
                </option>
              ))}
            </select>

            {/* Lengan Filter */}
            <select
              value={selectedLengan}
              onChange={(e) => setSelectedLengan(e.target.value)}
              className="py-2 px-3 text-xs bg-[#0F0F10] border border-[#2B2B32] text-neutral-200 rounded-xl font-medium focus:border-[#F27D26] focus:outline-hidden"
            >
              <option value="">Semua Lengan</option>
              <option value="PENDEK">Lengan Pendek</option>
              <option value="PANJANG">Lengan Panjang</option>
              <option value="3P4">Lengan 3/4</option>
              <option value="7P8">Lengan 7/8</option>
            </select>

            {/* Warehouse Filter */}
            <select
              value={selectedFilterGudang}
              onChange={(e) => setSelectedFilterGudang(e.target.value)}
              className="py-2 px-3 text-xs bg-[#0F0F10] border border-[#2B2B32] text-neutral-200 rounded-xl font-medium focus:border-[#F27D26] focus:outline-hidden"
            >
              <option value="">Semua Gudang ({warehouses.length})</option>
              {warehouses.map((wh) => (
                <option key={wh.GUDANG_ID} value={wh.GUDANG_ID}>
                  {wh.NAMA_GUDANG}
                </option>
              ))}
            </select>

            {/* Reset Filters */}
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedWarna('');
                setSelectedUkuran('');
                setSelectedLengan('');
                setSelectedFilterGudang('');
              }}
              className="py-2 px-3 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 border border-[#2B2B32] rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Reset
            </button>

            <span className="text-xs text-neutral-400 font-semibold ml-auto">
              {publicCatalogCards.length} Produk
            </span>
          </div>
        </div>
      )}

      {/* MAIN CONTAINER */}
      <main className="w-full max-w-[1920px] mx-auto px-3 sm:px-6 2xl:px-8 pt-6 flex-1">
        {/* ========================================================================= */}
        {/* PUBLIC VIEW: PRODUCT CATALOG CARDS GRID */}
        {/* ========================================================================= */}
        {!currentUser && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
                  <Package className="w-6 h-6 text-[#F27D26]" />
                  Katalog Stok Kaos Polos
                </h2>
                <p className="text-xs text-neutral-400">
                  Pantau stok aktual di{' '}
                  <strong className="text-neutral-200">
                    {warehouses.length <= 3
                      ? warehouses.map((w) => w.NAMA_GUDANG).join(' & ')
                      : `${warehouses.length} Gudang Aktif`}
                  </strong>{' '}
                  secara realtime
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowQuickLookupModal(true)}
                  className="px-4 py-2 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-[#F27D26]/20 transition-all cursor-pointer"
                >
                  <Camera className="w-4 h-4" /> Scan Barcode Kaos
                </button>
              </div>
            </div>

            {/* Products Grid */}
            {publicCatalogCards.length === 0 ? (
              <div className="p-12 text-center bg-[#161618] rounded-2xl border border-[#26262B] shadow-xs">
                <Search className="w-12 h-12 text-neutral-600 mx-auto mb-3" />
                <h3 className="font-bold text-base text-neutral-200">Tidak ada produk ditemukan</h3>
                <p className="text-xs text-neutral-400 mt-1 max-w-sm mx-auto">
                  Coba ubah kata kunci pencarian atau reset filter warna dan ukuran.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-5">
                {publicCatalogCards.map((item) => {
                  const hex = getWarnaHex(item.WARNA);

                  return (
                    <div
                      key={item.SKU_ID}
                      className="bg-[#161618] rounded-2xl border border-[#26262B] shadow-sm hover:border-[#3E3E48] hover:-translate-y-1 transition-all overflow-hidden flex flex-col group text-[#E0E0E0]"
                    >
                      {/* Shirt Illustration Card Header */}
                      <div className="shirt-preview-box h-36 sm:h-40 bg-[#121214] p-4 flex items-center justify-center relative overflow-hidden transition-colors">
                        <svg
                          viewBox="0 0 100 100"
                          className="w-24 h-24 sm:w-28 sm:h-28 drop-shadow-sm group-hover:scale-105 transition-transform"
                          dangerouslySetInnerHTML={{
                            __html: renderShirtPath(item.JENIS_LENGAN, hex, '#2B2B32'),
                          }}
                        />

                        {/* Size Badge */}
                        <span className="absolute bottom-2 right-2 card-size-badge text-[10px] px-2.5 py-0.5 rounded-md uppercase tracking-wider font-extrabold select-none">
                          {item.UKURAN}
                        </span>

                        {/* Reorder Warning Alert Badge */}
                        {item.hasReorder && (
                          <span className="absolute top-2 left-2 bg-amber-500 text-white text-[9px] font-extrabold px-2 py-0.5 rounded shadow-xs animate-pulse">
                            ⚠ REORDER
                          </span>
                        )}
                      </div>

                      {/* Card Body */}
                      <div className="p-3.5 flex-1 flex flex-col justify-between space-y-2.5">
                        <div>
                          {/* Color Chip */}
                          <div className="flex items-center gap-1.5 mb-1">
                            <span
                              className="w-3.5 h-3.5 rounded-full border border-neutral-500/50 shrink-0 shadow-xs"
                              style={{ backgroundColor: hex }}
                            />
                            <span className="text-[11px] font-bold text-neutral-300 truncate">{item.WARNA}</span>
                            <span className="text-[10px] text-neutral-500 ml-auto font-medium">{item.JENIS_LENGAN || 'PENDEK'}</span>
                          </div>

                          {/* Product Title */}
                          <h4 className="font-extrabold text-xs product-title leading-snug line-clamp-1">
                            {item.NAMA_PRODUK}
                          </h4>

                          {/* Monospace SKU */}
                          <div className="font-mono text-[10px] text-neutral-400 truncate mt-0.5">
                            {item.SKU_ID}
                          </div>
                        </div>

                        {/* Dynamic Multi-Warehouse Stock Badges & Total Summary */}
                        <div className="space-y-1.5 pt-1.5 border-t border-[#24242A]">
                          {/* Total Stock Summary Pill */}
                          <div className="flex items-center justify-between text-[10px]">
                            <span className="font-bold uppercase tracking-wider text-neutral-400">
                              Total Stok
                            </span>
                            <span
                              className={`font-black font-mono px-2 py-0.5 rounded-md ${
                                item.totalStock === 0
                                  ? 'bg-rose-950/60 text-rose-300 border border-rose-800/50'
                                  : item.totalStock <= (item.REORDER_LEVEL || 10)
                                  ? 'bg-amber-950/60 text-amber-300 border border-amber-800/50'
                                  : 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/50'
                              }`}
                            >
                              {item.totalStock} pcs
                            </span>
                          </div>

                          {/* Dynamic Warehouse Stock Grid (Adapts to 1, 2, 3, 4+ warehouses) */}
                          <div
                            className={`grid gap-1.5 ${
                              item.warehouseStocks.length === 1
                                ? 'grid-cols-1'
                                : item.warehouseStocks.length === 2
                                ? 'grid-cols-2'
                                : item.warehouseStocks.length === 3
                                ? 'grid-cols-3'
                                : 'grid-cols-2'
                            }`}
                          >
                            {item.warehouseStocks.map((wh) => {
                              const isFiltered =
                                selectedFilterGudang && selectedFilterGudang === wh.gudangId;
                              const badgeIndex = wh.colorIndex % 6;

                              return (
                                <div
                                  key={wh.gudangId}
                                  title={`${wh.gudangNama}: ${wh.qty} pcs`}
                                  className={`stock-badge-wh-${badgeIndex} rounded-lg ${
                                    item.warehouseStocks.length === 3 ? 'p-1' : 'p-1.5'
                                  } text-center transition-all ${
                                    isFiltered
                                      ? 'ring-2 ring-[#F27D26] scale-102 shadow-xs'
                                      : ''
                                  } ${wh.qty === 0 ? 'opacity-70 hover:opacity-100' : ''}`}
                                >
                                  <span
                                    className={`stock-number-wh-${badgeIndex} ${
                                      item.warehouseStocks.length === 3
                                        ? 'text-xs'
                                        : 'text-xs sm:text-sm'
                                    } font-extrabold block leading-tight font-mono`}
                                  >
                                    {wh.qty}
                                  </span>
                                  <span
                                    className={`stock-label-wh-${badgeIndex} ${
                                      item.warehouseStocks.length === 3
                                        ? 'text-[8px]'
                                        : 'text-[9px]'
                                    } font-bold uppercase block tracking-wider truncate`}
                                  >
                                    {wh.shortName}
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* ADMIN VIEW DASHBOARD (When Logged In) */}
        {/* ========================================================================= */}
        {currentUser && (
          <div className="space-y-6">
            {/* Top Dashboard Summary Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-4">
              <div className="bg-[#161618] rounded-xl sm:rounded-2xl p-3 sm:p-4 border border-[#26262B] shadow-xs flex items-center gap-2.5 sm:gap-3.5">
                <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-[#F27D26]/15 text-[#F27D26] border border-[#F27D26]/30 flex items-center justify-center shrink-0">
                  <Package className="w-4 h-4 sm:w-6 sm:h-6" />
                </div>
                <div className="min-w-0">
                  <span className="text-[9.5px] sm:text-[10px] font-bold uppercase tracking-wider text-neutral-400 block truncate">Total SKU</span>
                  <span className="text-lg sm:text-2xl font-extrabold text-white block leading-tight truncate">
                    {summaryStats.totalSku}
                  </span>
                </div>
              </div>

              <div className="bg-[#161618] rounded-xl sm:rounded-2xl p-3 sm:p-4 border border-[#26262B] shadow-xs flex items-center gap-2.5 sm:gap-3.5">
                <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-emerald-950/50 text-emerald-400 border border-emerald-800/40 flex items-center justify-center shrink-0">
                  <TrendingUp className="w-4 h-4 sm:w-6 sm:h-6" />
                </div>
                <div className="min-w-0">
                  <span className="text-[9.5px] sm:text-[10px] font-bold uppercase tracking-wider text-neutral-400 block truncate">Total Stok</span>
                  <span className="text-lg sm:text-2xl font-extrabold text-emerald-400 block leading-tight truncate">
                    {summaryStats.totalStock.toLocaleString('id-ID')} <span className="text-[10px] sm:text-xs font-normal text-neutral-400">pcs</span>
                  </span>
                </div>
              </div>

              <div className="bg-[#161618] rounded-xl sm:rounded-2xl p-3 sm:p-4 border border-[#26262B] shadow-xs flex items-center gap-2.5 sm:gap-3.5">
                <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-amber-950/50 text-amber-400 border border-amber-800/40 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-4 h-4 sm:w-6 sm:h-6" />
                </div>
                <div className="min-w-0">
                  <span className="text-[9.5px] sm:text-[10px] font-bold uppercase tracking-wider text-neutral-400 block truncate">Perlu Reorder</span>
                  <span className="text-lg sm:text-2xl font-extrabold text-amber-400 block leading-tight truncate">
                    {summaryStats.needReorderCount}
                  </span>
                </div>
              </div>

              <div className="bg-[#161618] rounded-xl sm:rounded-2xl p-3 sm:p-4 border border-[#26262B] shadow-xs flex items-center gap-2.5 sm:gap-3.5">
                <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-purple-950/50 text-purple-400 border border-purple-800/40 flex items-center justify-center shrink-0">
                  <ClipboardList className="w-4 h-4 sm:w-6 sm:h-6" />
                </div>
                <div className="min-w-0">
                  <span className="text-[9.5px] sm:text-[10px] font-bold uppercase tracking-wider text-neutral-400 block truncate">Transaksi Hari Ini</span>
                  <span className="text-lg sm:text-2xl font-extrabold text-purple-400 block leading-tight truncate">
                    {summaryStats.txToday}
                  </span>
                </div>
              </div>
            </div>

            {/* ANIMATED ADMIN TAB CONTENT */}
            <AnimatePresence mode="wait">
              {/* TAB 1: INVENTORY TABLE */}
              {adminTab === 'inventory' && (
                <motion.div
                  key="admin-tab-inventory"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.22, ease: 'easeOut' }}
                  className="bg-[#161618] rounded-2xl border border-[#26262B] shadow-xs overflow-hidden"
                >
                  {/* Table Top Controls & Document Buttons */}
                  <div className="p-4 sm:p-5 border-b border-[#24242A] flex flex-col gap-3.5 bg-[#121214]">
                    {/* Top Row: Title, Warehouse Switcher & Sync */}
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex flex-wrap items-center gap-3">
                        <div className="flex items-center gap-2">
                          <span className="w-3 h-3 rounded-full bg-[#F27D26]" />
                          <h3 className="font-extrabold text-sm sm:text-base text-white">
                            Inventori Gudang
                          </h3>
                        </div>

                        {/* Multi-Warehouse Filter Tabs */}
                        <div className="flex items-center gap-1 bg-[#0F0F10] p-1 rounded-xl border border-[#2B2B32] overflow-x-auto max-w-full">
                          <button
                            type="button"
                            onClick={() => setAdminSelectedGudang('ALL')}
                            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                              adminSelectedGudang === 'ALL'
                                ? 'bg-[#F27D26] text-white shadow-xs'
                                : 'text-neutral-400 hover:text-neutral-200 hover:bg-white/5'
                            }`}
                          >
                            Semua Gudang ({warehouses.length})
                          </button>
                          {warehouses.map((wh) => (
                            <button
                              key={wh.GUDANG_ID}
                              type="button"
                              onClick={() => setAdminSelectedGudang(wh.GUDANG_ID)}
                              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                                adminSelectedGudang === wh.GUDANG_ID
                                  ? 'bg-neutral-200 text-neutral-900 shadow-xs'
                                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-white/5'
                              }`}
                            >
                              <span>{wh.NAMA_GUDANG}</span>
                              <span className="text-[10px] opacity-75 font-mono">({wh.GUDANG_ID})</span>
                            </button>
                          ))}
                        </div>

                        {/* Summary Badges */}
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-[#1C1C20] border border-[#2E2E36] text-neutral-300">
                            Total: <strong className="text-white">{adminInventoryFiltered.length}</strong> SKU
                          </span>
                          <span className="hidden sm:inline-flex px-2.5 py-1 rounded-lg text-xs font-semibold bg-[#1C1C20] border border-[#2E2E36] text-emerald-400">
                            {adminInventoryFiltered.reduce((sum, i) => sum + (Number(i.JUMLAH_READY) || 0), 0)} pcs ready
                          </span>
                        </div>
                      </div>

                      {/* Quick Sync Slots Button */}
                      <button
                        type="button"
                        onClick={() => {
                          syncInventorySlots();
                          showToast('Slot inventori berhasil disinkronkan ke seluruh master gudang dan produk!', 'success');
                        }}
                        title="Sinkronkan slot stok untuk setiap produk dan gudang yang aktif"
                        className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 border border-neutral-700/80 transition-all cursor-pointer shadow-xs"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-[#F27D26]" />
                        Sinkronkan Slot Produk
                      </button>
                    </div>

                    {/* Bottom Row: Search & Action Buttons */}
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5 pt-2 border-t border-[#222226]">
                      {/* Search Field */}
                      <div className="relative w-full sm:w-auto">
                        <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={inventoryTableSearch}
                          onChange={(e) => setInventoryTableSearch(e.target.value)}
                          placeholder="🔍 Cari SKU, nama, warna, gudang..."
                          className="pl-8 pr-3 py-1.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-[#F27D26] focus:outline-hidden w-full sm:w-64"
                        />
                      </div>

                      {/* Document & Quick Action Buttons */}
                      <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2 w-full sm:w-auto">
                        {/* Sale Button */}
                        <button
                          type="button"
                          onClick={() => handleOpenSaleModal()}
                          className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer w-full sm:w-auto"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" /> Sale (Penjualan)
                        </button>

                        {/* Form Order Stok (PO) Button */}
                        <button
                          type="button"
                          onClick={() => handleOpenOrderModal()}
                          className="px-3 py-1.5 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer w-full sm:w-auto"
                        >
                          <ClipboardList className="w-3.5 h-3.5" /> Form Order (PO)
                        </button>

                        {/* Surat Jalan Button */}
                        <button
                          type="button"
                          onClick={() => handleOpenSuratJalanModal()}
                          className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer w-full sm:w-auto"
                        >
                          <Truck className="w-3.5 h-3.5" /> Surat Jalan
                        </button>

                        {/* Stok Opname Button */}
                        <button
                          type="button"
                          onClick={() => setAdminTab('opname')}
                          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer w-full sm:w-auto"
                        >
                          <ClipboardCheck className="w-3.5 h-3.5" /> Stok Opname
                        </button>

                        {/* Pelanggan & Piutang Button */}
                        <button
                          type="button"
                          onClick={() => setAdminTab('pelanggan')}
                          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer w-full sm:w-auto"
                          title="Buka Halaman Kelola Pelanggan & Buku Piutang"
                        >
                          <Users className="w-3.5 h-3.5" /> Pelanggan & Piutang
                        </button>

                        {/* Rekapitulasi Dokumen Button */}
                        <button
                          type="button"
                          onClick={() => setAdminTab('rekap')}
                          className="px-3 py-1.5 bg-[#202024] hover:bg-[#2B2B32] text-neutral-200 border border-[#32323A] rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer w-full sm:w-auto col-span-2 sm:col-auto"
                          title="Buka Halaman Rekapitulasi Sale, PO & Surat Jalan"
                        >
                          <FileSpreadsheet className="w-3.5 h-3.5 text-purple-400" /> Rekap Dokumen
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Table Component */}
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse text-xs min-w-[840px]">
                      <thead>
                        <tr className="bg-[#121214] border-b border-[#24242A] text-neutral-400 uppercase tracking-wider text-[11px]">
                          <th className="py-3 px-4 text-left font-bold">Gudang</th>
                          <th className="py-3 px-4 text-left font-bold">SKU ID</th>
                          <th className="py-3 px-4 text-left font-bold">Nama Produk</th>
                          <th className="py-3 px-4 text-left font-bold">Warna</th>
                          <th className="py-3 px-4 text-center font-bold">Ukuran</th>
                          <th className="py-3 px-4 text-center font-bold">Lengan</th>
                          <th className="py-3 px-4 text-center font-bold">Stok Ready</th>
                          <th className="py-3 px-4 text-center font-bold">Reorder Lvl</th>
                          <th className="py-3 px-4 text-center font-bold">Status</th>
                          <th className="py-3 px-4 text-right font-bold">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#24242A]">
                        {adminInventoryFiltered.length === 0 ? (
                          <tr>
                            <td colSpan={10} className="py-12 text-center text-neutral-400">
                              <div className="flex flex-col items-center justify-center gap-3">
                                <Package className="w-10 h-10 text-neutral-600" />
                                <p className="text-sm font-semibold text-neutral-300">
                                  {inventoryTableSearch
                                    ? `Tidak ada data inventori yang cocok dengan pencarian "${inventoryTableSearch}".`
                                    : 'Tidak ada data inventori di gudang yang dipilih.'}
                                </p>
                                <div className="flex items-center gap-2">
                                  {inventoryTableSearch && (
                                    <button
                                      type="button"
                                      onClick={() => setInventoryTableSearch('')}
                                      className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-xs font-bold text-neutral-200 rounded-xl transition-all cursor-pointer"
                                    >
                                      Bersihkan Pencarian
                                    </button>
                                  )}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      syncInventorySlots();
                                      showToast('Data slot produk berhasil disinkronkan!', 'success');
                                    }}
                                    className="px-3.5 py-1.5 bg-[#F27D26] hover:bg-[#d96c1d] text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-sm"
                                  >
                                    🔄 Sinkronkan Data Produk ke Gudang
                                  </button>
                                </div>
                              </div>
                            </td>
                          </tr>
                        ) : (
                          adminInventoryFiltered.map((item) => {
                            const isLow = item.JUMLAH_READY <= item.REORDER_LEVEL;
                            const isToko = item.GUDANG_ID.includes('TOKO');
                            const isUtama = item.GUDANG_ID.includes('ERVO') || item.GUDANG_ID.includes('UTAMA');

                            return (
                              <tr key={`${item.GUDANG_ID}-${item.SKU_ID}`} className="hover:bg-[#1C1C20] transition-colors">
                                <td className="py-2.5 px-4">
                                  {isToko ? (
                                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-950/60 border border-blue-800/40 text-blue-400 stock-badge-toko">
                                      {item.NAMA_GUDANG || item.GUDANG_ID}
                                    </span>
                                  ) : isUtama ? (
                                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/60 border border-emerald-800/40 text-emerald-400 stock-badge-ervo">
                                      {item.NAMA_GUDANG || 'GUDANG UTAMA'}
                                    </span>
                                  ) : (
                                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-950/60 border border-purple-800/40 text-purple-400">
                                      {item.NAMA_GUDANG || item.GUDANG_ID}
                                    </span>
                                  )}
                                </td>
                                <td className="py-2.5 px-4 font-mono font-bold text-neutral-200 whitespace-nowrap">{item.SKU_ID}</td>
                                <td className="py-2.5 px-4 font-bold table-product-name min-w-[140px]">{item.NAMA_PRODUK}</td>
                                <td className="py-2.5 px-4 whitespace-nowrap">
                                  <div className="flex items-center gap-1.5">
                                    <span
                                      className="w-3.5 h-3.5 rounded-full border border-neutral-500/60 shrink-0 shadow-xs"
                                      style={{ backgroundColor: getWarnaHex(item.WARNA) }}
                                    />
                                    <span className="font-semibold">{item.WARNA}</span>
                                  </div>
                                </td>
                                <td className="py-2.5 px-4 text-center font-bold text-neutral-200 whitespace-nowrap">{item.UKURAN}</td>
                                <td className="py-2.5 px-4 text-center text-neutral-400 whitespace-nowrap">{item.JENIS_LENGAN}</td>
                                <td className="py-2.5 px-4 text-center font-extrabold text-sm whitespace-nowrap">
                                  <span className={isLow ? 'text-amber-500 font-extrabold' : 'text-emerald-500 font-extrabold'}>
                                    {item.JUMLAH_READY} pcs
                                  </span>
                                </td>
                                <td className="py-2.5 px-4 text-center text-neutral-400 font-semibold whitespace-nowrap">{item.REORDER_LEVEL}</td>
                                <td className="py-2.5 px-4 text-center whitespace-nowrap">
                                  {isLow ? (
                                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/60 border border-amber-800/50 text-amber-300 status-badge-reorder">
                                      ⚠ Perlu Reorder
                                    </span>
                                  ) : (
                                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/60 border border-emerald-800/50 text-emerald-400 status-badge-safe">
                                      ✓ Aman
                                    </span>
                                  )}
                                </td>
                                <td className="py-2.5 px-4 text-right">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const prod = products.find((p) => p.SKU_ID === item.SKU_ID);
                                      setCorrectionItem({
                                        gudangId: item.GUDANG_ID,
                                        skuId: item.SKU_ID,
                                        current: item.JUMLAH_READY,
                                      });
                                      setCorrectionNewQty(item.JUMLAH_READY);
                                      setCorrectionHpp(prod?.HARGA_HPP || 0);
                                      setCorrectionJual(prod?.HARGA_JUAL || 0);
                                      setCorrectionReason('');
                                    }}
                                    className="px-2.5 py-1 text-neutral-300 hover:text-white bg-[#1C1C20] hover:bg-[#28282E] border border-[#2B2B32] rounded-lg text-xs font-bold transition-colors cursor-pointer"
                                  >
                                    Koreksi
                                  </button>
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}

              {/* TAB 2: BARANG MASUK (STOCK IN WITH BARCODE SCANNER & FINANCIAL WORKSTATION) */}
              {adminTab === 'masuk' && (() => {
                const selectedProd = products.find((p) => p.SKU_ID === txSku);
                // Pastikan selalu ada gudang aktif dengan fallback aman
                const activeWarehouses = warehouses.filter((w) => w.IS_ACTIVE !== false);
                const safeActiveWarehouses = activeWarehouses.length > 0 
                  ? activeWarehouses 
                  : (warehouses.length > 0 ? warehouses.map((w) => ({ ...w, IS_ACTIVE: true })) : INITIAL_GUDANG);
                const currentGudangId = txGudangId || safeActiveWarehouses[0]?.GUDANG_ID || 'GDG-01-ERVO';
                const currentStockItem = inventory.find(
                  (i) => i.GUDANG_ID === currentGudangId && i.SKU_ID === txSku
                );
                const currentStockQty = currentStockItem ? currentStockItem.JUMLAH_READY : 0;

                const hpp = Math.max(0, Number(txHargaHpp) || 0);
                const jual = Math.max(0, Number(txHargaJual) || 0);
                const qty = Math.max(0, Number(txJumlah) || 0);
                const totalHpp = qty * hpp;
                const totalJual = qty * jual;
                const profitPerPcs = Math.max(0, jual - hpp);
                const profitTotal = qty * profitPerPcs;
                const marginPercent = hpp > 0 ? Math.round((profitPerPcs / hpp) * 100) : 0;

                return (
                  <motion.div
                    key="admin-tab-masuk"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.22, ease: 'easeOut' }}
                    className="w-full max-w-full 2xl:max-w-[1850px] mx-auto bg-[#161618] rounded-2xl border border-[#26262B] shadow-xl overflow-hidden"
                  >
                    <div className="stock-in-header-banner p-4 sm:p-5 border-b border-[#24242A] bg-gradient-to-r from-emerald-800 to-teal-900 text-white flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center border border-white/20 stock-in-header-icon">
                          <ArrowDownToLine className="w-5 h-5 text-emerald-300" />
                        </div>
                        <div>
                          <h3 className="font-extrabold text-base leading-tight text-white stock-in-header-title">Workstation Tambah Barang Masuk</h3>
                          <p className="text-xs text-emerald-200 stock-in-header-subtitle">Restok stok konveksi, update HPP & harga ritel kasir</p>
                        </div>
                      </div>
                      <span className="px-3 py-1 bg-black/30 border border-white/20 rounded-full text-xs font-mono font-bold text-emerald-300 stock-in-header-site">
                        {currentUser.siteAccess?.toUpperCase().includes('ERVO') ? 'GUDANG UTAMA' : currentUser.siteAccess}
                      </span>
                    </div>

                    <form onSubmit={handleSubmitStockIn} className="p-5 sm:p-7 space-y-6">
                      {/* Top Grid: Left (SKU & Product Info) and Right (Quantity & Destination) */}
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 items-start">
                        {/* SKU Selection & Barcode Scan */}
                        <div className="space-y-2.5">
                          <div className="flex items-center justify-between">
                            <label className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                              Pilih Produk (SKU ID) *
                            </label>
                            <span className="text-[11px] text-neutral-500 font-medium">Scan barcode kamera atau pilih</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <select
                              value={txSku}
                              onChange={(e) => handleSelectTxSku(e.target.value)}
                              className="flex-1 p-2.5 text-xs font-mono font-bold bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 rounded-xl focus:border-emerald-500 focus:outline-hidden"
                            >
                              <option value="">-- Pilih Produk dari Master Produk --</option>
                              {products.map((p) => (
                                <option key={p.SKU_ID} value={p.SKU_ID}>
                                  {p.SKU_ID} — {p.NAMA_PRODUK} ({p.WARNA} {p.UKURAN})
                                </option>
                              ))}
                            </select>

                            <button
                              type="button"
                              onClick={() => setShowTxScanner(true)}
                              className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all shrink-0 cursor-pointer"
                              title="Pindai Barcode Kamera"
                            >
                              <Camera className="w-4 h-4" /> Scan Barcode
                            </button>
                          </div>

                          {/* Selected Product Card Preview */}
                          {selectedProd ? (
                            <div className="p-3 bg-[#111114] border border-[#26262E] rounded-xl flex items-center justify-between text-xs animate-in fade-in">
                              <div className="flex items-center gap-2.5">
                                <span
                                  className="w-4 h-4 rounded-full border border-neutral-600 shrink-0"
                                  style={{ backgroundColor: getWarnaHex(selectedProd.WARNA) }}
                                />
                                <div>
                                  <span className="font-extrabold text-neutral-100">{selectedProd.NAMA_PRODUK}</span>
                                  <div className="text-[11px] text-neutral-400">
                                    Warna: <strong className="text-neutral-200">{selectedProd.WARNA}</strong> | Ukuran:{' '}
                                    <strong className="text-neutral-200">{selectedProd.UKURAN}</strong> ({selectedProd.JENIS_LENGAN})
                                  </div>
                                </div>
                              </div>
                              <div className="text-right">
                                <span className="text-[10px] text-neutral-500 block uppercase">Stok Saat Ini</span>
                                <span className="font-extrabold text-sm text-emerald-400 font-mono">
                                  {currentStockQty} pcs
                                </span>
                              </div>
                            </div>
                          ) : (
                            <div className="p-3 bg-[#111114]/50 border border-dashed border-[#26262E] rounded-xl text-center text-xs text-neutral-500">
                              Pilih SKU produk di atas untuk melihat detail & stok saat ini
                            </div>
                          )}
                        </div>

                        {/* Quantity & Destination Warehouse */}
                        <div className="space-y-3">
                          <div className="space-y-1.5">
                            <div className="flex items-center justify-between">
                              <label className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                                Jumlah Masuk (Pcs) *
                              </label>
                              <div className="flex items-center gap-1">
                                {[12, 24, 50, 100, 200].map((preset) => (
                                  <button
                                    key={preset}
                                    type="button"
                                    onClick={() => setTxJumlah(preset)}
                                    className={`px-2 py-0.5 rounded-md text-[10px] font-bold border transition-colors cursor-pointer ${
                                      txJumlah === preset
                                        ? 'bg-emerald-600 text-white border-emerald-500'
                                        : 'bg-[#1C1C20] text-neutral-400 border-[#2B2B32] hover:text-neutral-200'
                                    }`}
                                  >
                                    {preset === 12 ? '1 Lusin' : preset === 24 ? '2 Lusin' : `+${preset}`}
                                  </button>
                                ))}
                              </div>
                            </div>
                            <input
                              type="number"
                              min="1"
                              value={txJumlah}
                              onChange={(e) => setTxJumlah(parseInt(e.target.value) || 0)}
                              className="w-full p-2.5 text-base font-extrabold bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 rounded-xl focus:border-emerald-500 focus:outline-hidden font-mono"
                            />
                          </div>

                          {/* Destination Warehouse Selector: Tampilkan Pilihan Gudang Aktif */}
                          <div className="bg-[#111114] p-3.5 rounded-xl border border-[#26262B] space-y-2.5">
                            <div className="flex items-center justify-between">
                              <label className="text-xs font-bold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5">
                                <Building2 className="w-3.5 h-3.5 text-emerald-400" />
                                Gudang Tujuan Masuk *
                              </label>
                              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-800/40 px-2 py-0.5 rounded-full flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                                {safeActiveWarehouses.length} Gudang Aktif Siap Pakai
                              </span>
                            </div>

                            <select
                              value={txGudangId}
                              onChange={(e) => setTxGudangId(e.target.value)}
                              className="w-full p-2.5 text-xs font-bold bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 rounded-xl focus:border-emerald-500 focus:outline-hidden"
                            >
                              <option value="">-- Pilih Gudang Tujuan Aktif ({safeActiveWarehouses.length} Tersedia) --</option>
                              {safeActiveWarehouses.map((w) => (
                                <option key={w.GUDANG_ID} value={w.GUDANG_ID}>
                                  🏢 {w.GUDANG_ID} — {w.NAMA_GUDANG} {w.LOKASI ? `(${w.LOKASI})` : ''} [AKTIF]
                                </option>
                              ))}
                            </select>

                            {/* Pilihan Cepat Gudang Aktif dalam Bentuk Tombol Kartu */}
                            <div className="space-y-1.5 pt-1">
                              <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">
                                Klik Langsung Gudang Aktif:
                              </span>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                {safeActiveWarehouses.map((w) => {
                                  const isSelected = (txGudangId || safeActiveWarehouses[0]?.GUDANG_ID) === w.GUDANG_ID;
                                  const stockInWh = inventory.find(
                                    (i) => i.GUDANG_ID === w.GUDANG_ID && i.SKU_ID === txSku
                                  )?.JUMLAH_READY || 0;
                                  return (
                                    <button
                                      key={w.GUDANG_ID}
                                      type="button"
                                      onClick={() => setTxGudangId(w.GUDANG_ID)}
                                      className={`p-2.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                                        isSelected
                                          ? 'bg-emerald-950/40 border-emerald-500 shadow-md ring-1 ring-emerald-500/40'
                                          : 'bg-[#161618] border-[#26262B] hover:border-[#383842] hover:bg-[#1C1C20]'
                                      }`}
                                    >
                                      <div className="min-w-0 pr-2">
                                        <div className="flex items-center gap-1.5">
                                          <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                                          <span className={`text-xs font-bold truncate ${isSelected ? 'text-emerald-300' : 'text-neutral-200'}`}>
                                            {w.NAMA_GUDANG}
                                          </span>
                                        </div>
                                        <div className="text-[10px] text-neutral-400 font-mono mt-0.5">
                                          {w.GUDANG_ID}
                                        </div>
                                      </div>
                                      <div className="text-right shrink-0">
                                        <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-800/40 block">
                                          Aktif
                                        </span>
                                        {txSku && (
                                          <span className="text-[10px] font-mono text-neutral-400 block mt-0.5">
                                            {stockInWh} pcs
                                          </span>
                                        )}
                                      </div>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                            <p className="text-[10px] text-neutral-500">
                              Stok barang masuk akan otomatis ditambahkan ke gudang aktif yang dipilih
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Harga HPP and Harga Jual with Real-time Margin */}
                      <div className="p-4 bg-[#111114] rounded-xl border border-[#26262E] space-y-3.5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
                            Penetapan Harga & Estimasi Finansial
                          </span>
                          {profitPerPcs > 0 && (
                            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-emerald-950/60 border border-emerald-800/60 text-emerald-400">
                              Margin: +{marginPercent}% (+{formatRupiah(profitPerPcs)}/pcs)
                            </span>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[11px] font-bold uppercase tracking-wider text-emerald-400 mb-1">
                              Harga HPP (Modal Beli / Pcs) *
                            </label>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-neutral-500">Rp</span>
                              <input
                                type="number"
                                min="0"
                                step="500"
                                value={txHargaHpp}
                                onChange={(e) => setTxHargaHpp(Math.max(0, parseInt(e.target.value) || 0))}
                                placeholder="30000"
                                className="w-full pl-9 pr-3 py-2 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-lg font-bold text-emerald-300 focus:border-emerald-500 focus:outline-hidden font-mono"
                              />
                            </div>
                            <p className="text-[10px] text-neutral-500 mt-1">Biaya modal restock / produksi konveksi</p>
                          </div>

                          <div>
                            <label className="block text-[11px] font-bold uppercase tracking-wider text-purple-400 mb-1">
                              Harga Jual (Patokan Ritel Kasir) *
                            </label>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-neutral-500">Rp</span>
                              <input
                                type="number"
                                min="0"
                                step="500"
                                value={txHargaJual}
                                onChange={(e) => setTxHargaJual(Math.max(0, parseInt(e.target.value) || 0))}
                                placeholder="45000"
                                className="w-full pl-9 pr-3 py-2 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-lg font-bold text-purple-300 focus:border-purple-500 focus:outline-hidden font-mono"
                              />
                            </div>
                            <p className="text-[10px] text-neutral-500 mt-1">Harga acuan nota kasir saat penjualan</p>
                          </div>
                        </div>

                        {/* Financial summary bar */}
                        <div className="pt-3 border-t border-[#222228] grid grid-cols-3 gap-2 text-center text-xs">
                          <div className="p-2 bg-[#16161A] rounded-lg border border-[#24242C]">
                            <span className="text-[10px] text-neutral-400 block">Total Pengadaan (HPP)</span>
                            <span className="font-extrabold text-emerald-400 font-mono text-xs sm:text-sm">
                              {formatRupiah(totalHpp)}
                            </span>
                          </div>
                          <div className="p-2 bg-[#16161A] rounded-lg border border-[#24242C]">
                            <span className="text-[10px] text-neutral-400 block">Potensi Omset (Jual)</span>
                            <span className="font-extrabold text-purple-400 font-mono text-xs sm:text-sm">
                              {formatRupiah(totalJual)}
                            </span>
                          </div>
                          <div className="p-2 bg-[#16161A] rounded-lg border border-[#24242C]">
                            <span className="text-[10px] text-neutral-400 block">Potensi Profit Kotor</span>
                            <span className="font-extrabold text-amber-400 font-mono text-xs sm:text-sm">
                              {formatRupiah(profitTotal)}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Keterangan & Preset Buttons */}
                      <div className="space-y-1.5">
                        <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300">
                          Keterangan / Supplier
                        </label>
                        <input
                          type="text"
                          value={txKeterangan}
                          onChange={(e) => setTxKeterangan(e.target.value)}
                          placeholder="Contoh: Restock kloter 04 konveksi mitra"
                          className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 placeholder-neutral-600 rounded-xl focus:border-emerald-500 focus:outline-hidden"
                        />
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {['Restock konveksi rutin', 'Kloter produksi baru', 'Retur konsinyasi', 'Supplier Bandung'].map((ket) => (
                            <button
                              key={ket}
                              type="button"
                              onClick={() => setTxKeterangan(ket)}
                              className="px-2 py-0.5 text-[10px] bg-[#1C1C20] hover:bg-[#25252A] text-neutral-400 hover:text-neutral-200 border border-[#2B2B32] rounded-md transition-colors cursor-pointer"
                            >
                              + {ket}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setTxSku('');
                            setTxJumlah(0);
                            setTxHargaHpp(0);
                            setTxHargaJual(0);
                            setTxKeterangan('');
                            setTxGudangId(safeActiveWarehouses[0]?.GUDANG_ID || '');
                            showToast('Form barang masuk dibatalkan & kembali ke default kosong.', 'info');
                          }}
                          className="px-5 py-3.5 bg-[#1F1F24] hover:bg-[#2A2A32] text-neutral-300 hover:text-white font-bold text-xs uppercase tracking-wider rounded-xl border border-[#2E2E38] transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                          title="Kosongkan form barang masuk ke default"
                        >
                          <RotateCcw className="w-4 h-4" /> Batal
                        </button>
                        <button
                          type="submit"
                          className="flex-1 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <CheckCircle2 className="w-4 h-4" /> Simpan Barang Masuk (+Update HPP & Jual Master)
                        </button>
                      </div>
                    </form>
                  </motion.div>
                );
              })()}

              {/* TAB 3: STOK OPNAME (PHYSICAL INVENTORY AUDIT) */}
              {adminTab === 'opname' && (
                <motion.div
                  key="admin-tab-opname"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.22, ease: 'easeOut' }}
                >
                  <StockOpnameView
                    inventory={inventory}
                    products={products}
                    warehouses={warehouses}
                    currentUser={currentUser}
                    logs={logs}
                    onApplyAdjustment={handleApplyOpnameAdjustment}
                    showToast={showToast}
                    settings={settings}
                  />
                </motion.div>
              )}

              {/* REKAPITULASI DOKUMEN VIEW (Sale, PO, Surat Jalan) */}
              {adminTab === 'rekap' && (
                <motion.div
                  key="admin-tab-rekap"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.22, ease: 'easeOut' }}
                >
                  <RekapitulasiView
                    sales={sales}
                    orders={orders}
                    suratJalanList={suratJalanList}
                    products={products}
                    warehouses={warehouses}
                    currentUser={currentUser}
                    onOpenSaleModal={handleOpenSaleModal}
                    onOpenOrderModal={handleOpenOrderModal}
                    onOpenSuratJalanModal={handleOpenSuratJalanModal}
                    onDeleteSale={handleDeleteSale}
                    onDeleteSaleItem={handleDeleteSaleItem}
                    onDeleteOrder={handleDeleteOrder}
                    onDeleteSuratJalan={handleDeleteSuratJalan}
                    showToast={showToast}
                    settings={settings}
                  />
                </motion.div>
              )}

              {/* KELOLA PELANGGAN & BUKU PIUTANG */}
              {adminTab === 'pelanggan' && (
                <motion.div
                  key="admin-tab-pelanggan"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.22, ease: 'easeOut' }}
                >
                  <PelangganView
                    customers={customers}
                    sales={sales}
                    currentUser={currentUser}
                    onSaveCustomer={handleSaveCustomer}
                    onDeleteCustomer={handleDeleteCustomer}
                    onUpdateSale={handleUpdateSale}
                    onOpenSaleModalWithCustomer={handleOpenSaleModalWithCustomer}
                    onOpenSaleModalDoc={handleOpenSaleModal}
                    showToast={showToast}
                    settings={settings}
                  />
                </motion.div>
              )}

              {/* LOG TRANSAKSI */}
              {adminTab === 'logs' && (
                <motion.div
                  key="admin-tab-logs"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.22, ease: 'easeOut' }}
                  className="bg-[#161618] rounded-2xl border border-[#26262B] shadow-xs overflow-hidden"
                >
                  <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] gap-2 flex-wrap">
                    <div>
                      <h3 className="font-extrabold text-sm sm:text-base text-white">
                        Log Transaksi & Riwayat Mutasi
                      </h3>
                      <p className="text-xs text-neutral-400">Rekap riwayat Barang Masuk, Surat Jalan (Keluar), Order PO, dan Penjualan</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {logs.length > 0 && (
                        isSpvOrOwner ? (
                          <button
                            type="button"
                            onClick={handleClearAllLogs}
                            className="px-2.5 py-1 bg-rose-950/50 hover:bg-rose-900/70 border border-rose-800/60 hover:border-rose-600 text-rose-300 rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95"
                            title="Hapus semua riwayat log transaksi (Khusus Owner & SPV)"
                          >
                            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                            <span className="hidden sm:inline">Hapus Semua Log</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            disabled
                            className="px-2.5 py-1 bg-neutral-900/40 border border-neutral-800/80 text-neutral-600 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 cursor-not-allowed opacity-50 select-none"
                            title="Hapus semua log terkunci (Hanya untuk Owner & SPV)"
                          >
                            <Lock className="w-3 h-3 text-neutral-600" />
                            <span className="hidden sm:inline">Hapus Semua Log</span>
                          </button>
                        )
                      )}
                      <span className="text-xs font-bold text-neutral-300 bg-[#1C1C20] border border-[#2B2B32] px-3 py-1 rounded-full">
                        {logs.length} Baris Log
                      </span>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse text-xs min-w-[850px]">
                      <thead>
                        <tr className="bg-[#121214] border-b border-[#24242A] text-neutral-400 uppercase tracking-wider text-[11px]">
                          <th className="py-3 px-4 text-left font-bold">Waktu</th>
                          <th className="py-3 px-4 text-left font-bold">TX ID</th>
                          <th className="py-3 px-4 text-left font-bold">SKU ID</th>
                          <th className="py-3 px-4 text-left font-bold">Gudang</th>
                          <th className="py-3 px-4 text-center font-bold">Jumlah</th>
                          <th className="py-3 px-4 text-center font-bold">Tipe</th>
                          <th className="py-3 px-4 text-left font-bold">User</th>
                          <th className="py-3 px-4 text-left font-bold">Keterangan & No. Dokumen</th>
                          <th className="py-3 px-4 text-center font-bold">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#24242A]">
                        {logs.length === 0 ? (
                          <tr>
                            <td colSpan={9} className="py-12 text-center text-neutral-500">
                              Belum ada riwayat transaksi atau riwayat log telah dibersihkan.
                            </td>
                          </tr>
                        ) : (
                          logs.map((l, idx) => {
                            const isPos = l.JUMLAH > 0;
                            const isKeluar = l.TIPE_TRANSAKSI === 'KELUAR';
                            const isOrder = l.TIPE_TRANSAKSI === 'ORDER';
                            const isSale = l.TIPE_TRANSAKSI === 'SALE';
                            const displayGudang = l.GUDANG_ID?.toUpperCase().includes('ERVO')
                              ? 'GDG-01-UTAMA'
                              : (l.GUDANG_ID || 'GDG-01-UTAMA');

                            return (
                              <tr key={l.TRANSAKSI_ID || idx} className="hover:bg-[#1C1C20] transition-colors">
                                <td className="py-2.5 px-4 text-neutral-400 whitespace-nowrap">
                                  {new Date(l.TIMESTAMP).toLocaleString('id-ID')}
                                </td>
                                <td className="py-2.5 px-4 font-mono font-bold text-[#F27D26]">{l.TRANSAKSI_ID}</td>
                                <td className="py-2.5 px-4 font-mono font-bold text-neutral-200">{l.SKU_ID}</td>
                                <td className="py-2.5 px-4">
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#1C1C20] border border-[#2B2B32] text-neutral-300">
                                    {displayGudang}
                                  </span>
                                </td>
                                <td className="py-2.5 px-4 text-center font-extrabold text-xs whitespace-nowrap">
                                  <span
                                    className={
                                      isSale
                                        ? 'text-purple-400'
                                        : isKeluar
                                        ? 'text-rose-400'
                                        : isOrder
                                        ? 'text-blue-400'
                                        : 'text-emerald-400'
                                    }
                                  >
                                    {isPos ? `+${l.JUMLAH}` : l.JUMLAH} pcs
                                  </span>
                                </td>
                                <td className="py-2.5 px-4 text-center whitespace-nowrap">
                                  <span
                                    className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                                      l.TIPE_TRANSAKSI === 'MASUK'
                                        ? 'bg-emerald-950/60 border border-emerald-800/50 text-emerald-300'
                                        : l.TIPE_TRANSAKSI === 'KELUAR'
                                        ? 'bg-rose-950/60 border border-rose-800/50 text-rose-300'
                                        : l.TIPE_TRANSAKSI === 'SALE'
                                        ? 'bg-purple-950/60 border border-purple-800/50 text-purple-300'
                                        : l.TIPE_TRANSAKSI === 'ORDER'
                                        ? 'bg-blue-950/60 border border-blue-800/50 text-blue-300'
                                        : 'bg-[#1C1C20] border border-[#2B2B32] text-neutral-300'
                                    }`}
                                  >
                                    {l.TIPE_TRANSAKSI}
                                  </span>
                                </td>
                                <td className="py-2.5 px-4 font-mono text-neutral-400">{l.USERS}</td>
                                <td className="py-2.5 px-4 text-neutral-300 leading-snug">{l.KETERANGAN}</td>
                                <td className="py-2.5 px-4 text-center whitespace-nowrap">
                                  {isSpvOrOwner ? (
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteLog(l.TRANSAKSI_ID)}
                                      className="p-1 px-2.5 bg-rose-600/15 hover:bg-rose-600 text-rose-400 hover:text-white border border-rose-500/30 hover:border-rose-600 rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1 cursor-pointer shadow-xs active:scale-95"
                                      title={`Hapus log transaksi ${l.TRANSAKSI_ID} (Akses Owner & SPV)`}
                                    >
                                      <Trash2 className="w-3.5 h-3.5 shrink-0" />
                                      <span>Hapus</span>
                                    </button>
                                  ) : (
                                    <button
                                      type="button"
                                      disabled
                                      className="p-1 px-2 bg-neutral-800/40 text-neutral-600 border border-neutral-800 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 cursor-not-allowed opacity-50 select-none"
                                      title="Aksi hapus hanya aktif ketika user yang login adalah Owner atau SPV"
                                    >
                                      <Lock className="w-3 h-3 shrink-0" />
                                      <span>Terkunci</span>
                                    </button>
                                  )}
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}

              {/* SETTINGS VIEW */}
              {adminTab === 'settings' && (
                <motion.div
                  key="settings"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.18 }}
                >
                  <SettingsView
                    warehouses={warehouses}
                    onUpdateWarehouses={handleUpdateWarehouses}
                    users={users}
                    onUpdateUsers={setUsers}
                    settings={settings}
                    onUpdateSettings={setSettings}
                    products={products}
                    onUpdateProducts={setProducts}
                    inventory={inventory}
                    onUpdateInventory={setInventory}
                    logs={logs}
                    orders={orders}
                    suratJalanList={suratJalanList}
                    sales={sales}
                    customers={customers}
                    currentUser={currentUser}
                    onResetFactoryData={handleResetData}
                    onImportAllData={handleImportAllData}
                    onOpenBackupModal={() => setShowBackupModal(true)}
                    showToast={showToast}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </main>

      {/* ========================================================================= */}
      {/* ALL INTERACTIVE MODALS */}
      {/* ========================================================================= */}

      {/* LOGIN MODAL */}
      {showLoginModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#161618] rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-[#2A2A30] text-[#E0E0E0]">
            <div className="p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] text-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#F27D26] flex items-center justify-center text-white shadow-md shadow-[#F27D26]/30">
                  <LogIn className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base sm:text-lg">Login Admin Gudang</h3>
                  <p className="text-xs text-neutral-400">Akses pengelolaan inventori dan validasi</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowLoginModal(false);
                  setLoginError('');
                }}
                className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleLogin} className="p-5 sm:p-6 space-y-4">
              {loginError && (
                <div className="p-3 bg-rose-950/50 border border-rose-800/60 text-rose-300 text-xs rounded-xl flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <div className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-400 mb-1.5">
                    Username
                  </label>
                  <input
                    type="text"
                    required
                    value={loginUsername}
                    onChange={(e) => setLoginUsername(e.target.value)}
                    placeholder="Masukkan username Anda"
                    className="w-full p-2.5 text-sm bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-600 focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-400 mb-1.5">
                    Password
                  </label>
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Masukkan password Anda"
                    className="w-full p-2.5 text-sm bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-600 focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#F27D26] hover:bg-[#d96c1d] text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md shadow-[#F27D26]/20 transition-all mt-2 cursor-pointer"
              >
                Masuk ke Dashboard
              </button>

              <div className="pt-2 text-center text-[11px] text-neutral-500 border-t border-[#222228]">
                Hanya akun resmi yang terdaftar di <span className="text-neutral-300 font-medium">Manajemen Pengguna</span> yang memiliki hak akses sistem.
              </div>
            </form>
          </div>
        </div>
      )}

      {/* STOCK CORRECTION MODAL */}
      {correctionItem && (() => {
        const isSpvOrOwner = Boolean(
          currentUser && (
            currentUser.role === 'OWNER' ||
            currentUser.role === 'SUPERVISOR' ||
            (currentUser.role as string) === 'SPV' ||
            currentUser.username.toLowerCase() === 'owner' ||
            currentUser.username.toLowerCase() === 'supervisor' ||
            currentUser.username.toLowerCase() === 'spv'
          )
        );
        const diff = correctionNewQty - correctionItem.current;
        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
            <div className="bg-[#161618] rounded-2xl shadow-2xl w-full max-w-2xl sm:max-w-3xl overflow-hidden border border-[#2A2A30] text-[#E0E0E0]">
              <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] text-white">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#F27D26]/20 border border-[#F27D26]/40 flex items-center justify-center text-[#F27D26]">
                    <Settings className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm sm:text-base leading-tight">Koreksi Stok Manual</h3>
                    <p className="text-[11px] text-neutral-400">Penyesuaian kuantitas fisik stok, Harga HPP, dan Harga Jual</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setCorrectionItem(null);
                    setCorrectionReason('');
                  }}
                  className="w-7 h-7 rounded-full bg-[#1E1E22] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-5 sm:p-6 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Left Column: Informasi Produk & Gudang */}
                  <div className="p-4 bg-[#111114] border border-[#24242C] rounded-xl text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-400">SKU ID:</span>
                      <strong className="font-mono text-neutral-200">{correctionItem.skuId}</strong>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-400">Gudang:</span>
                      <strong className="text-neutral-200">{correctionItem.gudangId}</strong>
                    </div>
                    <div className="flex items-center justify-between pt-1.5 border-t border-[#1E1E24]">
                      <span className="text-neutral-400">Stok Saat Ini:</span>
                      <strong className="text-neutral-100 font-mono text-sm">{correctionItem.current} pcs</strong>
                    </div>
                    <div className="flex items-center justify-between pt-1.5 border-t border-[#1E1E24]">
                      <span className="text-neutral-400">Harga HPP Saat Ini:</span>
                      <strong className="text-amber-400 font-mono text-xs">{formatRupiah(correctionHpp)}</strong>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-400">Harga Jual Saat Ini:</span>
                      <strong className="text-emerald-400 font-mono text-xs">{formatRupiah(correctionJual)}</strong>
                    </div>
                  </div>

                  {/* Right Column: Input Jumlah Stok Baru (Read Only kecuali Owner & SPV) */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-bold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5">
                        <span>Jumlah Stok Baru (Pcs) *</span>
                        {!isSpvOrOwner && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-950/70 border border-amber-800/60 text-amber-300 flex items-center gap-1">
                            <Lock className="w-3 h-3 text-amber-400" /> Read Only
                          </span>
                        )}
                      </label>
                      {isSpvOrOwner ? (
                        <span
                          className={`text-xs font-extrabold font-mono px-2 py-0.5 rounded-md ${
                            diff > 0
                              ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/60'
                              : diff < 0
                              ? 'bg-rose-950/70 text-rose-400 border border-rose-800/60'
                              : 'bg-[#202026] text-neutral-400'
                          }`}
                        >
                          {diff > 0 ? `+${diff}` : diff} pcs
                        </span>
                      ) : (
                        <span className="text-xs font-bold font-mono px-2 py-0.5 rounded-md bg-[#1C1C22] border border-[#2B2B32] text-neutral-400">
                          {correctionItem.current} pcs (Terkunci)
                        </span>
                      )}
                    </div>

                    <div className="relative">
                      <input
                        type="number"
                        min="0"
                        readOnly={!isSpvOrOwner}
                        disabled={!isSpvOrOwner}
                        value={isSpvOrOwner ? correctionNewQty : correctionItem.current}
                        onChange={(e) => {
                          if (isSpvOrOwner) {
                            setCorrectionNewQty(Math.max(0, parseInt(e.target.value) || 0));
                          }
                        }}
                        className={`w-full p-2.5 text-base font-extrabold rounded-xl font-mono transition-all ${
                          isSpvOrOwner
                            ? 'bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 focus:border-[#F27D26] focus:outline-hidden'
                            : 'bg-[#141418] border border-amber-900/50 text-neutral-400 cursor-not-allowed select-none opacity-85'
                        }`}
                        title={
                          isSpvOrOwner
                            ? 'Masukkan jumlah fisik stok baru'
                            : 'Kolom ini Read Only. Hanya user SPV dan Owner yang berwenang mengubah angka stok langsung.'
                        }
                      />
                      {!isSpvOrOwner && (
                        <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 pointer-events-none">
                          <span className="text-[10px] font-bold text-amber-400 bg-amber-950/90 px-2 py-0.5 rounded-md border border-amber-800/60 flex items-center gap-1 shadow-xs">
                            <Lock className="w-3 h-3 text-amber-400" /> SPV / Owner Only
                          </span>
                        </div>
                      )}
                    </div>

                    {!isSpvOrOwner && (
                      <div className="mt-2 p-2.5 rounded-xl bg-amber-950/30 border border-amber-800/50 flex items-start gap-2 text-[11px] text-amber-300 leading-snug">
                        <Lock className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                        <div>
                          <strong>Akses Terkunci (Read Only):</strong> Akun aktif (<strong>{currentUser?.username || 'user'}</strong> • <strong>{currentUser?.role || 'STAFF'}</strong>) tidak memiliki wewenang untuk mengubah kuantitas stok manual. Fitur ini hanya dapat diubah oleh <strong>SPV</strong> dan <strong>Owner</strong>.
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Bagian Harga HPP & Harga Jual (Dapat diubah oleh Admin/Staff/SPV/Owner) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-[#24242A]">
                  <div>
                    <label className="text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5 block">
                      Harga HPP (Modal) *
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-neutral-500 font-mono">
                        Rp
                      </span>
                      <input
                        type="number"
                        min="0"
                        value={correctionHpp}
                        onChange={(e) => setCorrectionHpp(Math.max(0, parseInt(e.target.value) || 0))}
                        placeholder="Harga modal"
                        className="w-full pl-9 pr-3 py-2 text-sm font-bold font-mono rounded-xl bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 focus:border-[#F27D26] focus:outline-hidden transition-all"
                      />
                    </div>
                    <span className="text-[10.5px] text-neutral-400 font-mono mt-0.5 block">
                      Terformat: {formatRupiah(correctionHpp)}
                    </span>
                  </div>

                  <div>
                    <label className="text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5 block">
                      Harga Jual Patokan *
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-neutral-500 font-mono">
                        Rp
                      </span>
                      <input
                        type="number"
                        min="0"
                        value={correctionJual}
                        onChange={(e) => setCorrectionJual(Math.max(0, parseInt(e.target.value) || 0))}
                        placeholder="Harga jual"
                        className="w-full pl-9 pr-3 py-2 text-sm font-bold font-mono rounded-xl bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 focus:border-[#F27D26] focus:outline-hidden transition-all"
                      />
                    </div>
                    <span className="text-[10.5px] text-neutral-400 font-mono mt-0.5 block">
                      Terformat: {formatRupiah(correctionJual)}
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                    Alasan Koreksi
                  </label>
                  <input
                    type="text"
                    value={correctionReason}
                    onChange={(e) => setCorrectionReason(e.target.value)}
                    placeholder="Contoh: Penyesuaian harga / selisih fisik opname"
                    className="w-full p-2.5 text-xs rounded-xl bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 placeholder-neutral-600 focus:border-[#F27D26] focus:outline-hidden"
                  />
                  <div className="flex flex-wrap gap-1.5 pt-1.5">
                    {['Penyesuaian harga HPP/Jual', 'Selisih opname fisik', 'Barang cacat/BS', 'Salah catat nota', 'Retur barang'].map((reason) => (
                      <button
                        key={reason}
                        type="button"
                        onClick={() => setCorrectionReason(reason)}
                        className="px-2.5 py-1 text-[11px] bg-[#1C1C20] hover:bg-[#25252A] text-neutral-300 hover:text-white border border-[#2B2B32] rounded-lg transition-colors cursor-pointer"
                      >
                        + {reason}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#24242A]">
                  <button
                    type="button"
                    onClick={() => {
                      setCorrectionItem(null);
                      setCorrectionReason('');
                    }}
                    className="px-4 py-2 text-xs font-bold text-neutral-400 hover:bg-[#1C1C20] rounded-xl cursor-pointer transition-colors"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveCorrection}
                    className="px-4 py-2 bg-[#F27D26] hover:bg-[#d96c1d] text-white text-xs font-bold rounded-xl shadow-md shadow-[#F27D26]/20 cursor-pointer transition-all flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {isSpvOrOwner ? 'Simpan Koreksi' : 'Simpan Perubahan'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* FORM ORDER STOK (PO) MODAL */}
      {showOrderModal && currentUser && (
        <OrderModal
          isOpen={showOrderModal}
          onClose={() => {
            setShowOrderModal(false);
            setActiveViewingOrder(null);
          }}
          products={products}
          warehouses={warehouses}
          currentUser={currentUser}
          onSaveOrder={handleSaveOrderDoc}
          showToast={showToast}
          initialDoc={activeViewingOrder}
          settings={settings}
        />
      )}

      {/* SURAT JALAN MODAL */}
      {showSuratJalanModal && currentUser && (
        <SuratJalanModal
          isOpen={showSuratJalanModal}
          onClose={() => {
            setShowSuratJalanModal(false);
            setActiveViewingSuratJalan(null);
          }}
          products={products}
          inventory={inventory}
          warehouses={warehouses}
          currentUser={currentUser}
          onSaveSuratJalan={handleSaveSuratJalanDoc}
          initialDoc={activeViewingSuratJalan}
          settings={settings}
        />
      )}

      {/* SALE MODAL */}
      {showSaleModal && currentUser && (
        <SaleModal
          isOpen={showSaleModal}
          onClose={() => {
            setShowSaleModal(false);
            setActiveViewingSale(null);
          }}
          products={products}
          inventory={inventory}
          warehouses={warehouses}
          customers={customers}
          currentUser={currentUser}
          onSaveSale={handleSaveSaleDoc}
          onSaveCustomer={handleSaveCustomer}
          showToast={showToast}
          initialDoc={activeViewingSale}
          settings={settings}
        />
      )}

      {/* BARCODE SCANNER FOR STOCK IN */}
      {showTxScanner && (
        <BarcodeScannerModal
          isOpen={showTxScanner}
          onClose={() => setShowTxScanner(false)}
          onScanSuccess={(code) => {
            const found = products.find(
              (p) => p.SKU_ID.toUpperCase() === code.toUpperCase() || p.BARCODE_ID?.toUpperCase() === code.toUpperCase()
            );
            if (found) {
              handleSelectTxSku(found.SKU_ID);
              showToast(`Barcode cocok: ${found.SKU_ID}`, 'success');
            } else {
              handleSelectTxSku(code);
              showToast(`Kode discan: ${code}`, 'info');
            }
          }}
          title="Pindai Barcode untuk Barang Masuk"
          subtitle="Arahkan kamera ke barcode label atau kemasan kaos"
        />
      )}

      {/* PRODUCT ADD / EDIT MODAL */}
      {editingProduct !== undefined && (
        <ProductModal
          isOpen={editingProduct !== undefined}
          onClose={() => setEditingProduct(undefined)}
          productToEdit={editingProduct}
          onSave={handleSaveProduct}
          settings={settings}
        />
      )}

      {/* LABEL PRINT MODAL */}
      {labelProduct && (
        <LabelPrintModal
          isOpen={!!labelProduct}
          onClose={() => setLabelProduct(null)}
          product={labelProduct}
          barcodeFormat={settings.barcodeFormat}
          brandName={settings.brandName}
          paperFormat={settings.labelPaperSize}
        />
      )}

      {/* QUICK BARCODE SCANNER LOOKUP MODAL */}
      {showQuickLookupModal && (
        <QuickScannerLookupModal
          isOpen={showQuickLookupModal}
          onClose={() => setShowQuickLookupModal(false)}
          products={products}
          inventory={inventory}
          warehouses={warehouses}
          onOpenBarangMasuk={(sku) => {
            if (!currentUser) {
              setShowLoginModal(true);
              return;
            }
            setAdminTab('masuk');
            setTxSku(sku);
          }}
          onOpenSuratJalan={() => {
            if (!currentUser) {
              setShowLoginModal(true);
              return;
            }
            setShowSuratJalanModal(true);
          }}
          onOpenSale={() => {
            if (!currentUser) {
              setShowLoginModal(true);
              return;
            }
            setShowSaleModal(true);
          }}
        />
      )}

      {/* GOOGLE APPS SCRIPT CODE MODAL */}
      {showGasModal && (
        <GasCodeModal isOpen={showGasModal} onClose={() => setShowGasModal(false)} />
      )}

      {/* MYSQL & PHPMYADMIN DATABASE MODAL */}
      <PhpMyAdminModal
        isOpen={showPhpMyAdminModal}
        onClose={() => setShowPhpMyAdminModal(false)}
        appData={{
          products,
          inventory,
          warehouses,
          customers,
          sales,
          orders,
          suratJalanList,
          logs,
          settings,
        }}
        onNotify={(msg, type) => showToast(msg, type)}
        onOpenOfflineSync={() => setShowOfflineSyncModal(true)}
        onRestoreFromDatabase={handleImportAllData}
        isSpvOrOwner={isSpvOrOwner}
        currentUser={currentUser}
      />

      {/* OFFLINE & QUOTA SYNC MODAL */}
      <OfflineSyncModal
        isOpen={showOfflineSyncModal}
        onClose={() => setShowOfflineSyncModal(false)}
        status={syncStatus}
        onNotify={(msg, type) => showToast(msg, type)}
      />

      {/* BACKUP & AUTOMATIC CHECKPOINT MODAL */}
      <BackupCheckpointModal
        isOpen={showBackupModal}
        onClose={() => setShowBackupModal(false)}
        products={products}
        warehouses={warehouses}
        inventory={inventory}
        logs={logs}
        users={users}
        settings={settings}
        orders={orders}
        suratJalanList={suratJalanList}
        sales={sales}
        customers={customers}
        currentUser={currentUser}
        onUpdateSettings={setSettings}
        onRestoreAllData={handleImportAllData}
        showToast={showToast}
      />

      {/* PUSH NOTIFICATION MODAL */}
      <NotificationModal
        isOpen={showNotificationModal}
        onClose={() => setShowNotificationModal(false)}
        onShowToast={showToast}
      />
    </div>
  );
}
