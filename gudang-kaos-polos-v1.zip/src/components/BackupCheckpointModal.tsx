import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  AppBackupData,
  CheckpointItem,
  CheckpointTriggerType,
  MasterProduk,
  MasterGudang,
  InventoryItem,
  LogTransaksi,
  UserAccount,
  AppSystemSettings,
  OrderDocument,
  SuratJalanDocument,
  SaleDocument,
  Pelanggan,
  User,
} from '../types';
import { CheckpointService, AppStateSnapshot } from '../services/checkpointService';
import { formatNumber, formatRupiah } from '../utils/formatters';
import {
  Database,
  Download,
  Upload,
  RotateCcw,
  ShieldCheck,
  Clock,
  Save,
  CheckCircle2,
  AlertTriangle,
  Trash2,
  Pin,
  Copy,
  Check,
  FileJson,
  Sparkles,
  Sliders,
  Layers,
  ArrowRight,
  HardDrive,
  Info,
  X,
  FileSpreadsheet,
  RefreshCw,
  FolderSync,
} from 'lucide-react';

interface BackupCheckpointModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: MasterProduk[];
  warehouses: MasterGudang[];
  inventory: InventoryItem[];
  logs: LogTransaksi[];
  users: UserAccount[];
  settings: AppSystemSettings;
  orders: OrderDocument[];
  suratJalanList: SuratJalanDocument[];
  sales: SaleDocument[];
  customers: Pelanggan[];
  currentUser: User | null;
  onUpdateSettings: (settings: AppSystemSettings) => void;
  onRestoreAllData: (data: AppBackupData) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const BackupCheckpointModal: React.FC<BackupCheckpointModalProps> = ({
  isOpen,
  onClose,
  products,
  warehouses,
  inventory,
  logs,
  users,
  settings,
  orders,
  suratJalanList,
  sales,
  customers,
  currentUser,
  onUpdateSettings,
  onRestoreAllData,
  showToast,
}) => {
  const [activeTab, setActiveTab] = useState<'create' | 'checkpoints' | 'restore' | 'settings'>('create');
  const [checkpoints, setCheckpoints] = useState<CheckpointItem[]>([]);
  const [isCopied, setIsCopied] = useState(false);

  // Form State: Manual Snapshot Creation
  const [manualName, setManualName] = useState('');
  const [manualNote, setManualNote] = useState('');
  const [isCreatingSnapshot, setIsCreatingSnapshot] = useState(false);

  // Form State: Restore JSON File
  const [importedData, setImportedData] = useState<AppBackupData | null>(null);
  const [importFileName, setImportFileName] = useState<string>('');
  const [createSafetyBeforeRestore, setCreateSafetyBeforeRestore] = useState(true);
  const [importError, setImportError] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Rollback Confirmation Target
  const [rollbackTarget, setRollbackTarget] = useState<CheckpointItem | null>(null);

  // Auto Checkpoint Configuration
  const [chkAutoEnabled, setChkAutoEnabled] = useState(
    settings.checkpointSettings?.autoCheckpointEnabled ?? true
  );
  const [chkIntervalMin, setChkIntervalMin] = useState(
    settings.checkpointSettings?.intervalMinutes ?? 30
  );
  const [chkMaxCheckpoints, setChkMaxCheckpoints] = useState(
    settings.checkpointSettings?.maxCheckpoints ?? 15
  );
  const [chkAutoBeforeOpname, setChkAutoBeforeOpname] = useState(
    settings.checkpointSettings?.autoBeforeOpname ?? true
  );
  const [chkAutoBeforeRestore, setChkAutoBeforeRestore] = useState(
    settings.checkpointSettings?.autoBeforeRestore ?? true
  );
  const [chkAutoAfterSale, setChkAutoAfterSale] = useState(
    settings.checkpointSettings?.autoAfterSale ?? false
  );

  // Refresh checkpoints when modal opens
  useEffect(() => {
    if (isOpen) {
      loadCheckpoints();
      setManualName(`Snapshot Manual - ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}`);
      setManualNote('');
      setImportedData(null);
      setImportError('');
      setRollbackTarget(null);

      // Sync settings
      if (settings.checkpointSettings) {
        setChkAutoEnabled(settings.checkpointSettings.autoCheckpointEnabled);
        setChkIntervalMin(settings.checkpointSettings.intervalMinutes);
        setChkMaxCheckpoints(settings.checkpointSettings.maxCheckpoints);
        setChkAutoBeforeOpname(settings.checkpointSettings.autoBeforeOpname);
        setChkAutoBeforeRestore(settings.checkpointSettings.autoBeforeRestore);
        setChkAutoAfterSale(settings.checkpointSettings.autoAfterSale);
      }
    }
  }, [isOpen, settings]);

  const loadCheckpoints = () => {
    const list = CheckpointService.getCheckpoints();
    setCheckpoints(list);
  };

  const currentStateSnapshot: AppStateSnapshot = useMemo(() => ({
    products,
    warehouses,
    inventory,
    logs,
    users,
    settings,
    orders,
    suratJalanList,
    sales,
    customers,
  }), [products, warehouses, inventory, logs, users, settings, orders, suratJalanList, sales, customers]);

  const currentBackupPayload = useMemo(() => {
    return CheckpointService.generateBackupData(currentStateSnapshot, 'Manual Export');
  }, [currentStateSnapshot]);

  const currentSizeKb = useMemo(() => {
    return CheckpointService.calculateSizeKb(currentBackupPayload);
  }, [currentBackupPayload]);

  // Handle Create Manual Snapshot
  const handleCreateManualSnapshot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualName.trim()) {
      showToast('Masukkan judul atau keterangan snapshot manual!', 'error');
      return;
    }

    setIsCreatingSnapshot(true);
    try {
      const chk = CheckpointService.createCheckpoint(
        'MANUAL',
        manualName.trim(),
        currentUser?.fullName || currentUser?.username || 'Admin',
        currentStateSnapshot,
        manualNote.trim(),
        settings.checkpointSettings
      );

      loadCheckpoints();
      showToast(`✅ Snapshot "${chk.name}" berhasil disimpan ke sistem checkpoint!`, 'success');
      setActiveTab('checkpoints');
    } catch (err: any) {
      showToast(`Gagal membuat snapshot: ${err?.message || 'Error tidak diketahui'}`, 'error');
    } finally {
      setIsCreatingSnapshot(false);
    }
  };

  // Handle Direct JSON Download
  const handleDownloadCurrentJson = () => {
    try {
      CheckpointService.downloadBackupJson(currentBackupPayload);
      showToast('Berkas backup JSON berhasil diunduh ke perangkat Anda.', 'success');
    } catch {
      showToast('Gagal mengunduh berkas backup JSON.', 'error');
    }
  };

  // Copy raw JSON to clipboard
  const handleCopyJsonToClipboard = () => {
    try {
      const jsonStr = JSON.stringify(currentBackupPayload, null, 2);
      navigator.clipboard.writeText(jsonStr);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2500);
      showToast('Format JSON backup berhasil disalin ke papan klip (clipboard)!', 'info');
    } catch {
      showToast('Gagal menyalin data ke clipboard.', 'error');
    }
  };

  // Handle Upload & Parse Backup File
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportFileName(file.name);
    setImportError('');
    setImportedData(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = CheckpointService.validateBackupJson(content);
      if (res.valid && res.data) {
        setImportedData(res.data);
        showToast(`Berkas "${file.name}" valid dan siap dipulihkan.`, 'success');
      } else {
        setImportError(res.error || 'Berkas JSON tidak valid.');
        showToast(res.error || 'Berkas backup rusak atau tidak valid.', 'error');
      }
    };
    reader.onerror = () => {
      setImportError('Gagal membaca berkas dari sistem komputer.');
      showToast('Gagal membaca berkas.', 'error');
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Execute Restore from JSON
  const handleExecuteRestore = () => {
    if (!importedData) return;

    // Safety Snapshot
    if (createSafetyBeforeRestore) {
      CheckpointService.createCheckpoint(
        'AUTO_RESTORE',
        `Safety Rollback sebelum Pulihkan Berkas ${importFileName}`,
        currentUser?.fullName || currentUser?.username || 'Sistem',
        currentStateSnapshot,
        'Dibuat otomatis sebagai titik pengaman sebelum menimpa data sistem.',
        settings.checkpointSettings
      );
    }

    onRestoreAllData(importedData);
    loadCheckpoints();
    showToast(`✅ Seluruh data berhasil dipulihkan dari "${importFileName}"!`, 'success');
    setImportedData(null);
    setImportFileName('');
    onClose();
  };

  // Execute Rollback to Checkpoint
  const handleExecuteRollback = () => {
    if (!rollbackTarget) return;

    // Create safety snapshot of right before rollback
    CheckpointService.createCheckpoint(
      'AUTO_RESTORE',
      `Safety Rollback sebelum Pulihkan Checkpoint [${rollbackTarget.name}]`,
      currentUser?.fullName || currentUser?.username || 'Sistem',
      currentStateSnapshot,
      'Dibuat otomatis sebelum melakukan rollback.',
      settings.checkpointSettings
    );

    onRestoreAllData(rollbackTarget.data);
    loadCheckpoints();
    showToast(`✅ Sistem berhasil dikembalikan ke checkpoint "${rollbackTarget.name}"!`, 'success');
    setRollbackTarget(null);
    onClose();
  };

  // Delete Checkpoint
  const handleDeleteCheckpoint = (id: string, name: string) => {
    if (confirm(`Hapus checkpoint "${name}" dari riwayat penyimpanan?`)) {
      const updated = CheckpointService.deleteCheckpoint(id);
      setCheckpoints(updated);
      showToast(`Checkpoint "${name}" berhasil dihapus.`, 'info');
    }
  };

  // Toggle Pin Checkpoint
  const handleTogglePin = (id: string) => {
    const updated = CheckpointService.togglePin(id);
    setCheckpoints(updated);
    showToast('Status semat (pin) checkpoint diperbarui.', 'info');
  };

  // Clear Auto Checkpoints
  const handleClearAutoCheckpoints = () => {
    if (confirm('Hapus semua checkpoint otomatis berkala? Snapshot manual dan yang disematkan (pinned) akan tetap dipertahankan.')) {
      const updated = CheckpointService.clearCheckpoints(true);
      setCheckpoints(updated);
      showToast('Riwayat checkpoint otomatis berhasil dibersihkan.', 'success');
    }
  };

  // Save Checkpoint Settings
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedSettings: AppSystemSettings = {
      ...settings,
      checkpointSettings: {
        autoCheckpointEnabled: chkAutoEnabled,
        intervalMinutes: Number(chkIntervalMin) || 30,
        maxCheckpoints: Number(chkMaxCheckpoints) || 15,
        autoBeforeOpname: chkAutoBeforeOpname,
        autoBeforeRestore: chkAutoBeforeRestore,
        autoAfterSale: chkAutoAfterSale,
      },
    };

    onUpdateSettings(updatedSettings);
    showToast('Pengaturan Checkpoint Otomatis berhasil disimpan.', 'success');
  };

  const getTriggerBadge = (type: CheckpointTriggerType) => {
    switch (type) {
      case 'MANUAL':
        return {
          label: 'Manual (Snapshot)',
          bg: 'bg-emerald-950/60 border-emerald-700/60 text-emerald-300',
        };
      case 'AUTO_INTERVAL':
        return {
          label: 'Otomatis (Interval)',
          bg: 'bg-blue-950/60 border-blue-700/60 text-blue-300',
        };
      case 'AUTO_OPNAME':
        return {
          label: 'Stok Opname',
          bg: 'bg-purple-950/60 border-purple-700/60 text-purple-300',
        };
      case 'AUTO_RESTORE':
        return {
          label: 'Safety Rollback',
          bg: 'bg-amber-950/60 border-amber-700/60 text-amber-300',
        };
      case 'AUTO_SALE':
        return {
          label: 'Transaksi Penjualan',
          bg: 'bg-rose-950/60 border-rose-700/60 text-rose-300',
        };
      default:
        return {
          label: 'Sistem',
          bg: 'bg-neutral-800 border-neutral-700 text-neutral-300',
        };
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-xs animate-in fade-in duration-200">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-[#141416] rounded-2xl sm:rounded-3xl shadow-2xl w-full max-w-4xl max-h-[92vh] flex flex-col border border-[#2A2A32] text-[#E0E0E0] overflow-hidden"
      >
        {/* MODAL HEADER */}
        <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#111114] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-br from-[#F27D26] to-amber-600 flex items-center justify-center text-white shadow-lg shadow-[#F27D26]/25 shrink-0">
              <Database className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base sm:text-lg text-white">
                  Pusat Backup & Checkpoint Otomatis
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-800 text-emerald-400 font-bold hidden sm:inline-block">
                  Auto-Recovery Aktif
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Pencadangan snapshot berkala, rollback aman, serta impor-ekspor berkas database lengkap
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* SYSTEM STATUS STATS BAR */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3 p-3 sm:p-4 bg-[#18181C] border-b border-[#24242A] text-xs shrink-0">
          <div className="bg-[#101012] p-2.5 rounded-xl border border-[#222228]">
            <span className="text-[10px] text-neutral-400 block font-medium">Checkpoint Tersimpan</span>
            <span className="font-extrabold text-sm sm:text-base text-white flex items-center gap-1.5 mt-0.5">
              <Layers className="w-4 h-4 text-[#F27D26]" /> {checkpoints.length} / {chkMaxCheckpoints} Slot
            </span>
          </div>

          <div className="bg-[#101012] p-2.5 rounded-xl border border-[#222228]">
            <span className="text-[10px] text-neutral-400 block font-medium">Checkpoint Terakhir</span>
            <span className="font-extrabold text-xs sm:text-sm text-neutral-200 flex items-center gap-1.5 mt-0.5 truncate">
              <Clock className="w-4 h-4 text-blue-400 shrink-0" />
              <span className="truncate">
                {checkpoints[0] ? CheckpointService.formatRelativeTime(checkpoints[0].timestamp) : 'Belum Ada'}
              </span>
            </span>
          </div>

          <div className="bg-[#101012] p-2.5 rounded-xl border border-[#222228]">
            <span className="text-[10px] text-neutral-400 block font-medium">Total Data Terdata</span>
            <span className="font-extrabold text-xs sm:text-sm text-emerald-400 flex items-center gap-1.5 mt-0.5">
              <HardDrive className="w-4 h-4 shrink-0" />
              <span>{formatNumber(products.length)} SKU • {formatNumber(currentBackupPayload.summary.totalStockPcs)} Pcs</span>
            </span>
          </div>

          <div className="bg-[#101012] p-2.5 rounded-xl border border-[#222228]">
            <span className="text-[10px] text-neutral-400 block font-medium">Auto-Checkpoint</span>
            <span className="font-extrabold text-xs sm:text-sm text-white flex items-center gap-1.5 mt-0.5">
              <span
                className={`w-2 h-2 rounded-full ${
                  chkAutoEnabled ? 'bg-emerald-400 animate-pulse' : 'bg-neutral-600'
                }`}
              />
              <span className={chkAutoEnabled ? 'text-emerald-300' : 'text-neutral-400'}>
                {chkAutoEnabled ? `Tiap ${chkIntervalMin} Menit` : 'Non-Aktif'}
              </span>
            </span>
          </div>
        </div>

        {/* TAB NAVIGATION */}
        <div className="flex items-center gap-2 px-4 sm:px-6 pt-3 border-b border-[#24242A] bg-[#141416] shrink-0 overflow-x-auto">
          {[
            { id: 'create' as const, label: 'Backup Manual & Ekspor', icon: Save },
            { id: 'checkpoints' as const, label: `Riwayat Checkpoint (${checkpoints.length})`, icon: Layers },
            { id: 'restore' as const, label: 'Pulihkan Berkas JSON', icon: Upload },
            { id: 'settings' as const, label: 'Pengaturan Otomatis', icon: Sliders },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-3.5 text-xs font-bold rounded-t-xl flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'border-[#F27D26] text-white bg-[#1A1A1E]'
                    : 'border-transparent text-neutral-400 hover:text-neutral-200 hover:bg-[#1A1A1E]/50'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* MODAL BODY (SCROLLABLE) */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* ========================================================================= */}
          {/* TAB 1: CREATE MANUAL BACKUP & EXPORT */}
          {/* ========================================================================= */}
          {activeTab === 'create' && (
            <div className="space-y-6">
              {/* Card 1: 1-Click Manual Snapshot to System Storage */}
              <div className="bg-[#18181C] rounded-2xl border border-[#2B2B32] p-4 sm:p-5">
                <div className="flex items-center gap-2.5 mb-3">
                  <div className="w-8 h-8 rounded-xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
                    <Save className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm sm:text-base text-white">
                      Buat Snapshot Checkpoint Manual Sekarang
                    </h4>
                    <p className="text-xs text-neutral-400">
                      Ambil salinan cadangan instan ke penyimpanan sistem sebelum melakukan perubahan besar
                    </p>
                  </div>
                </div>

                <form onSubmit={handleCreateManualSnapshot} className="space-y-3.5 text-xs">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                      Nama / Label Snapshot *
                    </label>
                    <input
                      type="text"
                      value={manualName}
                      onChange={(e) => setManualName(e.target.value)}
                      placeholder="misal: Sebelum Tutup Shift 1 / Sebelum Update Stok Lebaran"
                      required
                      className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                      Catatan Tambahan (Opsional)
                    </label>
                    <input
                      type="text"
                      value={manualNote}
                      onChange={(e) => setManualNote(e.target.value)}
                      placeholder="Keterangan kondisi inventori atau alasan backup..."
                      className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 focus:border-[#F27D26] focus:outline-hidden"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <span className="text-[11px] text-neutral-400">
                      Ukuran estimasi: <strong className="text-neutral-200">{currentSizeKb} KB</strong> • Otomatis disematkan (pinned)
                    </span>
                    <button
                      type="submit"
                      disabled={isCreatingSnapshot}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all cursor-pointer disabled:opacity-50"
                    >
                      <Save className="w-4 h-4" />
                      <span>{isCreatingSnapshot ? 'Menyimpan...' : 'Simpan Checkpoint Manual'}</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Card 2: Export to JSON File or Clipboard */}
              <div className="bg-[#18181C] rounded-2xl border border-[#2B2B32] p-4 sm:p-5">
                <div className="flex items-center gap-2.5 mb-3">
                  <div className="w-8 h-8 rounded-xl bg-blue-950 border border-blue-800 flex items-center justify-center text-blue-400">
                    <Download className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm sm:text-base text-white">
                      Unduh Berkas Arsip (.JSON) Komprehensif
                    </h4>
                    <p className="text-xs text-neutral-400">
                      Simpan file fisik ke komputer, laptop, flashdisk, atau kirim melalui email/Google Drive
                    </p>
                  </div>
                </div>

                <div className="bg-[#101012] p-3.5 rounded-xl border border-[#24242A] text-xs space-y-2 mb-4">
                  <div className="font-bold text-neutral-200">
                    Isi berkas backup yang akan diunduh:
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] text-neutral-400">
                    <div>• {formatNumber(products.length)} Master Produk (SKU)</div>
                    <div>• {formatNumber(warehouses.length)} Gudang Aktif</div>
                    <div>• {formatNumber(inventory.length)} Slot Stok Inventori</div>
                    <div>• {formatNumber(logs.length)} Baris Log Mutasi</div>
                    <div>• {formatNumber(sales.length)} Faktur Penjualan</div>
                    <div>• {formatNumber(orders.length)} Dokumen Order PO</div>
                    <div>• {formatNumber(suratJalanList.length)} Dokumen Surat Jalan</div>
                    <div>• {formatNumber(customers.length)} Master Pelanggan</div>
                    <div>• Pengaturan, Logo & Stempel Toko</div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={handleDownloadCurrentJson}
                    className="flex-1 min-w-[200px] py-2.5 px-4 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-md shadow-[#F27D26]/20 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4" /> Unduh Berkas JSON Lengkap (.json)
                  </button>

                  <button
                    type="button"
                    onClick={handleCopyJsonToClipboard}
                    className="py-2.5 px-4 bg-[#1F1F24] hover:bg-[#282830] text-neutral-200 border border-[#2E2E38] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {isCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-neutral-400" />}
                    <span>{isCopied ? 'Tersalin!' : 'Salin JSON ke Clipboard'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 2: CHECKPOINT HISTORY & ROLLBACK */}
          {/* ========================================================================= */}
          {activeTab === 'checkpoints' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h4 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-[#F27D26]" /> Daftar Checkpoint & Titik Rollback
                  </h4>
                  <p className="text-xs text-neutral-400">
                    Klik "Pulihkan" pada salah satu snapshot untuk mengembalikan kondisi data sistem
                  </p>
                </div>

                {checkpoints.length > 0 && (
                  <button
                    type="button"
                    onClick={handleClearAutoCheckpoints}
                    className="px-3 py-1.5 bg-[#1C1C20] hover:bg-rose-950/40 text-neutral-300 hover:text-rose-300 border border-[#2B2B32] hover:border-rose-800 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Bersihkan Auto-Checkpoint</span>
                  </button>
                )}
              </div>

              {checkpoints.length === 0 ? (
                <div className="bg-[#18181C] rounded-2xl border border-dashed border-[#2B2B32] p-8 text-center text-neutral-400 space-y-2">
                  <Database className="w-10 h-10 text-neutral-600 mx-auto" />
                  <p className="text-sm font-bold text-neutral-300">Belum Ada Checkpoint Tersimpan</p>
                  <p className="text-xs max-w-md mx-auto">
                    Buat snapshot manual di tab pertama atau biarkan sistem membuat checkpoint otomatis secara berkala sesuai interval waktu.
                  </p>
                  <button
                    type="button"
                    onClick={() => setActiveTab('create')}
                    className="mt-3 px-4 py-2 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Save className="w-4 h-4" /> Buat Snapshot Sekarang
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {checkpoints.map((chk) => {
                    const badge = getTriggerBadge(chk.triggerType);
                    const isNewest = checkpoints[0]?.id === chk.id;

                    return (
                      <div
                        key={chk.id}
                        className={`bg-[#18181C] rounded-2xl border p-4 transition-all ${
                          isNewest
                            ? 'border-[#F27D26]/40 shadow-sm shadow-[#F27D26]/10'
                            : 'border-[#26262B] hover:border-[#383840]'
                        }`}
                      >
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${badge.bg}`}>
                                {badge.label}
                              </span>

                              {chk.isPinned && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/60 border border-amber-800/60 text-amber-300 flex items-center gap-1">
                                  <Pin className="w-2.5 h-2.5" /> Disematkan (Anti-Prune)
                                </span>
                              )}

                              {isNewest && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/80 border border-emerald-800 text-emerald-300">
                                  Terbaru
                                </span>
                              )}

                              <span className="text-[11px] text-neutral-400 font-mono">
                                {new Date(chk.timestamp).toLocaleString('id-ID')}
                              </span>
                            </div>

                            <h5 className="font-extrabold text-sm sm:text-base text-white">
                              {chk.name}
                            </h5>

                            {chk.note && (
                              <p className="text-xs text-neutral-400 italic">
                                "{chk.note}"
                              </p>
                            )}

                            <div className="flex flex-wrap items-center gap-3 text-[11px] text-neutral-400 pt-1">
                              <span>Oleh: <strong className="text-neutral-200">{chk.creator}</strong></span>
                              <span>•</span>
                              <span>{chk.data.summary.totalProducts} Produk ({formatNumber(chk.data.summary.totalStockPcs)} Pcs)</span>
                              <span>•</span>
                              <span>{chk.data.summary.totalTransactions} Log Transaksi</span>
                              <span>•</span>
                              <span>{chk.data.summary.totalSales} Penjualan</span>
                              <span>•</span>
                              <span>{chk.sizeKb} KB</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            {/* Pin Button */}
                            <button
                              type="button"
                              onClick={() => handleTogglePin(chk.id)}
                              className={`p-2 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                                chk.isPinned
                                  ? 'bg-amber-950/50 text-amber-300 border-amber-800 hover:bg-amber-900/50'
                                  : 'bg-[#121214] text-neutral-400 border-[#2B2B32] hover:text-white'
                              }`}
                              title={chk.isPinned ? 'Lepaskan Sematan' : 'Sematkan agar aman dari auto-pruning'}
                            >
                              <Pin className="w-3.5 h-3.5" />
                            </button>

                            {/* Download JSON Button */}
                            <button
                              type="button"
                              onClick={() =>
                                CheckpointService.downloadBackupJson(
                                  chk.data,
                                  `checkpoint_${chk.id}_${chk.name.replace(/[^a-zA-Z0-9]/g, '_')}.json`
                                )
                              }
                              className="p-2 bg-[#121214] hover:bg-[#202026] text-neutral-300 hover:text-white border border-[#2B2B32] rounded-xl text-xs font-bold transition-colors cursor-pointer"
                              title="Unduh snapshot ini sebagai berkas JSON terpisah"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </button>

                            {/* Rollback Button */}
                            <button
                              type="button"
                              onClick={() => setRollbackTarget(chk)}
                              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                              title="Kembalikan sistem ke kondisi saat checkpoint ini dibuat"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              <span>Pulihkan</span>
                            </button>

                            {/* Delete Button */}
                            <button
                              type="button"
                              onClick={() => handleDeleteCheckpoint(chk.id, chk.name)}
                              className="p-2 bg-[#121214] hover:bg-rose-950/60 text-neutral-400 hover:text-rose-400 border border-[#2B2B32] hover:border-rose-800 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                              title="Hapus checkpoint ini"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 3: RESTORE FROM JSON FILE */}
          {/* ========================================================================= */}
          {activeTab === 'restore' && (
            <div className="space-y-5">
              <div className="bg-[#18181C] rounded-2xl border border-[#2B2B32] p-4 sm:p-5">
                <div className="flex items-center gap-2.5 mb-3">
                  <div className="w-8 h-8 rounded-xl bg-purple-950 border border-purple-800 flex items-center justify-center text-purple-400">
                    <Upload className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm sm:text-base text-white">
                      Unggah Berkas Backup JSON untuk Pemulihan
                    </h4>
                    <p className="text-xs text-neutral-400">
                      Pilih berkas .json yang telah diunduh sebelumnya untuk mengembalikan atau memindahkan data ke perangkat ini
                    </p>
                  </div>
                </div>

                <div className="border-2 border-dashed border-[#2E2E38] hover:border-[#F27D26] rounded-2xl p-6 text-center transition-colors">
                  <FileJson className="w-10 h-10 text-neutral-500 mx-auto mb-2" />
                  <p className="text-xs text-neutral-300 font-bold mb-1">
                    Pilih berkas format .JSON backup
                  </p>
                  <p className="text-[11px] text-neutral-500 mb-3">
                    Mendukung backup versi 2.0 maupun versi 2.5
                  </p>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".json"
                    onChange={handleFileChange}
                    className="hidden"
                  />

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-2 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    <Upload className="w-4 h-4" /> Pilih Berkas dari Perangkat
                  </button>
                </div>

                {importError && (
                  <div className="mt-3 p-3 bg-rose-950/40 border border-rose-800/60 rounded-xl text-xs text-rose-300 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                    <span>{importError}</span>
                  </div>
                )}
              </div>

              {/* Data Preview Card when JSON is Loaded */}
              {importedData && (
                <div className="bg-[#18181C] rounded-2xl border border-emerald-700/60 p-4 sm:p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-sm">
                      <CheckCircle2 className="w-5 h-5" />
                      <span>Ringkasan Data dalam Berkas: {importFileName}</span>
                    </div>
                    <span className="text-[10px] font-mono bg-emerald-950 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-800">
                      Ekspor: {new Date(importedData.exportedAt).toLocaleDateString('id-ID')}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                    <div className="bg-[#101012] p-2.5 rounded-xl border border-[#24242A]">
                      <span className="text-[10px] text-neutral-400 block">Master Produk</span>
                      <strong className="text-white text-sm">{importedData.summary.totalProducts} SKU</strong>
                    </div>
                    <div className="bg-[#101012] p-2.5 rounded-xl border border-[#24242A]">
                      <span className="text-[10px] text-neutral-400 block">Total Stok</span>
                      <strong className="text-emerald-400 text-sm">{formatNumber(importedData.summary.totalStockPcs)} Pcs</strong>
                    </div>
                    <div className="bg-[#101012] p-2.5 rounded-xl border border-[#24242A]">
                      <span className="text-[10px] text-neutral-400 block">Gudang</span>
                      <strong className="text-white text-sm">{importedData.summary.totalWarehouses} Unit</strong>
                    </div>
                    <div className="bg-[#101012] p-2.5 rounded-xl border border-[#24242A]">
                      <span className="text-[10px] text-neutral-400 block">Log Transaksi</span>
                      <strong className="text-white text-sm">{importedData.summary.totalTransactions} Baris</strong>
                    </div>
                    <div className="bg-[#101012] p-2.5 rounded-xl border border-[#24242A]">
                      <span className="text-[10px] text-neutral-400 block">Nota Penjualan</span>
                      <strong className="text-white text-sm">{importedData.summary.totalSales} Dokumen</strong>
                    </div>
                    <div className="bg-[#101012] p-2.5 rounded-xl border border-[#24242A]">
                      <span className="text-[10px] text-neutral-400 block">Order PO</span>
                      <strong className="text-white text-sm">{importedData.summary.totalOrders} Dokumen</strong>
                    </div>
                    <div className="bg-[#101012] p-2.5 rounded-xl border border-[#24242A]">
                      <span className="text-[10px] text-neutral-400 block">Surat Jalan</span>
                      <strong className="text-white text-sm">{importedData.summary.totalSuratJalan} Dokumen</strong>
                    </div>
                    <div className="bg-[#101012] p-2.5 rounded-xl border border-[#24242A]">
                      <span className="text-[10px] text-neutral-400 block">Pelanggan</span>
                      <strong className="text-white text-sm">{importedData.summary.totalCustomers} Akun</strong>
                    </div>
                  </div>

                  <div className="p-3 bg-amber-950/30 border border-amber-800/40 rounded-xl text-xs text-amber-200/90 flex items-start gap-2.5">
                    <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold block">Proteksi Keamanan Rollback:</span>
                      Sistem akan membuat checkpoint cadangan otomatis tepat sebelum proses pemulihan berjalan. Anda selalu dapat kembali ke kondisi sekarang kapan saja jika diperlukan.
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <label className="flex items-center gap-2 cursor-pointer text-xs text-neutral-300">
                      <input
                        type="checkbox"
                        checked={createSafetyBeforeRestore}
                        onChange={(e) => setCreateSafetyBeforeRestore(e.target.checked)}
                        className="rounded accent-[#F27D26]"
                      />
                      <span>Buat Safety Checkpoint Otomatis sebelum menerapkan</span>
                    </label>

                    <button
                      type="button"
                      onClick={handleExecuteRestore}
                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-600/25 transition-all cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" /> Terapkan & Pulihkan Data Sekarang
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 4: AUTOMATIC CHECKPOINT SETTINGS */}
          {/* ========================================================================= */}
          {activeTab === 'settings' && (
            <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
              <div className="bg-[#18181C] rounded-2xl border border-[#2B2B32] p-4 sm:p-5 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-[#24242A]">
                  <div>
                    <h4 className="font-extrabold text-sm sm:text-base text-white">
                      Aktifkan Checkpoint Otomatis Berkala (Interval)
                    </h4>
                    <p className="text-xs text-neutral-400">
                      Sistem akan otomatis mengambil snapshot cadangan pada interval waktu yang Anda tentukan
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setChkAutoEnabled(!chkAutoEnabled)}
                    className={`px-3 py-1.5 rounded-full font-bold text-xs cursor-pointer transition-colors ${
                      chkAutoEnabled
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
                    }`}
                  >
                    {chkAutoEnabled ? '✓ AKTIF' : '✗ NON-AKTIF'}
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                      Frekuensi Interval Checkpoint
                    </label>
                    <select
                      value={chkIntervalMin}
                      onChange={(e) => setChkIntervalMin(Number(e.target.value))}
                      disabled={!chkAutoEnabled}
                      className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden disabled:opacity-50"
                    >
                      <option value={15}>Setiap 15 Menit (Sangat Aman)</option>
                      <option value={30}>Setiap 30 Menit (Direkomendasikan)</option>
                      <option value={60}>Setiap 1 Jam</option>
                      <option value={120}>Setiap 2 Jam</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                      Batas Maksimal Checkpoint Tersimpan
                    </label>
                    <select
                      value={chkMaxCheckpoints}
                      onChange={(e) => setChkMaxCheckpoints(Number(e.target.value))}
                      className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                    >
                      <option value={5}>5 Slot Terakhir</option>
                      <option value={10}>10 Slot Terakhir</option>
                      <option value={15}>15 Slot Terakhir (Direkomendasikan)</option>
                      <option value={20}>20 Slot Terakhir</option>
                    </select>
                    <span className="text-[10px] text-neutral-500 mt-1 block">
                      Snapshot tertua akan digantikan otomatis kecuali jika disematkan (pinned).
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#24242A] space-y-3">
                  <div className="font-bold text-neutral-200">
                    Pemicu Checkpoint Otomatis Berdasarkan Peristiwa (Event Triggers):
                  </div>

                  <label className="flex items-center justify-between p-3 rounded-xl bg-[#111114] border border-[#24242A] cursor-pointer">
                    <div>
                      <span className="font-bold text-white block">Sebelum Penyetujuan Berita Acara Stok Opname</span>
                      <span className="text-[10px] text-neutral-400">Otomatis buat checkpoint sebelum angka stok disesuaikan dari hasil audit fisik</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={chkAutoBeforeOpname}
                      onChange={(e) => setChkAutoBeforeOpname(e.target.checked)}
                      className="rounded accent-[#F27D26]"
                    />
                  </label>

                  <label className="flex items-center justify-between p-3 rounded-xl bg-[#111114] border border-[#24242A] cursor-pointer">
                    <div>
                      <span className="font-bold text-white block">Safety Checkpoint Sebelum Restore / Reset Pabrik</span>
                      <span className="text-[10px] text-neutral-400">Pastikan selalu ada titik cadangan darurat sebelum data di-restore atau di-reset</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={chkAutoBeforeRestore}
                      onChange={(e) => setChkAutoBeforeRestore(e.target.checked)}
                      className="rounded accent-[#F27D26]"
                    />
                  </label>

                  <label className="flex items-center justify-between p-3 rounded-xl bg-[#111114] border border-[#24242A] cursor-pointer">
                    <div>
                      <span className="font-bold text-white block">Otomatis Setelah Transaksi Penjualan Baru</span>
                      <span className="text-[10px] text-neutral-400">Buat snapshot setiap ada pencatatan nota kasir/penjualan</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={chkAutoAfterSale}
                      onChange={(e) => setChkAutoAfterSale(e.target.checked)}
                      className="rounded accent-[#F27D26]"
                    />
                  </label>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4" /> Simpan Pengaturan Checkpoint
                </button>
              </div>
            </form>
          )}
        </div>

        {/* ========================================================================= */}
        {/* MODAL ROLLBACK CONFIRMATION OVERLAY */}
        {/* ========================================================================= */}
        {rollbackTarget && (
          <div className="fixed inset-0 z-60 bg-black/85 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-[#18181C] rounded-2xl border border-rose-800/80 p-5 sm:p-6 max-w-lg w-full space-y-4 shadow-2xl"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-950 border border-rose-800 flex items-center justify-center text-rose-400 shrink-0">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-extrabold text-base text-rose-300">
                    Konfirmasi Pulihkan (Rollback) Checkpoint
                  </h4>
                  <p className="text-xs text-neutral-400">
                    Tindakan ini akan mengembalikan seluruh data inventori, transaksi & dokumen
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-[#101012] rounded-xl border border-[#24242A] text-xs space-y-1.5">
                <div>
                  <span className="text-neutral-400 block text-[10px] uppercase">Target Checkpoint:</span>
                  <span className="font-bold text-white text-sm">{rollbackTarget.name}</span>
                </div>
                <div className="text-[11px] text-neutral-300 flex justify-between">
                  <span>Waktu Checkpoint:</span>
                  <span className="font-mono">{new Date(rollbackTarget.timestamp).toLocaleString('id-ID')}</span>
                </div>
                <div className="text-[11px] text-neutral-300 flex justify-between">
                  <span>Isi Data:</span>
                  <span>{rollbackTarget.data.summary.totalProducts} SKU • {formatNumber(rollbackTarget.data.summary.totalStockPcs)} Pcs • {rollbackTarget.data.summary.totalTransactions} Transaksi</span>
                </div>
              </div>

              <p className="text-xs text-neutral-300">
                Data sistem Anda saat ini akan otomatis disimpan sebagai <strong>Safety Checkpoint</strong> sebelum proses pengembalian dilakukan, sehingga Anda tetap terlindungi dan dapat berpindah kembali kapan saja.
              </p>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setRollbackTarget(null)}
                  className="px-4 py-2 bg-[#24242A] hover:bg-[#2C2C34] text-neutral-300 rounded-xl font-bold text-xs cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleExecuteRollback}
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md shadow-rose-600/30 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" /> Ya, Pulihkan ke Titik Ini
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </motion.div>
    </div>
  );
};
