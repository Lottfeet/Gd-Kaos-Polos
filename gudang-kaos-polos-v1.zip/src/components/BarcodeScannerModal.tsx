import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { Camera, Flashlight, RefreshCw, Upload, X, CheckCircle2, AlertCircle, Keyboard } from 'lucide-react';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess: (decodedText: string) => void;
  title?: string;
  subtitle?: string;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onScanSuccess,
  title = 'Pemindai Barcode & QR',
  subtitle = 'Arahkan kamera ke barcode produk atau SKU',
}) => {
  const [activeTab, setActiveTab] = useState<'camera' | 'upload' | 'manual'>('camera');
  const [cameras, setCameras] = useState<{ id: string; label: string }[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [manualInput, setManualInput] = useState<string>('');
  const [lastScanned, setLastScanned] = useState<string | null>(null);

  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);
  const readerElementId = 'barcode-reader-viewport';

  const playBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.12);
    } catch {
      // AudioContext might be blocked until user gesture, ignore error
    }
  };

  const handleScanResult = (decodedText: string) => {
    const cleanText = decodedText.trim();
    if (!cleanText) return;

    setLastScanned(cleanText);
    playBeep();

    // Stop scanning and trigger success callback
    stopScanner();
    setTimeout(() => {
      onScanSuccess(cleanText);
      onClose();
    }, 400);
  };

  // Start Camera scanner
  const startScanner = async (cameraId?: string) => {
    setErrorMessage('');
    try {
      if (!navigator?.mediaDevices?.getUserMedia) {
        setErrorMessage('Browser ini tidak mendukung akses kamera langsung. Silakan gunakan tab "Ketik / Scanner USB" atau "Upload Foto".');
        setActiveTab('manual');
        return;
      }

      if (!html5QrCodeRef.current) {
        html5QrCodeRef.current = new Html5Qrcode(readerElementId);
      }

      const scanner = html5QrCodeRef.current;
      if (scanner.isScanning) {
        try {
          await scanner.stop();
        } catch {
          // ignore stop error
        }
      }

      // Query available cameras safely
      let availableCameras = cameras;
      if (availableCameras.length === 0) {
        try {
          const devices = await Html5Qrcode.getCameras();
          if (devices && devices.length > 0) {
            availableCameras = devices;
            setCameras(devices);
          }
        } catch (camListErr) {
          console.warn('Could not enumerate camera devices:', camListErr);
        }
      }

      let deviceConfig: string | { facingMode: string } = { facingMode: 'environment' };

      if (cameraId) {
        deviceConfig = cameraId;
      } else if (selectedCameraId) {
        deviceConfig = selectedCameraId;
      } else if (availableCameras.length > 0) {
        const backCam = availableCameras.find(
          (d) =>
            d.label.toLowerCase().includes('back') ||
            d.label.toLowerCase().includes('rear') ||
            d.label.toLowerCase().includes('belakang')
        );
        const chosen = backCam ? backCam.id : availableCameras[0].id;
        setSelectedCameraId(chosen);
        deviceConfig = chosen;
      }

      const scanConfig = {
        fps: 15,
        qrbox: { width: 280, height: 160 },
        aspectRatio: 1.333,
      };

      try {
        await scanner.start(
          deviceConfig,
          scanConfig,
          (decodedText) => {
            handleScanResult(decodedText);
          },
          () => {
            // frame error callback - silent
          }
        );
        setIsScanning(true);
      } catch (firstStartErr: unknown) {
        // If back camera / specific config failed, try user facing mode or default
        console.warn('First scanner start attempt failed, trying fallback camera config:', firstStartErr);
        try {
          await scanner.start(
            { facingMode: 'user' },
            scanConfig,
            (decodedText) => {
              handleScanResult(decodedText);
            },
            () => {}
          );
          setIsScanning(true);
        } catch (fallbackErr: unknown) {
          throw fallbackErr; // Rethrow to main error handler
        }
      }
    } catch (err: unknown) {
      console.warn('Camera scanner initialization notice:', err);
      const msg = err instanceof Error ? err.message : String(err);
      if (
        msg.includes('Permission') ||
        msg.includes('NotAllowedError') ||
        msg.includes('Permission denied')
      ) {
        setErrorMessage('Izin akses kamera belum diaktifkan di browser. Anda dapat mengizinkan akses kamera atau gunakan tab "Upload Foto" / "Ketik Barcode".');
      } else if (
        msg.includes('not found') ||
        msg.includes('NotFoundError') ||
        msg.includes('DevicesNotFoundError') ||
        msg.includes('OverconstrainedError') ||
        msg.includes('Requested device not found')
      ) {
        setErrorMessage('Kamera tidak terdeteksi pada perangkat ini. Beralih otomatis ke tab "Ketik / Scanner USB".');
        setActiveTab('manual');
      } else {
        setErrorMessage('Kamera tidak dapat diakses (' + msg + '). Anda dapat menggunakan tab "Upload Foto" atau "Ketik / Scanner USB".');
        setActiveTab('manual');
      }
      setIsScanning(false);
    }
  };

  const stopScanner = async () => {
    try {
      if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
        await html5QrCodeRef.current.stop();
      }
    } catch (err) {
      console.warn('Error stopping scanner:', err);
    }
    setIsScanning(false);
  };

  // Switch Camera device
  const handleCameraChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newId = e.target.value;
    setSelectedCameraId(newId);
    if (activeTab === 'camera') {
      stopScanner().then(() => {
        startScanner(newId);
      });
    }
  };

  // Handle image file upload for scanning
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];

    try {
      setErrorMessage('');
      const html5QrCode = new Html5Qrcode('file-scanner-temp');
      const decodedResult = await html5QrCode.scanFile(file, true);
      if (decodedResult) {
        handleScanResult(decodedResult);
      }
      html5QrCode.clear();
    } catch {
      setErrorMessage('Barcode tidak terdeteksi pada gambar yang diunggah. Pastikan gambar jelas dan terang.');
    }
  };

  // Handle manual submit
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualInput.trim()) return;
    handleScanResult(manualInput.trim());
  };

  useEffect(() => {
    if (isOpen && activeTab === 'camera') {
      const timer = setTimeout(() => {
        startScanner();
      }, 300);
      return () => {
        clearTimeout(timer);
        stopScanner();
      };
    } else {
      stopScanner();
    }
  }, [isOpen, activeTab]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-[#161618] rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-[#2A2A30] flex flex-col max-h-[92vh] text-[#E0E0E0]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F27D26] flex items-center justify-center text-white shadow-md shadow-[#F27D26]/30">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg leading-tight text-white">{title}</h3>
              <p className="text-xs text-neutral-400">{subtitle}</p>
            </div>
          </div>
          <button
            onClick={() => {
              stopScanner();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switchers */}
        <div className="flex border-b border-[#26262B] bg-[#141416] text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('camera')}
            className={`flex-1 py-3 px-2 flex items-center justify-center gap-2 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'camera'
                ? 'border-[#F27D26] text-[#F27D26] bg-[#1A1A1E]'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Camera className="w-4 h-4" />
            Kamera Langsung
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('upload')}
            className={`flex-1 py-3 px-2 flex items-center justify-center gap-2 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'upload'
                ? 'border-[#F27D26] text-[#F27D26] bg-[#1A1A1E]'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Upload className="w-4 h-4" />
            Upload Foto
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('manual')}
            className={`flex-1 py-3 px-2 flex items-center justify-center gap-2 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'manual'
                ? 'border-[#F27D26] text-[#F27D26] bg-[#1A1A1E]'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Keyboard className="w-4 h-4" />
            Ketik / Scanner USB
          </button>
        </div>

        {/* Body content */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 flex flex-col items-center justify-center">
          {/* CAMERA TAB */}
          {activeTab === 'camera' && (
            <div className="w-full flex flex-col items-center">
              {/* Camera selection & controls */}
              {cameras.length > 1 && (
                <div className="w-full mb-3 flex items-center gap-2">
                  <label className="text-xs font-medium text-neutral-300 whitespace-nowrap">Pilih Kamera:</label>
                  <select
                    value={selectedCameraId}
                    onChange={handleCameraChange}
                    className="flex-1 text-xs bg-[#121214] border border-[#2B2B32] text-neutral-200 rounded-lg p-2 focus:border-[#F27D26] focus:outline-hidden"
                  >
                    {cameras.map((c) => (
                      <option key={c.id} value={c.id} className="bg-[#161618] text-neutral-200">
                        {c.label || `Kamera ${c.id}`}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={() => {
                      stopScanner().then(() => startScanner());
                    }}
                    className="p-2 text-neutral-400 hover:text-[#F27D26] bg-[#121214] rounded-lg border border-[#2B2B32] transition-colors"
                    title="Muat Ulang Kamera"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Viewport container */}
              <div className="relative w-full max-w-[380px] aspect-[4/3] bg-black rounded-xl overflow-hidden shadow-inner border-2 border-[#2B2B32] flex items-center justify-center">
                <div id={readerElementId} className="w-full h-full object-cover"></div>

                {/* Laser animation indicator overlay */}
                {isScanning && (
                  <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
                    <div className="w-64 h-36 border-2 border-[#F27D26]/80 rounded-xl relative overflow-hidden shadow-2xl">
                      {/* Corner marks */}
                      <div className="absolute top-0 left-0 w-4 h-4 border-t-4 border-l-4 border-[#F27D26]"></div>
                      <div className="absolute top-0 right-0 w-4 h-4 border-t-4 border-r-4 border-[#F27D26]"></div>
                      <div className="absolute bottom-0 left-0 w-4 h-4 border-b-4 border-l-4 border-[#F27D26]"></div>
                      <div className="absolute bottom-0 right-0 w-4 h-4 border-b-4 border-r-4 border-[#F27D26]"></div>

                      {/* Moving red/orange laser line */}
                      <div className="w-full h-0.5 bg-[#F27D26] shadow-[0_0_10px_#F27D26] animate-bounce absolute top-1/2 -translate-y-1/2"></div>
                    </div>
                    <span className="text-[11px] text-white/90 bg-black/80 px-3 py-1 rounded-full mt-3 font-medium tracking-wide border border-white/10">
                      Posisikan barcode di dalam kotak
                    </span>
                  </div>
                )}
              </div>

              {lastScanned && (
                <div className="mt-3 flex items-center gap-2 text-xs font-bold text-emerald-300 bg-emerald-950/60 px-3 py-1.5 rounded-lg border border-emerald-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Terdeteksi: <span className="font-mono text-white">{lastScanned}</span>
                </div>
              )}
            </div>
          )}

          {/* UPLOAD TAB */}
          {activeTab === 'upload' && (
            <div className="w-full flex flex-col items-center py-4">
              <div id="file-scanner-temp" className="hidden"></div>
              <label
                htmlFor="barcode-file-input"
                className="w-full max-w-sm border-2 border-dashed border-[#2E2E36] hover:border-[#F27D26] bg-[#121214] hover:bg-[#18181C] rounded-2xl p-8 flex flex-col items-center justify-center cursor-pointer transition-colors text-center"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#F27D26]/15 text-[#F27D26] border border-[#F27D26]/30 flex items-center justify-center mb-3 shadow-xs">
                  <Upload className="w-7 h-7" />
                </div>
                <span className="font-bold text-sm text-neutral-100 mb-1">Pilih atau Seret Foto Barcode</span>
                <span className="text-xs text-neutral-400 max-w-xs">Mendukung format JPG, PNG, WEBP dari kamera ponsel atau galeri</span>
                <input
                  id="barcode-file-input"
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          )}

          {/* MANUAL / USB SCANNER TAB */}
          {activeTab === 'manual' && (
            <form onSubmit={handleManualSubmit} className="w-full max-w-sm py-4">
              <div className="mb-4">
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-2">
                  Masukkan SKU ID atau Barcode
                </label>
                <input
                  type="text"
                  value={manualInput}
                  onChange={(e) => setManualInput(e.target.value)}
                  placeholder="Contoh: KPCM-30S-HTM-L-PDK"
                  autoFocus
                  className="w-full p-3 font-mono text-sm border-2 border-[#2E2E36] rounded-xl focus:border-[#F27D26] focus:outline-hidden bg-[#0F0F10] text-neutral-100 placeholder-neutral-600"
                />
                <p className="text-[11px] text-neutral-400 mt-2 leading-relaxed">
                  💡 <em>Jika Anda menggunakan barcode scanner USB / Bluetooth, arahkan scanner ke barcode dan otomatis terinput.</em>
                </p>
              </div>
              <button
                type="submit"
                disabled={!manualInput.trim()}
                className="w-full py-3 bg-[#F27D26] hover:bg-[#e06d1a] disabled:opacity-40 text-white font-bold text-sm rounded-xl shadow-md shadow-[#F27D26]/20 transition-colors cursor-pointer"
              >
                Terapkan Barcode
              </button>
            </form>
          )}

          {/* Error Message */}
          {errorMessage && (
            <div className="mt-3 w-full p-3 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-300 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-400" />
              <span className="leading-relaxed">{errorMessage}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 bg-[#121214] border-t border-[#24242A] flex items-center justify-between">
          <span className="text-[11px] text-neutral-500">Auto-detect Code-128 & QR Code</span>
          <button
            type="button"
            onClick={() => {
              stopScanner();
              onClose();
            }}
            className="px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-neutral-200 hover:bg-[#1E1E24] rounded-lg transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
