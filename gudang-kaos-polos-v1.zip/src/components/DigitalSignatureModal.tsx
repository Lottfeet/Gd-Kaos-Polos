import React, { useEffect, useRef, useState } from 'react';
import { PenTool, RotateCcw, Check, X, Type, Sparkles, ShieldCheck, Stamp } from 'lucide-react';
import { SignatureData, AppSystemSettings } from '../types';

interface DigitalSignatureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveSignature: (signature: SignatureData) => void;
  title?: string;
  defaultSignerName?: string;
  roleLabel?: string;
  settings?: AppSystemSettings;
}

export const DigitalSignatureModal: React.FC<DigitalSignatureModalProps> = ({
  isOpen,
  onClose,
  onSaveSignature,
  title = 'Tanda Tangan Digital Pengesahan',
  defaultSignerName = '',
  roleLabel = 'Pihak yang Mengesahkan',
  settings,
}) => {
  const [mode, setMode] = useState<'draw' | 'type' | 'stamp'>('draw');
  const [signerName, setSignerName] = useState(defaultSignerName);
  const [inkColor, setInkColor] = useState<'#1e3a8a' | '#0f172a' | '#2563eb'>('#1e3a8a');
  const [strokeWidth, setStrokeWidth] = useState<number>(2.5);
  const [isEmpty, setIsEmpty] = useState<boolean>(true);
  const [strokeHistory, setStrokeHistory] = useState<ImageData[]>([]);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isDrawingRef = useRef<boolean>(false);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);

  useEffect(() => {
    if (isOpen) {
      setSignerName(defaultSignerName);
      setIsEmpty(true);
      setStrokeHistory([]);
      // Always default to 'draw' mode for a fresh, clean canvas slate
      setMode('draw');
      setTimeout(() => {
        initCanvas();
      }, 150);
    }
  }, [isOpen, defaultSignerName, settings]);

  const initCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * 2;
    canvas.height = rect.height * 2;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.scale(2, 2);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    clearCanvas();
  };

  const getCanvasCoordinates = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();

    if ('touches' in e) {
      const touch = e.touches[0];
      return {
        x: touch.clientX - rect.left,
        y: touch.clientY - rect.top,
      };
    } else {
      return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      };
    }
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Save current state for undo
    const currentState = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setStrokeHistory((prev) => [...prev.slice(-10), currentState]);

    isDrawingRef.current = true;
    const point = getCanvasCoordinates(e);
    lastPointRef.current = point;

    ctx.beginPath();
    ctx.strokeStyle = inkColor;
    ctx.lineWidth = strokeWidth;
    ctx.moveTo(point.x, point.y);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    e.preventDefault();

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const currentPoint = getCanvasCoordinates(e);
    if (!lastPointRef.current) {
      lastPointRef.current = currentPoint;
      return;
    }

    ctx.beginPath();
    ctx.strokeStyle = inkColor;
    ctx.lineWidth = strokeWidth;
    ctx.moveTo(lastPointRef.current.x, lastPointRef.current.y);
    ctx.lineTo(currentPoint.x, currentPoint.y);
    ctx.stroke();

    lastPointRef.current = currentPoint;
    setIsEmpty(false);
  };

  const stopDrawing = () => {
    if (isDrawingRef.current) {
      isDrawingRef.current = false;
      lastPointRef.current = null;
    }
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setIsEmpty(true);
    setStrokeHistory([]);
  };

  const handleUndo = () => {
    const canvas = canvasRef.current;
    if (!canvas || strokeHistory.length === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const prevHistory = [...strokeHistory];
    const previousState = prevHistory.pop();
    setStrokeHistory(prevHistory);

    if (previousState) {
      ctx.putImageData(previousState, 0, 0);
      if (prevHistory.length === 0) {
        setIsEmpty(true);
      }
    }
  };

  const renderTypedSignatureToCanvas = (): string => {
    const canvas = document.createElement('canvas');
    canvas.width = 400;
    canvas.height = 160;
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';

    ctx.fillStyle = 'transparent';
    ctx.fillRect(0, 0, 400, 160);

    ctx.font = 'italic 44px "Brush Script MT", "Caveat", "Segoe Script", cursive';
    ctx.fillStyle = inkColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(signerName || 'Tanda Tangan', 200, 80);

    // Decorative flourish line underneath
    ctx.beginPath();
    ctx.strokeStyle = inkColor;
    ctx.lineWidth = 2;
    ctx.moveTo(80, 115);
    ctx.bezierCurveTo(150, 125, 250, 105, 320, 120);
    ctx.stroke();

    return canvas.toDataURL('image/png');
  };

  const handleSave = () => {
    if (!signerName.trim() && mode !== 'stamp') {
      alert('Mohon isi nama penandatangan.');
      return;
    }

    let finalDataUrl = '';

    if (mode === 'draw') {
      const canvas = canvasRef.current;
      if (!canvas || isEmpty) {
        alert('Mohon bubuhkan tanda tangan pada area kanvas terlebih dahulu.');
        return;
      }
      finalDataUrl = canvas.toDataURL('image/png');
    } else if (mode === 'stamp') {
      if (!settings?.stampUrl) {
        alert('Stempel resmi toko belum diunggah di Pengaturan Sistem.');
        return;
      }
      finalDataUrl = settings.stampUrl;
    } else {
      finalDataUrl = renderTypedSignatureToCanvas();
    }

    const effectiveName =
      mode === 'stamp'
        ? signerName.trim() || settings?.brandName || 'Stempel Resmi Toko'
        : signerName.trim();

    const sigObj: SignatureData = {
      name: effectiveName,
      roleTitle: roleLabel,
      imageDataUrl: finalDataUrl,
      signedAt: new Date().toISOString(),
    };

    onSaveSignature(sigObj);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-[#161618] rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden border border-[#2A2A30] flex flex-col text-[#E0E0E0]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F27D26] flex items-center justify-center text-white shadow-md shadow-[#F27D26]/30">
              <PenTool className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg leading-tight text-white">{title}</h3>
              <p className="text-xs text-neutral-400">Pengesahan dokumen resmi divisi gudang</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 space-y-4">
          {/* Signer Name Input */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
              Nama Penandatangan ({roleLabel}) *
            </label>
            <input
              type="text"
              value={signerName}
              onChange={(e) => setSignerName(e.target.value)}
              placeholder="Contoh: Admin Gudang Utama / Bpk. Hendra"
              className="w-full p-2.5 text-sm bg-[#0F0F10] border border-[#2B2B32] rounded-xl focus:border-[#F27D26] focus:outline-hidden font-medium text-neutral-100 placeholder-neutral-600"
            />
          </div>

          {/* Mode Switcher */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#26262B] pb-2">
            <div className="flex flex-wrap items-center gap-1.5 bg-[#121214] p-1 rounded-xl border border-[#26262C]">
              <button
                type="button"
                onClick={() => setMode('draw')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  mode === 'draw' ? 'bg-[#1E1E24] text-[#F27D26] shadow-xs' : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <PenTool className="w-3.5 h-3.5" /> Goresan Tangan
              </button>
              <button
                type="button"
                onClick={() => setMode('type')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  mode === 'type' ? 'bg-[#1E1E24] text-[#F27D26] shadow-xs' : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Type className="w-3.5 h-3.5" /> Gaya Teks
              </button>
              {settings?.stampUrl ? (
                <button
                  type="button"
                  onClick={() => setMode('stamp')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    mode === 'stamp' ? 'bg-purple-950/80 text-purple-300 border border-purple-800/80 shadow-xs' : 'text-neutral-400 hover:text-purple-300'
                  }`}
                >
                  <Stamp className="w-3.5 h-3.5" /> Cap Stempel Toko
                </button>
              ) : null}
            </div>

            {/* Ink Color Selector (for draw & type modes) */}
            {mode !== 'stamp' && (
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] font-semibold text-neutral-400 mr-1">Tinta:</span>
                <button
                  type="button"
                  onClick={() => setInkColor('#1e3a8a')}
                  className={`w-6 h-6 rounded-full bg-[#1e3a8a] border-2 transition-transform cursor-pointer ${
                    inkColor === '#1e3a8a' ? 'scale-110 border-blue-400 ring-2 ring-blue-500/20' : 'border-transparent'
                  }`}
                  title="Biru Navy Formal"
                />
                <button
                  type="button"
                  onClick={() => setInkColor('#0f172a')}
                  className={`w-6 h-6 rounded-full bg-[#0f172a] border-2 transition-transform cursor-pointer ${
                    inkColor === '#0f172a' ? 'scale-110 border-neutral-400 ring-2 ring-neutral-500/20' : 'border-transparent'
                  }`}
                  title="Hitam Klasik"
                />
                <button
                  type="button"
                  onClick={() => setInkColor('#2563eb')}
                  className={`w-6 h-6 rounded-full bg-[#2563eb] border-2 transition-transform cursor-pointer ${
                    inkColor === '#2563eb' ? 'scale-110 border-blue-300 ring-2 ring-blue-400/20' : 'border-transparent'
                  }`}
                  title="Biru Terang"
                />
              </div>
            )}
          </div>

          {/* DRAW MODE CANVAS */}
          {mode === 'draw' && (
            <div className="space-y-2">
              <div className="relative border-2 border-dashed border-[#2E2E36] rounded-xl bg-[#101012] overflow-hidden shadow-inner touch-none">
                <canvas
                  ref={canvasRef}
                  onMouseDown={startDrawing}
                  onMouseMove={draw}
                  onMouseUp={stopDrawing}
                  onMouseLeave={stopDrawing}
                  onTouchStart={startDrawing}
                  onTouchMove={draw}
                  onTouchEnd={stopDrawing}
                  className="w-full h-44 cursor-crosshair block"
                />

                {isEmpty && (
                  <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center text-neutral-500">
                    <PenTool className="w-6 h-6 mb-1 opacity-50" />
                    <span className="text-xs font-medium">Bubuhkan tanda tangan di sini (layar sentuh / mouse)</span>
                  </div>
                )}

                {/* Baseline Guide */}
                <div className="absolute bottom-6 left-6 right-6 border-b border-[#25252A] pointer-events-none"></div>
              </div>

              {/* Canvas Controls */}
              <div className="flex items-center justify-between text-xs pt-1">
                <div className="flex items-center gap-2">
                  <span className="text-neutral-400">Ketebalan:</span>
                  <button
                    type="button"
                    onClick={() => setStrokeWidth(1.8)}
                    className={`px-2 py-0.5 rounded-md border cursor-pointer ${
                      strokeWidth === 1.8 ? 'bg-[#222228] border-[#F27D26] text-[#F27D26] font-bold' : 'border-[#2B2B32] text-neutral-400'
                    }`}
                  >
                    Halus
                  </button>
                  <button
                    type="button"
                    onClick={() => setStrokeWidth(2.6)}
                    className={`px-2 py-0.5 rounded-md border cursor-pointer ${
                      strokeWidth === 2.6 ? 'bg-[#222228] border-[#F27D26] text-[#F27D26] font-bold' : 'border-[#2B2B32] text-neutral-400'
                    }`}
                  >
                    Sedang
                  </button>
                  <button
                    type="button"
                    onClick={() => setStrokeWidth(3.8)}
                    className={`px-2 py-0.5 rounded-md border cursor-pointer ${
                      strokeWidth === 3.8 ? 'bg-[#222228] border-[#F27D26] text-[#F27D26] font-bold' : 'border-[#2B2B32] text-neutral-400'
                    }`}
                  >
                    Tebal
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleUndo}
                    disabled={strokeHistory.length === 0}
                    className="p-1.5 text-neutral-400 hover:text-neutral-200 disabled:opacity-30 rounded-lg hover:bg-[#1E1E22] flex items-center gap-1 cursor-pointer"
                    title="Urungkan"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Undo
                  </button>
                  <button
                    type="button"
                    onClick={clearCanvas}
                    className="px-2.5 py-1 text-rose-400 hover:bg-rose-950/40 rounded-lg border border-rose-800/60 font-semibold cursor-pointer"
                  >
                    Hapus
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TYPE MODE PREVIEW */}
          {mode === 'type' && (
            <div className="border-2 border-[#2E2E36] rounded-xl bg-[#101012] p-6 flex flex-col items-center justify-center min-h-[176px]">
              <div
                style={{ color: inkColor }}
                className="text-4xl italic font-serif text-center select-none py-3 tracking-wide"
              >
                {signerName || 'Tanda Tangan'}
              </div>
              <div className="w-48 h-0.5 bg-[#2E2E36] mt-2"></div>
              <span className="text-[11px] text-neutral-400 mt-2 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-[#F27D26]" />
                Format pengesahan tanda tangan digital otomatis
              </span>
            </div>
          )}

          {/* STAMP MODE PREVIEW */}
          {mode === 'stamp' && settings?.stampUrl && (
            <div className="border-2 border-purple-800/60 rounded-xl bg-[#101012] p-6 flex flex-col items-center justify-center min-h-[176px] space-y-3">
              <div className="w-32 h-32 bg-white rounded-xl p-2 shadow-lg border border-purple-500/30 flex items-center justify-center overflow-hidden">
                <img
                  src={settings.stampUrl}
                  alt="Stempel Resmi Toko"
                  className="max-h-full max-w-full object-contain rotate-[-4deg]"
                />
              </div>
              <div className="text-center">
                <span className="text-xs font-bold text-white block">
                  {settings.brandName || 'Stempel Resmi Perusahaan/Toko'}
                </span>
                <span className="text-[11px] text-purple-300 flex items-center justify-center gap-1 mt-0.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
                  Menggantikan tanda tangan manual dengan cap stempel sah
                </span>
              </div>
            </div>
          )}

          <div className="bg-blue-950/40 border border-blue-800/60 rounded-xl p-3 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
            <p className="text-[11px] text-blue-200 leading-relaxed">
              Tanda tangan digital ini akan disematkan langsung pada dokumen resmi (Surat Jalan / Form Order / Nota Penjualan)
              beserta cap tanggal dan waktu verifikasi secara otomatis.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#121214] border-t border-[#24242A] flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 text-xs font-bold text-neutral-400 hover:text-neutral-200 hover:bg-[#1E1E24] rounded-xl transition-colors cursor-pointer"
          >
            Batal
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2.5 bg-[#F27D26] hover:bg-[#e06d1a] text-white text-xs font-bold rounded-xl shadow-md shadow-[#F27D26]/20 flex items-center gap-2 transition-colors cursor-pointer"
          >
            <Check className="w-4 h-4" /> Sahkan Tanda Tangan
          </button>
        </div>
      </div>
    </div>
  );
};
