import React, { useState } from 'react';
import { Code, Copy, Check, X, ExternalLink, Terminal } from 'lucide-react';

interface GasCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GasCodeModal: React.FC<GasCodeModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'codegs' | 'indexhtml'>('codegs');
  const [copied, setCopied] = useState<boolean>(false);

  const codeGsContent = `// ============================================================
// Code.gs — Backend Google Apps Script (Versi 2.0.0)
// Inventori Kaos Polos | Gudang Utama & Toko + E-Signature + Barcode
// ============================================================

const SPREADSHEET_ID = '1Z7OJ_QHBkjyP6I-cuuAHXJ6csj53ivB2k4EE_5KYLnQ';

const SHEET_USERS          = 'USERS';
const SHEET_MASTER_PRODUK  = 'MASTER_PRODUK';
const SHEET_MASTER_GUDANG  = 'MASTER_GUDANG';
const SHEET_LOG_TRANSAKSI  = 'LOG_TRANSAKSI';
const SHEET_INVENTORY      = 'INVENTORY';

function doGet(e) {
  const template = HtmlService.createTemplateFromFile('index');
  return template.evaluate()
    .setTitle('Inventori Kaos Polos - Gudang & E-Signature')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1.0');
}

function getSpreadsheet() {
  return SpreadsheetApp.openById(SPREADSHEET_ID);
}

function getSheet(sheetName) {
  return getSpreadsheet().getSheetByName(sheetName);
}

function sheetToObjects(sheetName) {
  const sheet   = getSheet(sheetName);
  if (!sheet) return [];
  const allData = sheet.getDataRange().getValues();
  if (allData.length < 2) return [];

  const headers = allData[0];
  const rows    = allData.slice(1);

  return rows.map(row => {
    const obj = {};
    headers.forEach((header, index) => {
      obj[header] = row[index] instanceof Date ? row[index].toISOString() : row[index];
    });
    return obj;
  });
}

function generateTxId() {
  const sheet   = getSheet(SHEET_LOG_TRANSAKSI);
  const lastRow = sheet ? sheet.getLastRow() : 1;
  return 'TX' + String(lastRow).padStart(4, '0');
}

function login(username, password) {
  const users = sheetToObjects(SHEET_USERS);
  const matchedUser = users.find(u => u.Username === username && u.Password === password);
  if (matchedUser) {
    return {
      success    : true,
      username   : matchedUser.Username,
      role       : matchedUser.Role,
      siteAccess : matchedUser.SiteAccess
    };
  }
  return { success : false, message : 'Username atau password salah.' };
}

function getInventory() {
  const inventoryData = sheetToObjects(SHEET_INVENTORY);
  const produkData    = sheetToObjects(SHEET_MASTER_PRODUK);
  const produkMap = {};
  produkData.forEach(p => { produkMap[p.SKU_ID] = p; });

  return inventoryData.map(inv => {
    const produk = produkMap[inv.SKU_ID] || {};
    return {
      GUDANG_ID     : inv.GUDANG_ID,
      SKU_ID        : inv.SKU_ID,
      NAMA_PRODUK   : inv.NAMA_PRODUK,
      JUMLAH_READY  : inv.JUMLAH_READY,
      REORDER_LEVEL : inv.REORDER_LEVEL,
      REORDER       : inv.REORDER,
      ORDER_DATE    : inv.ORDER_DATE,
      WARNA         : produk.WARNA || '',
      UKURAN        : produk.UKURAN || '',
      KATEGORI      : produk.KATEGORI || '',
      JENIS_LENGAN  : produk.JENIS_LENGAN || ''
    };
  });
}

function getMasterProduk() {
  return sheetToObjects(SHEET_MASTER_PRODUK);
}

function getMasterGudang() {
  return sheetToObjects(SHEET_MASTER_GUDANG);
}

function getLogTransaksi(gudangId) {
  const allLogs = sheetToObjects(SHEET_LOG_TRANSAKSI);
  if (gudangId && gudangId !== 'ALL') {
    return allLogs.filter(log => log.GUDANG_ID === gudangId);
  }
  return allLogs;
}

function addTransaksi(transaksiData) {
  if (!transaksiData.SKU_ID || !transaksiData.GUDANG_ID || !transaksiData.JUMLAH || !transaksiData.TIPE_TRANSAKSI) {
    return { success: false, message: 'Field wajib belum lengkap.' };
  }
  const jumlahInput = Math.abs(Number(transaksiData.JUMLAH));
  const jumlahDelta = transaksiData.TIPE_TRANSAKSI === 'MASUK' ? jumlahInput : -jumlahInput;

  const updateResult = updateStokInventory(
    transaksiData.SKU_ID,
    transaksiData.GUDANG_ID,
    jumlahDelta,
    transaksiData.USERNAME
  );
  if (!updateResult.success) return updateResult;

  const logSheet = getSheet(SHEET_LOG_TRANSAKSI);
  const txId = generateTxId();
  logSheet.appendRow([
    new Date(),
    txId,
    transaksiData.SKU_ID,
    transaksiData.GUDANG_ID,
    jumlahDelta,
    transaksiData.TIPE_TRANSAKSI,
    transaksiData.USERNAME,
    transaksiData.KETERANGAN || ''
  ]);

  return { success: true, message: \`Transaksi \${txId} berhasil dicatat.\`, txId: txId, stokBaru: updateResult.stokBaru };
}

function updateStokInventory(skuId, gudangId, delta, username) {
  const sheet = getSheet(SHEET_INVENTORY);
  const allData = sheet.getDataRange().getValues();

  for (let i = 1; i < allData.length; i++) {
    if (String(allData[i][0]).trim() === gudangId && String(allData[i][1]).trim() === skuId) {
      const stokLama = Number(allData[i][3]) || 0;
      const reorderLevel = Number(allData[i][4]) || 10;
      const stokBaru = stokLama + delta;
      if (stokBaru < 0) {
        return { success: false, message: \`Stok tidak mencukupi (tersedia: \${stokLama})\` };
      }
      sheet.getRange(i + 1, 4).setValue(stokBaru);
      const statusReorder = stokBaru <= reorderLevel ? 'YES' : 'NO';
      sheet.getRange(i + 1, 6).setValue(statusReorder);
      sheet.getRange(i + 1, 7).setValue(statusReorder === 'YES' ? new Date() : '');
      return { success: true, stokBaru: stokBaru };
    }
  }

  const stokAwal = Math.max(0, delta);
  sheet.appendRow([gudangId, skuId, skuId, stokAwal, 10, stokAwal <= 10 ? 'YES' : 'NO', stokAwal <= 10 ? new Date() : '']);
  return { success: true, stokBaru: stokAwal };
}

function addOrderStok(orderData) {
  if (!orderData.gudangId || !orderData.username || !orderData.items || orderData.items.length === 0) {
    return { success: false, message: 'Data order belum lengkap.' };
  }
  const logSheet = getSheet(SHEET_LOG_TRANSAKSI);
  const timestamp = new Date();
  const txIds = [];

  orderData.items.forEach(item => {
    if (!item.SKU_ID || !item.jumlah) return;
    const txId = generateTxId();
    const jumlah = Math.abs(Number(item.jumlah));
    const keterangan = [\`NO.ORDER:\${orderData.nomorOrder}\`, orderData.supplier ? \`SUPPLIER:\${orderData.supplier}\` : '', item.keterangan || '', orderData.catatan || ''].filter(Boolean).join(' | ');

    logSheet.appendRow([timestamp, txId, item.SKU_ID, orderData.gudangId, jumlah, 'ORDER', orderData.username, keterangan]);
    txIds.push(txId);
  });

  return { success: true, message: \`Order \${orderData.nomorOrder} berhasil disimpan (\${txIds.length} item).\`, nomorOrder: orderData.nomorOrder, totalItem: txIds.length };
}

function addSuratJalan(sjData) {
  if (!sjData.gudangId || !sjData.username || !sjData.tujuan || !sjData.items || sjData.items.length === 0) {
    return { success: false, message: 'Data surat jalan belum lengkap.' };
  }
  const logSheet = getSheet(SHEET_LOG_TRANSAKSI);
  const timestamp = new Date();
  let totalItem = 0;

  sjData.items.forEach(item => {
    if (!item.SKU_ID || !item.jumlah) return;
    const jumlah = Math.abs(Number(item.jumlah));
    updateStokInventory(item.SKU_ID, sjData.gudangId, -jumlah, sjData.username);
    const txId = generateTxId();
    const keterangan = [\`NO.SJ:\${sjData.nomorSJ}\`, \`TUJUAN:\${sjData.tujuan}\`, sjData.penerima ? \`PENERIMA:\${sjData.penerima}\` : '', sjData.driver ? \`DRIVER:\${sjData.driver}\` : '', sjData.kendaraan ? \`KENDARAAN:\${sjData.kendaraan}\` : '', item.keterangan || '', sjData.catatan || ''].filter(Boolean).join(' | ');

    logSheet.appendRow([timestamp, txId, item.SKU_ID, sjData.gudangId, -jumlah, 'KELUAR', sjData.username, keterangan]);
    totalItem++;
  });

  return { success: true, message: \`Surat Jalan \${sjData.nomorSJ} tersimpan (\${totalItem} item dipotong).\`, nomorSJ: sjData.nomorSJ, totalItem: totalItem };
}

function addSale(saleData) {
  if (!saleData.gudangId || !saleData.username || !saleData.items || saleData.items.length === 0) {
    return { success: false, message: 'Data penjualan belum lengkap.' };
  }
  const logSheet = getSheet(SHEET_LOG_TRANSAKSI);
  const timestamp = new Date();
  let totalItem = 0;

  saleData.items.forEach(item => {
    if (!item.SKU_ID || !item.jumlah) return;
    const jumlah = Math.abs(Number(item.jumlah));
    updateStokInventory(item.SKU_ID, saleData.gudangId, -jumlah, saleData.username);
    const txId = generateTxId();
    const keterangan = [\`NO.SALE:\${saleData.nomorSale}\`, saleData.pelanggan ? \`PELANGGAN:\${saleData.pelanggan}\` : '', saleData.kontak ? \`KONTAK:\${saleData.kontak}\` : '', saleData.metode ? \`BAYAR:\${saleData.metode}\` : '', item.keterangan || '', saleData.catatan || ''].filter(Boolean).join(' | ');

    logSheet.appendRow([timestamp, txId, item.SKU_ID, saleData.gudangId, -jumlah, 'SALE', saleData.username, keterangan]);
    totalItem++;
  });

  return { success: true, message: \`Sale \${saleData.nomorSale} tersimpan (\${totalItem} item dipotong).\`, nomorSale: saleData.nomorSale, totalItem: totalItem };
}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(codeGsContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-[#161618] rounded-2xl shadow-2xl w-full max-w-3xl overflow-hidden border border-[#2A2A30] flex flex-col max-h-[90vh] text-[#E0E0E0]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F27D26] flex items-center justify-center text-white shadow-md shadow-[#F27D26]/30">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg leading-tight text-white">Kode Sumber Google Apps Script (GAS)</h3>
              <p className="text-xs text-neutral-400">Salin kode ini ke editor script Google Spreadsheet Anda</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tabs & Toolbar */}
        <div className="p-3 bg-[#141416] border-b border-[#26262B] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('codegs')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'codegs' ? 'bg-[#1E1E24] text-[#F27D26] shadow-xs' : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              Code.gs (Backend)
            </button>
          </div>
          <button
            onClick={copyToClipboard}
            className="px-3.5 py-1.5 bg-[#F27D26] hover:bg-[#e06d1a] text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-300" /> Tersalin!
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" /> Salin Seluruh Kode
              </>
            )}
          </button>
        </div>

        {/* Code View Body */}
        <div className="p-4 overflow-y-auto flex-1 bg-[#0A0A0C] text-neutral-200 font-mono text-xs leading-relaxed border-y border-[#202024]">
          <pre className="whitespace-pre-wrap">{codeGsContent}</pre>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#121214] border-t border-[#24242A] flex items-center justify-between text-xs text-neutral-400">
          <span className="font-mono text-[11px]">Spreadsheet ID: 1Z7OJ_QHBkjyP6I-cuuAHXJ6csj53ivB2k4EE_5KYLnQ</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-[#1C1C20] hover:bg-[#28282E] font-bold rounded-xl text-neutral-300 transition-colors border border-[#2B2B32] cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
