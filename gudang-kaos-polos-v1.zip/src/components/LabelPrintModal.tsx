import React, { useEffect, useRef, useState } from 'react';
import { MasterProduk } from '../types';
import { getWarnaHex } from '../utils/tshirtSvg';
import { renderCodeToCanvas, generateCodeDataUrl, BarcodeFormat } from '../utils/codeRenderer';
import { Printer, X, Plus, Minus, Tag, QrCode, Barcode, Check } from 'lucide-react';

interface LabelPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: MasterProduk | null;
  barcodeFormat?: BarcodeFormat;
  brandName?: string;
  paperFormat?: 'A4_40_LABELS' | 'THERMAL_50X30' | 'THERMAL_40X20' | 'THERMAL_100X150';
}

export const LabelPrintModal: React.FC<LabelPrintModalProps> = ({
  isOpen,
  onClose,
  product,
  barcodeFormat: initialBarcodeFormat = 'CODE128',
  brandName = 'INVENTORI KAOS POLOS',
  paperFormat: initialPaperFormat = 'A4_40_LABELS',
}) => {
  const [qty, setQty] = useState<number>(6);
  const [selectedFormat, setSelectedFormat] = useState<BarcodeFormat>(initialBarcodeFormat);
  const [selectedPaper, setSelectedPaper] = useState(initialPaperFormat);
  const [isGenerating, setIsGenerating] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Sync format with props when opened
  useEffect(() => {
    if (isOpen) {
      setSelectedFormat(initialBarcodeFormat || 'CODE128');
      setSelectedPaper(initialPaperFormat || 'A4_40_LABELS');
    }
  }, [isOpen, initialBarcodeFormat, initialPaperFormat]);

  useEffect(() => {
    if (isOpen && product) {
      const timer = setTimeout(() => {
        renderAllCanvases();
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [isOpen, product, qty, selectedFormat]);

  const renderAllCanvases = async () => {
    if (!product) return;
    const barcodeVal = (product.BARCODE_ID || product.SKU_ID).toUpperCase();
    for (let i = 0; i < qty; i++) {
      const canvas = document.getElementById(`label-code-canvas-${i}`) as HTMLCanvasElement | null;
      if (canvas) {
        if (selectedFormat === 'QR_CODE') {
          await renderCodeToCanvas(canvas, barcodeVal, 'QR_CODE', { qrWidth: 68, qrMargin: 1 });
        } else {
          await renderCodeToCanvas(canvas, barcodeVal, 'CODE128', { barWidth: 1.3, height: 34, margin: 4 });
        }
      }
    }
  };

  const handlePrint = async () => {
    if (!product) return;
    setIsGenerating(true);

    const barcodeVal = (product.BARCODE_ID || product.SKU_ID).toUpperCase();

    // Generate high resolution image data URL for instant, reliable rendering in print window
    const codeImgUrl = await generateCodeDataUrl(
      barcodeVal,
      selectedFormat,
      selectedFormat === 'QR_CODE'
        ? { qrWidth: 160, qrMargin: 1 }
        : { barWidth: 1.8, height: 50, margin: 6 }
    );

    const isThermal = selectedPaper === 'THERMAL_50X30' || selectedPaper === 'THERMAL_40X20';
    const isQr = selectedFormat === 'QR_CODE';

    const cardHtml = `
      <div class="label-card ${isQr ? 'qr-layout' : 'barcode-layout'}">
        <div class="brand-title">${brandName}</div>
        <div class="product-name">${product.NAMA_PRODUK}</div>
        <div class="product-variant">${product.WARNA} • ${product.UKURAN} • ${product.JENIS_LENGAN || 'PENDEK'}</div>
        <div class="code-container">
          <img src="${codeImgUrl}" alt="${barcodeVal}" class="${isQr ? 'qr-img' : 'barcode-img'}" />
        </div>
        <div class="sku-code">${barcodeVal}</div>
      </div>
    `;

    const cardsHtml = Array.from({ length: qty }).map(() => cardHtml).join('');

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Cetak Label ${isQr ? 'QR Code' : 'Barcode'} - ${product.SKU_ID}</title>
          <meta charset="utf-8" />
          <style>
            @page {
              size: ${isThermal ? '58mm 40mm' : 'A4 portrait'};
              margin: ${isThermal ? '2mm' : '8mm'};
            }
            * { box-sizing: border-box; }
            body {
              margin: 0;
              padding: ${isThermal ? '2px' : '10px'};
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              background: #fff;
              color: #0f172a;
            }
            .no-print-bar {
              margin-bottom: 12px;
              padding: 10px 14px;
              background: #f1f5f9;
              border-radius: 8px;
              display: flex;
              justify-content: space-between;
              align-items: center;
              font-size: 13px;
              font-weight: bold;
            }
            .grid-container {
              display: grid;
              grid-template-columns: ${isThermal ? '1fr' : 'repeat(4, 1fr)'};
              gap: ${isThermal ? '4mm' : '5mm'};
            }
            .label-card {
              border: 1px dashed #94a3b8;
              border-radius: 6px;
              padding: 6px 8px;
              text-align: center;
              background: #fff;
              page-break-inside: avoid;
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              height: ${isThermal ? '125px' : '138px'};
            }
            .brand-title {
              font-size: 8px;
              font-weight: 800;
              text-transform: uppercase;
              color: #64748b;
              letter-spacing: 0.5px;
              margin-bottom: 2px;
            }
            .product-name {
              font-size: 11px;
              font-weight: 800;
              color: #0f172a;
              margin-bottom: 2px;
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
              max-width: 100%;
            }
            .product-variant {
              font-size: 9px;
              font-weight: 700;
              color: #334155;
              margin-bottom: 3px;
            }
            .code-container {
              display: flex;
              align-items: center;
              justify-content: center;
              margin: 2px 0;
            }
            .barcode-img {
              max-height: 38px;
              max-width: 95%;
              object-fit: contain;
            }
            .qr-img {
              width: 54px;
              height: 54px;
              object-fit: contain;
            }
            .sku-code {
              font-family: monospace;
              font-size: 9px;
              font-weight: 800;
              color: #0f172a;
              letter-spacing: 1px;
              margin-top: 1px;
            }
            @media print {
              .no-print-bar { display: none !important; }
              body { padding: 0; }
              .label-card { border: 1px solid #cbd5e1; }
            }
          </style>
        </head>
        <body>
          <div class="no-print-bar">
            <span>Lembar Cetak Label ${isQr ? 'QR Code 2D' : 'Barcode Code-128'} (${qty} Pcs) - ${product.SKU_ID}</span>
            <button onclick="window.print()" style="padding: 6px 16px; background: #7c3aed; color: #fff; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
              Cetak Sekarang
            </button>
          </div>
          <div class="grid-container">
            ${cardsHtml}
          </div>
          <script>
            window.onload = function() {
              setTimeout(function() { window.print(); }, 400);
            };
          </script>
        </body>
      </html>
    `;

    try {
      const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      const blobUrl = URL.createObjectURL(blob);
      let printWindow = window.open(blobUrl, '_blank');
      if (!printWindow) {
        printWindow = window.open('', '_blank');
        if (printWindow) {
          printWindow.document.open();
          printWindow.document.write(htmlContent);
          printWindow.document.close();
        } else {
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = `Label_${product.SKU_ID}.html`;
          document.body.appendChild(a);
          a.click();
          a.remove();
        }
      }
    } catch {
      window.print();
    }
    setIsGenerating(false);
  };

  if (!isOpen || !product) return null;

  const barcodeVal = (product.BARCODE_ID || product.SKU_ID).toUpperCase();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-1 sm:p-3 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-[#161618] rounded-2xl shadow-2xl w-full max-w-5xl 2xl:max-w-6xl overflow-hidden border border-[#2A2A30] flex flex-col max-h-[94vh] text-[#E0E0E0]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white shadow-md shadow-purple-600/30">
              {selectedFormat === 'QR_CODE' ? <QrCode className="w-5 h-5" /> : <Barcode className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg leading-tight text-white flex items-center gap-2">
                Cetak Label {selectedFormat === 'QR_CODE' ? 'QR Code 2D Matrix' : 'Barcode Code-128'}
              </h3>
              <p className="text-xs text-neutral-400">Siap tempel pada kemasan kaos atau rak gudang</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1" ref={containerRef}>
          {/* Selected Product Card */}
          <div className="p-3.5 bg-[#121214] border border-[#26262B] rounded-xl flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span
                className="w-5 h-5 rounded-full border border-white/20 shrink-0"
                style={{ backgroundColor: getWarnaHex(product.WARNA) }}
              />
              <div>
                <div className="font-bold text-sm text-neutral-100">{product.NAMA_PRODUK}</div>
                <div className="text-xs text-purple-400 font-mono font-semibold">{product.SKU_ID}</div>
                <div className="text-[11px] text-neutral-400">
                  {product.WARNA} • Ukuran {product.UKURAN} • Lengan {product.JENIS_LENGAN || 'PENDEK'}
                </div>
              </div>
            </div>

            {/* Quantity Stepper */}
            <div className="flex items-center gap-2 bg-[#0F0F10] px-3 py-1.5 rounded-xl border border-[#2B2B32] shadow-xs">
              <span className="text-xs font-semibold text-neutral-400">Jumlah:</span>
              <button
                type="button"
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                className="w-7 h-7 rounded-lg bg-[#1C1C20] hover:bg-[#28282E] flex items-center justify-center text-neutral-300 transition-colors cursor-pointer border border-[#2F2F36]"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <input
                type="number"
                min="1"
                max="60"
                value={qty}
                onChange={(e) => setQty(Math.min(60, Math.max(1, parseInt(e.target.value) || 1)))}
                className="w-12 text-center text-xs font-bold border border-[#2B2B32] bg-[#161618] text-neutral-100 rounded-md p-1 focus:outline-hidden"
              />
              <button
                type="button"
                onClick={() => setQty((q) => Math.min(60, q + 1))}
                className="w-7 h-7 rounded-lg bg-[#1C1C20] hover:bg-[#28282E] flex items-center justify-center text-neutral-300 transition-colors cursor-pointer border border-[#2F2F36]"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Quick Format & Layout Switcher */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Format Selector */}
            <div className="bg-[#121214] p-3 rounded-xl border border-[#24242A]">
              <label className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 block mb-2">
                Tipe Simbol Label:
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedFormat('CODE128')}
                  className={`px-2.5 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                    selectedFormat === 'CODE128'
                      ? 'bg-purple-950/70 border-purple-500 text-purple-200'
                      : 'bg-[#18181B] border-[#2A2A30] text-neutral-400 hover:text-white'
                  }`}
                >
                  <Barcode className="w-3.5 h-3.5" /> Code-128
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedFormat('QR_CODE')}
                  className={`px-2.5 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                    selectedFormat === 'QR_CODE'
                      ? 'bg-purple-950/70 border-purple-500 text-purple-200'
                      : 'bg-[#18181B] border-[#2A2A30] text-neutral-400 hover:text-white'
                  }`}
                >
                  <QrCode className="w-3.5 h-3.5" /> QR Code 2D
                </button>
              </div>
            </div>

            {/* Paper Size Selector */}
            <div className="bg-[#121214] p-3 rounded-xl border border-[#24242A]">
              <label className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 block mb-2">
                Ukuran Kertas:
              </label>
              <select
                value={selectedPaper}
                onChange={(e) => setSelectedPaper(e.target.value as any)}
                className="w-full p-2 bg-[#18181B] border border-[#2A2A30] rounded-lg text-xs font-bold text-neutral-200 focus:border-purple-500 focus:outline-hidden"
              >
                <option value="A4_40_LABELS">Kertas A4 (Grid 4x10 = 40 Label)</option>
                <option value="THERMAL_50X30">Printer Thermal Kasir (50 x 30 mm)</option>
                <option value="THERMAL_40X20">Printer Thermal Mini (40 x 20 mm)</option>
              </select>
            </div>
          </div>

          {/* Label Preview Grid */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                Pratinjau Label ({qty} Lembar - {selectedFormat === 'QR_CODE' ? 'QR Code 2D' : 'Barcode Code-128'})
              </span>
              <span className="text-[11px] text-purple-400 font-semibold">{brandName}</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-72 overflow-y-auto p-3 bg-[#0E0E10] rounded-xl border border-[#24242A]">
              {Array.from({ length: qty }).map((_, i) => (
                <div
                  key={i}
                  className="bg-white border border-slate-300 rounded-lg p-2.5 shadow-sm flex flex-col items-center justify-center text-center text-slate-900 min-h-[135px]"
                >
                  <div className="text-[8px] font-extrabold text-slate-500 uppercase tracking-widest leading-none mb-1">
                    {brandName}
                  </div>
                  <div className="text-[11px] font-bold text-slate-900 leading-tight truncate w-full mb-0.5">
                    {product.NAMA_PRODUK}
                  </div>
                  <div className="text-[9px] text-slate-600 font-semibold leading-none mb-1.5">
                    {product.WARNA} | {product.UKURAN} | {product.JENIS_LENGAN || 'PENDEK'}
                  </div>

                  <div className="my-1 flex items-center justify-center">
                    <canvas id={`label-code-canvas-${i}`} className="max-w-full block" />
                  </div>

                  <div className="text-[9px] font-mono text-slate-800 font-bold tracking-wider">{barcodeVal}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#121214] border-t border-[#24242A] flex items-center justify-between">
          <div className="text-xs text-neutral-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-purple-400"></span>
            Format Aktif: <strong>{selectedFormat === 'QR_CODE' ? 'QR Code 2D' : 'Code-128'}</strong>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-bold text-neutral-400 hover:text-neutral-200 hover:bg-[#1C1C20] rounded-xl transition-colors cursor-pointer"
            >
              Tutup
            </button>
            <button
              type="button"
              disabled={isGenerating}
              onClick={handlePrint}
              className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-md shadow-purple-600/30 flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              {isGenerating ? 'Menyiapkan Lembar...' : 'Cetak Label / Simpan PDF'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
