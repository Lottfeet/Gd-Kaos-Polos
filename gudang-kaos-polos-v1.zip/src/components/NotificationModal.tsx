import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Bell,
  CheckCircle2,
  AlertTriangle,
  ShoppingBag,
  Truck,
  Cloud,
  Layers,
  Trash2,
  X,
  Volume2,
  ShieldCheck,
  Package,
} from 'lucide-react';
import {
  PushNotificationService,
  PushNotificationItem,
} from '../services/notificationService';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  onShowToast,
}) => {
  const [notifications, setNotifications] = useState<PushNotificationItem[]>(() =>
    PushNotificationService.getHistory()
  );
  const [permission, setPermission] = useState<NotificationPermission>(() =>
    PushNotificationService.getPermission()
  );

  useEffect(() => {
    const unsub = PushNotificationService.subscribe((items) => {
      setNotifications([...items]);
      setPermission(PushNotificationService.getPermission());
    });
    return () => unsub();
  }, []);

  // Keyboard shortcut: Escape to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const handleRequestPermission = async () => {
    const perm = await PushNotificationService.requestPermission();
    setPermission(perm);
    if (perm === 'granted') {
      onShowToast('Push Notifikasi browser berhasil diaktifkan!', 'success');
      PushNotificationService.sendNotification(
        '🔔 Push Notifikasi Aktif',
        'Notifikasi sistem inventori kaos polos sekarang aktif di peramban Anda.',
        'SISTEM'
      );
    } else if (perm === 'denied') {
      onShowToast('Izin notifikasi ditolak oleh peramban. Anda dapat mengaktifkannya via pengaturan browser.', 'error');
    }
  };

  const handleTestNotification = () => {
    PushNotificationService.sendNotification(
      '📦 Peringatan Stok Kaos Menipis (Tes)',
      'Stok Kaos Polos 30s Hitam (Size L) tersisa 8 pcs di Gudang Utama. Segera buat PO!',
      'STOK'
    );
    onShowToast('Tes push notifikasi berhasil dikirim!', 'success');
  };

  const handleMarkAllRead = () => {
    PushNotificationService.markAllAsRead();
  };

  const handleClearAll = () => {
    PushNotificationService.clearAll();
    onShowToast('Riwayat notifikasi berhasil dibersihkan.', 'info');
  };

  const getCategoryIcon = (cat: PushNotificationItem['category']) => {
    switch (cat) {
      case 'STOK':
        return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      case 'SALE':
        return <ShoppingBag className="w-4 h-4 text-emerald-400" />;
      case 'ORDER':
        return <Package className="w-4 h-4 text-sky-400" />;
      case 'SJ':
        return <Truck className="w-4 h-4 text-purple-400" />;
      case 'CLOUD':
        return <Cloud className="w-4 h-4 text-indigo-400" />;
      default:
        return <Bell className="w-4 h-4 text-[#F27D26]" />;
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end overflow-hidden">
          {/* Backdrop Overlay with Fade-in and Fade-out - Clicking outside automatically closes */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22, ease: 'easeInOut' }}
            onClick={onClose}
            className="fixed inset-0 bg-black/65 backdrop-blur-xs cursor-pointer"
            aria-label="Klik untuk menutup notifikasi"
          />

          {/* Right Side Notification Drawer with Slide & Fade In / Fade Out */}
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 280 }}
            onClick={(e) => e.stopPropagation()}
            className="relative z-10 w-full max-w-md sm:max-w-lg h-full bg-[#161618] border-l border-[#2B2B32] shadow-2xl flex flex-col text-[#E0E0E0] select-auto"
          >
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] text-white shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#F27D26]/20 border border-[#F27D26]/40 flex items-center justify-center text-[#F27D26]">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-white flex items-center gap-2">
                    Pusat Push Notifikasi
                    {notifications.some((n) => !n.read) && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-[#F27D26] text-white animate-pulse">
                        {notifications.filter((n) => !n.read).length} Baru
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-neutral-400">Peringatan otomatis stok, pesanan, faktur, dan cloud</p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer border border-[#2B2B32]"
                title="Tutup (Esc)"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Browser Permission Control Banner */}
            <div className="p-4 bg-[#111114] border-b border-[#222228] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white">Izin Push Browser:</span>
                  {permission === 'granted' ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Aktif
                    </span>
                  ) : permission === 'denied' ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-950 text-rose-400 border border-rose-800 flex items-center gap-1">
                      <X className="w-3 h-3" /> Diblokir di Browser
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800 flex items-center gap-1">
                      Belum Diizinkan
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-neutral-400">
                  {permission === 'granted'
                    ? 'Notifikasi sistem akan muncul di layar desktop/ponsel Anda saat ada aktivitas penting.'
                    : 'Aktifkan agar menerima notifikasi saat ada stok menipis dan transaksi baru.'}
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {permission !== 'granted' ? (
                  <button
                    type="button"
                    onClick={handleRequestPermission}
                    className="px-3 py-1.5 bg-[#F27D26] hover:bg-[#e06d1a] text-white text-xs font-bold rounded-xl transition-all shadow-sm cursor-pointer"
                  >
                    Aktifkan Notifikasi
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleTestNotification}
                    className="px-3 py-1.5 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-200 border border-[#2B2B32] text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
                    title="Kirim Tes Push Notifikasi"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-amber-400" /> Tes Notifikasi
                  </button>
                )}
              </div>
            </div>

            {/* Notification List Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
              {notifications.length === 0 ? (
                <div className="py-16 text-center space-y-2">
                  <div className="w-12 h-12 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-500 mx-auto">
                    <Bell className="w-6 h-6" />
                  </div>
                  <p className="text-xs font-bold text-neutral-300">Belum ada riwayat notifikasi</p>
                  <p className="text-[11px] text-neutral-500 max-w-xs mx-auto">
                    Peringatan stok menipis, penjualan kasir, surat jalan, dan sinkronisasi akan muncul di sini.
                  </p>
                  <button
                    type="button"
                    onClick={handleTestNotification}
                    className="mt-2 px-3 py-1.5 bg-[#1C1C20] hover:bg-[#28282E] text-xs font-bold text-neutral-300 border border-[#2B2B32] rounded-xl cursor-pointer"
                  >
                    Kirim Tes Notifikasi Sekarang
                  </button>
                </div>
              ) : (
                notifications.map((item) => (
                  <div
                    key={item.id}
                    className={`p-3 rounded-xl border transition-all ${
                      item.read
                        ? 'bg-[#121214] border-[#222228] opacity-75'
                        : 'bg-[#18181C] border-[#2E2E38] shadow-xs'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <div className="p-2 rounded-lg bg-[#0F0F12] border border-[#26262E] shrink-0 mt-0.5">
                        {getCategoryIcon(item.category)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-extrabold text-xs text-white truncate block">
                            {item.title}
                          </span>
                          <span className="text-[10px] text-neutral-500 shrink-0 font-mono">
                            {new Date(item.timestamp).toLocaleTimeString('id-ID', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-300 mt-0.5 leading-relaxed">
                          {item.body}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer Actions */}
            <div className="p-3.5 border-t border-[#24242A] bg-[#121214] flex items-center justify-between text-xs shrink-0">
              <div className="flex items-center gap-2">
                {notifications.length > 0 && (
                  <>
                    <button
                      type="button"
                      onClick={handleMarkAllRead}
                      className="px-2.5 py-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 text-[11px] font-semibold cursor-pointer"
                    >
                      Tandai Dibaca
                    </button>
                    <button
                      type="button"
                      onClick={handleClearAll}
                      className="px-2.5 py-1 text-rose-400 hover:text-rose-300 rounded-lg hover:bg-rose-950/40 text-[11px] font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" /> Bersihkan
                    </button>
                  </>
                )}
              </div>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-1.5 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-200 rounded-xl font-bold transition-colors cursor-pointer border border-[#2B2B32]"
              >
                Tutup
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
