import React, { useState } from 'react';
import {
  Cloud,
  CloudOff,
  AlertTriangle,
  RefreshCw,
  CheckCircle2,
  X,
  Download,
  Trash2,
  FileText,
  Package,
  ShoppingCart,
  Truck,
  ArrowRight,
  Database,
  Layers,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import {
  OfflineSyncService,
  PendingSyncItem,
  SyncStatusState,
} from '../services/offlineSyncService';
import { MysqlSyncService } from '../services/mysqlSyncService';

interface OfflineSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  status: SyncStatusState;
  onNotify: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const OfflineSyncModal: React.FC<OfflineSyncModalProps> = ({
  isOpen,
  onClose,
  status,
  onNotify,
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [progressInfo, setProgressInfo] = useState<{ current: number; total: number; title: string } | null>(null);
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);

  if (!isOpen) return null;

  const queue = OfflineSyncService.getQueue();

  const handleSyncNow = async () => {
    setIsProcessing(true);
    setProgressInfo({ current: 0, total: queue.length, title: 'Memulai sinkronisasi...' });

    const result = await MysqlSyncService.processPendingQueue((curr, tot, item) => {
      setProgressInfo({ current: curr + 1, total: tot, title: item.title });
    });

    setIsProcessing(false);
    setProgressInfo(null);

    if (result.success) {
      onNotify(
        `Sukses! Seluruh ${result.processed} transaksi tertunda berhasil disinkronkan ke database MySQL!`,
        'success'
      );
    } else {
      onNotify(
        result.error ||
          `Sinkronisasi selesai sebagian (${result.processed} sukses, ${result.remaining} tersisa).`,
        'info'
      );
    }
  };

  const handleDownloadBackup = () => {
    try {
      const jsonStr = OfflineSyncService.exportQueueAsJson();
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup_antrean_offline_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      onNotify('File cadangan transaksi offline berhasil diunduh.', 'success');
    } catch {
      onNotify('Gagal mengunduh file cadangan.', 'error');
    }
  };

  const handleClearQueue = () => {
    OfflineSyncService.clearQueue();
    setConfirmClearOpen(false);
    onNotify('Antrean transaksi tertunda telah dibersihkan.', 'info');
  };

  const getActionBadge = (action: string) => {
    switch (action) {
      case 'saveSale':
      case 'deleteSale':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-950/70 text-purple-300 border border-purple-800/60">
            <ShoppingCart className="w-3 h-3 text-purple-400" /> Penjualan
          </span>
        );
      case 'saveOrder':
      case 'deleteOrder':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-950/70 text-amber-300 border border-amber-800/60">
            <FileText className="w-3 h-3 text-amber-400" /> Order PO
          </span>
        );
      case 'saveSuratJalan':
      case 'deleteSuratJalan':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-sky-950/70 text-sky-300 border border-sky-800/60">
            <Truck className="w-3 h-3 text-sky-400" /> Surat Jalan
          </span>
        );
      case 'saveInventoryItem':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-950/70 text-emerald-300 border border-emerald-800/60">
            <Package className="w-3 h-3 text-emerald-400" /> Stok Inventori
          </span>
        );
      case 'saveLog':
      case 'deleteLog':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-neutral-800 text-neutral-300 border border-neutral-700">
            <Clock className="w-3 h-3 text-neutral-400" /> Log Transaksi
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-950/70 text-blue-300 border border-blue-800/60">
            <Database className="w-3 h-3 text-blue-400" /> Data Master
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-xs">
      <div className="bg-[#161618] border border-[#26262B] rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95">
        {/* Header Modal */}
        <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] shrink-0">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center border ${
                status.isQuotaLimited
                  ? 'bg-amber-500/10 border-amber-500/40 text-amber-400'
                  : status.isOffline
                  ? 'bg-blue-500/10 border-blue-500/40 text-blue-400'
                  : queue.length > 0
                  ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-400'
                  : 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400'
              }`}
            >
              {status.isQuotaLimited ? (
                <AlertTriangle className="w-5 h-5" />
              ) : status.isOffline ? (
                <CloudOff className="w-5 h-5" />
              ) : (
                <Cloud className="w-5 h-5" />
              )}
            </div>
            <div>
              <h3 className="font-extrabold text-base text-white flex items-center gap-2">
                Pusat Sinkronisasi Offline & Kuota Database
                {queue.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    {queue.length} Tertunda
                  </span>
                )}
              </h3>
              <p className="text-xs text-neutral-400">
                Otomatis mengalihkan ke Local Storage saat limit harian & mengupload saat online
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs flex-1">
          {/* Status Banner */}
          <div
            className={`p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
              status.isQuotaLimited
                ? 'bg-amber-950/30 border-amber-800/60 text-amber-200'
                : status.isOffline
                ? 'bg-blue-950/30 border-blue-800/60 text-blue-200'
                : queue.length > 0
                ? 'bg-indigo-950/30 border-indigo-800/60 text-indigo-200'
                : 'bg-emerald-950/30 border-emerald-800/60 text-emerald-200'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className="mt-0.5">
                {status.isQuotaLimited ? (
                  <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                ) : status.isOffline ? (
                  <CloudOff className="w-5 h-5 text-blue-400 shrink-0" />
                ) : queue.length > 0 ? (
                  <RefreshCw className="w-5 h-5 text-indigo-400 shrink-0" />
                ) : (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                )}
              </div>
              <div className="space-y-0.5">
                <div className="font-extrabold text-sm text-white">
                  {status.isQuotaLimited
                    ? 'Koneksi Database MySQL Terbatas'
                    : status.isOffline
                    ? 'Mode Offline (Tanpa Jaringan Internet)'
                    : queue.length > 0
                    ? `${queue.length} Transaksi Menunggu Di-Upload`
                    : 'Database Online & Semua Data Ter-Sinkronkan'}
                </div>
                <p className="text-[11.5px] leading-relaxed text-neutral-300">
                  {status.isQuotaLimited
                    ? 'Transaksi dialihkan secara aman ke Local Storage perangkat Anda. Sistem akan mengupload otomatis saat koneksi MySQL pulih.'
                    : status.isOffline
                    ? 'Semua transaksi tetap tersimpan aman di browser Anda dan akan di-upload otomatis saat tersambung kembali ke server MySQL.'
                    : queue.length > 0
                    ? 'Transaksi tersimpan di Local Storage dan siap diunggah ke database MySQL.'
                    : 'Tidak ada transaksi yang tertunda. Semua faktur, PO, surat jalan, dan mutasi stok telah tersimpan di database MySQL.'}
                </p>
              </div>
            </div>

            {/* Quick Upload Button */}
            {queue.length > 0 && (
              <button
                type="button"
                onClick={handleSyncNow}
                disabled={isProcessing}
                className="w-full sm:w-auto px-4 py-2 bg-[#F27D26] hover:bg-[#d96c1d] disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-md shadow-[#F27D26]/20 transition-all shrink-0 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isProcessing ? 'animate-spin' : ''}`} />
                {isProcessing ? 'Mengunggah...' : 'Upload Sekarang'}
              </button>
            )}
          </div>

          {/* Progress Bar (saat proses upload berjalan) */}
          {progressInfo && (
            <div className="p-3.5 rounded-xl bg-[#101012] border border-[#2B2B32] space-y-2 animate-in fade-in">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-neutral-200 flex items-center gap-2">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#F27D26]" />
                  Sedang Mengupload: {progressInfo.title}
                </span>
                <span className="font-mono text-neutral-400">
                  {progressInfo.current} / {progressInfo.total}
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-neutral-800 overflow-hidden">
                <div
                  className="h-full bg-linear-to-r from-[#F27D26] to-amber-400 transition-all duration-200"
                  style={{
                    width: `${Math.min(100, (progressInfo.current / progressInfo.total) * 100)}%`,
                  }}
                />
              </div>
            </div>
          )}

          {/* Stat Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div className="p-3 rounded-xl bg-[#0F0F11] border border-[#24242A]">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">
                Total Antrean Tertunda
              </span>
              <span className="text-xl font-extrabold text-white mt-0.5 block">
                {queue.length} <span className="text-xs font-normal text-neutral-400">transaksi/dokumen</span>
              </span>
            </div>

            <div className="p-3 rounded-xl bg-[#0F0F11] border border-[#24242A]">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">
                Status Ketahanan Data
              </span>
              <span className="text-xs font-extrabold text-emerald-400 mt-1 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                100% Aman di Local Storage
              </span>
            </div>

            <div className="p-3 rounded-xl bg-[#0F0F11] border border-[#24242A]">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">
                Auto-Upload Background
              </span>
              <span className="text-xs font-extrabold text-sky-400 mt-1 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                Aktif Saat Online / Pulih
              </span>
            </div>
          </div>

          {/* List Transaksi Tertunda */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-extrabold text-sm text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#F27D26]" />
                Rincian Transaksi yang Tertunda ({queue.length})
              </h4>

              {queue.length > 0 && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleDownloadBackup}
                    className="px-2.5 py-1 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 hover:text-white border border-[#2B2B32] rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                    title="Unduh backup JSON transaksi yang tertunda"
                  >
                    <Download className="w-3.5 h-3.5 text-blue-400" /> Cadangkan JSON
                  </button>

                  <button
                    type="button"
                    onClick={() => setConfirmClearOpen(true)}
                    className="px-2.5 py-1 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 hover:text-white border border-rose-800/60 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                    title="Kosongkan antrean"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-400" /> Bersihkan
                  </button>
                </div>
              )}
            </div>

            {queue.length === 0 ? (
              <div className="p-8 text-center bg-[#0F0F11] border border-[#24242A] rounded-xl">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2 opacity-80" />
                <p className="font-bold text-neutral-300 text-sm">Tidak ada transaksi yang tertunda</p>
                <p className="text-xs text-neutral-500 mt-1">
                  Semua transaksi penjualan, PO, surat jalan, dan mutasi stok telah tersimpan di cloud Firestore.
                </p>
              </div>
            ) : (
              <div className="border border-[#24242A] rounded-xl overflow-hidden divide-y divide-[#202026] max-h-72 overflow-y-auto bg-[#0F0F11]">
                {queue.map((item, idx) => (
                  <div
                    key={item.id}
                    className="p-3 flex items-center justify-between gap-3 hover:bg-[#151518] transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="font-mono text-neutral-500 text-xs w-5 text-right shrink-0">
                        {idx + 1}.
                      </span>
                      <div className="min-w-0 space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          {getActionBadge(item.action)}
                          <span className="font-bold text-white text-xs truncate">
                            {item.title}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[10.5px] text-neutral-400">
                          <span>
                            {new Date(item.timestamp).toLocaleString('id-ID', {
                              dateStyle: 'short',
                              timeStyle: 'medium',
                            })}
                          </span>
                          <span>•</span>
                          <span>Percobaan: {item.attempts}x</span>
                          {item.isQuotaLimit && (
                            <>
                              <span>•</span>
                              <span className="text-amber-400 font-semibold">Terkait Limit Kuota</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        OfflineSyncService.removeById(item.id);
                        onNotify(`Item ${item.title} dihapus dari antrean.`, 'info');
                      }}
                      className="p-1.5 text-neutral-500 hover:text-rose-400 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer shrink-0"
                      title="Hapus dari antrean"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer Modal */}
        <div className="p-4 border-t border-[#24242A] flex items-center justify-between bg-[#121214] shrink-0">
          <span className="text-[11px] text-neutral-500 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Background Sync Worker Aktif
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 hover:text-white border border-[#2B2B32] rounded-xl text-xs font-bold cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </div>
      </div>

      {/* Confirmation Modal to Clear Queue */}
      {confirmClearOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-black/85">
          <div className="bg-[#1A1A1E] border border-rose-800/60 rounded-2xl p-5 max-w-sm w-full space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-sm text-white">Kosongkan Semua Antrean?</h4>
              <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                {queue.length} transaksi tertunda yang belum tersimpan di cloud tidak akan diunggah. Pastikan Anda sudah mengunduh file cadangan jika diperlukan.
              </p>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmClearOpen(false)}
                className="px-3 py-1.5 bg-[#25252A] hover:bg-[#303036] text-neutral-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleClearQueue}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                Ya, Kosongkan
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
