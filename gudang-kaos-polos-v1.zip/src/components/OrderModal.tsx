import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  MasterGudang,
  MasterProduk,
  OrderDocument,
  OrderItem,
  SignatureData,
  User,
  AppSystemSettings,
} from '../types';
import { DigitalSignatureModal } from './DigitalSignatureModal';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import {
  FileText,
  Plus,
  Trash2,
  Camera,
  PenTool,
  CheckCircle,
  Printer,
  X,
  ShieldCheck,
  CreditCard,
  Lock,
  Info,
  RotateCcw,
  Building2,
  Truck,
  AlertTriangle,
  Calendar,
  Clock,
  Edit2,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { formatRupiah, terbilangRupiah } from '../utils/formatters';
import { printElement } from '../utils/printHelper';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: MasterProduk[];
  warehouses?: MasterGudang[];
  currentUser: User;
  onSaveOrder: (order: OrderDocument) => void;
  showToast?: (text: string, type?: 'success' | 'error' | 'info') => void;
  initialDoc?: OrderDocument | null;
  settings?: AppSystemSettings;
}

// Rekomendasi vendor supplier/konveksi populer untuk kemudahan pengisian form
const DEFAULT_SUPPLIERS = [
  'CV. Sumber Bahan Textile',
  'PT. Sinar Rajut Nusantara',
  'Konveksi Mitra Abadi Bandung',
  'Grosir Kain Combed Solo',
  'Pabrik Kaos Pratama',
  'Vendor Sablon & Konveksi Berkah',
];

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  products,
  warehouses,
  currentUser,
  onSaveOrder,
  showToast,
  initialDoc,
  settings,
}) => {
  const printableRef = useRef<HTMLDivElement>(null);
  const [printStatus, setPrintStatus] = useState<string | null>(null);

  // Cek otorisasi role: Hanya SUPERVISOR, SPV, OWNER, ADMIN, dan MANAGER yang berwenang mengubah form order PO
  const isSpvOrOwner =
    !currentUser ||
    currentUser?.role === 'SUPERVISOR' ||
    currentUser?.role === 'OWNER' ||
    (currentUser?.role as string) === 'SPV' ||
    currentUser?.role === 'ADMIN' ||
    currentUser?.role === 'MANAGER';

  // Cek apakah user berwenang memilih gudang (Owner, Supervisor, atau siteAccess mencakup SEMUA)
  const hasAllWarehouseAccess =
    currentUser?.siteAccess?.toUpperCase().includes('SEMUA') ||
    currentUser?.role === 'OWNER' ||
    currentUser?.role === 'SUPERVISOR';

  // Daftar gudang aktif yang valid
  const activeWarehouses = useMemo(() => {
    if (!warehouses || warehouses.length === 0) {
      return [
        { GUDANG_ID: 'GDG-01-ERVO', NAMA_GUDANG: 'GUDANG UTAMA', LOKASI: 'Pusat Distribusi Utama - Blok A', IS_ACTIVE: true, IS_DEFAULT: true },
        { GUDANG_ID: 'GDG-02-TOKO', NAMA_GUDANG: 'GUDANG TOKO', LOKASI: 'Outlet Ritel & Display - Lantai 1', IS_ACTIVE: true, IS_DEFAULT: false },
      ];
    }
    const filtered = warehouses.filter((w) => w.IS_ACTIVE !== false);
    return filtered.length > 0 ? filtered : warehouses;
  }, [warehouses]);

  const getDefaultGudangId = () => {
    if (initialDoc?.gudangId) return initialDoc.gudangId;
    if (currentUser?.siteAccess?.includes('UTAMA') || currentUser?.siteAccess?.includes('ERVO')) return 'GDG-01-ERVO';
    if (currentUser?.siteAccess?.includes('TOKO')) return 'GDG-02-TOKO';
    const def = activeWarehouses.find((w) => w.IS_DEFAULT);
    return def ? def.GUDANG_ID : activeWarehouses[0]?.GUDANG_ID || 'GDG-01-ERVO';
  };

  const [selectedGudangId, setSelectedGudangId] = useState<string>(getDefaultGudangId);
  const [nomorOrder, setNomorOrder] = useState('');
  const [tanggal, setTanggal] = useState('');
  const [supplier, setSupplier] = useState('');
  const [kontak, setKontak] = useState('');
  const [alamat, setAlamat] = useState('');
  const [metode, setMetode] = useState('TRANSFER');
  const [statusPembayaran, setStatusPembayaran] = useState<'LUNAS' | 'PIUTANG' | 'SEBAGIAN'>('LUNAS');
  const [jumlahBayarInput, setJumlahBayarInput] = useState<number>(0);
  const [jatuhTempo, setJatuhTempo] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().split('T')[0];
  });
  const [catatan, setCatatan] = useState('');
  const [diskonNominal, setDiskonNominal] = useState<number>(0);
  const [items, setItems] = useState<OrderItem[]>([]);

  // 2 Digital Signatures: Pembuat PO & Pimpinan / SPV
  const [sigAdmin, setSigAdmin] = useState<SignatureData | undefined>(undefined);
  const [sigSupervisor, setSigSupervisor] = useState<SignatureData | undefined>(undefined);
  const [activeSigRole, setActiveSigRole] = useState<'admin' | 'supervisor' | null>(null);

  // Scanner
  const [scannerTargetRowId, setScannerTargetRowId] = useState<string | null>(null);
  const [isSaved, setIsSaved] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      if (initialDoc) {
        setNomorOrder(initialDoc.nomorOrder);
        setTanggal(initialDoc.tanggal);
        if (initialDoc.gudangId) {
          setSelectedGudangId(initialDoc.gudangId);
        }
        setSupplier(initialDoc.supplier || '');
        setKontak(initialDoc.kontak || '');
        setAlamat(initialDoc.alamat || '');
        setMetode(initialDoc.statusPembayaran === 'PIUTANG' ? (initialDoc.metode || '') : (initialDoc.metode || 'TRANSFER'));
        setStatusPembayaran(initialDoc.statusPembayaran || 'LUNAS');
        setJumlahBayarInput(initialDoc.jumlahBayar ?? (initialDoc.totalNominal || 0));
        if (initialDoc.jatuhTempo) {
          setJatuhTempo(initialDoc.jatuhTempo);
        }
        setCatatan(initialDoc.catatan || '');
        setDiskonNominal(initialDoc.diskonNominal || 0);
        setItems(initialDoc.items || []);
        setSigAdmin(initialDoc.signatureAdmin);
        setSigSupervisor(initialDoc.signatureSupervisor);
        setIsSaved(false);
        setPrintStatus(null);
        return;
      }

      const now = new Date();
      const pad = (n: number) => String(n).padStart(2, '0');
      const dateStr = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`;
      const randomSeq = String(Math.floor(1000 + Math.random() * 9000));
      setNomorOrder(`ORD-${dateStr}-${randomSeq}`);
      setTanggal(`${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`);
      setSelectedGudangId(getDefaultGudangId());
      setSupplier('');
      setKontak('');
      setAlamat('');
      setMetode('TRANSFER');
      setStatusPembayaran('LUNAS');
      setJumlahBayarInput(0);
      const d = new Date();
      d.setDate(d.getDate() + 14);
      setJatuhTempo(d.toISOString().split('T')[0]);
      setCatatan('');
      setDiskonNominal(0);
      setSigAdmin(undefined);
      setSigSupervisor(undefined);
      setIsSaved(false);
      setPrintStatus(null);
      setItems([
        {
          id: 'item-1',
          SKU_ID: '',
          jumlah: 24,
          hargaSatuan: 0,
          subtotal: 0,
          keterangan: '',
        },
      ]);
    }
  }, [isOpen, products, currentUser, initialDoc, warehouses]);

  // Handler Batal: Kembalikan seluruh form order PO ke default kosong bersih
  const handleResetForm = () => {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const dateStr = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`;
    const randomSeq = String(Math.floor(1000 + Math.random() * 9000));
    setNomorOrder(`ORD-${dateStr}-${randomSeq}`);
    setTanggal(`${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`);
    setSelectedGudangId(getDefaultGudangId());
    setSupplier('');
    setKontak('');
    setAlamat('');
    setMetode('TRANSFER');
    setStatusPembayaran('LUNAS');
    setJumlahBayarInput(0);
    const d = new Date();
    d.setDate(d.getDate() + 14);
    setJatuhTempo(d.toISOString().split('T')[0]);
    setCatatan('');
    setDiskonNominal(0);
    setSigAdmin(undefined);
    setSigSupervisor(undefined);
    setIsSaved(false);
    setPrintStatus(null);
    setItems([
      {
        id: `item-${Date.now()}`,
        SKU_ID: '',
        jumlah: 24,
        hargaSatuan: 0,
        subtotal: 0,
        keterangan: '',
      },
    ]);
  };

  const addItem = () => {
    if (!isSpvOrOwner) return;
    setIsSaved(false);
    setItems((prev) => [
      ...prev,
      {
        id: `item-${Date.now()}`,
        SKU_ID: '',
        jumlah: 24,
        hargaSatuan: 0,
        subtotal: 0,
        keterangan: '',
      },
    ]);
  };

  const removeItem = (id: string) => {
    if (!isSpvOrOwner || items.length <= 1) return;
    setIsSaved(false);
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  const updateItem = (id: string, updates: Partial<OrderItem>) => {
    if (!isSpvOrOwner) return;
    setIsSaved(false);
    setItems((prev) =>
      prev.map((i) => {
        if (i.id !== id) return i;
        const updated = { ...i, ...updates };
        if (updates.SKU_ID !== undefined && updates.SKU_ID !== i.SKU_ID) {
          const matchedProd = products.find((p) => p.SKU_ID === updates.SKU_ID);
          // Default harga beli menggunakan HARGA_HPP jika ada, atau 30.000
          updated.hargaSatuan = matchedProd?.HARGA_HPP || 30000;
        }
        const qty = Number(updated.jumlah) || 0;
        const price = Number(updated.hargaSatuan) || 0;
        updated.subtotal = qty * price;
        return updated;
      })
    );
  };

  const handleBarcodeScanned = (decodedText: string) => {
    if (!isSpvOrOwner) return;
    const match = products.find(
      (p) =>
        p.SKU_ID.toUpperCase() === decodedText.toUpperCase() ||
        (p.BARCODE_ID && p.BARCODE_ID.toUpperCase() === decodedText.toUpperCase())
    );

    if (match && scannerTargetRowId) {
      updateItem(scannerTargetRowId, {
        SKU_ID: match.SKU_ID,
        hargaSatuan: match.HARGA_HPP || 30000,
      });
    } else if (match) {
      const price = match.HARGA_HPP || 30000;
      const qty = 24;
      setItems((prev) => [
        ...prev,
        {
          id: `item-${Date.now()}`,
          SKU_ID: match.SKU_ID,
          jumlah: qty,
          hargaSatuan: price,
          subtotal: qty * price,
          keterangan: 'Scan Barcode',
        },
      ]);
    } else {
      alert(`Produk dengan barcode/SKU "${decodedText}" tidak ditemukan dalam Master Data.`);
    }
    setScannerTargetRowId(null);
  };

  const totalQty = items.reduce((sum, item) => sum + (Number(item.jumlah) || 0), 0);
  const subtotalNominal = items.reduce(
    (sum, item) => sum + (item.subtotal !== undefined ? item.subtotal : (Number(item.jumlah) || 0) * (Number(item.hargaSatuan) || 0)),
    0
  );
  const totalNominal = Math.max(0, subtotalNominal - (Number(diskonNominal) || 0));

  // Perhitungan Otomatis Pembayaran & Sisa Utang/Hutang Pembelian
  const computedJumlahBayar = useMemo(() => {
    if (statusPembayaran === 'LUNAS') {
      return totalNominal;
    }
    if (statusPembayaran === 'PIUTANG') {
      return 0;
    }
    // SEBAGIAN (DP)
    return Math.min(totalNominal, Math.max(0, Number(jumlahBayarInput) || 0));
  }, [statusPembayaran, totalNominal, jumlahBayarInput]);

  const computedSisaPiutang = Math.max(0, totalNominal - computedJumlahBayar);

  const handleSave = () => {
    if (!isSpvOrOwner) {
      alert('Akses Ditolak: Hanya user SPV dan Owner yang berwenang menyimpan pesanan stok PO.');
      return;
    }

    if (!supplier.trim()) {
      alert('Nama Supplier / Vendor Konveksi wajib diisi.');
      return;
    }

    const validItems: OrderItem[] = [];

    items.forEach((item) => {
      if (!item.SKU_ID || Number(item.jumlah) <= 0) return;
      const qty = Number(item.jumlah) || 0;
      const price = Number(item.hargaSatuan) || 0;
      validItems.push({
        ...item,
        jumlah: qty,
        hargaSatuan: price,
        subtotal: qty * price,
      });
    });

    if (validItems.length === 0) {
      alert('Tambahkan minimal 1 item barang yang valid.');
      return;
    }

    const selectedWarehouse = activeWarehouses.find((w) => w.GUDANG_ID === selectedGudangId);

    const doc: OrderDocument = {
      nomorOrder,
      tanggal,
      gudangId: selectedGudangId,
      gudangNama: selectedWarehouse?.NAMA_GUDANG || currentUser.siteAccess,
      username: currentUser.username,
      supplier: supplier.trim() || 'Supplier / Konveksi Mitra',
      kontak: kontak.trim() || '-',
      alamat: alamat.trim() || undefined,
      metode,
      catatan,
      subtotalNominal,
      diskonNominal: Number(diskonNominal) || 0,
      totalNominal,
      statusPembayaran,
      jumlahBayar: computedJumlahBayar,
      sisaPiutang: computedSisaPiutang,
      jatuhTempo: statusPembayaran !== 'LUNAS' ? jatuhTempo : undefined,
      tampilkanNominal: true,
      items: validItems,
      signatureAdmin: sigAdmin,
      signatureSupervisor: sigSupervisor,
      createdAt: initialDoc?.createdAt || new Date().toISOString(),
    };

    onSaveOrder(doc);
    setIsSaved(true);

    if (showToast) {
      showToast(`Purchase Order ${nomorOrder} berhasil disimpan!`, 'success');
    }

    try {
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    } catch {
      // ignore
    }
  };

  const handlePrint = () => {
    if (!printableRef.current) return;
    printElement(
      printableRef.current,
      {
        title: `Purchase Order Resmi - ${nomorOrder}`,
        filename: `PO_${nomorOrder}`,
      },
      (msg) => {
        setPrintStatus(msg);
        setTimeout(() => setPrintStatus(null), 5000);
      }
    );
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-1 sm:p-2 bg-black/85 backdrop-blur-xs animate-in fade-in duration-200">
        <div className="bg-[#161618] rounded-2xl shadow-2xl w-full max-w-[99vw] 2xl:max-w-[1850px] overflow-hidden border border-[#2A2A32] flex flex-col h-[97vh] text-[#E0E0E0]">
          {/* Header Modal - Harmonis & Seragam dengan Form Sale */}
          <div className="p-3.5 sm:p-4 border-b border-[#24242A] flex items-center justify-between bg-[#121214] text-white shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[#F27D26] text-white flex items-center justify-center shadow-md shadow-[#F27D26]/30">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm sm:text-base leading-tight text-white flex items-center gap-2">
                  Form Order Stok (PO) & Dokumen Pemesanan
                  <span className="font-mono text-xs font-bold text-orange-400 bg-orange-950/60 border border-orange-800/50 px-2 py-0.5 rounded-full">
                    {nomorOrder}
                  </span>
                  {!isSpvOrOwner && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-950/70 border border-amber-800/60 text-amber-300 flex items-center gap-1">
                      <Lock className="w-3 h-3 text-amber-400" /> Read Only (SPV/Owner Only)
                    </span>
                  )}
                </h3>
                <p className="text-[11px] text-neutral-400">Pratinjau purchase order besar diperluas dengan opsi cetak langsung & simpan PDF</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body Content - 2 Columns (Identik Proporsi dengan Form Sale) */}
          <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
            {/* Left: Form Controls (Lebar Diperluas Sama Persis dengan Form Sale) */}
            <div className="w-full lg:w-[420px] xl:w-[480px] 2xl:w-[520px] bg-[#121214] border-r border-[#24242A] p-3 sm:p-4 overflow-y-auto space-y-3 shrink-0">
              {/* Otorisasi Read-Only Banner */}
              {!isSpvOrOwner && (
                <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-800/60 text-amber-300 text-xs flex items-start gap-2 shadow-xs">
                  <Lock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-amber-200 text-[11px] flex items-center gap-1">
                      Mode Baca Saja (Terkunci)
                    </div>
                    <div className="text-[10px] text-amber-300/80 leading-tight mt-0.5">
                      Kolom input ini terkunci untuk akun <strong>{currentUser.username}</strong> ({currentUser.role}). Hanya user <strong>SPV</strong> dan <strong>Owner</strong> yang berwenang mengubah rincian form order PO.
                    </div>
                  </div>
                </div>
              )}

              {/* Section 0: Pilihan Unit Gudang Tujuan Restock */}
              <div className="bg-[#161618] p-2.5 rounded-xl border border-[#26262B] space-y-1.5 shadow-xs">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-[#F27D26]" />
                    Gudang Tujuan PO *
                  </label>
                  {hasAllWarehouseAccess ? (
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-orange-950/70 border border-orange-800/60 text-orange-300">
                      Multi-Gudang
                    </span>
                  ) : (
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-neutral-800 border border-neutral-700 text-neutral-400 flex items-center gap-0.5">
                      <Lock className="w-2.5 h-2.5" /> Terkunci
                    </span>
                  )}
                </div>

                {hasAllWarehouseAccess && !initialDoc ? (
                  <select
                    value={selectedGudangId}
                    disabled={!isSpvOrOwner}
                    onChange={(e) => setSelectedGudangId(e.target.value)}
                    className="w-full p-2 text-xs font-bold bg-[#0D0D10] border border-orange-900/50 rounded-lg text-orange-200 focus:border-[#F27D26] focus:outline-hidden cursor-pointer"
                  >
                    {activeWarehouses.map((wh) => (
                      <option key={wh.GUDANG_ID} value={wh.GUDANG_ID} className="bg-[#161618] text-neutral-200">
                        {wh.NAMA_GUDANG} ({wh.GUDANG_ID}) {wh.LOKASI ? `— ${wh.LOKASI}` : ''}
                      </option>
                    ))}
                  </select>
                ) : (
                  <div className="p-2 bg-[#0D0D10] border border-[#26262E] rounded-lg flex items-center justify-between text-xs">
                    <span className="font-bold text-neutral-200">
                      {activeWarehouses.find((w) => w.GUDANG_ID === selectedGudangId)?.NAMA_GUDANG || selectedGudangId}
                    </span>
                    <span className="text-[10px] font-mono text-orange-400">{selectedGudangId}</span>
                  </div>
                )}
                <p className="text-[9.5px] text-neutral-400 leading-tight">
                  Barang pesanan PO akan dialokasikan dan masuk ke unit gudang di atas saat kedatangan fisik.
                </p>
              </div>

              {/* Section 1: Data Transaksi & Supplier */}
              <div className="bg-[#161618] p-2.5 rounded-xl border border-[#26262B] space-y-2 shadow-xs">
                <div className="flex items-center justify-between text-[11px] font-bold text-neutral-300 uppercase tracking-wider">
                  <span className="flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5 text-[#F27D26]" /> Supplier / Vendor Konveksi
                  </span>
                  <span className="text-[9px] text-neutral-500 font-mono">{tanggal}</span>
                </div>

                {/* Rekomendasi Vendor Supplier Cepat */}
                {isSpvOrOwner && !initialDoc && (
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-orange-400 mb-0.5">
                      Pilihan Cepat Vendor Supplier
                    </label>
                    <select
                      value={supplier}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val) setSupplier(val);
                      }}
                      className="w-full p-1.5 text-xs rounded-lg bg-[#0D0D10] border border-orange-900/60 text-orange-200 focus:border-[#F27D26] focus:outline-hidden font-medium"
                    >
                      <option value="">-- Ketik Nama Vendor Manual --</option>
                      {DEFAULT_SUPPLIERS.map((s) => (
                        <option key={s} value={s} className="bg-[#161618] text-neutral-200">
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="space-y-1.5">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">
                      Nama Supplier / Konveksi *
                    </label>
                    <input
                      type="text"
                      value={supplier}
                      readOnly={!isSpvOrOwner}
                      onChange={(e) => setSupplier(e.target.value)}
                      placeholder="Nama vendor pabrik / konveksi"
                      className={`w-full p-1.5 text-xs rounded-lg transition-all ${
                        isSpvOrOwner
                          ? 'bg-[#0D0D10] border border-[#26262E] text-neutral-100 placeholder-neutral-600 focus:border-[#F27D26] focus:outline-hidden font-semibold'
                          : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed select-none'
                      }`}
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">
                        No. Kontak / WA Supplier
                      </label>
                      <input
                        type="text"
                        value={kontak}
                        readOnly={!isSpvOrOwner}
                        onChange={(e) => setKontak(e.target.value)}
                        placeholder="0812..."
                        className={`w-full p-1.5 text-xs rounded-lg transition-all ${
                          isSpvOrOwner
                            ? 'bg-[#0D0D10] border border-[#26262E] text-neutral-100 placeholder-neutral-600 focus:border-[#F27D26] focus:outline-hidden font-mono'
                            : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed select-none'
                        }`}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">
                        Alamat / Kota Pabrik
                      </label>
                      <input
                        type="text"
                        value={alamat}
                        readOnly={!isSpvOrOwner}
                        onChange={(e) => setAlamat(e.target.value)}
                        placeholder="Bandung / Solo / Jakarta"
                        className={`w-full p-1.5 text-xs rounded-lg transition-all ${
                          isSpvOrOwner
                            ? 'bg-[#0D0D10] border border-[#26262E] text-neutral-100 placeholder-neutral-600 focus:border-[#F27D26] focus:outline-hidden'
                            : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed select-none'
                        }`}
                      />
                    </div>
                  </div>
                </div>

                {/* Modul Status Pembayaran & Pembelian (Sama Persis dengan Form Sale) */}
                <div className="payment-config-module pt-2 border-t border-[#24242A] space-y-2">
                  {/* Header Bar */}
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-300 flex items-center gap-1">
                      <CreditCard className="w-3 h-3 text-[#F27D26]" />
                      Status Pembayaran Pembelian *
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[9.5px] font-extrabold whitespace-nowrap shadow-2xs ${
                        statusPembayaran === 'LUNAS'
                          ? 'bg-emerald-950/70 border border-emerald-700/60 text-emerald-300'
                          : statusPembayaran === 'SEBAGIAN'
                          ? 'bg-amber-950/70 border border-amber-700/60 text-amber-300'
                          : 'bg-rose-950/70 border border-rose-700/60 text-rose-300'
                      }`}
                    >
                      {statusPembayaran === 'LUNAS'
                        ? '✓ Lunas 100%'
                        : statusPembayaran === 'SEBAGIAN'
                        ? '⚡ DP / Uang Muka'
                        : '⏳ Tempo / Utang PO'}
                    </span>
                  </div>

                  {/* 3-Way Segmented Control */}
                  <div className="p-1 bg-[#0D0D10] border border-[#26262E] rounded-xl grid grid-cols-3 gap-1 shadow-inner payment-segmented-control">
                    <button
                      type="button"
                      disabled={!isSpvOrOwner}
                      onClick={() => {
                        setStatusPembayaran('LUNAS');
                        setJumlahBayarInput(totalNominal);
                        if (metode === 'TEMPO') setMetode('TRANSFER');
                      }}
                      className={`py-1.5 px-1 rounded-lg text-[10.5px] font-extrabold transition-all flex items-center justify-center gap-1 cursor-pointer ${
                        statusPembayaran === 'LUNAS'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      <span>✓</span> Lunas
                    </button>
                    <button
                      type="button"
                      disabled={!isSpvOrOwner}
                      onClick={() => {
                        setStatusPembayaran('SEBAGIAN');
                        const defaultDp = Math.round(totalNominal * 0.5);
                        setJumlahBayarInput(defaultDp);
                        if (metode === 'TEMPO') setMetode('TRANSFER');
                      }}
                      className={`py-1.5 px-1 rounded-lg text-[10.5px] font-extrabold transition-all flex items-center justify-center gap-1 cursor-pointer ${
                        statusPembayaran === 'SEBAGIAN'
                          ? 'bg-amber-600 text-white shadow-xs'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      <span>⚡</span> DP
                    </button>
                    <button
                      type="button"
                      disabled={!isSpvOrOwner}
                      onClick={() => {
                        setStatusPembayaran('PIUTANG');
                        setJumlahBayarInput(0);
                        setMetode('');
                      }}
                      className={`py-1.5 px-1 rounded-lg text-[10.5px] font-extrabold transition-all flex items-center justify-center gap-1 cursor-pointer ${
                        statusPembayaran === 'PIUTANG'
                          ? 'bg-rose-600 text-white shadow-xs'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      <span>⏳</span> Tempo
                    </button>
                  </div>

                  {/* Dynamic Context Card: LUNAS */}
                  {statusPembayaran === 'LUNAS' && (
                    <div className="p-2.5 bg-[#0D0D10] border border-emerald-900/40 rounded-xl space-y-2 animate-in fade-in payment-context-card">
                      <div className="flex items-center justify-between text-[11px] px-0.5">
                        <span className="text-neutral-400">Total Terbayar:</span>
                        <span className="font-mono font-extrabold text-emerald-400 text-xs">
                          {formatRupiah(totalNominal)}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-1.5 pt-1.5 border-t border-[#1E1E24]">
                        <div>
                          <label className="block text-[9.5px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">
                            Metode Bayar
                          </label>
                          <select
                            value={metode === 'TEMPO' ? 'TRANSFER' : (metode || 'TRANSFER')}
                            disabled={!isSpvOrOwner}
                            onChange={(e) => setMetode(e.target.value)}
                            className="w-full p-1.5 text-xs rounded-lg font-bold bg-[#141418] border border-[#2B2B32] text-orange-300 focus:outline-hidden focus:border-[#F27D26]"
                          >
                            <option value="TRANSFER">🏦 Transfer Bank</option>
                            <option value="TUNAI">💵 Tunai Kasir</option>
                            <option value="GIRO">📑 Bilyet Giro / Cek</option>
                            <option value="COD">📦 Bayar Saat Tiba (COD)</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-[9.5px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">
                            Tanggal Order PO
                          </label>
                          <input
                            type="date"
                            value={tanggal}
                            readOnly={!isSpvOrOwner}
                            onChange={(e) => setTanggal(e.target.value)}
                            className="w-full p-1.5 text-xs rounded-lg bg-[#141418] border border-[#2B2B32] text-neutral-200 focus:outline-hidden focus:border-[#F27D26] font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Dynamic Context Card: SEBAGIAN (DP) */}
                  {statusPembayaran === 'SEBAGIAN' && (
                    <div className="p-2.5 bg-[#0D0D10] border border-amber-900/50 rounded-xl space-y-2 animate-in fade-in payment-context-card">
                      <div>
                        <div className="flex items-center justify-between text-[10px] mb-1">
                          <span className="text-amber-300 font-bold">Uang Muka / DP Dibayar (Rp):</span>
                          <span className="text-rose-400 font-bold font-mono text-[10px]">
                            Sisa Utang: {formatRupiah(computedSisaPiutang)}
                          </span>
                        </div>
                        <input
                          type="number"
                          min="0"
                          max={totalNominal}
                          value={jumlahBayarInput}
                          readOnly={!isSpvOrOwner}
                          onChange={(e) => setJumlahBayarInput(Number(e.target.value))}
                          className="w-full p-1.5 text-xs font-mono font-bold bg-[#141418] border border-amber-700/60 rounded-lg text-amber-300 focus:outline-hidden focus:border-amber-500"
                        />
                        {/* Quick DP Shortcuts */}
                        <div className="flex items-center gap-1 mt-1 text-[9px]">
                          <span className="text-neutral-500">Shortcut:</span>
                          {[
                            { pct: 0.25, label: '25%' },
                            { pct: 0.5, label: '50%' },
                            { pct: 0.75, label: '75%' },
                          ].map(({ pct, label }) => (
                            <button
                              key={label}
                              type="button"
                              disabled={!isSpvOrOwner}
                              onClick={() => setJumlahBayarInput(Math.round(totalNominal * pct))}
                              className="px-1.5 py-0.5 bg-[#1C1C22] hover:bg-amber-950/60 text-neutral-300 hover:text-amber-300 rounded border border-[#2E2E36] cursor-pointer"
                            >
                              {label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Jatuh Tempo */}
                      <div className="pt-1.5 border-t border-[#1E1E24]">
                        <div className="flex items-center justify-between text-[10px] mb-0.5">
                          <label className="text-neutral-300 font-bold flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-[#F27D26]" /> Jatuh Tempo Pelunasan:
                          </label>
                          <span className="text-[9.5px] text-neutral-400 font-mono">
                            {jatuhTempo}
                          </span>
                        </div>
                        <input
                          type="date"
                          value={jatuhTempo}
                          readOnly={!isSpvOrOwner}
                          onChange={(e) => setJatuhTempo(e.target.value)}
                          className="w-full p-1.5 text-xs font-mono bg-[#141418] border border-[#2B2B32] rounded-lg text-neutral-200 focus:outline-hidden focus:border-[#F27D26]"
                        />
                        <div className="flex items-center gap-1 text-[9px] mt-1">
                          <span className="text-neutral-500">Preset:</span>
                          {[7, 14, 30].map((days) => (
                            <button
                              key={days}
                              type="button"
                              disabled={!isSpvOrOwner}
                              onClick={() => {
                                const d = new Date();
                                d.setDate(d.getDate() + days);
                                setJatuhTempo(d.toISOString().split('T')[0]);
                              }}
                              className="px-1.5 py-0.5 bg-[#1C1C22] hover:bg-[#282830] text-neutral-300 rounded border border-[#2E2E36] cursor-pointer"
                            >
                              +{days}hr
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Metode Bayar DP & Tanggal */}
                      <div className="grid grid-cols-2 gap-1.5 pt-1.5 border-t border-[#1E1E24]">
                        <div>
                          <label className="block text-[9.5px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">
                            Metode Bayar DP
                          </label>
                          <select
                            value={metode === 'TEMPO' ? 'TRANSFER' : (metode || 'TRANSFER')}
                            disabled={!isSpvOrOwner}
                            onChange={(e) => setMetode(e.target.value)}
                            className="w-full p-1.5 text-xs rounded-lg font-bold bg-[#141418] border border-[#2B2B32] text-amber-300 focus:outline-hidden focus:border-amber-500"
                          >
                            <option value="TRANSFER">🏦 Transfer Bank</option>
                            <option value="TUNAI">💵 Tunai Kasir</option>
                            <option value="GIRO">📑 Bilyet Giro</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-[9.5px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">
                            Tanggal Order PO
                          </label>
                          <input
                            type="date"
                            value={tanggal}
                            readOnly={!isSpvOrOwner}
                            onChange={(e) => setTanggal(e.target.value)}
                            className="w-full p-1.5 text-xs rounded-lg bg-[#141418] border border-[#2B2B32] text-neutral-200 focus:outline-hidden focus:border-[#F27D26] font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Dynamic Context Card: PIUTANG (TEMPO 100%) */}
                  {statusPembayaran === 'PIUTANG' && (
                    <div className="p-2.5 bg-[#0D0D10] border border-rose-900/60 rounded-xl space-y-2 animate-in fade-in payment-context-card">
                      <div className="flex items-center justify-between text-[11px] p-2.5 rounded-lg bg-rose-950/50 border border-rose-900/60 text-rose-300">
                        <div>
                          <span className="block text-[9.5px] font-bold uppercase text-rose-400 tracking-wider">Total Utang Pembelian (Tempo 100%)</span>
                          <span className="font-mono font-extrabold text-base text-rose-300 block">{formatRupiah(totalNominal)}</span>
                        </div>
                        <div className="text-right text-[10px] text-neutral-400">
                          <span className="block text-[9px] uppercase tracking-wider text-neutral-400">Bayar Saat Ini:</span>
                          <strong className="block text-rose-400 font-mono font-extrabold text-xs">Belum Bayar (Rp 0)</strong>
                        </div>
                      </div>

                      {/* Jatuh Tempo */}
                      <div>
                        <div className="flex items-center justify-between text-[10px] mb-0.5">
                          <label className="text-neutral-300 font-bold flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-[#F27D26]" /> Tanggal Jatuh Tempo Pelunasan:
                          </label>
                          <span className="text-[9.5px] text-rose-300 font-mono font-bold">
                            {jatuhTempo}
                          </span>
                        </div>
                        <input
                          type="date"
                          value={jatuhTempo}
                          readOnly={!isSpvOrOwner}
                          onChange={(e) => setJatuhTempo(e.target.value)}
                          className="w-full p-1.5 text-xs font-mono bg-[#141418] border border-[#2B2B32] rounded-lg text-neutral-200 focus:outline-hidden focus:border-[#F27D26]"
                        />
                        <div className="flex items-center gap-1 text-[9px] mt-1">
                          <span className="text-neutral-500">Preset:</span>
                          {[7, 14, 30].map((days) => (
                            <button
                              key={days}
                              type="button"
                              disabled={!isSpvOrOwner}
                              onClick={() => {
                                const d = new Date();
                                d.setDate(d.getDate() + days);
                                setJatuhTempo(d.toISOString().split('T')[0]);
                              }}
                              className="px-1.5 py-0.5 bg-[#1C1C22] hover:bg-[#282830] text-neutral-300 rounded border border-[#2E2E36] cursor-pointer"
                            >
                              +{days}hr
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Rencana Bayar & Tanggal PO */}
                      <div className="grid grid-cols-2 gap-1.5 pt-1.5 border-t border-[#1E1E24]">
                        <div>
                          <label className="block text-[9.5px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">
                            Rencana Pelunasan
                          </label>
                          <select
                            value={metode || ''}
                            disabled={!isSpvOrOwner}
                            onChange={(e) => setMetode(e.target.value)}
                            className="w-full p-1.5 text-xs rounded-lg font-bold bg-[#141418] border border-[#2B2B32] text-neutral-300 focus:outline-hidden focus:border-rose-500"
                          >
                            <option value="">— (Belum Tahu / Nanti) —</option>
                            <option value="TRANSFER">🏦 Transfer Bank</option>
                            <option value="TUNAI">💵 Tunai Kasir</option>
                            <option value="GIRO">📑 Bilyet Giro</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-[9.5px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">
                            Tanggal Order PO
                          </label>
                          <input
                            type="date"
                            value={tanggal}
                            readOnly={!isSpvOrOwner}
                            onChange={(e) => setTanggal(e.target.value)}
                            className="w-full p-1.5 text-xs rounded-lg bg-[#141418] border border-[#2B2B32] text-neutral-200 focus:outline-hidden focus:border-[#F27D26] font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">
                    Catatan / Instruksi Khusus PO
                  </label>
                  <input
                    type="text"
                    value={catatan}
                    readOnly={!isSpvOrOwner}
                    onChange={(e) => setCatatan(e.target.value)}
                    placeholder="Contoh: Prioritas kirim, packing plastik per lusin"
                    className={`w-full p-1.5 text-xs rounded-lg ${
                      isSpvOrOwner
                        ? 'bg-[#0D0D10] border border-[#26262E] text-neutral-100 placeholder-neutral-600 focus:border-[#F27D26] focus:outline-hidden'
                        : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed select-none'
                    }`}
                  />
                </div>
              </div>

              {/* Section 2: Items List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-300">
                    Daftar Barang Dipesan ({items.length})
                  </span>
                  {isSpvOrOwner && (
                    <button
                      type="button"
                      onClick={addItem}
                      className="px-2 py-0.5 bg-orange-950/70 hover:bg-orange-900 border border-orange-800/80 text-orange-300 text-[10px] font-bold rounded-md flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Plus className="w-3 h-3" /> Tambah
                    </button>
                  )}
                </div>

                <div className="space-y-2 max-h-56 overflow-y-auto pr-0.5">
                  {items.map((item, idx) => {
                    const prod = products.find((p) => p.SKU_ID === item.SKU_ID);

                    return (
                      <div
                        key={item.id}
                        className="bg-[#161618] p-2 rounded-xl space-y-1.5 border border-[#26262B] shadow-xs transition-all"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#F27D26]" />
                            <span className="text-[10px] font-bold text-neutral-200">#{idx + 1}</span>
                            {prod?.WARNA && (
                              <span className="text-[9px] text-neutral-400 truncate max-w-[120px]">
                                · {prod.WARNA} {prod.UKURAN}
                              </span>
                            )}
                          </div>
                          {isSpvOrOwner && (
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => setScannerTargetRowId(item.id)}
                                className="p-1 text-neutral-400 hover:text-[#F27D26] bg-[#1E1E24] hover:bg-[#282830] rounded transition-colors border border-[#2B2B32] cursor-pointer"
                                title="Pindai Barcode"
                              >
                                <Camera className="w-3 h-3" />
                              </button>
                              {items.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => removeItem(item.id)}
                                  className="p-1 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded transition-colors cursor-pointer"
                                  title="Hapus baris"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Product Selector */}
                        <select
                          value={item.SKU_ID}
                          disabled={!isSpvOrOwner}
                          onChange={(e) => updateItem(item.id, { SKU_ID: e.target.value })}
                          className={`w-full p-1.5 text-[11px] rounded-lg font-mono ${
                            isSpvOrOwner
                              ? 'bg-[#0D0D10] border border-[#26262E] text-neutral-200 focus:border-[#F27D26] focus:outline-hidden'
                              : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed'
                          }`}
                        >
                          <option value="">-- Pilih SKU Kaos --</option>
                          {products.map((p) => (
                            <option key={p.SKU_ID} value={p.SKU_ID}>
                              {p.SKU_ID} ({p.WARNA} {p.UKURAN})
                            </option>
                          ))}
                        </select>

                        {/* Qty & Unit Price */}
                        <div className="grid grid-cols-2 gap-1.5">
                          <div>
                            <label className="block text-[9px] text-neutral-400 font-semibold mb-0.5">
                              Qty Pesan (Pcs)
                            </label>
                            <input
                              type="number"
                              min="1"
                              value={item.jumlah}
                              readOnly={!isSpvOrOwner}
                              onChange={(e) => updateItem(item.id, { jumlah: parseInt(e.target.value) || 0 })}
                              className={`w-full p-1 text-xs font-bold rounded-lg text-center ${
                                isSpvOrOwner
                                  ? 'bg-[#0D0D10] border border-[#26262E] text-neutral-100 focus:outline-hidden focus:border-[#F27D26]'
                                  : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed'
                              }`}
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] text-neutral-400 font-semibold mb-0.5">
                              Harga Beli (HPP)
                            </label>
                            <input
                              type="number"
                              min="0"
                              step="500"
                              value={item.hargaSatuan || 0}
                              readOnly={!isSpvOrOwner}
                              onChange={(e) => updateItem(item.id, { hargaSatuan: parseInt(e.target.value) || 0 })}
                              className={`w-full p-1 text-xs font-bold rounded-lg text-right ${
                                isSpvOrOwner
                                  ? 'bg-[#0D0D10] border border-[#26262E] text-orange-400 focus:outline-hidden focus:border-[#F27D26]'
                                  : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed'
                              }`}
                            />
                          </div>
                        </div>

                        {/* Subtotal Line */}
                        <div className="flex items-center justify-between bg-[#111114] px-2 py-1 rounded text-[10px] border border-[#202026]">
                          <span className="text-neutral-500">Subtotal:</span>
                          <span className="font-mono font-bold text-orange-300">
                            {formatRupiah(item.subtotal || (Number(item.jumlah) || 0) * (Number(item.hargaSatuan) || 0))}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Section 3: Ringkasan Tagihan */}
              <div className="bg-[#161618] p-2.5 rounded-xl border border-[#26262B] space-y-1.5 shadow-xs">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-neutral-400">Total Qty:</span>
                  <span className="font-bold text-neutral-200">{totalQty} pcs</span>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-neutral-400">Subtotal:</span>
                  <span className="font-mono font-bold text-neutral-200">{formatRupiah(subtotalNominal)}</span>
                </div>
                <div className="flex items-center justify-between gap-1 text-[11px]">
                  <span className="text-neutral-400 shrink-0">Diskon / Potongan:</span>
                  <div className="w-24">
                    <input
                      type="number"
                      min="0"
                      step="1000"
                      value={diskonNominal || ''}
                      readOnly={!isSpvOrOwner}
                      onChange={(e) => setDiskonNominal(Math.max(0, parseInt(e.target.value) || 0))}
                      placeholder="0"
                      className={`w-full p-1 text-[11px] text-right rounded font-bold ${
                        isSpvOrOwner
                          ? 'bg-[#0D0D10] border border-[#26262E] text-rose-400 focus:outline-hidden focus:border-[#F27D26]'
                          : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed'
                      }`}
                    />
                  </div>
                </div>
                <div className="pt-1.5 border-t border-[#24242A] flex items-center justify-between">
                  <span className="text-[11px] font-extrabold uppercase text-orange-300">Total PO:</span>
                  <span className="text-sm font-extrabold text-orange-400 font-mono">{formatRupiah(totalNominal)}</span>
                </div>
              </div>

              {/* Section 4: 2 Signatures Box */}
              <div className="bg-[#161618] p-2.5 rounded-xl border border-[#26262B] space-y-1.5 shadow-xs">
                <div className="flex items-center justify-between">
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                    Tanda Tangan Pengesahan PO
                  </span>
                  {settings?.useStampAsSignature && settings?.stampUrl && (
                    <span className="text-[9px] font-bold text-orange-300 bg-orange-950/60 px-1.5 py-0.2 rounded border border-orange-800/60 flex items-center gap-0.5">
                      <ShieldCheck className="w-2.5 h-2.5" /> Stempel Toko Aktif
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-1.5">
                  {/* Pembuat PO */}
                  <div className="p-1.5 rounded-lg bg-[#111114] border border-[#26262E] flex flex-col justify-between">
                    <div>
                      <div className="text-[9px] font-bold text-neutral-400 uppercase">Pembuat PO</div>
                      <div className="text-[10px] font-bold truncate mt-0.5">
                        {sigAdmin ? (
                          <span className="text-emerald-400 flex items-center gap-1 font-bold">
                            <CheckCircle className="w-2.5 h-2.5 shrink-0" /> {sigAdmin.name}
                          </span>
                        ) : settings?.useStampAsSignature && settings?.stampUrl ? (
                          <span className="text-orange-300 flex items-center gap-1 text-[9px] font-bold">
                            <ShieldCheck className="w-2.5 h-2.5 text-orange-400 shrink-0" /> Stempel Toko
                          </span>
                        ) : (
                          <span className="text-neutral-500 italic text-[9.5px]">Belum Ditandatangani</span>
                        )}
                      </div>
                    </div>
                    {isSpvOrOwner && (
                      <div className="flex items-center gap-1 mt-1">
                        <button
                          type="button"
                          onClick={() => setActiveSigRole('admin')}
                          className="flex-1 py-0.5 px-1.5 text-[9px] font-bold text-orange-300 hover:bg-orange-950/60 border border-orange-800/80 rounded flex items-center justify-center gap-1 transition-colors cursor-pointer"
                        >
                          <PenTool className="w-2.5 h-2.5" /> {sigAdmin ? 'Ubah' : 'TTD'}
                        </button>
                        {settings?.stampUrl && !sigAdmin && (
                          <button
                            type="button"
                            onClick={() => {
                              setSigAdmin({
                                name: settings.brandName || currentUser.username,
                                roleTitle: 'Pembuat PO (Stempel Toko)',
                                imageDataUrl: settings.stampUrl!,
                                signedAt: new Date().toISOString(),
                              });
                            }}
                            className="py-0.5 px-1.5 text-[9px] font-bold text-orange-300 hover:bg-orange-950/60 border border-orange-800/80 rounded transition-colors cursor-pointer"
                            title="Terapkan Stempel Resmi Toko"
                          >
                            Cap
                          </button>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Pimpinan / Supervisor */}
                  <div className="p-1.5 rounded-lg bg-[#111114] border border-[#26262E] flex flex-col justify-between">
                    <div>
                      <div className="text-[9px] font-bold text-neutral-400 uppercase">Supervisor / SPV</div>
                      <div className="text-[10px] font-bold truncate mt-0.5">
                        {sigSupervisor ? (
                          <span className="text-emerald-400 flex items-center gap-1 font-bold">
                            <CheckCircle className="w-2.5 h-2.5 shrink-0" /> {sigSupervisor.name}
                          </span>
                        ) : (
                          <span className="text-neutral-500 italic text-[9.5px]">Belum Ditandatangani</span>
                        )}
                      </div>
                    </div>
                    {isSpvOrOwner && (
                      <button
                        type="button"
                        onClick={() => setActiveSigRole('supervisor')}
                        className="mt-1 py-0.5 px-1.5 text-[9px] font-bold text-orange-300 hover:bg-orange-950/60 border border-orange-800/80 rounded flex items-center justify-center gap-1 transition-colors cursor-pointer"
                      >
                        <PenTool className="w-2.5 h-2.5" /> {sigSupervisor ? 'Ubah' : 'TTD'}
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons: Batal & Simpan */}
              <div className="pt-1 flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleResetForm}
                  className="px-4 py-2.5 bg-[#1F1F24] hover:bg-[#2A2A32] text-neutral-300 hover:text-white font-bold text-xs uppercase tracking-wider rounded-xl border border-[#2E2E38] transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                  title="Kembalikan form ke default kosong"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Batal
                </button>
                {isSpvOrOwner ? (
                  <button
                    type="button"
                    onClick={handleSave}
                    className="flex-1 py-2.5 bg-[#F27D26] hover:bg-[#d96c1d] text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md shadow-[#F27D26]/30 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {isSaved ? (
                      <>
                        <CheckCircle className="w-4 h-4" /> Dokumen PO Tersimpan (Klik untuk Simpan Ulang)
                      </>
                    ) : initialDoc ? (
                      <>
                        <Edit2 className="w-4 h-4" /> Simpan Perubahan Order PO
                      </>
                    ) : (
                      'Simpan Purchase Order (PO)'
                    )}
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled
                    className="flex-1 py-2.5 bg-neutral-800 border border-neutral-700 text-neutral-400 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-not-allowed opacity-80"
                    title="Hanya SPV dan Owner yang berwenang menyimpan perubahan PO"
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-400" /> Read Only (SPV/Owner Only)
                  </button>
                )}
              </div>
            </div>

            {/* Right: Printable Dokumen Purchase Order (PO) Preview (Area Preview Sangat Luas) */}
            <div className="flex-1 bg-[#09090B] p-2 sm:p-5 overflow-y-auto flex flex-col items-center border-l border-[#202024]">
              {printStatus && (
                <div className="mb-3 w-full max-w-5xl p-2.5 bg-orange-950/80 border border-orange-700 rounded-xl text-xs text-orange-200 flex items-center justify-between animate-in fade-in">
                  <div className="flex items-center gap-2">
                    <Info className="w-4 h-4 text-orange-400 shrink-0" />
                    <span>{printStatus}</span>
                  </div>
                  <button onClick={() => setPrintStatus(null)} className="text-orange-300 hover:text-white text-xs cursor-pointer">✕</button>
                </div>
              )}

              <div ref={printableRef} className="w-full max-w-full 2xl:max-w-7xl bg-white shadow-2xl rounded-2xl overflow-hidden border border-slate-300 printable-document text-slate-900">
                {/* Header Kop PO dengan Logo Toko Terintegrasi */}
                <div
                  className="text-white p-6 flex items-start justify-between printable-header-banner"
                  style={{ backgroundColor: settings?.invoiceHeaderColor || '#F27D26' }}
                >
                  <div className="flex items-center gap-4">
                    {settings?.logoUrl ? (
                      <div className="w-16 h-16 bg-white rounded-xl p-1 shadow-md flex items-center justify-center shrink-0 overflow-hidden border border-white/30">
                        <img
                          src={settings.logoUrl}
                          alt="Logo Toko"
                          className="max-w-full max-h-full object-contain"
                        />
                      </div>
                    ) : null}
                    <div>
                      <h2 className="text-xl font-extrabold tracking-wide uppercase text-white">
                        {settings?.brandName || 'PURCHASE ORDER (PO)'}
                      </h2>
                      <p className="text-xs text-white/90 mt-0.5 font-medium">
                        {settings?.companySubtitle || 'Surat Pesanan Resmi Restok & Pembelian Bahan Kaos'}
                      </p>
                      {settings?.companyAddress && (
                        <p className="text-[10px] text-white/80 mt-1 max-w-lg leading-relaxed">
                          {settings.companyAddress}
                          {settings.companyPhone ? ` • Telp/WA: ${settings.companyPhone}` : ''}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right text-xs space-y-1">
                    <div className="doc-header-badge inline-block bg-black/35 border border-white/40 px-3 py-1.5 rounded-lg text-right shadow-sm">
                      <div className="flex items-center justify-end gap-1.5 mb-0.5">
                        <span className="text-[10px] text-white/90 block uppercase font-bold tracking-wider">
                          SURAT PESANAN PO
                        </span>
                        {statusPembayaran === 'LUNAS' ? (
                          <span className="text-[9px] font-extrabold bg-emerald-500 text-white px-1.5 py-0.2 rounded shadow-xs">
                            LUNAS
                          </span>
                        ) : statusPembayaran === 'SEBAGIAN' ? (
                          <span className="text-[9px] font-extrabold bg-amber-500 text-white px-1.5 py-0.2 rounded shadow-xs">
                            DP (SEBAGIAN)
                          </span>
                        ) : (
                          <span className="text-[9px] font-extrabold bg-rose-500 text-white px-1.5 py-0.2 rounded shadow-xs">
                            TEMPO (UTANG)
                          </span>
                        )}
                      </div>
                      <span className="font-mono font-bold text-white text-sm block">{nomorOrder}</span>
                    </div>
                    <div className="mt-1">
                      <span className="text-white/80">Tanggal Order: </span>
                      <span className="font-semibold text-white">{tanggal}</span>
                    </div>
                    {statusPembayaran !== 'LUNAS' && jatuhTempo && (
                      <div className="text-[11px] text-amber-200 font-medium">
                        <span>Jatuh Tempo: </span>
                        <strong className="font-bold text-white underline underline-offset-2">{jatuhTempo}</strong>
                      </div>
                    )}
                  </div>
                </div>

                {/* Sub-header Information Grid (Format Identik dengan Nota Sale) */}
                {(() => {
                  const selectedWarehouse = activeWarehouses.find((w) => w.GUDANG_ID === selectedGudangId);
                  const displayGudangNama = selectedWarehouse?.NAMA_GUDANG || initialDoc?.gudangNama || 'GUDANG TUJUAN';
                  const displayGudangId = selectedWarehouse?.GUDANG_ID || selectedGudangId || initialDoc?.gudangId || 'GDG';
                  const pemesanNama = initialDoc?.username || currentUser.username;

                  return (
                    <div className="p-5 border-b border-slate-200 grid grid-cols-2 gap-4 text-xs bg-slate-50/50">
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                          PEMESAN (GUDANG TUJUAN)
                        </span>
                        <div className="font-bold text-sm text-slate-900">{settings?.brandName || 'DISTRO KAOS POLOS COMBED 30S'}</div>
                        <div className="text-slate-600">
                          Unit: <strong>{displayGudangNama}</strong> ({displayGudangId}) | Pembuat: {pemesanNama}
                        </div>
                        {selectedWarehouse?.LOKASI && (
                          <div className="text-[10px] text-slate-500 mt-0.5">Lokasi: {selectedWarehouse.LOKASI}</div>
                        )}
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                          SUPPLIER / VENDOR KONVEKSI
                        </span>
                        <div className="font-bold text-sm text-slate-900">{supplier || '—'}</div>
                        <div className="text-slate-600">Kontak: {kontak || '—'}</div>
                        {alamat && (
                          <div className="text-[10px] text-slate-500 mt-0.5">Alamat: {alamat}</div>
                        )}
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                          METODE & STATUS PEMBAYARAN
                        </span>
                        <div className="flex flex-wrap items-center gap-1.5">
                          {statusPembayaran === 'PIUTANG' ? (
                            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-100 text-rose-800 font-extrabold text-xs">
                              <Clock className="w-3.5 h-3.5 text-rose-600" /> Belum Bayar (Tempo)
                            </div>
                          ) : (
                            <>
                              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-orange-100 text-orange-800 font-extrabold text-xs">
                                <CreditCard className="w-3.5 h-3.5" /> {metode || 'TRANSFER'}
                              </div>
                              {statusPembayaran === 'LUNAS' ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-extrabold text-xs">
                                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> LUNAS
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 font-extrabold text-xs">
                                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" /> DP: {formatRupiah(computedJumlahBayar)}
                                </span>
                              )}
                            </>
                          )}
                        </div>
                        {statusPembayaran !== 'LUNAS' && (
                          <div className="mt-1 text-[11px] text-rose-700 font-semibold flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-600 animate-pulse" />
                            <span>Sisa Utang: <strong className="font-mono font-bold">{formatRupiah(computedSisaPiutang)}</strong></span>
                            {jatuhTempo && (
                              <span className="text-slate-500 ml-1">· Jatuh Tempo: <strong className="text-slate-700">{jatuhTempo}</strong></span>
                            )}
                          </div>
                        )}
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                          CATATAN KHUSUS PO
                        </span>
                        <div className="font-medium text-slate-800">{catatan || '—'}</div>
                      </div>
                    </div>
                  );
                })()}

                {/* Table of Items (Persis Sama Tata Letak & Kolom dengan Sale) */}
                <div className="p-4 sm:p-6 overflow-x-auto">
                  <table className="w-full border-collapse text-xs min-w-[500px]">
                    <thead>
                      <tr className="bg-orange-50 border-b-2 border-orange-200 text-slate-700">
                        <th className="py-2.5 px-3 text-left font-bold w-10">No</th>
                        <th className="py-2.5 px-3 text-left font-bold">SKU ID</th>
                        <th className="py-2.5 px-3 text-left font-bold">Nama Produk & Varian Kaos</th>
                        <th className="py-2.5 px-3 text-center font-bold w-20">Qty (Pcs)</th>
                        <th className="py-2.5 px-3 text-right font-bold w-32">Harga Satuan</th>
                        <th className="py-2.5 px-3 text-right font-bold w-36">Subtotal</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {items.filter((item) => item.SKU_ID).length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-6 text-center text-slate-400 italic">
                            Belum ada item pesanan dipilih. Silakan pilih SKU Kaos pada form di sebelah kiri.
                          </td>
                        </tr>
                      ) : (
                        items
                          .filter((item) => item.SKU_ID)
                          .map((item, i) => {
                            const prod = products.find((p) => p.SKU_ID === item.SKU_ID);
                            const lineSubtotal =
                              item.subtotal !== undefined
                                ? item.subtotal
                                : (Number(item.jumlah) || 0) * (Number(item.hargaSatuan) || 0);

                            return (
                              <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                                <td className="py-2.5 px-3 text-slate-500 font-mono text-center">{i + 1}</td>
                                <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{item.SKU_ID}</td>
                                <td className="py-2.5 px-3">
                                  <div className="font-semibold text-slate-800">{prod?.NAMA_PRODUK || 'Kaos Polos Combed'}</div>
                                  {prod?.WARNA && (
                                    <div className="text-[10px] text-slate-500 mt-0.5">
                                      Warna: <strong>{prod.WARNA}</strong> | Ukuran: <strong>{prod.UKURAN}</strong>
                                    </div>
                                  )}
                                  {item.keterangan && (
                                    <div className="text-[10px] italic text-slate-400 mt-0.5">{item.keterangan}</div>
                                  )}
                                </td>
                                <td className="py-2.5 px-3 text-center font-extrabold text-slate-900 font-mono text-sm">
                                  {item.jumlah}
                                </td>
                                <td className="py-2.5 px-3 text-right text-slate-700 font-mono">
                                  {formatRupiah(item.hargaSatuan || 0)}
                                </td>
                                <td className="py-2.5 px-3 text-right font-bold text-orange-950 font-mono text-sm">
                                  {formatRupiah(lineSubtotal)}
                                </td>
                              </tr>
                            );
                          })
                      )}
                    </tbody>
                    <tfoot>
                      <tr className="border-t-2 border-slate-300 bg-slate-50 font-bold text-slate-800">
                        <td colSpan={3} className="py-2.5 px-3 text-right">Subtotal Pesanan PO ({totalQty} Pcs):</td>
                        <td className="py-2.5 px-3 text-center font-mono font-extrabold">{totalQty} pcs</td>
                        <td></td>
                        <td className="py-2.5 px-3 text-right font-mono text-slate-900">{formatRupiah(subtotalNominal)}</td>
                      </tr>
                      {Number(diskonNominal) > 0 && (
                        <tr className="border-t border-slate-200 bg-rose-50/50 font-bold text-rose-700">
                          <td colSpan={5} className="py-2 px-3 text-right">Potongan Diskon Supplier:</td>
                          <td className="py-2 px-3 text-right font-mono">- {formatRupiah(diskonNominal)}</td>
                        </tr>
                      )}
                      <tr className="border-t-2 border-orange-600 bg-orange-50 text-orange-950 font-extrabold text-sm">
                        <td colSpan={5} className="py-3 px-3 text-right uppercase tracking-wider">
                          TOTAL NILAI PURCHASE ORDER:
                        </td>
                        <td className="py-3 px-3 text-right font-mono text-base text-orange-900">
                          {formatRupiah(totalNominal)}
                        </td>
                      </tr>
                      {/* Rincian Status Pembayaran & Sisa Utang */}
                      <tr className="border-t border-slate-200 bg-slate-50/80 text-xs font-semibold">
                        <td colSpan={3} className="py-2.5 px-3 text-slate-700">
                          <span>Status Pembayaran: </span>
                          <span
                            className={`ml-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold inline-block ${
                              computedSisaPiutang <= 0
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                : computedJumlahBayar > 0
                                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                : 'bg-rose-100 text-rose-800 border border-rose-300'
                            }`}
                          >
                            {computedSisaPiutang <= 0
                              ? '✓ LUNAS'
                              : computedJumlahBayar > 0
                              ? 'SEBAGIAN (DP)'
                              : 'TEMPO (UTANG)'}
                          </span>
                        </td>
                        <td colSpan={2} className="py-2.5 px-3 text-right text-slate-700">
                          Sudah Dibayar / DP:
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-sm">
                          {computedJumlahBayar > 0 ? (
                            <span className="text-emerald-700">{formatRupiah(computedJumlahBayar)}</span>
                          ) : (
                            <span className="text-rose-600 font-bold">Belum Bayar (Rp 0)</span>
                          )}
                        </td>
                      </tr>
                      {computedSisaPiutang > 0 && (
                        <tr className="border-t border-rose-200 bg-rose-50/80 text-xs font-bold text-rose-800">
                          <td colSpan={3} className="py-2.5 px-3 text-rose-700">
                            Jatuh Tempo Pelunasan: <span className="font-mono">{jatuhTempo || '-'}</span>
                          </td>
                          <td colSpan={2} className="py-2.5 px-3 text-right uppercase tracking-wide">
                            Sisa Utang Belum Terbayar:
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-extrabold text-sm text-rose-700">
                            {formatRupiah(computedSisaPiutang)}
                          </td>
                        </tr>
                      )}
                    </tfoot>
                  </table>
                </div>

                {/* Terbilang Huruf */}
                <div className="mx-6 p-3 bg-orange-50/60 rounded-xl border border-orange-200 text-xs flex items-center gap-2 text-orange-950">
                  <span className="font-bold uppercase tracking-wider text-[10px] text-orange-700 shrink-0">
                    Terbilang:
                  </span>
                  <span className="italic font-medium capitalize">
                    # {terbilangRupiah(totalNominal)} Rupiah #
                  </span>
                </div>

                {/* Signatures Section in Document (Format Identik dengan Nota Sale) */}
                <div className="p-6 pt-5 grid grid-cols-2 gap-8 text-xs">
                  {/* Pembuat PO */}
                  <div className="flex flex-col items-center text-center">
                    <span className="text-slate-600 mb-1.5 font-medium">Diajukan oleh (Pembuat PO):</span>
                    <div className="w-44 h-22 border border-dashed border-slate-300 rounded-lg bg-white flex items-center justify-center relative overflow-hidden">
                      {sigAdmin ? (
                        <>
                          <img
                            src={sigAdmin.imageDataUrl}
                            alt="Tanda Tangan Pembuat"
                            className="max-h-18 max-w-[160px] object-contain"
                          />
                          <div className="absolute top-0.5 right-0.5 text-[8px] font-bold text-emerald-600 bg-emerald-50 px-1 rounded flex items-center gap-0.5">
                            <ShieldCheck className="w-2.5 h-2.5" /> Terverifikasi
                          </div>
                        </>
                      ) : settings?.useStampAsSignature && settings?.stampUrl ? (
                        <>
                          <img
                            src={settings.stampUrl}
                            alt="Stempel Resmi Toko"
                            className="max-h-18 max-w-[150px] object-contain drop-shadow-sm rotate-[-3deg]"
                          />
                          <div className="absolute top-0.5 right-0.5 text-[8px] font-bold text-orange-700 bg-orange-50 px-1 rounded flex items-center gap-0.5 border border-orange-200">
                            <ShieldCheck className="w-2.5 h-2.5 text-orange-600" /> Stempel Sah
                          </div>
                        </>
                      ) : (
                        <span className="text-[9px] text-slate-400 italic">Belum bertanda tangan</span>
                      )}
                    </div>
                    <span className="font-bold text-slate-900 mt-1 border-t border-slate-300 pt-0.5 w-36 text-[11px] truncate">
                      {sigAdmin
                        ? sigAdmin.name
                        : settings?.useStampAsSignature && settings?.stampUrl
                        ? settings.brandName || currentUser.username
                        : '( ........................................ )'}
                    </span>
                    <span className="text-[9px] text-slate-500">
                      {sigAdmin
                        ? 'Admin Pembuat PO'
                        : settings?.useStampAsSignature && settings?.stampUrl
                        ? 'Disahkan Stempel Resmi Toko'
                        : '(Belum Ditandatangani)'}
                    </span>
                  </div>

                  {/* Supervisor */}
                  <div className="flex flex-col items-center text-center">
                    <span className="text-slate-600 mb-1.5 font-medium">Disetujui oleh (Supervisor/SPV):</span>
                    <div className="w-44 h-22 border border-dashed border-slate-300 rounded-lg bg-white flex items-center justify-center relative overflow-hidden">
                      {sigSupervisor ? (
                        <>
                          <img
                            src={sigSupervisor.imageDataUrl}
                            alt="Tanda Tangan Supervisor"
                            className="max-h-18 max-w-[160px] object-contain"
                          />
                          <div className="absolute top-0.5 right-0.5 text-[8px] font-bold text-emerald-600 bg-emerald-50 px-1 rounded flex items-center gap-0.5">
                            <ShieldCheck className="w-2.5 h-2.5" /> Terverifikasi
                          </div>
                        </>
                      ) : (
                        <span className="text-[9px] text-slate-400 italic">Belum bertanda tangan</span>
                      )}
                    </div>
                    <span className="font-bold text-slate-900 mt-1 border-t border-slate-300 pt-0.5 w-36 text-[11px] truncate">
                      {sigSupervisor ? sigSupervisor.name : '( ........................................ )'}
                    </span>
                    <span className="text-[9px] text-slate-500">
                      {sigSupervisor ? 'Pimpinan / Supervisor' : '(Belum Ditandatangani)'}
                    </span>
                  </div>
                </div>

                {/* Footer Legal Stamp */}
                <div className="px-6 py-2.5 bg-slate-100 border-t border-slate-200 text-center text-[10px] text-slate-500">
                  Dokumen Purchase Order (PO) Sah Digital • Digenerate otomatis oleh Sistem Gudang Inventori Kaos Polos •{' '}
                  {new Date().toLocaleString('id-ID')}
                </div>
              </div>

              {/* Action Bar Cetak PO: Hanya tampil setelah tombol Simpan PO diklik atau saat melihat dokumen tersimpan */}
              <div className="mt-4 mb-2 flex items-center justify-center">
                {isSaved && (
                  <button
                    type="button"
                    onClick={handlePrint}
                    className="px-6 py-2.5 bg-[#F27D26] hover:bg-[#d96c1d] text-white text-xs font-bold rounded-xl shadow-lg flex items-center gap-2 transition-all cursor-pointer hover:scale-102 active:scale-98 animate-in fade-in"
                  >
                    <Printer className="w-4 h-4" /> Cetak Purchase Order (PO) / Simpan PDF
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Barcode Scanner Modal */}
      {scannerTargetRowId && isSpvOrOwner && (
        <BarcodeScannerModal
          isOpen={!!scannerTargetRowId}
          onClose={() => setScannerTargetRowId(null)}
          onScanSuccess={handleBarcodeScanned}
          title="Pindai Barcode Kaos untuk Purchase Order (PO)"
          subtitle="Arahkan kamera pada barcode label kaos atau rak gudang"
        />
      )}

      {/* Signature Modal */}
      {activeSigRole && isSpvOrOwner && (
        <DigitalSignatureModal
          isOpen={!!activeSigRole}
          onClose={() => setActiveSigRole(null)}
          settings={settings}
          defaultSignerName={activeSigRole === 'admin' ? currentUser.username : 'Supervisor Gudang'}
          roleLabel={activeSigRole === 'admin' ? 'Admin Pembuat PO' : 'Pimpinan / Supervisor'}
          onSaveSignature={(sig) => {
            if (activeSigRole === 'admin') setSigAdmin(sig);
            if (activeSigRole === 'supervisor') setSigSupervisor(sig);
          }}
        />
      )}
    </>
  );
};
