import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Users,
  CreditCard,
  Search,
  Plus,
  Edit2,
  Trash2,
  Phone,
  MapPin,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Send,
  Eye,
  ShoppingBag,
  Building2,
  Filter,
  DollarSign,
  ArrowUpRight,
  TrendingDown,
  X,
  FileSpreadsheet,
  ChevronDown,
  ChevronUp,
  Layers,
} from 'lucide-react';
import {
  Pelanggan,
  SaleDocument,
  TipePelanggan,
  User,
  AppSystemSettings,
  PembayaranPiutang,
} from '../types';
import { formatRupiah, formatNumber } from '../utils/formatters';

interface PelangganViewProps {
  customers: Pelanggan[];
  sales: SaleDocument[];
  currentUser: User;
  onSaveCustomer: (customer: Pelanggan) => void;
  onDeleteCustomer: (id: string) => void;
  onUpdateSale: (updatedSale: SaleDocument) => void;
  onOpenSaleModalWithCustomer?: (customer: Pelanggan) => void;
  onOpenSaleModalDoc?: (doc: SaleDocument) => void;
  showToast: (msg: string, type: 'success' | 'error' | 'info') => void;
  settings?: AppSystemSettings;
}

const TIPE_PELANGGAN_OPTIONS: { value: TipePelanggan; label: string; color: string }[] = [
  { value: 'DISTRO', label: 'Distro / Clothing', color: 'bg-purple-950/60 text-purple-300 border-purple-800' },
  { value: 'GROSIR', label: 'Grosir / Partai', color: 'bg-blue-950/60 text-blue-300 border-blue-800' },
  { value: 'RESELLER', label: 'Reseller', color: 'bg-amber-950/60 text-amber-300 border-amber-800' },
  { value: 'KONVEKSI', label: 'Konveksi / Sablon', color: 'bg-emerald-950/60 text-emerald-300 border-emerald-800' },
  { value: 'RITEL', label: 'Ritel / Eceran', color: 'bg-teal-950/60 text-teal-300 border-teal-800' },
  { value: 'UMUM', label: 'Umum / Walk-in', color: 'bg-neutral-800 text-neutral-300 border-neutral-700' },
];

export const PelangganView: React.FC<PelangganViewProps> = ({
  customers,
  sales,
  currentUser,
  onSaveCustomer,
  onDeleteCustomer,
  onUpdateSale,
  onOpenSaleModalWithCustomer,
  onOpenSaleModalDoc,
  showToast,
  settings,
}) => {
  const [activeTab, setActiveTab] = useState<'pelanggan' | 'piutang'>('pelanggan');

  // Customer Management States
  const [customerSearch, setCustomerSearch] = useState('');
  const [selectedTipeFilter, setSelectedTipeFilter] = useState<string>('ALL');
  const [editingCustomer, setEditingCustomer] = useState<Pelanggan | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [confirmDeleteCustomer, setConfirmDeleteCustomer] = useState<Pelanggan | null>(null);

  // Form State for Add/Edit Customer
  const [formId, setFormId] = useState('');
  const [formNama, setFormNama] = useState('');
  const [formTelepon, setFormTelepon] = useState('');
  const [formAlamat, setFormAlamat] = useState('');
  const [formKota, setFormKota] = useState('Bandung');
  const [formTipe, setFormTipe] = useState<TipePelanggan>('DISTRO');
  const [formPlafon, setFormPlafon] = useState<number>(5000000);
  const [formCatatan, setFormCatatan] = useState('');

  // Accounts Receivable States
  const [piutangSearch, setPiutangSearch] = useState('');
  const [piutangStatusFilter, setPiutangStatusFilter] = useState<'ALL' | 'PIUTANG' | 'SEBAGIAN' | 'JATUH_TEMPO' | 'LUNAS'>('ALL');
  const [selectedCustomerFilter, setSelectedCustomerFilter] = useState<string>('ALL');
  const [expandedCustomerIds, setExpandedCustomerIds] = useState<Set<string>>(new Set());

  // Toggle accordion expand/collapse
  const toggleCustomerExpanded = (customerId: string) => {
    setExpandedCustomerIds((prev) => {
      const next = new Set(prev);
      if (next.has(customerId)) {
        next.delete(customerId);
      } else {
        next.add(customerId);
      }
      return next;
    });
  };

  // Payment Recording Modal State
  const [payingSale, setPayingSale] = useState<SaleDocument | null>(null);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<string>('TUNAI');
  const [paymentDate, setPaymentDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [paymentNotes, setPaymentNotes] = useState<string>('');

  // Otorisasi: Aksi delete eksklusif untuk akun OWNER dan SPV/SUPERVISOR
  const isSpvOrOwner = Boolean(
    currentUser && (
      currentUser.role === 'OWNER' ||
      currentUser.role === 'SUPERVISOR' ||
      (currentUser.role as string) === 'SPV' ||
      currentUser.username?.toLowerCase() === 'owner' ||
      currentUser.username?.toLowerCase() === 'supervisor' ||
      currentUser.username?.toLowerCase() === 'spv'
    )
  );

  // Helper: Calculate total purchases and unpaid debt per customer
  const customerStatsMap = useMemo(() => {
    const map = new Map<string, { totalOmzet: number; totalPiutang: number; invoiceCount: number; unpaidCount: number }>();

    customers.forEach((c) => {
      map.set(c.id, { totalOmzet: 0, totalPiutang: 0, invoiceCount: 0, unpaidCount: 0 });
    });

    sales.forEach((s) => {
      // Match by pelangganId, or fallback to matching name
      let custId = s.pelangganId;
      if (!custId && s.pelanggan) {
        const found = customers.find((c) => c.nama.toLowerCase() === s.pelanggan.toLowerCase());
        if (found) custId = found.id;
      }

      if (custId && map.has(custId)) {
        const stat = map.get(custId)!;
        const totalNominal = s.totalNominal || 0;
        const sisaPiutang = s.sisaPiutang !== undefined ? s.sisaPiutang : (s.statusPembayaran === 'PIUTANG' ? totalNominal : (s.statusPembayaran === 'SEBAGIAN' ? totalNominal - (s.jumlahBayar || 0) : 0));

        stat.totalOmzet += totalNominal;
        stat.totalPiutang += Math.max(0, sisaPiutang);
        stat.invoiceCount += 1;
        if (sisaPiutang > 0) {
          stat.unpaidCount += 1;
        }
      }
    });

    return map;
  }, [customers, sales]);

  // Overall Receivables KPI Statistics
  const piutangKpi = useMemo(() => {
    let totalPiutang = 0;
    let totalTerbayar = 0;
    let countUnpaid = 0;
    let countOverdue = 0;
    let overdueNominal = 0;

    const todayStr = new Date().toISOString().split('T')[0];

    sales.forEach((s) => {
      const total = s.totalNominal || 0;
      const sisa = s.sisaPiutang !== undefined ? s.sisaPiutang : (s.statusPembayaran === 'PIUTANG' ? total : (s.statusPembayaran === 'SEBAGIAN' ? Math.max(0, total - (s.jumlahBayar || 0)) : 0));
      const terbayar = s.jumlahBayar || (total - sisa);

      totalPiutang += Math.max(0, sisa);
      totalTerbayar += Math.max(0, terbayar);

      if (sisa > 0) {
        countUnpaid += 1;
        if (s.jatuhTempo && s.jatuhTempo < todayStr) {
          countOverdue += 1;
          overdueNominal += sisa;
        }
      }
    });

    return {
      totalPiutang,
      totalTerbayar,
      countUnpaid,
      countOverdue,
      overdueNominal,
    };
  }, [sales]);

  // Jumlah pelanggan unik yang memiliki piutang aktif (sisa > 0)
  const totalCustomersWithPiutang = useMemo(() => {
    const keysWithPiutang = new Set<string>();
    sales.forEach((s) => {
      const total = s.totalNominal || 0;
      const sisa =
        s.sisaPiutang !== undefined
          ? s.sisaPiutang
          : s.statusPembayaran === 'PIUTANG'
          ? total
          : s.statusPembayaran === 'SEBAGIAN'
          ? Math.max(0, total - (s.jumlahBayar || 0))
          : 0;
      if (sisa > 0) {
        const key = s.pelangganId || (s.pelanggan ? s.pelanggan.trim().toLowerCase() : 'umum');
        keysWithPiutang.add(key);
      }
    });
    return keysWithPiutang.size;
  }, [sales]);

  // Filtered Customers
  const filteredCustomers = useMemo(() => {
    return customers.filter((c) => {
      if (selectedTipeFilter !== 'ALL' && c.tipe !== selectedTipeFilter) return false;
      if (customerSearch) {
        const q = customerSearch.toLowerCase();
        const matchId = c.id.toLowerCase().includes(q);
        const matchNama = c.nama.toLowerCase().includes(q);
        const matchTelepon = c.telepon.toLowerCase().includes(q);
        const matchKota = c.kota?.toLowerCase().includes(q) || false;
        const matchAlamat = c.alamat?.toLowerCase().includes(q) || false;
        if (!matchId && !matchNama && !matchTelepon && !matchKota && !matchAlamat) {
          return false;
        }
      }
      return true;
    });
  }, [customers, selectedTipeFilter, customerSearch]);

  // Filtered Receivables Invoices (Daftar Piutang)
  const filteredReceivables = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];

    return sales
      .filter((s) => {
        const total = s.totalNominal || 0;
        const sisa = s.sisaPiutang !== undefined ? s.sisaPiutang : (s.statusPembayaran === 'PIUTANG' ? total : (s.statusPembayaran === 'SEBAGIAN' ? Math.max(0, total - (s.jumlahBayar || 0)) : 0));
        const isOverdue = s.jatuhTempo && s.jatuhTempo < todayStr && sisa > 0;

        // Status Filter
        if (piutangStatusFilter === 'PIUTANG' && (sisa <= 0 || s.jumlahBayar && s.jumlahBayar > 0)) return false;
        if (piutangStatusFilter === 'SEBAGIAN' && (sisa <= 0 || !s.jumlahBayar || s.jumlahBayar === 0)) return false;
        if (piutangStatusFilter === 'JATUH_TEMPO' && !isOverdue) return false;
        if (piutangStatusFilter === 'LUNAS' && sisa > 0) return false;
        if (piutangStatusFilter === 'ALL' && sisa <= 0) return false; // Default: show only invoices with outstanding debt

        // Customer Filter
        if (selectedCustomerFilter !== 'ALL') {
          if (s.pelangganId !== selectedCustomerFilter && s.pelanggan !== selectedCustomerFilter) {
            return false;
          }
        }

        // Search Filter
        if (piutangSearch) {
          const q = piutangSearch.toLowerCase();
          const matchNo = s.nomorSale.toLowerCase().includes(q);
          const matchPel = s.pelanggan.toLowerCase().includes(q);
          const matchKontak = s.kontak?.toLowerCase().includes(q) || false;
          if (!matchNo && !matchPel && !matchKontak) return false;
        }

        return true;
      })
      .sort((a, b) => {
        // Sort by overdue first, then by date descending
        const today = new Date().toISOString().split('T')[0];
        const aSisa = a.sisaPiutang ?? 0;
        const bSisa = b.sisaPiutang ?? 0;
        const aOverdue = a.jatuhTempo && a.jatuhTempo < today && aSisa > 0;
        const bOverdue = b.jatuhTempo && b.jatuhTempo < today && bSisa > 0;
        if (aOverdue && !bOverdue) return -1;
        if (!aOverdue && bOverdue) return 1;
        return new Date(b.tanggal).getTime() - new Date(a.tanggal).getTime();
      });
  }, [sales, piutangStatusFilter, selectedCustomerFilter, piutangSearch]);

  // Grouped Receivables by Customer (Akumulasi per Pelanggan)
  // Menjamin jika no. hape, alamat, atau pengejaan nama diubah di master pelanggan,
  // seluruh transaksi tetap terkumpul rapi di bawah pelanggan yang sama tanpa terpisah/double!
  const groupedReceivables = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const groupMap = new Map<string, {
      customerId: string;
      customerName: string;
      customerPhone: string;
      customerAddress: string;
      customerCity: string;
      customerType: TipePelanggan;
      plafonPiutang: number;
      invoices: SaleDocument[];
      totalNilaiFaktur: number;
      totalSudahDibayar: number;
      totalSisaPiutang: number;
      unpaidCount: number;
      nearestJatuhTempo?: string;
      hasOverdue: boolean;
      overdueCount: number;
    }>();

    filteredReceivables.forEach((sale) => {
      // Find customer in master data by ID first, then fallback to name
      let cust = customers.find((c) => c.id === sale.pelangganId);
      if (!cust && sale.pelanggan) {
        cust = customers.find((c) => c.nama.trim().toLowerCase() === sale.pelanggan.trim().toLowerCase());
      }

      // Group key: if registered customer, use their ID (guarantees edits to name/phone/address never split or duplicate)
      const groupKey = cust ? cust.id : `UNREG-${(sale.pelanggan || 'Umum').trim().toLowerCase()}`;

      const total = sale.totalNominal || 0;
      const sisa = sale.sisaPiutang !== undefined ? sale.sisaPiutang : (sale.statusPembayaran === 'PIUTANG' ? total : (sale.statusPembayaran === 'SEBAGIAN' ? Math.max(0, total - (sale.jumlahBayar || 0)) : 0));
      const terbayar = sale.jumlahBayar || (total - sisa);
      const isOverdue = Boolean(sale.jatuhTempo && sale.jatuhTempo < today && sisa > 0);

      if (!groupMap.has(groupKey)) {
        groupMap.set(groupKey, {
          customerId: cust ? cust.id : groupKey,
          customerName: cust ? cust.nama : sale.pelanggan,
          customerPhone: cust ? cust.telepon : (sale.kontak || '-'),
          customerAddress: cust ? (cust.alamat || cust.kota || '') : (sale.alamat || ''),
          customerCity: cust ? (cust.kota || '') : '',
          customerType: cust ? cust.tipe : 'UMUM',
          plafonPiutang: cust ? cust.plafonPiutang : 0,
          invoices: [],
          totalNilaiFaktur: 0,
          totalSudahDibayar: 0,
          totalSisaPiutang: 0,
          unpaidCount: 0,
          nearestJatuhTempo: undefined,
          hasOverdue: false,
          overdueCount: 0,
        });
      }

      const grp = groupMap.get(groupKey)!;
      grp.invoices.push(sale);
      grp.totalNilaiFaktur += total;
      grp.totalSudahDibayar += terbayar;
      grp.totalSisaPiutang += Math.max(0, sisa);
      if (sisa > 0) {
        grp.unpaidCount += 1;
      }
      if (isOverdue) {
        grp.hasOverdue = true;
        grp.overdueCount += 1;
      }
      if (sale.jatuhTempo && sisa > 0) {
        if (!grp.nearestJatuhTempo || sale.jatuhTempo < grp.nearestJatuhTempo) {
          grp.nearestJatuhTempo = sale.jatuhTempo;
        }
      }
    });

    // Sort by hasOverdue first, then by totalSisaPiutang descending
    return Array.from(groupMap.values()).sort((a, b) => {
      if (a.hasOverdue && !b.hasOverdue) return -1;
      if (!a.hasOverdue && b.hasOverdue) return 1;
      return b.totalSisaPiutang - a.totalSisaPiutang;
    });
  }, [filteredReceivables, customers]);

  // Open Modal for New Customer
  const handleAddNewCustomer = () => {
    // Generate next ID
    const maxNum = customers.reduce((max, c) => {
      const match = c.id.match(/CUST-(\d+)/);
      if (match) {
        const num = parseInt(match[1], 10);
        return num > max ? num : max;
      }
      return max;
    }, 0);
    const newId = `CUST-${String(maxNum + 1).padStart(3, '0')}`;

    setEditingCustomer(null);
    setFormId(newId);
    setFormNama('');
    setFormTelepon('');
    setFormAlamat('');
    setFormKota('Bandung');
    setFormTipe('DISTRO');
    setFormPlafon(5000000);
    setFormCatatan('');
    setIsModalOpen(true);
  };

  // Open Modal for Editing Customer
  const handleEditCustomer = (cust: Pelanggan) => {
    setEditingCustomer(cust);
    setFormId(cust.id);
    setFormNama(cust.nama);
    setFormTelepon(cust.telepon);
    setFormAlamat(cust.alamat || '');
    setFormKota(cust.kota || 'Bandung');
    setFormTipe(cust.tipe);
    setFormPlafon(cust.plafonPiutang !== undefined ? cust.plafonPiutang : 5000000);
    setFormCatatan(cust.catatan || '');
    setIsModalOpen(true);
  };

  // Submit Customer Form
  const handleSubmitCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNama.trim()) {
      showToast('Nama pelanggan wajib diisi', 'error');
      return;
    }

    const newCustomer: Pelanggan = {
      id: formId,
      nama: formNama.trim(),
      telepon: formTelepon.trim() || '-',
      alamat: formAlamat.trim() || undefined,
      kota: formKota.trim() || undefined,
      tipe: formTipe,
      plafonPiutang: Number(formPlafon) || 0,
      catatan: formCatatan.trim() || undefined,
      createdAt: editingCustomer?.createdAt || new Date().toISOString(),
    };

    onSaveCustomer(newCustomer);
    setIsModalOpen(false);
    showToast(
      editingCustomer
        ? `Data pelanggan "${newCustomer.nama}" berhasil diperbarui`
        : `Pelanggan baru "${newCustomer.nama}" berhasil ditambahkan`,
      'success'
    );
  };

  // Open Payment Modal for a specific sale
  const handleOpenPaymentModal = (sale: SaleDocument) => {
    const total = sale.totalNominal || 0;
    const sisa = sale.sisaPiutang !== undefined ? sale.sisaPiutang : (sale.statusPembayaran === 'PIUTANG' ? total : (sale.statusPembayaran === 'SEBAGIAN' ? Math.max(0, total - (sale.jumlahBayar || 0)) : 0));

    setPayingSale(sale);
    setPaymentAmount(sisa); // default full remaining payment
    setPaymentMethod('TUNAI');
    setPaymentDate(new Date().toISOString().split('T')[0]);
    setPaymentNotes('');
  };

  // Submit Payment Record
  const handleRecordPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payingSale) return;

    const amount = Number(paymentAmount) || 0;
    if (amount <= 0) {
      showToast('Nominal pelunasan harus lebih besar dari 0', 'error');
      return;
    }

    const currentTotal = payingSale.totalNominal || 0;
    const currentPaid = payingSale.jumlahBayar || 0;
    const currentSisa = payingSale.sisaPiutang !== undefined ? payingSale.sisaPiutang : Math.max(0, currentTotal - currentPaid);

    if (amount > currentSisa) {
      showToast(`Nominal pembayaran melebihi sisa piutang (${formatRupiah(currentSisa)})`, 'error');
      return;
    }

    const newPaidTotal = currentPaid + amount;
    const newSisa = Math.max(0, currentTotal - newPaidTotal);
    const newStatus: 'LUNAS' | 'SEBAGIAN' | 'PIUTANG' = newSisa <= 0 ? 'LUNAS' : 'SEBAGIAN';

    const newPaymentRecord: PembayaranPiutang = {
      id: `PAY-${Date.now().toString().slice(-6)}`,
      tanggal: paymentDate,
      jumlahBayar: amount,
      metode: paymentMethod,
      catatan: paymentNotes.trim() || (newSisa <= 0 ? 'Pelunasan penuh tagihan' : 'Pembayaran cicilan'),
      kasir: currentUser.username,
      createdAt: new Date().toISOString(),
    };

    const updatedSale: SaleDocument = {
      ...payingSale,
      statusPembayaran: newStatus,
      jumlahBayar: newPaidTotal,
      sisaPiutang: newSisa,
      riwayatPelunasan: [...(payingSale.riwayatPelunasan || []), newPaymentRecord],
    };

    onUpdateSale(updatedSale);
    setPayingSale(null);
    showToast(
      newSisa <= 0
        ? `Pembayaran ${formatRupiah(amount)} dicatat. Faktur ${payingSale.nomorSale} kini LUNAS! 🎉`
        : `Pembayaran cicilan ${formatRupiah(amount)} dicatat. Sisa piutang: ${formatRupiah(newSisa)}`,
      'success'
    );
  };

  // Generate WhatsApp Message for Debt Reminder
  const handleSendWhatsAppReminder = (sale: SaleDocument) => {
    const rawPhone = sale.kontak ? sale.kontak.replace(/[^0-9]/g, '') : '';
    let waPhone = rawPhone;
    if (waPhone.startsWith('0')) {
      waPhone = '62' + waPhone.slice(1);
    }

    if (!waPhone) {
      showToast('Nomor WhatsApp pelanggan tidak valid', 'error');
      return;
    }

    const sisa = sale.sisaPiutang ?? (sale.totalNominal || 0);
    const brand = settings?.brandName || 'Distro Kaos Polos';
    const message = encodeURIComponent(
      `Halo Kak *${sale.pelanggan}*,\n\nSalam dari *${brand}*.\nKami mengonfirmasi tagihan faktur belanja kaos polos:\n• No. Faktur: *${sale.nomorSale}*\n• Tanggal: *${sale.tanggal}*\n• Sisa Piutang: *${formatRupiah(sisa)}*\n• Jatuh Tempo: *${sale.jatuhTempo || '-'}*\n\nMohon konfirmasinya untuk rencana pelunasan via transfer atau tunai. Terima kasih banyak atas kerjasamanya! 🙏`
    );

    const waUrl = `https://wa.me/${waPhone}?text=${message}`;
    window.open(waUrl, '_blank');
  };

  // Generate WhatsApp Message for Accumulated Grouped Customer Debt Reminder
  const handleSendGroupedWhatsAppReminder = (group: {
    customerId: string;
    customerName: string;
    customerPhone: string;
    invoices: SaleDocument[];
    totalSisaPiutang: number;
    nearestJatuhTempo?: string;
  }) => {
    const rawPhone = group.customerPhone ? group.customerPhone.replace(/[^0-9]/g, '') : '';
    let waPhone = rawPhone;
    if (waPhone.startsWith('0')) {
      waPhone = '62' + waPhone.slice(1);
    }

    if (!waPhone) {
      showToast('Nomor WhatsApp pelanggan tidak valid', 'error');
      return;
    }

    const brand = settings?.brandName || 'Distro Kaos Polos';
    const invoiceList = group.invoices
      .map((inv) => {
        const sisa = inv.sisaPiutang !== undefined ? inv.sisaPiutang : Math.max(0, (inv.totalNominal || 0) - (inv.jumlahBayar || 0));
        return `• *${inv.nomorSale}* (${inv.tanggal}) - Sisa: ${formatRupiah(sisa)}${inv.jatuhTempo ? ` (Jatuh tempo: ${inv.jatuhTempo})` : ''}`;
      })
      .join('\n');

    const message = encodeURIComponent(
      `Halo Kak *${group.customerName}*,\n\nSalam dari *${brand}*.\nKami mengonfirmasi akumulasi tagihan piutang belanja kaos polos Anda:\n\n• *Total Sisa Piutang: ${formatRupiah(group.totalSisaPiutang)}*\n• *Jumlah Tagihan: ${group.invoices.length} Faktur*\n\nRincian Faktur Belum Lunas:\n${invoiceList}\n\nMohon konfirmasinya untuk rencana pelunasan via transfer atau tunai. Terima kasih banyak atas kerjasamanya! 🙏`
    );

    const waUrl = `https://wa.me/${waPhone}?text=${message}`;
    window.open(waUrl, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* View Header with Sub-tabs (Pelanggan vs Piutang) */}
      <div className="bg-[#161618] rounded-2xl border border-[#26262B] p-4 sm:p-5 shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-purple-950/60 border border-purple-800/60 flex items-center justify-center text-purple-400 shrink-0 shadow-sm">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-white flex items-center gap-2">
              Kelola Pelanggan & Buku Piutang
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-900/60 border border-purple-700 text-purple-300 font-mono font-bold">
                {customers.length} Pelanggan
              </span>
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Master data konsumen grosir/distro, pengaturan plafon kredit, dan tracking penagihan piutang belum lunas
            </p>
          </div>
        </div>

        {/* Tab Switcher & Quick Add Button */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="bg-[#0F0F10] p-1 rounded-xl border border-[#26262B] flex items-center">
            <button
              type="button"
              onClick={() => setActiveTab('pelanggan')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'pelanggan'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" /> Daftar Pelanggan
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('piutang')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'piutang'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" /> Buku Piutang
              {totalCustomersWithPiutang > 0 && (
                <span className="ml-1 px-1.5 py-0.2 bg-rose-500 text-white rounded-full text-[10px] font-extrabold">
                  {totalCustomersWithPiutang}
                </span>
              )}
            </button>
          </div>

          {activeTab === 'pelanggan' && isSpvOrOwner && (
            <button
              type="button"
              onClick={handleAddNewCustomer}
              className="px-3.5 py-2 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Tambah Pelanggan
            </button>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: KELOLA PELANGGAN */}
      {/* ========================================================================= */}
      {activeTab === 'pelanggan' && (
        <motion.div
          key="tab-pelanggan"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          className="space-y-4"
        >
          {/* Summary Mini Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="bg-[#161618] rounded-xl p-3.5 border border-[#26262B]">
              <span className="text-[10px] uppercase font-bold text-neutral-400 block tracking-wider">Total Pelanggan</span>
              <span className="text-xl font-extrabold text-white mt-1 block">{customers.length} Orang/Toko</span>
              <span className="text-[11px] text-neutral-500 mt-0.5 block">Distro, grosir, sablon & reseller</span>
            </div>
            <div className="bg-[#161618] rounded-xl p-3.5 border border-[#26262B]">
              <span className="text-[10px] uppercase font-bold text-neutral-400 block tracking-wider">Pelanggan Berpiutang</span>
              <span className="text-xl font-extrabold text-amber-400 mt-1 block">
                {(Array.from(customerStatsMap.values()) as { totalOmzet: number; totalPiutang: number }[]).filter((s) => s.totalPiutang > 0).length} Konsumen
              </span>
              <span className="text-[11px] text-amber-400/80 mt-0.5 block">Memiliki tagihan aktif</span>
            </div>
            <div className="bg-[#161618] rounded-xl p-3.5 border border-[#26262B]">
              <span className="text-[10px] uppercase font-bold text-neutral-400 block tracking-wider">Total Piutang Berjalan</span>
              <span className="text-xl font-extrabold text-rose-400 mt-1 block">
                {formatRupiah(piutangKpi.totalPiutang)}
              </span>
              <span className="text-[11px] text-rose-400/80 mt-0.5 block">Belum dibayar oleh pembeli</span>
            </div>
            <div className="bg-[#161618] rounded-xl p-3.5 border border-[#26262B]">
              <span className="text-[10px] uppercase font-bold text-neutral-400 block tracking-wider">Akumulasi Penjualan</span>
              <span className="text-xl font-extrabold text-emerald-400 mt-1 block">
                {formatRupiah(
                  (Array.from(customerStatsMap.values()) as { totalOmzet: number; totalPiutang: number }[]).reduce(
                    (sum: number, s) => sum + s.totalOmzet,
                    0
                  )
                )}
              </span>
              <span className="text-[11px] text-emerald-400/80 mt-0.5 block">Gross sales seluruh pelanggan</span>
            </div>
          </div>

          {/* Customer Table Container */}
          <div className="bg-[#161618] rounded-2xl border border-[#26262B] shadow-xs overflow-hidden">
            {/* Filter Bar */}
            <div className="p-4 border-b border-[#24242A] flex flex-wrap items-center justify-between gap-3 bg-[#121214]">
              <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
                <div className="relative flex-1 max-w-sm">
                  <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={customerSearch}
                    onChange={(e) => setCustomerSearch(e.target.value)}
                    placeholder="🔍 Cari nama, ID, nomor WA, kota..."
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-purple-500 focus:outline-hidden"
                  />
                </div>

                <select
                  value={selectedTipeFilter}
                  onChange={(e) => setSelectedTipeFilter(e.target.value)}
                  className="p-1.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-200 focus:border-purple-500 focus:outline-hidden font-medium"
                >
                  <option value="ALL">Semua Kategori Pelanggan</option>
                  {TIPE_PELANGGAN_OPTIONS.map((t) => (
                    <option key={t.value} value={t.value}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="text-xs text-neutral-400">
                Menampilkan <strong className="text-neutral-200">{filteredCustomers.length}</strong> dari {customers.length} pelanggan
              </div>
            </div>

            {/* Customers Table */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-xs min-w-[780px]">
                <thead>
                  <tr className="border-b border-[#24242A] bg-[#121214] text-neutral-400 font-bold uppercase tracking-wider text-[10px]">
                    <th className="py-3 px-4 text-left">ID & Nama Pelanggan</th>
                    <th className="py-3 px-4 text-left">Kategori</th>
                    <th className="py-3 px-4 text-left">Kontak & Lokasi</th>
                    <th className="py-3 px-4 text-right">Plafon Kredit</th>
                    <th className="py-3 px-4 text-right">Sisa Piutang</th>
                    <th className="py-3 px-4 text-right">Total Belanja</th>
                    <th className="py-3 px-4 text-center">Faktur</th>
                    <th className="py-3 px-4 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#24242A]">
                  {filteredCustomers.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-neutral-500">
                        <Users className="w-8 h-8 mx-auto mb-2 opacity-40 text-neutral-400" />
                        <p className="font-bold text-sm text-neutral-300">Tidak ada pelanggan yang cocok</p>
                        <p className="text-xs mt-1 text-neutral-500">Gunakan kata kunci lain atau tambahkan pelanggan baru</p>
                      </td>
                    </tr>
                  ) : (
                    filteredCustomers.map((cust) => {
                      const stats = customerStatsMap.get(cust.id) || { totalOmzet: 0, totalPiutang: 0, invoiceCount: 0, unpaidCount: 0 };
                      const tipeBadge = TIPE_PELANGGAN_OPTIONS.find((t) => t.value === cust.tipe) || TIPE_PELANGGAN_OPTIONS[5];
                      const plafon = cust.plafonPiutang || 0;
                      const isOverLimit = plafon > 0 && stats.totalPiutang > plafon;

                      return (
                        <tr key={cust.id} className="hover:bg-[#1A1A1E] transition-colors">
                          {/* Nama & ID */}
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 rounded-lg bg-[#202026] flex items-center justify-center font-bold text-purple-400 border border-[#2B2B32] shrink-0 text-xs">
                                {cust.nama.charAt(0).toUpperCase()}
                              </div>
                              <div>
                                <div className="font-bold text-neutral-100 flex items-center gap-1.5">
                                  <span>{cust.nama}</span>
                                </div>
                                <span className="font-mono text-[10px] text-neutral-400 block">{cust.id}</span>
                              </div>
                            </div>
                          </td>

                          {/* Kategori Pelanggan */}
                          <td className="py-3 px-4">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${tipeBadge.color}`}>
                              {tipeBadge.label}
                            </span>
                          </td>

                          {/* Kontak & Lokasi */}
                          <td className="py-3 px-4">
                            <div className="space-y-0.5">
                              {cust.telepon && cust.telepon !== '-' ? (
                                <a
                                  href={`https://wa.me/${cust.telepon.replace(/[^0-9]/g, '').replace(/^0/, '62')}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-emerald-400 hover:text-emerald-300 font-mono flex items-center gap-1 text-[11px] group"
                                  title="Chat WhatsApp"
                                >
                                  <Phone className="w-3 h-3 group-hover:scale-110 transition-transform" />
                                  <span>{cust.telepon}</span>
                                </a>
                              ) : (
                                <span className="text-neutral-500 text-[11px]">-</span>
                              )}
                              {(cust.kota || cust.alamat) && (
                                <div className="text-[10px] text-neutral-400 flex items-center gap-1 truncate max-w-[200px]" title={`${cust.alamat || ''} ${cust.kota || ''}`}>
                                  <MapPin className="w-2.5 h-2.5 shrink-0 text-neutral-500" />
                                  <span className="truncate">{cust.kota || cust.alamat}</span>
                                </div>
                              )}
                            </div>
                          </td>

                          {/* Plafon Kredit */}
                          <td className="py-3 px-4 text-right">
                            <span className="font-mono font-semibold text-neutral-300">
                              {plafon > 0 ? formatRupiah(plafon) : <span className="text-neutral-500">Tidak Dibatasi</span>}
                            </span>
                          </td>

                          {/* Sisa Piutang Aktif */}
                          <td className="py-3 px-4 text-right">
                            {stats.totalPiutang > 0 ? (
                              <div>
                                <span className="font-mono font-extrabold text-rose-400 text-sm">
                                  {formatRupiah(stats.totalPiutang)}
                                </span>
                                {isOverLimit && (
                                  <span className="block text-[9px] font-bold text-rose-300 bg-rose-950/80 border border-rose-800 rounded px-1 mt-0.5">
                                    ⚠️ Melebihi Plafon!
                                  </span>
                                )}
                              </div>
                            ) : (
                              <span className="text-emerald-400 font-semibold text-xs flex items-center justify-end gap-1">
                                <CheckCircle2 className="w-3 h-3" /> Lunas (Rp 0)
                              </span>
                            )}
                          </td>

                          {/* Total Belanja */}
                          <td className="py-3 px-4 text-right font-mono font-bold text-neutral-200">
                            {formatRupiah(stats.totalOmzet)}
                          </td>

                          {/* Jumlah Faktur */}
                          <td className="py-3 px-4 text-center">
                            <span className="px-2 py-0.5 rounded-full bg-[#1C1C22] border border-[#2B2B32] font-mono text-neutral-300 text-[11px]">
                              {stats.invoiceCount} nota
                            </span>
                          </td>

                          {/* Aksi */}
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {onOpenSaleModalWithCustomer && (
                                <button
                                  type="button"
                                  onClick={() => onOpenSaleModalWithCustomer(cust)}
                                  className="p-1.5 bg-purple-950/60 hover:bg-purple-900 border border-purple-800 text-purple-300 rounded-lg transition-colors cursor-pointer"
                                  title="Buat Transaksi Penjualan untuk Pelanggan Ini"
                                >
                                  <ShoppingBag className="w-3.5 h-3.5" />
                                </button>
                              )}

                              <button
                                type="button"
                                onClick={() => handleEditCustomer(cust)}
                                className="p-1.5 bg-[#1C1C20] hover:bg-[#28282E] border border-[#2B2B32] text-neutral-300 hover:text-white rounded-lg transition-colors cursor-pointer"
                                title="Edit Data Pelanggan"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>

                              {isSpvOrOwner ? (
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (stats.totalPiutang > 0) {
                                      showToast(`Tidak dapat menghapus pelanggan "${cust.nama}" karena masih memiliki piutang aktif sebesar ${formatRupiah(stats.totalPiutang)}. Lunasi piutang terlebih dahulu.`, 'error');
                                      return;
                                    }
                                    setConfirmDeleteCustomer(cust);
                                  }}
                                  className="p-1.5 bg-[#1C1C20] hover:bg-rose-950/60 border border-[#2B2B32] text-neutral-400 hover:text-rose-400 rounded-lg transition-colors cursor-pointer"
                                  title="Hapus Pelanggan (Akses Owner & SPV)"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  disabled
                                  className="p-1.5 bg-neutral-900/40 border border-neutral-800/80 text-neutral-600 rounded-lg cursor-not-allowed opacity-35 select-none"
                                  title="Aksi Hapus Terkunci (Hanya untuk Owner & SPV)"
                                >
                                  <Trash2 className="w-3.5 h-3.5 text-neutral-600" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: BUKU PIUTANG & PELUNASAN (ACCOUNTS RECEIVABLE) */}
      {/* ========================================================================= */}
      {activeTab === 'piutang' && (
        <motion.div
          key="tab-piutang"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          className="space-y-4"
        >
          {/* Receivables KPI Overview Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="bg-[#161618] rounded-xl p-4 border border-[#26262B] shadow-xs">
              <span className="text-[10px] uppercase font-bold text-neutral-400 block tracking-wider">Total Piutang Belum Lunas</span>
              <span className="text-xl sm:text-2xl font-extrabold text-rose-400 mt-1 block leading-tight">
                {formatRupiah(piutangKpi.totalPiutang)}
              </span>
              <span className="text-[11px] text-neutral-400 mt-1 block">
                Dari <strong className="text-rose-300">{piutangKpi.countUnpaid} faktur</strong> penjualan
              </span>
            </div>

            <div className="bg-[#161618] rounded-xl p-4 border border-rose-900/40 bg-rose-950/20 shadow-xs">
              <span className="text-[10px] uppercase font-bold text-rose-300 block tracking-wider flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 text-rose-400" /> Lewat Jatuh Tempo (Overdue)
              </span>
              <span className="text-xl sm:text-2xl font-extrabold text-rose-300 mt-1 block leading-tight">
                {formatRupiah(piutangKpi.overdueNominal)}
              </span>
              <span className="text-[11px] text-rose-400 mt-1 block">
                {piutangKpi.countOverdue} faktur perlu ditagih segera
              </span>
            </div>

            <div className="bg-[#161618] rounded-xl p-4 border border-[#26262B] shadow-xs">
              <span className="text-[10px] uppercase font-bold text-neutral-400 block tracking-wider">Total Pembayaran Masuk</span>
              <span className="text-xl sm:text-2xl font-extrabold text-emerald-400 mt-1 block leading-tight">
                {formatRupiah(piutangKpi.totalTerbayar)}
              </span>
              <span className="text-[11px] text-emerald-400/80 mt-1 block">
                DP dan pelunasan cicilan kasir
              </span>
            </div>

            <div className="bg-[#161618] rounded-xl p-4 border border-[#26262B] shadow-xs">
              <span className="text-[10px] uppercase font-bold text-neutral-400 block tracking-wider">Persentase Terkoleksi</span>
              <span className="text-xl sm:text-2xl font-extrabold text-purple-400 mt-1 block leading-tight">
                {piutangKpi.totalPiutang + piutangKpi.totalTerbayar > 0
                  ? Math.round((piutangKpi.totalTerbayar / (piutangKpi.totalPiutang + piutangKpi.totalTerbayar)) * 100)
                  : 100}%
              </span>
              <span className="text-[11px] text-neutral-400 mt-1 block">
                Collection recovery rate
              </span>
            </div>
          </div>

          {/* Table Container */}
          <div className="bg-[#161618] rounded-2xl border border-[#26262B] shadow-xs overflow-hidden">
            {/* Filter Bar */}
            <div className="p-4 border-b border-[#24242A] flex flex-wrap items-center justify-between gap-3 bg-[#121214]">
              <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
                <div className="relative flex-1 max-w-sm">
                  <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={piutangSearch}
                    onChange={(e) => setPiutangSearch(e.target.value)}
                    placeholder="🔍 Cari No. Faktur atau Nama Pelanggan..."
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-purple-500 focus:outline-hidden"
                  />
                </div>

                <select
                  value={piutangStatusFilter}
                  onChange={(e) => setPiutangStatusFilter(e.target.value as any)}
                  className="p-1.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-200 focus:border-purple-500 focus:outline-hidden font-medium"
                >
                  <option value="ALL">Semua Piutang Aktif</option>
                  <option value="PIUTANG">Belum Ada Pembayaran (Tempo 100%)</option>
                  <option value="SEBAGIAN">Sebagian (Sudah Bayar DP / Cicil)</option>
                  <option value="JATUH_TEMPO">⚠️ Lewat Jatuh Tempo (Overdue)</option>
                  <option value="LUNAS">Sudah Lunas</option>
                </select>

                <select
                  value={selectedCustomerFilter}
                  onChange={(e) => setSelectedCustomerFilter(e.target.value)}
                  className="p-1.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-200 focus:border-purple-500 focus:outline-hidden font-medium"
                >
                  <option value="ALL">Semua Pelanggan</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.nama} ({c.id})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2">
                <div className="px-3 py-1.5 bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-xs text-neutral-300 flex items-center gap-2 shadow-inner">
                  <Layers className="w-3.5 h-3.5 text-purple-400" />
                  <span>
                    <strong className="text-white font-bold">{groupedReceivables.length}</strong> pelanggan memiliki piutang
                  </span>
                </div>
              </div>
            </div>

            {/* Informasi Akumulasi & Jaminan Integritas Data */}
            <div className="px-4 py-2.5 bg-[#141418] border-b border-[#24242A] flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 text-purple-300">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span className="font-semibold text-[11px]">
                  Akumulasi Otomatis per Pelanggan Aktif: Seluruh faktur terkumpul rapi per nama & identitas pelanggan.
                </span>
              </div>
              <span className="text-[10.5px] text-neutral-400 font-medium">
                🛡️ Perubahan No. HP, Alamat, atau Ejaan Nama di master otomatis sinkron ke transaksi (tidak akan terpisah / dobel).
              </span>
            </div>

            {/* TABEL: AKUMULASI PER PELANGGAN (ACCUMULATED PER CUSTOMER) */}
            <div className="overflow-x-auto">
                <table className="w-full border-collapse text-xs min-w-[850px]">
                  <thead>
                    <tr className="border-b border-[#24242A] bg-[#121214] text-neutral-400 font-bold uppercase tracking-wider text-[10px]">
                      <th className="py-3 px-4 text-left">Pelanggan & Kontak</th>
                      <th className="py-3 px-4 text-center">Faktur Belum Lunas</th>
                      <th className="py-3 px-4 text-right">Total Nilai Tagihan</th>
                      <th className="py-3 px-4 text-right">Sudah Dibayar</th>
                      <th className="py-3 px-4 text-right">Total Sisa Piutang</th>
                      <th className="py-3 px-4 text-center">Jatuh Tempo Terdekat</th>
                      <th className="py-3 px-4 text-center">Status Piutang</th>
                      <th className="py-3 px-4 text-right">Aksi Pelunasan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#24242A]">
                    {groupedReceivables.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-12 text-center text-neutral-500">
                          <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-emerald-400/60" />
                          <p className="font-bold text-sm text-neutral-300">Tidak ada piutang aktif pada filter ini</p>
                          <p className="text-xs mt-1 text-neutral-500">Semua pelanggan telah melunasi tagihannya</p>
                        </td>
                      </tr>
                    ) : (
                      groupedReceivables.map((grp) => {
                        const isExpanded = expandedCustomerIds.has(grp.customerId);
                        const isOverdue = grp.hasOverdue;

                        return (
                          <React.Fragment key={grp.customerId}>
                            <tr
                              className={`transition-colors cursor-pointer ${
                                isExpanded ? 'bg-[#18181D]' : 'hover:bg-[#1A1A1E]'
                              }`}
                              onClick={() => toggleCustomerExpanded(grp.customerId)}
                            >
                              {/* Pelanggan & Kontak */}
                              <td className="py-3 px-4">
                                <div className="flex items-start gap-2">
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      toggleCustomerExpanded(grp.customerId);
                                    }}
                                    className="mt-0.5 p-1 rounded-md bg-[#202026] hover:bg-purple-950/80 text-neutral-300 hover:text-purple-300 transition-colors"
                                    title={isExpanded ? 'Tutup Rincian' : 'Buka Rincian Faktur'}
                                  >
                                    {isExpanded ? (
                                      <ChevronUp className="w-3.5 h-3.5" />
                                    ) : (
                                      <ChevronDown className="w-3.5 h-3.5" />
                                    )}
                                  </button>
                                  <div>
                                    <div className="flex items-center gap-1.5">
                                      <strong className="text-neutral-100 text-xs sm:text-sm font-bold">
                                        {grp.customerName}
                                      </strong>
                                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#202026] text-neutral-300 border border-[#2B2B32]">
                                        {grp.customerId}
                                      </span>
                                    </div>
                                    <div className="text-[11px] text-neutral-400 flex items-center gap-2 mt-0.5 font-mono">
                                      <span>📞 {grp.customerPhone}</span>
                                      {grp.customerCity && <span>📍 {grp.customerCity}</span>}
                                    </div>
                                  </div>
                                </div>
                              </td>

                              {/* Jumlah Faktur Belum Lunas */}
                              <td className="py-3 px-4 text-center">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    toggleCustomerExpanded(grp.customerId);
                                  }}
                                  className="px-2 py-1 rounded-lg bg-purple-950/60 hover:bg-purple-900 border border-purple-800 text-purple-300 font-bold text-[11px] inline-flex items-center gap-1 cursor-pointer transition-colors"
                                >
                                  <span>{grp.invoices.length} Faktur</span>
                                  {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                                </button>
                              </td>

                              {/* Total Nilai Tagihan */}
                              <td className="py-3 px-4 text-right font-mono font-bold text-neutral-200">
                                {formatRupiah(grp.totalNilaiFaktur)}
                              </td>

                              {/* Sudah Dibayar (Belum Bayar jika tempo/0) */}
                              <td className="py-3 px-4 text-right">
                                {grp.totalSudahDibayar > 0 ? (
                                  <div>
                                    <span className="font-mono font-bold text-emerald-400 block">
                                      {formatRupiah(grp.totalSudahDibayar)}
                                    </span>
                                    <span className="text-[10px] text-amber-400 block font-medium">DP / Cicilan</span>
                                  </div>
                                ) : (
                                  <span className="text-neutral-400 font-semibold text-xs italic">
                                    Belum Bayar
                                  </span>
                                )}
                              </td>

                              {/* Total Sisa Piutang */}
                              <td className="py-3 px-4 text-right">
                                <span className="font-mono font-extrabold text-rose-400 text-sm sm:text-base block">
                                  {formatRupiah(grp.totalSisaPiutang)}
                                </span>
                                {grp.plafonPiutang > 0 && (
                                  <span className="text-[10px] text-neutral-500 block">
                                    Limit: {formatRupiah(grp.plafonPiutang)}
                                  </span>
                                )}
                              </td>

                              {/* Jatuh Tempo Terdekat */}
                              <td className="py-3 px-4 text-center">
                                {grp.nearestJatuhTempo ? (
                                  <div className="inline-block">
                                    <span
                                      className={`font-mono text-xs font-bold block ${
                                        isOverdue ? 'text-rose-400' : 'text-neutral-300'
                                      }`}
                                    >
                                      {grp.nearestJatuhTempo}
                                    </span>
                                    {isOverdue ? (
                                      <span className="px-1.5 py-0.2 rounded-md bg-rose-950 border border-rose-800 text-rose-300 text-[9px] font-extrabold inline-block mt-0.5 animate-pulse">
                                        ⚠️ {grp.overdueCount} Lewat Tempo
                                      </span>
                                    ) : (
                                      <span className="text-[9px] text-neutral-500 block">Jatuh tempo terdekat</span>
                                    )}
                                  </div>
                                ) : (
                                  <span className="text-neutral-500 text-[11px]">-</span>
                                )}
                              </td>

                              {/* Status Piutang */}
                              <td className="py-3 px-4 text-center">
                                {grp.totalSisaPiutang <= 0 ? (
                                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-950/60 border border-emerald-800 text-emerald-400">
                                    ✓ LUNAS
                                  </span>
                                ) : isOverdue ? (
                                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-950 border border-rose-700 text-rose-300 animate-pulse">
                                    ⚠️ OVERDUE
                                  </span>
                                ) : grp.totalSudahDibayar > 0 ? (
                                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-950/60 border border-amber-800 text-amber-300">
                                    SEBAGIAN (DP)
                                  </span>
                                ) : (
                                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-950/60 border border-rose-800 text-rose-400">
                                    BELUM BAYAR
                                  </span>
                                )}
                              </td>

                              {/* Aksi Pelunasan */}
                              <td className="py-3 px-4 text-right">
                                <div
                                  className="flex items-center justify-end gap-1.5"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  {grp.invoices.length > 0 && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        if (grp.invoices.length === 1) {
                                          handleOpenPaymentModal(grp.invoices[0]);
                                        } else {
                                          toggleCustomerExpanded(grp.customerId);
                                        }
                                      }}
                                      className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs transition-colors cursor-pointer"
                                      title={
                                        grp.invoices.length === 1
                                          ? 'Catat Pembayaran Piutang'
                                          : 'Buka Daftar Faktur untuk Pelunasan'
                                      }
                                    >
                                      <DollarSign className="w-3.5 h-3.5" />
                                      <span>{grp.invoices.length === 1 ? 'Bayar' : 'Pelunasan'}</span>
                                    </button>
                                  )}

                                  {grp.customerPhone && grp.customerPhone !== '-' && (
                                    <button
                                      type="button"
                                      onClick={() => handleSendGroupedWhatsAppReminder(grp)}
                                      className="p-1.5 bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 rounded-lg transition-colors cursor-pointer"
                                      title="Kirim Rekap Tagihan Akumulasi via WhatsApp"
                                    >
                                      <Send className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>

                            {/* NESTED ACCORDION: DETAIL FAKTUR PER PELANGGAN */}
                            {isExpanded && (
                              <tr className="bg-[#101013] border-b border-[#24242A]">
                                <td colSpan={8} className="p-3 sm:p-4">
                                  <div className="bg-[#141418] rounded-xl border border-[#2B2B32] p-3 sm:p-4 space-y-2.5 shadow-inner">
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-2">
                                        <FileSpreadsheet className="w-4 h-4 text-purple-400" />
                                        <span className="font-extrabold text-xs text-white">
                                          Rincian {grp.invoices.length} Faktur Penjualan: {grp.customerName}
                                        </span>
                                      </div>
                                      <span className="text-[11px] text-neutral-400">
                                        Total Sisa Piutang:{' '}
                                        <strong className="text-rose-400 font-mono">
                                          {formatRupiah(grp.totalSisaPiutang)}
                                        </strong>
                                      </span>
                                    </div>

                                    {/* Sub-table Faktur */}
                                    <div className="overflow-x-auto">
                                      <table className="w-full text-[11px] border-collapse min-w-[720px]">
                                        <thead>
                                          <tr className="border-b border-[#24242A] text-neutral-400 font-bold uppercase text-[9.5px]">
                                            <th className="py-2 px-2.5 text-left">No. Faktur</th>
                                            <th className="py-2 px-2.5 text-left">Tanggal</th>
                                            <th className="py-2 px-2.5 text-left">Gudang</th>
                                            <th className="py-2 px-2.5 text-right">Nilai Faktur</th>
                                            <th className="py-2 px-2.5 text-right">Sudah Dibayar</th>
                                            <th className="py-2 px-2.5 text-right">Sisa Piutang</th>
                                            <th className="py-2 px-2.5 text-center">Jatuh Tempo</th>
                                            <th className="py-2 px-2.5 text-center">Status</th>
                                            <th className="py-2 px-2.5 text-right">Aksi</th>
                                          </tr>
                                        </thead>
                                        <tbody className="divide-y divide-[#202026]">
                                          {grp.invoices.map((inv) => {
                                            const total = inv.totalNominal || 0;
                                            const sisa =
                                              inv.sisaPiutang !== undefined
                                                ? inv.sisaPiutang
                                                : inv.statusPembayaran === 'PIUTANG'
                                                ? total
                                                : inv.statusPembayaran === 'SEBAGIAN'
                                                ? Math.max(0, total - (inv.jumlahBayar || 0))
                                                : 0;
                                            const terbayar = inv.jumlahBayar || total - sisa;
                                            const isInvOverdue = Boolean(
                                              inv.jatuhTempo && inv.jatuhTempo < new Date().toISOString().split('T')[0] && sisa > 0
                                            );

                                            return (
                                              <tr key={inv.nomorSale} className="hover:bg-[#1A1A20] transition-colors">
                                                <td className="py-2 px-2.5 font-mono font-bold text-purple-400">
                                                  {inv.nomorSale}
                                                </td>
                                                <td className="py-2 px-2.5 text-neutral-300 font-mono">{inv.tanggal}</td>
                                                <td className="py-2 px-2.5 text-neutral-400">
                                                  {inv.gudangNama || inv.gudangId}
                                                </td>
                                                <td className="py-2 px-2.5 text-right font-mono font-bold text-neutral-200">
                                                  {formatRupiah(total)}
                                                </td>
                                                <td className="py-2 px-2.5 text-right">
                                                  {terbayar > 0 ? (
                                                    <span className="font-mono text-emerald-400 font-bold">
                                                      {formatRupiah(terbayar)}
                                                    </span>
                                                  ) : (
                                                    <span className="text-neutral-400 font-medium italic">
                                                      Belum Bayar
                                                    </span>
                                                  )}
                                                </td>
                                                <td className="py-2 px-2.5 text-right font-mono font-extrabold text-rose-400">
                                                  {formatRupiah(sisa)}
                                                </td>
                                                <td className="py-2 px-2.5 text-center font-mono">
                                                  {inv.jatuhTempo ? (
                                                    <span className={isInvOverdue ? 'text-rose-400 font-bold' : 'text-neutral-300'}>
                                                      {inv.jatuhTempo}
                                                    </span>
                                                  ) : (
                                                    <span className="text-neutral-500">-</span>
                                                  )}
                                                </td>
                                                <td className="py-2 px-2.5 text-center">
                                                  {sisa <= 0 ? (
                                                    <span className="px-2 py-0.2 rounded-full text-[9px] font-extrabold bg-emerald-950/60 border border-emerald-800 text-emerald-400">
                                                      ✓ LUNAS
                                                    </span>
                                                  ) : isInvOverdue ? (
                                                    <span className="px-2 py-0.2 rounded-full text-[9px] font-extrabold bg-rose-950 border border-rose-700 text-rose-300">
                                                      OVERDUE
                                                    </span>
                                                  ) : terbayar > 0 ? (
                                                    <span className="px-2 py-0.2 rounded-full text-[9px] font-extrabold bg-amber-950/60 border border-amber-800 text-amber-300">
                                                      SEBAGIAN (DP)
                                                    </span>
                                                  ) : (
                                                    <span className="px-2 py-0.2 rounded-full text-[9px] font-extrabold bg-rose-950/60 border border-rose-800 text-rose-400">
                                                      BELUM BAYAR
                                                    </span>
                                                  )}
                                                </td>
                                                <td className="py-2 px-2.5 text-right">
                                                  <div className="flex items-center justify-end gap-1">
                                                    {sisa > 0 && (
                                                      <button
                                                        type="button"
                                                        onClick={() => handleOpenPaymentModal(inv)}
                                                        className="px-2 py-0.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                                                        title="Catat Pembayaran Faktur Ini"
                                                      >
                                                        <DollarSign className="w-3 h-3" /> Bayar
                                                      </button>
                                                    )}
                                                    {inv.kontak && inv.kontak !== '-' && (
                                                      <button
                                                        type="button"
                                                        onClick={() => handleSendWhatsAppReminder(inv)}
                                                        className="p-1 bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 rounded cursor-pointer"
                                                        title="Kirim Tagihan WA Faktur Ini"
                                                      >
                                                        <Send className="w-3 h-3" />
                                                      </button>
                                                    )}
                                                    {onOpenSaleModalDoc && (
                                                      <button
                                                        type="button"
                                                        onClick={() => onOpenSaleModalDoc(inv)}
                                                        className="p-1 bg-[#1C1C20] hover:bg-purple-900/60 border border-[#2B2B32] text-neutral-300 hover:text-white rounded cursor-pointer flex items-center gap-1"
                                                        title="Lihat & Edit Nota Penjualan"
                                                      >
                                                        <Eye className="w-3 h-3" />
                                                        <Edit2 className="w-2.5 h-2.5 text-purple-400" />
                                                      </button>
                                                    )}
                                                  </div>
                                                </td>
                                              </tr>
                                            );
                                          })}
                                        </tbody>
                                      </table>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            )}
                          </React.Fragment>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
          </div>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: TAMBAH / EDIT PELANGGAN */}
      {/* ========================================================================= */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-xs">
          <div className="bg-[#161618] border border-[#26262B] rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
            <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-purple-950/60 border border-purple-800 flex items-center justify-center text-purple-400">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-white">
                    {editingCustomer ? 'Edit Data Pelanggan' : 'Tambah Pelanggan Baru'}
                  </h3>
                  <p className="text-[11px] text-neutral-400">
                    {editingCustomer
                      ? 'Perubahan nama, nomor HP, atau alamat langsung disinkronkan ke seluruh histori transaksi'
                      : 'Form profil konsumen grosir & limit piutang'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitCustomer} className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-1">
                    ID Pelanggan (Otomatis)
                  </label>
                  <input
                    type="text"
                    value={formId}
                    readOnly
                    className="w-full p-2 bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-400 font-mono font-bold cursor-not-allowed"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-1">
                    Kategori Pelanggan *
                  </label>
                  <select
                    value={formTipe}
                    onChange={(e) => setFormTipe(e.target.value as TipePelanggan)}
                    className="w-full p-2 bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-purple-500 focus:outline-hidden"
                  >
                    {TIPE_PELANGGAN_OPTIONS.map((t) => (
                      <option key={t.value} value={t.value}>
                        {t.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-300 mb-1">
                  Nama Pelanggan / Toko / Brand *
                </label>
                <input
                  type="text"
                  required
                  value={formNama}
                  onChange={(e) => setFormNama(e.target.value)}
                  placeholder="Contoh: Distro Screaming Goods / Toko Berkah"
                  className="w-full p-2 bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-purple-500 focus:outline-hidden font-bold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-1">
                    No. Telepon / WhatsApp
                  </label>
                  <input
                    type="text"
                    value={formTelepon}
                    onChange={(e) => setFormTelepon(e.target.value)}
                    placeholder="0812-3456-7890"
                    className="w-full p-2 bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-purple-500 focus:outline-hidden font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-1">
                    Kota / Wilayah
                  </label>
                  <input
                    type="text"
                    value={formKota}
                    onChange={(e) => setFormKota(e.target.value)}
                    placeholder="Bandung, Jakarta, Cimahi, dll"
                    className="w-full p-2 bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-purple-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-1">
                  Alamat Lengkap Toko / Pengiriman
                </label>
                <textarea
                  rows={2}
                  value={formAlamat}
                  onChange={(e) => setFormAlamat(e.target.value)}
                  placeholder="Jl. Raya No. ..., Kelurahan, Kecamatan"
                  className="w-full p-2 bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-purple-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-300 mb-1">
                  Plafon Limit Piutang Maksimal (Rp)
                </label>
                <input
                  type="number"
                  step="500000"
                  min="0"
                  value={formPlafon}
                  onChange={(e) => setFormPlafon(Number(e.target.value))}
                  placeholder="5000000"
                  className="w-full p-2 bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-amber-400 font-mono font-bold focus:border-purple-500 focus:outline-hidden"
                />
                <p className="text-[10px] text-neutral-500 mt-1">
                  Batas kredit maksimal yang diperbolehkan kasir saat transaksi tempo. Masukkan 0 jika tidak ada plafon.
                </p>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-1">
                  Catatan Tambahan
                </label>
                <input
                  type="text"
                  value={formCatatan}
                  onChange={(e) => setFormCatatan(e.target.value)}
                  placeholder="Catatan kebiasaan order, PIC, atau ketentuan bayar"
                  className="w-full p-2 bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-purple-500 focus:outline-hidden"
                />
              </div>

              <div className="pt-3 border-t border-[#24242A] flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 rounded-xl font-bold cursor-pointer transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold cursor-pointer shadow-md transition-colors"
                >
                  {editingCustomer ? 'Simpan Perubahan' : 'Tambah Pelanggan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CATAT PEMBAYARAN / PELUNASAN PIUTANG */}
      {/* ========================================================================= */}
      {payingSale && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-xs">
          <div className="bg-[#161618] border border-[#26262B] rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
            <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-950/60 border border-emerald-800 flex items-center justify-center text-emerald-400">
                  <DollarSign className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-white">Catat Pembayaran Piutang</h3>
                  <p className="text-[11px] text-neutral-400 font-mono">Faktur: {payingSale.nomorSale}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPayingSale(null)}
                className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleRecordPayment} className="p-5 space-y-4 text-xs">
              {/* Info Faktur */}
              <div className="p-3 bg-[#0F0F10] border border-[#26262E] rounded-xl grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[10px] text-neutral-500 uppercase block font-bold">Pelanggan</span>
                  <span className="font-bold text-neutral-200">{payingSale.pelanggan}</span>
                </div>
                <div>
                  <span className="text-[10px] text-neutral-500 uppercase block font-bold">Gudang</span>
                  <span className="font-semibold text-neutral-300">{payingSale.gudangNama || payingSale.gudangId}</span>
                </div>
                <div>
                  <span className="text-[10px] text-neutral-500 uppercase block font-bold">Total Nilai Tagihan</span>
                  <span className="font-mono font-bold text-neutral-300">{formatRupiah(payingSale.totalNominal || 0)}</span>
                </div>
                <div>
                  <span className="text-[10px] text-neutral-500 uppercase block font-bold">Sisa Piutang Saat Ini</span>
                  <span className="font-mono font-extrabold text-rose-400 text-sm">
                    {formatRupiah(
                      payingSale.sisaPiutang !== undefined
                        ? payingSale.sisaPiutang
                        : Math.max(0, (payingSale.totalNominal || 0) - (payingSale.jumlahBayar || 0))
                    )}
                  </span>
                </div>
              </div>

              {/* Form Input Pembayaran */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-300">
                    Nominal Pembayaran Diterima (Rp) *
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      const sisa =
                        payingSale.sisaPiutang !== undefined
                          ? payingSale.sisaPiutang
                          : Math.max(0, (payingSale.totalNominal || 0) - (payingSale.jumlahBayar || 0));
                      setPaymentAmount(sisa);
                    }}
                    className="text-[10px] font-bold text-emerald-400 hover:text-emerald-300 underline cursor-pointer"
                  >
                    Bayar Lunas Penuh (100%)
                  </button>
                </div>
                <input
                  type="number"
                  required
                  min="1000"
                  max={
                    payingSale.sisaPiutang !== undefined
                      ? payingSale.sisaPiutang
                      : Math.max(0, (payingSale.totalNominal || 0) - (payingSale.jumlahBayar || 0))
                  }
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(Number(e.target.value))}
                  className="w-full p-2.5 bg-[#0F0F10] border border-emerald-900/60 rounded-xl text-emerald-400 font-mono font-extrabold text-base focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-1">
                    Metode Pembayaran *
                  </label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full p-2 bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-emerald-500 focus:outline-hidden"
                  >
                    <option value="TUNAI">💵 Tunai Kasir</option>
                    <option value="TRANSFER BCA">🏦 Transfer Bank BCA</option>
                    <option value="TRANSFER MANDIRI">🏦 Transfer Bank Mandiri</option>
                    <option value="TRANSFER BRI">🏦 Transfer Bank BRI</option>
                    <option value="QRIS">📱 QRIS</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-1">
                    Tanggal Bayar
                  </label>
                  <input
                    type="date"
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                    className="w-full p-2 bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-medium focus:border-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-1">
                  Catatan / Bukti Ref Pembayaran
                </label>
                <input
                  type="text"
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  placeholder="Misal: Bukti transfer BCA a.n. Andi / Pelunasan termin 2"
                  className="w-full p-2 bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              {/* Riwayat Cicilan Sebelumnya Jika Ada */}
              {payingSale.riwayatPelunasan && payingSale.riwayatPelunasan.length > 0 && (
                <div className="p-2.5 bg-[#0F0F10] border border-[#26262B] rounded-xl space-y-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">
                    Riwayat Pembayaran Sebelumnya ({payingSale.riwayatPelunasan.length} kali)
                  </span>
                  <div className="space-y-1 max-h-24 overflow-y-auto pr-1">
                    {payingSale.riwayatPelunasan.map((p, idx) => (
                      <div key={idx} className="flex items-center justify-between text-[11px] text-neutral-300 border-b border-[#1E1E24] pb-0.5">
                        <span>{p.tanggal} • {p.metode}</span>
                        <span className="font-mono font-bold text-emerald-400">+{formatRupiah(p.jumlahBayar)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="pt-3 border-t border-[#24242A] flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPayingSale(null)}
                  className="px-4 py-2 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 rounded-xl font-bold cursor-pointer transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold cursor-pointer shadow-md transition-colors flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" /> Simpan Pembayaran
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE CUSTOMER MODAL */}
      {confirmDeleteCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-[#161618] rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-[#2A2A30] text-[#E0E0E0] p-5 space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-white">Hapus Data Pelanggan</h3>
                <p className="text-xs text-neutral-400">Tindakan ini tidak dapat dibatalkan</p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-rose-950/20 border border-rose-900/40 text-xs text-neutral-300">
              <p>
                Apakah Anda yakin ingin menghapus pelanggan <strong>&quot;{confirmDeleteCustomer.nama}&quot;</strong> (ID: {confirmDeleteCustomer.id})?
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setConfirmDeleteCustomer(null)}
                className="px-4 py-2 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 rounded-xl text-xs font-bold border border-[#2B2B32] cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!isSpvOrOwner) {
                    showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan menghapus data pelanggan!', 'error');
                    setConfirmDeleteCustomer(null);
                    return;
                  }
                  onDeleteCustomer(confirmDeleteCustomer.id);
                  showToast(`Pelanggan "${confirmDeleteCustomer.nama}" berhasil dihapus.`, 'info');
                  setConfirmDeleteCustomer(null);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-md shadow-rose-600/30"
              >
                <Trash2 className="w-3.5 h-3.5" /> Ya, Hapus Sekarang
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
