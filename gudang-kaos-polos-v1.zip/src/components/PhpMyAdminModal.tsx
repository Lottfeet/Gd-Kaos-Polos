import React, { useState, useEffect } from 'react';
import {
  Database,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Download,
  Upload,
  HardDrive,
  Settings,
  HelpCircle,
  X,
  Server,
  Layers,
  FileCode,
  ShieldCheck,
  Check,
  ExternalLink,
} from 'lucide-react';
import { MysqlSyncService, DbStatusResponse } from '../services/mysqlSyncService';
import { OfflineSyncService } from '../services/offlineSyncService';
import {
  MasterProduk,
  InventoryItem,
  MasterGudang,
  Pelanggan,
  SaleDocument,
  OrderDocument,
  SuratJalanDocument,
  LogTransaksi,
  AppSystemSettings,
  User,
} from '../types';

interface PhpMyAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  appData: {
    products: MasterProduk[];
    inventory: InventoryItem[];
    warehouses: MasterGudang[];
    customers: Pelanggan[];
    sales: SaleDocument[];
    orders: OrderDocument[];
    suratJalanList: SuratJalanDocument[];
    logs: LogTransaksi[];
    settings: AppSystemSettings;
  };
  onNotify: (text: string, type: 'success' | 'error' | 'info') => void;
  onOpenOfflineSync?: () => void;
  onRestoreFromDatabase?: (data: any) => void;
  isSpvOrOwner?: boolean;
  currentUser?: User | null;
}

export const PhpMyAdminModal: React.FC<PhpMyAdminModalProps> = ({
  isOpen,
  onClose,
  appData,
  onNotify,
  onOpenOfflineSync,
  onRestoreFromDatabase,
  isSpvOrOwner = true,
  currentUser = null,
}) => {
  const [activeTab, setActiveTab] = useState<'status' | 'tables' | 'guide' | 'settings'>('status');
  const [loading, setLoading] = useState(false);
  const [pulling, setPulling] = useState(false);
  const [pushing, setPushing] = useState(false);
  const [dbStatus, setDbStatus] = useState<DbStatusResponse | null>(null);

  // Form custom connection settings
  const [host, setHost] = useState('localhost');
  const [port, setPort] = useState('3306');
  const [user, setUser] = useState('root');
  const [password, setPassword] = useState('');
  const [database, setDatabase] = useState('db_kaospolos');
  const [bridgeUrl, setBridgeUrl] = useState('');
  const [connectionMode, setConnectionMode] = useState<'bridge' | 'direct'>('bridge');
  const [configSaving, setConfigSaving] = useState(false);

  // Cek status database saat modal dibuka
  const checkStatus = async () => {
    setLoading(true);
    try {
      const status = await MysqlSyncService.testConnection();
      setDbStatus(status);
      if (status.host) setHost(status.host);
      if (status.port) setPort(String(status.port));
      if (status.user) setUser(status.user);
      if (status.database) setDatabase(status.database);
      if (status.bridgeUrl) {
        setBridgeUrl(status.bridgeUrl);
        setConnectionMode('bridge');
      } else if (status.type === 'direct') {
        setConnectionMode('direct');
      }
    } catch (err: any) {
      console.warn('Gagal cek status MySQL:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      checkStatus();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Handle Download File SQL
  const handleDownloadSql = () => {
    const link = document.createElement('a');
    link.href = '/database_kaospolos.sql';
    link.download = 'database_kaospolos.sql';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onNotify('File SQL database_kaospolos.sql berhasil diunduh. Siap diimpor ke phpMyAdmin!', 'success');
  };

  // Handle Download PHP Bridge (api.php)
  const handleDownloadBridge = () => {
    const link = document.createElement('a');
    link.href = '/api/db/download-bridge';
    link.download = 'api.php';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onNotify('File api.php berhasil diunduh! Silakan upload file ini ke folder public_html di cPanel.', 'success');
  };

  // Handle Pull data from MySQL
  const handlePullFromDb = async () => {
    if (!window.confirm('Tarik semua data dari MySQL / phpMyAdmin? Data di browser saat ini akan diperbarui sesuai data di database.')) {
      return;
    }
    setPulling(true);
    try {
      const res = await MysqlSyncService.pullAllDataFromDatabase();
      if (res.success && res.data) {
        if (onRestoreFromDatabase) {
          onRestoreFromDatabase(res.data);
        }
        const total = Object.values(res.counts || {}).reduce((a, b) => a + b, 0);
        onNotify(`Berhasil memuat ${total} data dari MySQL / phpMyAdmin!`, 'success');
        checkStatus();
      } else {
        onNotify(res.error || 'Gagal memuat data dari database MySQL', 'error');
      }
    } catch (err: any) {
      onNotify(err.message || 'Terjadi kesalahan saat memuat data', 'error');
    } finally {
      setPulling(false);
    }
  };

  // Handle Push data to MySQL
  const handlePushToDb = async () => {
    if (!window.confirm('Unggah semua data lokal saat ini ke database MySQL / phpMyAdmin?')) {
      return;
    }
    setPushing(true);
    try {
      const res = await MysqlSyncService.migrateLocalDataToDatabase(appData);
      if (res.success) {
        onNotify(`Sukses! ${res.count} baris data berhasil tersimpan ke MySQL.`, 'success');
        checkStatus();
      } else {
        onNotify(res.error || 'Gagal mengirim data ke MySQL', 'error');
      }
    } catch (err: any) {
      onNotify(err.message || 'Terjadi kesalahan saat mengunggah data', 'error');
    } finally {
      setPushing(false);
    }
  };

  // Handle Save Custom Connection
  const handleSaveConnection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (connectionMode === 'bridge' && !bridgeUrl.trim()) {
      onNotify('Silakan masukkan URL file api.php di website hosting Anda (contoh: https://domainanda.com/api.php)', 'error');
      return;
    }
    setConfigSaving(true);
    try {
      const res = await fetch('/api/db/configure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          host,
          port: parseInt(port, 10),
          user,
          password,
          database,
          bridgeUrl: connectionMode === 'bridge' ? bridgeUrl.trim() : '',
        }),
      });
      const data = await res.json();
      if (data.connected) {
        onNotify(
          data.type === 'bridge'
            ? 'Koneksi ke phpMyAdmin via PHP Web Bridge berhasil terhubung!'
            : `Koneksi ke MySQL database '${database}' berhasil terhubung!`,
          'success'
        );
        setDbStatus(data);
        setActiveTab('status');
      } else {
        onNotify(`Gagal terhubung: ${data.error || 'Periksa URL Bridge atau host/port MySQL'}`, 'error');
      }
    } catch (err: any) {
      onNotify(`Gagal mengatur koneksi: ${err.message}`, 'error');
    } finally {
      setConfigSaving(false);
    }
  };

  const isConnected = dbStatus?.connected ?? false;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-slate-200">
        
        {/* Header Modal */}
        <div className="px-6 py-4 bg-gradient-to-r from-amber-600 via-amber-700 to-indigo-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 shadow-inner">
              <Database className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold tracking-tight">Koneksi Database phpMyAdmin & MySQL</h3>
                <span
                  className={`text-xs px-2.5 py-0.5 rounded-full font-semibold border flex items-center gap-1 ${
                    isConnected
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40'
                      : 'bg-rose-500/20 text-rose-300 border-rose-400/40'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'
                    }`}
                  />
                  {isConnected ? 'MySQL Terhubung' : 'MySQL Offline'}
                </span>
              </div>
              <p className="text-xs text-amber-100/80">
                Penyimpanan data lokal terstruktur, kompatibel dengan phpMyAdmin, XAMPP, Laragon & MySQL
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-white/70 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 border-b border-slate-200 bg-slate-50 flex gap-2">
          <button
            onClick={() => setActiveTab('status')}
            className={`py-3 px-4 font-medium text-sm border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'status'
                ? 'border-amber-600 text-amber-700 font-bold bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Server className="w-4 h-4" />
            Status & Sinkronisasi
          </button>
          <button
            onClick={() => setActiveTab('tables')}
            className={`py-3 px-4 font-medium text-sm border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'tables'
                ? 'border-amber-600 text-amber-700 font-bold bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-4 h-4" />
            Daftar Tabel MySQL
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`py-3 px-4 font-medium text-sm border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'guide'
                ? 'border-amber-600 text-amber-700 font-bold bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            Panduan phpMyAdmin (Import SQL)
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`py-3 px-4 font-medium text-sm border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'settings'
                ? 'border-amber-600 text-amber-700 font-bold bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Settings className="w-4 h-4" />
            Konfigurasi Host & Port
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {activeTab === 'status' && (
            <div className="space-y-6">
              {/* Connection Status Card */}
              <div
                className={`p-5 rounded-xl border flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                  isConnected
                    ? 'bg-emerald-50/70 border-emerald-200'
                    : 'bg-amber-50/70 border-amber-200'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`p-2.5 rounded-xl shrink-0 ${
                      isConnected ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                    }`}
                  >
                    {isConnected ? <CheckCircle2 className="w-6 h-6" /> : <AlertCircle className="w-6 h-6" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-800 text-base">
                        {isConnected
                          ? `Tersambung ke Database MySQL (${dbStatus?.database})`
                          : 'Koneksi MySQL Belum Terdeteksi'}
                      </h4>
                      {isConnected && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-600 text-white font-bold">
                          {dbStatus?.type === 'bridge' ? 'PHP Web Bridge (Port 443)' : 'Direct MySQL (Port 3306)'}
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-600 mt-1">
                      {isConnected ? (
                        <>
                          {dbStatus?.type === 'bridge' ? (
                            <span>URL Bridge: <span className="font-mono font-semibold text-indigo-700">{dbStatus?.bridgeUrl}</span> | Database: <span className="font-mono font-semibold">{dbStatus?.database}</span></span>
                          ) : (
                            <span>Server: <span className="font-mono font-semibold">{dbStatus?.host}:{dbStatus?.port}</span> | User: <span className="font-mono font-semibold">{dbStatus?.user}</span> | Database: <span className="font-mono font-semibold">{dbStatus?.database}</span></span>
                          )}
                        </>
                      ) : (
                        <div className="space-y-1">
                          <p className="font-mono text-red-600 font-semibold">{dbStatus?.error}</p>
                          {dbStatus?.error?.includes('ETIMEDOUT') && (
                            <p className="text-amber-800 bg-amber-100/70 p-2 rounded-lg text-[11px] leading-relaxed">
                              💡 <strong>Port 3306 Diblokir Firewall Rumahweb:</strong> Buka tab <strong>"Konfigurasi Host & Port"</strong> di atas, lalu pilih <strong>"1. PHP Web Bridge (api.php)"</strong>. Cukup download file <code>api.php</code> dan upload ke cPanel agar database langsung terhubung bebas blokir!
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={checkStatus}
                    disabled={loading}
                    className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors shadow-sm flex items-center gap-1.5"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                    Cek Koneksi
                  </button>
                  <button
                    onClick={handleDownloadSql}
                    className="px-3.5 py-2 text-xs font-bold rounded-lg bg-amber-600 hover:bg-amber-700 text-white transition-colors shadow-sm flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download File SQL
                  </button>
                </div>
              </div>

              {/* Action Buttons for Sync */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-5 rounded-xl border border-slate-200 bg-white shadow-sm space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
                      <Download className="w-5 h-5" />
                    </div>
                    <div>
                      <h5 className="font-bold text-slate-800 text-sm">Tarik Data dari MySQL (Pull)</h5>
                      <p className="text-xs text-slate-500">
                        Muat data terbaru dari phpMyAdmin / MySQL ke aplikasi browser ini
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={handlePullFromDb}
                    disabled={pulling || !isConnected}
                    className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-sm ${
                      isConnected
                        ? 'bg-indigo-600 hover:bg-indigo-700 text-white'
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                    }`}
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${pulling ? 'animate-spin' : ''}`} />
                    {pulling ? 'Memuat Data...' : 'Tarik Data dari Database MySQL'}
                  </button>
                </div>

                <div className="p-5 rounded-xl border border-slate-200 bg-white shadow-sm space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
                      <Upload className="w-5 h-5" />
                    </div>
                    <div>
                      <h5 className="font-bold text-slate-800 text-sm">Kirim Data Lokal ke MySQL (Push)</h5>
                      <p className="text-xs text-slate-500">
                        Simpan seluruh data produk, stok, transaksi dan pelanggan saat ini ke MySQL
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={handlePushToDb}
                    disabled={pushing || !isConnected}
                    className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-sm ${
                      isConnected
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                    }`}
                  >
                    <Upload className={`w-3.5 h-3.5 ${pushing ? 'animate-spin' : ''}`} />
                    {pushing ? 'Menyimpan...' : 'Sinkronkan Total ke MySQL'}
                  </button>
                </div>
              </div>

              {/* Data Summary */}
              <div className="p-5 rounded-xl border border-slate-200 bg-slate-50 space-y-3">
                <h5 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Ringkasan Data Saat Ini di Memori Lokal
                </h5>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                  <div className="p-3 bg-white rounded-lg border border-slate-200">
                    <span className="block text-xl font-bold text-slate-800">{appData.products.length}</span>
                    <span className="text-xs text-slate-500">Master Produk</span>
                  </div>
                  <div className="p-3 bg-white rounded-lg border border-slate-200">
                    <span className="block text-xl font-bold text-slate-800">{appData.inventory.length}</span>
                    <span className="text-xs text-slate-500">Item Stok Gudang</span>
                  </div>
                  <div className="p-3 bg-white rounded-lg border border-slate-200">
                    <span className="block text-xl font-bold text-slate-800">{appData.sales.length}</span>
                    <span className="text-xs text-slate-500">Faktur Penjualan</span>
                  </div>
                  <div className="p-3 bg-white rounded-lg border border-slate-200">
                    <span className="block text-xl font-bold text-slate-800">{appData.customers.length}</span>
                    <span className="text-xs text-slate-500">Pelanggan</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'tables' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-800 text-sm">Struktur Tabel MySQL (`db_kaospolos`)</h4>
                  <p className="text-xs text-slate-500">
                    Tabel-tabel ini terdaftar dan dapat dibuka langsung melalui antarmuka phpMyAdmin
                  </p>
                </div>
                <button
                  onClick={checkStatus}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center gap-1"
                >
                  <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
                  Refresh
                </button>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 font-bold">
                      <th className="py-2.5 px-4">Nama Tabel MySQL</th>
                      <th className="py-2.5 px-4">Fungsi Data</th>
                      <th className="py-2.5 px-4 text-center">Jumlah Baris di MySQL</th>
                      <th className="py-2.5 px-4 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-600">
                    <tr>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">master_produk</td>
                      <td className="py-2.5 px-4">Katalog SKU, nama kaos, warna, gramasi, harga HPP & harga jual</td>
                      <td className="py-2.5 px-4 text-center font-bold text-slate-800">
                        {dbStatus?.tableCounts?.products ?? '-'}
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                          Aktif
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">inventori</td>
                      <td className="py-2.5 px-4">Stok ready per gudang, batas reorder level, status restock</td>
                      <td className="py-2.5 px-4 text-center font-bold text-slate-800">
                        {dbStatus?.tableCounts?.inventory ?? '-'}
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                          Aktif
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">master_gudang</td>
                      <td className="py-2.5 px-4">Daftar gudang utama, cabang toko ritel, penanggung jawab</td>
                      <td className="py-2.5 px-4 text-center font-bold text-slate-800">
                        {dbStatus?.tableCounts?.warehouses ?? '-'}
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                          Aktif
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">pelanggan</td>
                      <td className="py-2.5 px-4">Data customer, kategori grosir/ritel/konveksi, plafon kredit piutang</td>
                      <td className="py-2.5 px-4 text-center font-bold text-slate-800">
                        {dbStatus?.tableCounts?.customers ?? '-'}
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                          Aktif
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">transaksi_penjualan</td>
                      <td className="py-2.5 px-4">Faktur kasir, nota grosir, diskon, piutang tempo, riwayat cicilan</td>
                      <td className="py-2.5 px-4 text-center font-bold text-slate-800">
                        {dbStatus?.tableCounts?.sales ?? '-'}
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                          Aktif
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">order_po</td>
                      <td className="py-2.5 px-4">Dokumen Purchase Order pemesanan kaos polos ke supplier pabrik</td>
                      <td className="py-2.5 px-4 text-center font-bold text-slate-800">
                        {dbStatus?.tableCounts?.orders ?? '-'}
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                          Aktif
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">surat_jalan</td>
                      <td className="py-2.5 px-4">Pengiriman antar gudang / ekspedisi, driver, tanda tangan digital</td>
                      <td className="py-2.5 px-4 text-center font-bold text-slate-800">
                        {dbStatus?.tableCounts?.suratJalanList ?? '-'}
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                          Aktif
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">log_transaksi</td>
                      <td className="py-2.5 px-4">Audit log pergerakan stok (MASUK, KELUAR, SALE, KOREKSI)</td>
                      <td className="py-2.5 px-4 text-center font-bold text-slate-800">
                        {dbStatus?.tableCounts?.logs ?? '-'}
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                          Aktif
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">app_settings</td>
                      <td className="py-2.5 px-4">Pengaturan kop nota, nama distro, logo cap stempel & konfigurasi sistem</td>
                      <td className="py-2.5 px-4 text-center font-bold text-slate-800">1</td>
                      <td className="py-2.5 px-4 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                          Aktif
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">app_users</td>
                      <td className="py-2.5 px-4">Akun login pengguna, hak akses per gudang, password & role</td>
                      <td className="py-2.5 px-4 text-center font-bold text-slate-800">
                        {dbStatus?.tableCounts?.users ?? '-'}
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                          Aktif
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'guide' && (
            <div className="space-y-6">
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-amber-800 font-bold text-sm">
                  <FileCode className="w-5 h-5 text-amber-600" />
                  File Skema SQL Otomatis Tersedia
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Kami telah membuat file SQL bernama <code className="bg-amber-100 text-amber-900 px-1 py-0.5 rounded font-mono font-bold">database_kaospolos.sql</code> yang dirancang khusus agar langsung bisa diimpor ke <strong>phpMyAdmin</strong> tanpa konfigurasi rumit.
                </p>
                <button
                  onClick={handleDownloadSql}
                  className="mt-2 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold flex items-center gap-2 shadow-sm transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Download database_kaospolos.sql Sekarang
                </button>
              </div>

              <div className="space-y-4">
                <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-slate-800 text-white flex items-center justify-center text-xs">1</span>
                  Langkah-Langkah Import ke phpMyAdmin:
                </h4>

                <ol className="space-y-3 pl-2 text-xs text-slate-700">
                  <li className="flex items-start gap-3">
                    <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-[11px] shrink-0">1</span>
                    <div>
                      <p className="font-semibold text-slate-800">Buka Panel phpMyAdmin</p>
                      <p className="text-slate-500 mt-0.5">
                        Buka browser dan kunjungi <a href="http://localhost/phpmyadmin" target="_blank" rel="noreferrer" className="text-indigo-600 font-mono underline">http://localhost/phpmyadmin</a> (atau URL phpMyAdmin server hosting Anda).
                      </p>
                    </div>
                  </li>

                  <li className="flex items-start gap-3">
                    <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-[11px] shrink-0">2</span>
                    <div>
                      <p className="font-semibold text-slate-800">Buat Database Baru (db_kaospolos)</p>
                      <p className="text-slate-500 mt-0.5">
                        Klik menu <strong>Basis Data (Databases)</strong> di phpMyAdmin, isi nama basis data: <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">db_kaospolos</code>, lalu klik tombol <strong>Buat (Create)</strong>. (Jika sudah ada, Anda bisa langsung memilihnya di panel sebelah kiri).
                      </p>
                    </div>
                  </li>

                  <li className="flex items-start gap-3">
                    <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-[11px] shrink-0">3</span>
                    <div>
                      <p className="font-semibold text-slate-800">Pilih Tab Impor (Import)</p>
                      <p className="text-slate-500 mt-0.5">
                        Klik database <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">db_kaospolos</code> di sidebar kiri, lalu klik tab <strong>Impor (Import)</strong> di deretan menu navigasi atas phpMyAdmin.
                      </p>
                    </div>
                  </li>

                  <li className="flex items-start gap-3">
                    <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-[11px] shrink-0">4</span>
                    <div>
                      <p className="font-semibold text-slate-800">Pilih File SQL & Klik Kirim (Go)</p>
                      <p className="text-slate-500 mt-0.5">
                        Klik tombol <strong>Choose File / Browse (Telusuri)</strong> dan pilih file <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">database_kaospolos.sql</code> yang Anda unduh. Gulir ke bawah halaman lalu klik tombol <strong>Kirim / Go / Import</strong>.
                      </p>
                    </div>
                  </li>

                  <li className="flex items-start gap-3">
                    <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-[11px] shrink-0">✓</span>
                    <div>
                      <p className="font-semibold text-slate-800">Selesai! Seluruh Tabel & Data Siap Digunakan</p>
                      <p className="text-slate-500 mt-0.5">
                        phpMyAdmin akan menampilkan notifikasi hijau: <em>Import has been successfully finished</em>. Semua data kaos polos, stok gudang, dan pelanggan langsung tersinkronkan!
                      </p>
                    </div>
                  </li>
                </ol>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-5 max-w-2xl">
              <div>
                <h4 className="font-bold text-slate-800 text-sm">Pilihan Metode Sambungan Database</h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Pilih metode yang sesuai dengan lingkungan server Anda.
                </p>
              </div>

              {/* Mode Selector Tabs */}
              <div className="grid grid-cols-2 gap-3 p-1.5 bg-slate-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => setConnectionMode('bridge')}
                  className={`py-2 px-3 rounded-lg text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                    connectionMode === 'bridge'
                      ? 'bg-white text-amber-700 shadow-sm border border-slate-200'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    <span>1. PHP Web Bridge (api.php)</span>
                  </div>
                  <span className="text-[10px] font-normal text-slate-500">Sangat Direkomendasikan untuk cPanel / Rumahweb</span>
                </button>

                <button
                  type="button"
                  onClick={() => setConnectionMode('direct')}
                  className={`py-2 px-3 rounded-lg text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                    connectionMode === 'direct'
                      ? 'bg-white text-indigo-700 shadow-sm border border-slate-200'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <Server className="w-3.5 h-3.5" />
                    <span>2. Direct MySQL (Port 3306)</span>
                  </div>
                  <span className="text-[10px] font-normal text-slate-500">Untuk XAMPP Lokal / VPS / Port 3306 Terbuka</span>
                </button>
              </div>

              {/* Form Mode 1: PHP Web Bridge */}
              {connectionMode === 'bridge' && (
                <form onSubmit={handleSaveConnection} className="space-y-4">
                  <div className="p-4 rounded-xl bg-amber-50/80 border border-amber-200 text-xs text-slate-700 space-y-2">
                    <div className="font-bold text-amber-900 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-amber-700" />
                      Kenapa Menggunakan PHP Web Bridge?
                    </div>
                    <p className="text-[11px] leading-relaxed text-slate-600">
                      Hosting shared (seperti Rumahweb) <strong>menutup port 3306</strong> demi keamanan sehingga koneksi langsung selalu <code>ETIMEDOUT</code>. 
                      Dengan file bridge <code className="bg-amber-100 text-amber-900 px-1 py-0.5 rounded font-mono font-bold">api.php</code>, aplikasi berkomunikasi via <strong>HTTPS (Port 443)</strong> yang selalu diizinkan di hosting manapun!
                    </p>
                    <div className="pt-1 flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={handleDownloadBridge}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download File api.php Siap Pakai
                      </button>
                      <span className="text-[11px] text-slate-500">
                        Upload ke folder <code>public_html</code> di File Manager cPanel Anda.
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      URL Endpoint api.php di Website Anda
                    </label>
                    <input
                      type="url"
                      value={bridgeUrl}
                      onChange={(e) => setBridgeUrl(e.target.value)}
                      placeholder="https://namadomainanda.com/api.php"
                      className="w-full text-xs px-3 py-2.5 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />
                    <p className="text-[11px] text-slate-500 mt-1">
                      Contoh: <span className="font-mono text-indigo-600">https://kaospolos.com/api.php</span> atau nama domain hosting Anda tempat file api.php diunggah.
                    </p>
                  </div>

                  <div className="pt-2 flex items-center gap-2">
                    <button
                      type="submit"
                      disabled={configSaving}
                      className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold flex items-center gap-2 transition-colors shadow-sm"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${configSaving ? 'animate-spin' : ''}`} />
                      {configSaving ? 'Menyambungkan...' : 'Simpan & Uji Sambungan Bridge'}
                    </button>
                  </div>
                </form>
              )}

              {/* Form Mode 2: Direct MySQL */}
              {connectionMode === 'direct' && (
                <form onSubmit={handleSaveConnection} className="space-y-4">
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600">
                    <p className="font-semibold text-slate-800 mb-1">Catatan Port 3306:</p>
                    <p className="text-[11px]">
                      Jika status menghasilkan error <code className="bg-red-50 text-red-700 px-1 rounded">connect ETIMEDOUT</code>, berarti port 3306 diblokir oleh firewall hosting Rumahweb. Mintalah bantuan CS Rumahweb untuk membuka port 3306 atau gunakan <strong>Mode 1 (PHP Web Bridge)</strong> di atas.
                    </p>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="col-span-2">
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Host Database</label>
                      <input
                        type="text"
                        value={host}
                        onChange={(e) => setHost(e.target.value)}
                        placeholder="202.10.43.17 atau localhost"
                        className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-amber-500 focus:outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Port</label>
                      <input
                        type="number"
                        value={port}
                        onChange={(e) => setPort(e.target.value)}
                        placeholder="3306"
                        className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-amber-500 focus:outline-none"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">User MySQL</label>
                      <input
                        type="text"
                        value={user}
                        onChange={(e) => setUser(e.target.value)}
                        placeholder="hump6894_kaospolos"
                        className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-amber-500 focus:outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Password</label>
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="10203040@kaospolos"
                        className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Database</label>
                    <input
                      type="text"
                      value={database}
                      onChange={(e) => setDatabase(e.target.value)}
                      placeholder="hump6894_Gd_kaospolos"
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-amber-500 focus:outline-none"
                      required
                    />
                  </div>

                  <div className="pt-2 flex items-center gap-2">
                    <button
                      type="submit"
                      disabled={configSaving}
                      className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold flex items-center gap-2 transition-colors shadow-sm"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${configSaving ? 'animate-spin' : ''}`} />
                      {configSaving ? 'Menyambungkan...' : 'Simpan & Uji Sambungan Direct'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setHost('localhost');
                        setPort('3306');
                        setUser('root');
                        setPassword('');
                        setDatabase('db_kaospolos');
                      }}
                      className="px-3 py-2.5 text-xs text-slate-600 hover:text-slate-800"
                    >
                      Reset Default XAMPP
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Mendukung phpMyAdmin & MySQL / MariaDB (Offline-First Storage)</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg font-semibold transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
