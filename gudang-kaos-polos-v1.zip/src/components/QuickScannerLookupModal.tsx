import React, { useState } from 'react';
import { InventoryItem, MasterGudang, MasterProduk } from '../types';
import { getWarnaHex, renderShirtPath } from '../utils/tshirtSvg';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import { QrCode, Search, X, Layers, CheckCircle2, ArrowRight, DollarSign, Tag } from 'lucide-react';
import { formatRupiah } from '../utils/formatters';

interface QuickScannerLookupModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: MasterProduk[];
  inventory: InventoryItem[];
  warehouses: MasterGudang[];
  onOpenBarangMasuk: (sku: string) => void;
  onOpenSuratJalan: (sku: string) => void;
  onOpenSale: (sku: string) => void;
}

export const QuickScannerLookupModal: React.FC<QuickScannerLookupModalProps> = ({
  isOpen,
  onClose,
  products,
  inventory,
  warehouses,
  onOpenBarangMasuk,
  onOpenSuratJalan,
  onOpenSale,
}) => {
  const [scannedCode, setScannedCode] = useState<string>('');
  const [matchedProduct, setMatchedProduct] = useState<MasterProduk | null>(null);
  const [showLiveScanner, setShowLiveScanner] = useState<boolean>(false);

  const handleScanFound = (code: string) => {
    const clean = code.trim().toUpperCase();
    setScannedCode(clean);
    setShowLiveScanner(false);

    const found = products.find(
      (p) =>
        p.SKU_ID.toUpperCase() === clean ||
        (p.BARCODE_ID && p.BARCODE_ID.toUpperCase() === clean) ||
        p.SKU_ID.toUpperCase().includes(clean)
    );

    setMatchedProduct(found || null);
  };

  const getStockByWarehouse = (skuId: string, gudangKeyword: string) => {
    const item = inventory.find((i) => i.SKU_ID === skuId && i.GUDANG_ID.includes(gudangKeyword));
    return item ? item.JUMLAH_READY : 0;
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
        <div className="bg-[#161618] rounded-2xl shadow-2xl w-full max-w-4xl 2xl:max-w-5xl overflow-hidden border border-[#2A2A30] flex flex-col text-[#E0E0E0]">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] text-white">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#F27D26] flex items-center justify-center text-white shadow-md shadow-[#F27D26]/30">
                <QrCode className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base sm:text-lg leading-tight text-white">Pemeriksaan Cepat Barcode</h3>
                <p className="text-xs text-neutral-400">Pindai barcode kaos untuk melihat info & stok seketika</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="p-4 sm:p-6 space-y-4">
            {/* Search Input Bar */}
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={scannedCode}
                  onChange={(e) => handleScanFound(e.target.value)}
                  placeholder="Ketik SKU atau hasil scan barcode..."
                  className="w-full pl-9 pr-3 py-2 text-xs font-mono bg-[#0F0F10] border border-[#2B2B32] rounded-xl uppercase focus:border-[#F27D26] focus:outline-hidden text-neutral-100 placeholder-neutral-600"
                />
              </div>
              <button
                type="button"
                onClick={() => setShowLiveScanner(true)}
                className="px-3.5 py-2 bg-[#F27D26] hover:bg-[#e06d1a] text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
              >
                <QrCode className="w-4 h-4" /> Scan Kamera
              </button>
            </div>

            {/* Found Product Result Card */}
            {matchedProduct ? (
              <div className="bg-[#121214] border border-[#26262B] rounded-2xl p-4 sm:p-5 space-y-4 shadow-sm">
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 bg-[#18181C] rounded-xl border border-[#2B2B32] flex items-center justify-center shrink-0 p-1">
                    <svg
                      viewBox="0 0 100 100"
                      className="w-full h-full"
                      dangerouslySetInnerHTML={{
                        __html: renderShirtPath(
                          matchedProduct.JENIS_LENGAN,
                          getWarnaHex(matchedProduct.WARNA),
                          '#E0E0E0'
                        ),
                      }}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-white/20 shrink-0"
                        style={{ backgroundColor: getWarnaHex(matchedProduct.WARNA) }}
                      />
                      <span className="text-xs font-bold text-neutral-300">{matchedProduct.WARNA}</span>
                      <span className="text-xs text-neutral-500">•</span>
                      <span className="text-xs font-extrabold card-size-badge px-2.5 py-0.5 rounded-md">
                        {matchedProduct.UKURAN}
                      </span>
                    </div>
                    <h4 className="font-extrabold text-white text-sm sm:text-base leading-tight truncate">
                      {matchedProduct.NAMA_PRODUK}
                    </h4>
                    <div className="text-xs font-mono font-bold text-[#F27D26] tracking-wide mt-0.5">
                      {matchedProduct.SKU_ID}
                    </div>
                  </div>
                </div>

                {/* Pricing Information */}
                {(matchedProduct.HARGA_HPP !== undefined || matchedProduct.HARGA_JUAL !== undefined) && (
                  <div className="grid grid-cols-2 gap-2.5 p-2.5 bg-[#17171C] rounded-xl border border-[#2B2B34] text-xs">
                    <div>
                      <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block">Harga HPP (Modal)</span>
                      <span className="font-extrabold font-mono text-emerald-300 text-sm">
                        {formatRupiah(matchedProduct.HARGA_HPP || 0)}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-purple-400 font-bold uppercase tracking-wider block">Harga Jual (Ritel)</span>
                      <span className="font-extrabold font-mono text-purple-300 text-sm">
                        {formatRupiah(matchedProduct.HARGA_JUAL || 0)}
                      </span>
                    </div>
                  </div>
                )}

                {/* Stock per Warehouse (Dynamic Multi-Warehouse Support) */}
                <div className="pt-1 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-neutral-400 uppercase tracking-wider text-[10px]">
                      Stok di Seluruh Gudang:
                    </span>
                    <span className="font-black font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/50 px-2.5 py-0.5 rounded-full text-xs">
                      Total:{' '}
                      {warehouses.reduce((sum, w) => {
                        const invItem = inventory.find(
                          (i) => i.SKU_ID === matchedProduct.SKU_ID && i.GUDANG_ID === w.GUDANG_ID
                        );
                        return sum + (invItem ? invItem.JUMLAH_READY : 0);
                      }, 0)}{' '}
                      pcs
                    </span>
                  </div>

                  <div
                    className={`grid gap-2 ${
                      warehouses.length === 1
                        ? 'grid-cols-1'
                        : warehouses.length === 2
                        ? 'grid-cols-2'
                        : warehouses.length === 3
                        ? 'grid-cols-3'
                        : 'grid-cols-2 sm:grid-cols-3'
                    }`}
                  >
                    {warehouses.map((wh, idx) => {
                      const invItem = inventory.find(
                        (i) => i.SKU_ID === matchedProduct.SKU_ID && i.GUDANG_ID === wh.GUDANG_ID
                      );
                      const qty = invItem ? invItem.JUMLAH_READY : 0;
                      const badgeIndex = idx % 6;

                      return (
                        <div
                          key={wh.GUDANG_ID}
                          className={`stock-badge-wh-${badgeIndex} rounded-xl p-2.5 text-center transition-colors`}
                        >
                          <span
                            className={`text-[10px] font-bold stock-label-wh-${badgeIndex} uppercase tracking-wider block truncate`}
                          >
                            {wh.NAMA_GUDANG}
                          </span>
                          <span
                            className={`text-lg sm:text-xl font-extrabold stock-number-wh-${badgeIndex} block mt-0.5 font-mono`}
                          >
                            {qty} <span className="text-xs font-normal opacity-75">pcs</span>
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Quick Transaction Action Buttons */}
                <div className="pt-2 border-t border-[#26262B] space-y-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 block">
                    Aksi Cepat untuk SKU Ini:
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        onOpenBarangMasuk(matchedProduct.SKU_ID);
                        onClose();
                      }}
                      className="py-2 px-1 text-center bg-[#1A1A1E] hover:bg-emerald-950/50 border border-[#2B2B32] hover:border-emerald-700 text-emerald-300 font-bold text-[11px] rounded-lg transition-colors cursor-pointer"
                    >
                      + Stok Masuk
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onOpenSuratJalan(matchedProduct.SKU_ID);
                        onClose();
                      }}
                      className="py-2 px-1 text-center bg-[#1A1A1E] hover:bg-rose-950/50 border border-[#2B2B32] hover:border-rose-700 text-rose-300 font-bold text-[11px] rounded-lg transition-colors cursor-pointer"
                    >
                      🚚 Surat Jalan
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onOpenSale(matchedProduct.SKU_ID);
                        onClose();
                      }}
                      className="py-2 px-1 text-center bg-[#1A1A1E] hover:bg-purple-950/50 border border-[#2B2B32] hover:border-purple-700 text-purple-300 font-bold text-[11px] rounded-lg transition-colors cursor-pointer"
                    >
                      🏷 Jual (Sale)
                    </button>
                  </div>
                </div>
              </div>
            ) : scannedCode ? (
              <div className="p-8 text-center bg-[#121214] border border-[#26262B] rounded-2xl">
                <Layers className="w-10 h-10 text-neutral-600 mx-auto mb-2 opacity-50" />
                <h4 className="font-bold text-sm text-neutral-200">SKU atau Barcode Tidak Ditemukan</h4>
                <p className="text-xs text-neutral-400 mt-1 max-w-xs mx-auto">
                  Kode "{scannedCode}" belum terdaftar pada Master Produk. Silakan tambahkan pada tab Master Produk.
                </p>
              </div>
            ) : (
              <div className="p-8 text-center bg-[#121214] border border-[#26262B] rounded-2xl">
                <QrCode className="w-10 h-10 text-neutral-600 mx-auto mb-2 opacity-50" />
                <h4 className="font-bold text-sm text-neutral-200">Siap Memindai Barcode</h4>
                <p className="text-xs text-neutral-400 mt-1">
                  Klik tombol "Scan Kamera" atau ketik kode SKU pada kolom pencarian di atas.
                </p>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-4 bg-[#121214] border-t border-[#24242A] flex justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-neutral-400 hover:text-neutral-200 hover:bg-[#1E1E24] rounded-xl transition-colors cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </div>
      </div>

      {showLiveScanner && (
        <BarcodeScannerModal
          isOpen={showLiveScanner}
          onClose={() => setShowLiveScanner(false)}
          onScanSuccess={handleScanFound}
          title="Pindai Barcode Kaos Cepat"
          subtitle="Arahkan kamera ke barcode untuk memeriksa stok"
        />
      )}
    </>
  );
};
