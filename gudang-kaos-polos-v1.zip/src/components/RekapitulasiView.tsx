import React, { useState, useMemo, useRef } from 'react';
import {
  FileSpreadsheet,
  ShoppingBag,
  ClipboardList,
  Truck,
  Search,
  Filter,
  Calendar,
  Printer,
  Download,
  Plus,
  Eye,
  Trash2,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Clock,
  Building2,
  TrendingUp,
  Package,
  Layers,
  ShieldCheck,
  AlertCircle,
  X,
  FileCheck,
  RotateCcw,
  Edit2,
} from 'lucide-react';
import {
  MasterProduk,
  MasterGudang,
  OrderDocument,
  SuratJalanDocument,
  SaleDocument,
  OrderItem,
  User,
  AppSystemSettings,
} from '../types';
import { formatRupiah, formatNumber } from '../utils/formatters';
import { printElement } from '../utils/printHelper';
import { getWarnaHex } from '../utils/tshirtSvg';

// Helper to determine Ukuran & Lengan for items matching the Warehouse Inventory page
export const getItemUkuran = (skuId: string, prod?: MasterProduk): string => {
  if (prod?.UKURAN) return prod.UKURAN;
  const parts = skuId.split('-');
  if (parts.length >= 4) return parts[3];
  if (parts.length >= 3) return parts[2];
  return '-';
};

export const getItemLengan = (skuId: string, prod?: MasterProduk): string => {
  if (prod?.JENIS_LENGAN) return prod.JENIS_LENGAN;
  const upper = skuId.toUpperCase();
  if (upper.endsWith('-PJG') || upper.endsWith('-PJ') || upper.includes('PANJANG')) return 'PANJANG';
  if (upper.endsWith('-3P4') || upper.includes('3P4')) return '3P4';
  if (upper.endsWith('-7P8') || upper.includes('7P8')) return '7P8';
  return 'PENDEK';
};

export type RekapTab = 'all' | 'sale' | 'order' | 'sj';

interface RekapitulasiViewProps {
  sales: SaleDocument[];
  orders: OrderDocument[];
  suratJalanList: SuratJalanDocument[];
  products: MasterProduk[];
  warehouses: MasterGudang[];
  currentUser: User;
  onOpenSaleModal: (doc?: SaleDocument) => void;
  onOpenOrderModal: (doc?: OrderDocument) => void;
  onOpenSuratJalanModal: (doc?: SuratJalanDocument) => void;
  onDeleteSale?: (nomorSale: string) => void;
  onDeleteSaleItem?: (nomorSale: string, itemId: string) => void;
  onDeleteOrder?: (nomorOrder: string) => void;
  onDeleteSuratJalan?: (nomorSJ: string) => void;
  showToast: (msg: string, type: 'success' | 'error' | 'info') => void;
  settings?: AppSystemSettings;
}

export const RekapitulasiView: React.FC<RekapitulasiViewProps> = ({
  sales,
  orders,
  suratJalanList,
  products,
  warehouses,
  currentUser,
  onOpenSaleModal,
  onOpenOrderModal,
  onOpenSuratJalanModal,
  onDeleteSale,
  onDeleteSaleItem,
  onDeleteOrder,
  onDeleteSuratJalan,
  showToast,
  settings,
}) => {
  const [activeTab, setActiveTab] = useState<RekapTab>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGudang, setSelectedGudang] = useState('');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | '7days' | 'month' | 'custom'>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [expandedDocId, setExpandedDocId] = useState<string | null>(null);

  // Modal confirm delete dokumen
  const [deleteTarget, setDeleteTarget] = useState<{
    type: 'sale' | 'order' | 'sj';
    id: string;
    title: string;
  } | null>(null);

  // Modal confirm delete item dari faktur penjualan
  const [deleteItemTarget, setDeleteItemTarget] = useState<{
    nomorSale: string;
    item: OrderItem;
    gudangNama: string;
  } | null>(null);

  const printRecapRef = useRef<HTMLDivElement>(null);

  // Otorisasi: Aksi delete dan perubahan resmi eksklusif untuk akun OWNER dan SPV/SUPERVISOR
  const isSpvOrOwner = Boolean(
    currentUser && (
      currentUser.role === 'OWNER' ||
      currentUser.role === 'SUPERVISOR' ||
      (currentUser.role as string) === 'SPV' ||
      currentUser.username?.toLowerCase() === 'owner' ||
      currentUser.username?.toLowerCase() === 'supervisor' ||
      currentUser.username?.toLowerCase() === 'spv'
    )
  );

  // Date filter helper
  const filterByDate = (dateStr: string) => {
    if (dateFilter === 'all') return true;
    const docDate = new Date(dateStr);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (dateFilter === 'today') {
      const target = new Date(dateStr);
      target.setHours(0, 0, 0, 0);
      return target.getTime() === today.getTime();
    }

    if (dateFilter === '7days') {
      const past7 = new Date();
      past7.setDate(today.getDate() - 7);
      past7.setHours(0, 0, 0, 0);
      return docDate >= past7;
    }

    if (dateFilter === 'month') {
      return (
        docDate.getMonth() === today.getMonth() &&
        docDate.getFullYear() === today.getFullYear()
      );
    }

    if (dateFilter === 'custom') {
      if (startDate && docDate < new Date(startDate)) return false;
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        if (docDate > end) return false;
      }
      return true;
    }

    return true;
  };

  // Filtered Sales
  const filteredSales = useMemo(() => {
    return sales.filter((s) => {
      if (!filterByDate(s.tanggal || s.createdAt)) return false;
      if (selectedGudang && s.gudangId !== selectedGudang && s.gudangNama !== selectedGudang) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchNo = s.nomorSale.toLowerCase().includes(q);
        const matchPelanggan = s.pelanggan?.toLowerCase().includes(q);
        const matchKontak = s.kontak?.toLowerCase().includes(q);
        const matchCatatan = s.catatan?.toLowerCase().includes(q);
        const matchItem = s.items?.some((it) => it.SKU_ID.toLowerCase().includes(q));
        if (!matchNo && !matchPelanggan && !matchKontak && !matchCatatan && !matchItem) {
          return false;
        }
      }
      return true;
    });
  }, [sales, dateFilter, startDate, endDate, selectedGudang, searchQuery]);

  // Filtered Orders (PO)
  const filteredOrders = useMemo(() => {
    return orders.filter((o) => {
      if (!filterByDate(o.tanggal || o.createdAt)) return false;
      if (selectedGudang && o.gudangId !== selectedGudang && o.gudangNama !== selectedGudang) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchNo = o.nomorOrder.toLowerCase().includes(q);
        const matchSupplier = o.supplier?.toLowerCase().includes(q);
        const matchCatatan = o.catatan?.toLowerCase().includes(q);
        const matchItem = o.items?.some((it) => it.SKU_ID.toLowerCase().includes(q));
        if (!matchNo && !matchSupplier && !matchCatatan && !matchItem) {
          return false;
        }
      }
      return true;
    });
  }, [orders, dateFilter, startDate, endDate, selectedGudang, searchQuery]);

  // Filtered Surat Jalan
  const filteredSuratJalan = useMemo(() => {
    return suratJalanList.filter((sj) => {
      if (!filterByDate(sj.tanggal || sj.createdAt)) return false;
      if (selectedGudang && sj.gudangId !== selectedGudang && sj.gudangNama !== selectedGudang) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchNo = sj.nomorSJ.toLowerCase().includes(q);
        const matchTujuan = sj.tujuan?.toLowerCase().includes(q);
        const matchPenerima = sj.penerima?.toLowerCase().includes(q);
        const matchDriver = sj.driver?.toLowerCase().includes(q);
        const matchKendaraan = sj.kendaraan?.toLowerCase().includes(q);
        const matchCatatan = sj.catatan?.toLowerCase().includes(q);
        const matchItem = sj.items?.some((it) => it.SKU_ID.toLowerCase().includes(q));
        if (!matchNo && !matchTujuan && !matchPenerima && !matchDriver && !matchKendaraan && !matchCatatan && !matchItem) {
          return false;
        }
      }
      return true;
    });
  }, [suratJalanList, dateFilter, startDate, endDate, selectedGudang, searchQuery]);

  // Totals calculations
  const totalSalePcs = useMemo(
    () => filteredSales.reduce((acc, s) => acc + (s.items?.reduce((sum, it) => sum + (Number(it.jumlah) || 0), 0) || 0), 0),
    [filteredSales]
  );
  const totalSaleNominal = useMemo(
    () => filteredSales.reduce((acc, s) => acc + (s.totalNominal ?? s.subtotalNominal ?? 0), 0),
    [filteredSales]
  );

  const totalOrderPcs = useMemo(
    () => filteredOrders.reduce((acc, o) => acc + (o.items?.reduce((sum, it) => sum + (Number(it.jumlah) || 0), 0) || 0), 0),
    [filteredOrders]
  );
  const totalOrderNominal = useMemo(
    () =>
      filteredOrders.reduce((acc, o) => {
        const docTotal = o.items?.reduce(
          (sum, it) => sum + (Number(it.jumlah) || 0) * (Number(it.hargaSatuan) || 0),
          0
        ) || 0;
        return acc + docTotal;
      }, 0),
    [filteredOrders]
  );

  const totalSJPcs = useMemo(
    () => filteredSuratJalan.reduce((acc, sj) => acc + (sj.items?.reduce((sum, it) => sum + (Number(it.jumlah) || 0), 0) || 0), 0),
    [filteredSuratJalan]
  );
  const totalSJNominal = useMemo(
    () => filteredSuratJalan.reduce((acc, sj) => acc + (sj.totalNominal ?? 0), 0),
    [filteredSuratJalan]
  );

  // Handle Print Recap Table
  const handlePrintRecap = () => {
    if (!printRecapRef.current) return;
    const tabName =
      activeTab === 'sale'
        ? 'Rekapitulasi Penjualan (Sale)'
        : activeTab === 'order'
        ? 'Rekapitulasi Purchase Order (PO)'
        : activeTab === 'sj'
        ? 'Rekapitulasi Surat Jalan (SJ)'
        : 'Rekapitulasi Dokumen (Sale, PO & Surat Jalan)';

    printElement(printRecapRef.current, {
      title: `${tabName} - ${new Date().toLocaleDateString('id-ID')}`,
      filename: `Laporan_Rekap_${activeTab.toUpperCase()}_${Date.now()}.pdf`,
    });
  };

  // Export CSV
  const handleExportCSV = () => {
    let rows: string[][] = [];
    let filename = `Rekap_${activeTab}_${Date.now()}.csv`;

    if (activeTab === 'sale' || activeTab === 'all') {
      rows.push(['TIPE', 'NO. DOKUMEN', 'TANGGAL', 'GUDANG', 'PELANGGAN / MITRA', 'METODE / STATUS', 'TOTAL PCS', 'TOTAL NILAI (RP)', 'CATATAN']);
      filteredSales.forEach((s) => {
        const pcs = s.items?.reduce((sum, it) => sum + (Number(it.jumlah) || 0), 0) || 0;
        rows.push([
          'SALE',
          s.nomorSale,
          s.tanggal,
          s.gudangNama || s.gudangId,
          `"${s.pelanggan || '-'}"`,
          s.metode || 'TUNAI',
          String(pcs),
          String(s.totalNominal || 0),
          `"${s.catatan || ''}"`,
        ]);
      });
    }

    if (activeTab === 'order' || activeTab === 'all') {
      if (activeTab === 'order') {
        rows.push(['TIPE', 'NO. PO', 'TANGGAL', 'GUDANG', 'SUPPLIER', 'TOTAL PCS', 'ESTIMASI NILAI (RP)', 'CATATAN']);
      }
      filteredOrders.forEach((o) => {
        const pcs = o.items?.reduce((sum, it) => sum + (Number(it.jumlah) || 0), 0) || 0;
        const val = o.items?.reduce((sum, it) => sum + (Number(it.jumlah) || 0) * (Number(it.hargaSatuan) || 0), 0) || 0;
        rows.push([
          'PO',
          o.nomorOrder,
          o.tanggal,
          o.gudangNama || o.gudangId,
          `"${o.supplier || '-'}"`,
          'ORDER',
          String(pcs),
          String(val),
          `"${o.catatan || ''}"`,
        ]);
      });
    }

    if (activeTab === 'sj' || activeTab === 'all') {
      if (activeTab === 'sj') {
        rows.push(['TIPE', 'NO. SJ', 'TANGGAL', 'GUDANG ASAL', 'TUJUAN', 'PENERIMA', 'DRIVER', 'TOTAL PCS', 'NILAI BARANG (RP)', 'CATATAN']);
      }
      filteredSuratJalan.forEach((sj) => {
        const pcs = sj.items?.reduce((sum, it) => sum + (Number(it.jumlah) || 0), 0) || 0;
        rows.push([
          'SURAT_JALAN',
          sj.nomorSJ,
          sj.tanggal,
          sj.gudangNama || sj.gudangId,
          `"${sj.tujuan || '-'}"`,
          sj.driver || '-',
          String(pcs),
          String(sj.totalNominal || 0),
          `"${sj.catatan || ''}"`,
        ]);
      });
    }

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast(`Data rekapitulasi berhasil diexport ke file CSV (${filename}).`, 'success');
  };

  const executeDelete = () => {
    if (!deleteTarget) return;
    if (!isSpvOrOwner) {
      showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan menghapus dokumen resmi!', 'error');
      setDeleteTarget(null);
      return;
    }
    if (deleteTarget.type === 'sale' && onDeleteSale) {
      onDeleteSale(deleteTarget.id);
      showToast(`Nota Sale ${deleteTarget.id} berhasil dihapus dari rekap.`, 'info');
    } else if (deleteTarget.type === 'order' && onDeleteOrder) {
      onDeleteOrder(deleteTarget.id);
      showToast(`Purchase Order ${deleteTarget.id} berhasil dihapus dari rekap.`, 'info');
    } else if (deleteTarget.type === 'sj' && onDeleteSuratJalan) {
      onDeleteSuratJalan(deleteTarget.id);
      showToast(`Surat Jalan ${deleteTarget.id} berhasil dihapus dari rekap.`, 'info');
    }
    setDeleteTarget(null);
  };

  const executeDeleteItem = () => {
    if (!deleteItemTarget) return;
    if (!isSpvOrOwner) {
      showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan mengoreksi faktur!', 'error');
      setDeleteItemTarget(null);
      return;
    }
    if (onDeleteSaleItem) {
      onDeleteSaleItem(deleteItemTarget.nomorSale, deleteItemTarget.item.id);
    }
    setDeleteItemTarget(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#161618] border border-[#26262B] p-5 sm:p-6 rounded-2xl shadow-sm">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-linear-to-br from-purple-600 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-purple-600/20">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white flex items-center gap-2">
                Rekapitulasi Dokumen Resmi
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-950/80 border border-purple-800 text-purple-300">
                  Sale • PO • Surat Jalan
                </span>
              </h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                Pusat data rekapitulasi lengkap penjualan ritel/grosir, purchase order supplier, dan surat jalan mutasi barang.
              </p>
            </div>
          </div>
        </div>

        {/* Header Action Buttons (Cetak Rekap & Export CSV) */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Cetak Rekap */}
          <button
            type="button"
            onClick={handlePrintRecap}
            className="px-3.5 py-2 bg-[#202024] hover:bg-[#2C2C32] text-neutral-200 border border-[#32323A] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Cetak format cetak resmi / PDF"
          >
            <Printer className="w-3.5 h-3.5 text-neutral-300" /> Cetak Rekap
          </button>

          {/* Export CSV */}
          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3.5 py-2 bg-[#202024] hover:bg-[#2C2C32] text-emerald-400 hover:text-emerald-300 border border-[#32323A] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Export CSV Excel"
          >
            <Download className="w-3.5 h-3.5" /> Export CSV
          </button>
        </div>
      </div>

      {/* Primary Navigation Tabs */}
      <div className="bg-[#121214] border border-[#24242A] rounded-2xl p-1.5 flex flex-wrap gap-1">
        <button
          type="button"
          onClick={() => setActiveTab('all')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'all'
              ? 'bg-[#222228] text-white shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#18181C]'
          }`}
        >
          <Layers className="w-4 h-4 text-sky-400" />
          <span>Semua Rekap</span>
          <span className="ml-1 text-[10px] px-1.5 py-0.2 rounded-full bg-neutral-800 text-neutral-300">
            {sales.length + orders.length + suratJalanList.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('sale')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'sale'
              ? 'bg-purple-950/70 border border-purple-800/80 text-purple-200 shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#18181C]'
          }`}
        >
          <ShoppingBag className="w-4 h-4 text-purple-400" />
          <span>Rekapitulasi Sale ({filteredSales.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('order')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'order'
              ? 'bg-orange-950/70 border border-[#F27D26]/60 text-orange-200 shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#18181C]'
          }`}
        >
          <ClipboardList className="w-4 h-4 text-[#F27D26]" />
          <span>Rekapitulasi PO ({filteredOrders.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('sj')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'sj'
              ? 'bg-rose-950/70 border border-rose-800/80 text-rose-200 shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#18181C]'
          }`}
        >
          <Truck className="w-4 h-4 text-rose-400" />
          <span>Rekap Surat Jalan ({filteredSuratJalan.length})</span>
        </button>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        {/* Card 1: Sale Summary */}
        <div className="bg-[#161618] border border-[#24242A] p-4 rounded-2xl relative overflow-hidden group hover:border-purple-600/50 transition-all">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-1">
            <span className="font-semibold text-purple-300">Total Omzet Sale</span>
            <ShoppingBag className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-lg sm:text-xl font-black text-white font-mono tracking-tight">
            {formatRupiah(totalSaleNominal)}
          </div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mt-2 pt-2 border-t border-[#24242A]">
            <span>{filteredSales.length} Transaksi</span>
            <span className="font-bold text-purple-400">{formatNumber(totalSalePcs)} pcs</span>
          </div>
        </div>

        {/* Card 2: PO Summary */}
        <div className="bg-[#161618] border border-[#24242A] p-4 rounded-2xl relative overflow-hidden group hover:border-[#F27D26]/50 transition-all">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-1">
            <span className="font-semibold text-orange-300">Total Nilai PO</span>
            <ClipboardList className="w-4 h-4 text-[#F27D26]" />
          </div>
          <div className="text-lg sm:text-xl font-black text-white font-mono tracking-tight">
            {formatRupiah(totalOrderNominal)}
          </div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mt-2 pt-2 border-t border-[#24242A]">
            <span>{filteredOrders.length} Pesanan PO</span>
            <span className="font-bold text-[#F27D26]">{formatNumber(totalOrderPcs)} pcs</span>
          </div>
        </div>

        {/* Card 3: Surat Jalan Summary */}
        <div className="bg-[#161618] border border-[#24242A] p-4 rounded-2xl relative overflow-hidden group hover:border-rose-600/50 transition-all">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-1">
            <span className="font-semibold text-rose-300">Barang Terkirim (SJ)</span>
            <Truck className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-lg sm:text-xl font-black text-white font-mono tracking-tight">
            {formatNumber(totalSJPcs)} <span className="text-xs font-normal text-neutral-400">pcs</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mt-2 pt-2 border-t border-[#24242A]">
            <span>{filteredSuratJalan.length} Surat Jalan</span>
            <span className="font-bold text-rose-400">{formatRupiah(totalSJNominal)}</span>
          </div>
        </div>

        {/* Card 4: Net Flow Balance */}
        <div className="bg-[#161618] border border-[#24242A] p-4 rounded-2xl relative overflow-hidden group hover:border-sky-600/50 transition-all">
          <div className="flex items-center justify-between text-neutral-400 text-xs mb-1">
            <span className="font-semibold text-sky-300">Aktivitas Periode Ini</span>
            <TrendingUp className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-lg sm:text-xl font-black text-white font-mono tracking-tight">
            {filteredSales.length + filteredOrders.length + filteredSuratJalan.length} <span className="text-xs font-normal text-neutral-400">Dokumen</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 mt-2 pt-2 border-t border-[#24242A]">
            <span>Total Item Mutasi</span>
            <span className="font-bold text-sky-400">{formatNumber(totalSalePcs + totalOrderPcs + totalSJPcs)} pcs</span>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-[#161618] border border-[#26262B] p-4 rounded-2xl flex flex-wrap items-center gap-3">
        {/* Search Input */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="🔍 Cari No. Dokumen, Pelanggan, Supplier, SKU, Driver..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-purple-500 focus:outline-hidden"
          />
        </div>

        {/* Filter Gudang */}
        <div className="flex items-center gap-1.5">
          <Building2 className="w-4 h-4 text-neutral-500 hidden sm:block" />
          <select
            value={selectedGudang}
            onChange={(e) => setSelectedGudang(e.target.value)}
            className="py-2 px-3 text-xs bg-[#0F0F10] border border-[#2B2B32] text-neutral-200 rounded-xl focus:border-purple-500 focus:outline-hidden"
          >
            <option value="">Semua Gudang</option>
            {warehouses.map((w) => (
              <option key={w.GUDANG_ID} value={w.GUDANG_ID}>
                {w.NAMA_GUDANG}
              </option>
            ))}
          </select>
        </div>

        {/* Filter Tanggal */}
        <div className="flex items-center gap-1.5">
          <Calendar className="w-4 h-4 text-neutral-500 hidden sm:block" />
          <select
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value as any)}
            className="py-2 px-3 text-xs bg-[#0F0F10] border border-[#2B2B32] text-neutral-200 rounded-xl focus:border-purple-500 focus:outline-hidden"
          >
            <option value="all">Semua Tanggal</option>
            <option value="today">Hari Ini</option>
            <option value="7days">7 Hari Terakhir</option>
            <option value="month">Bulan Ini</option>
            <option value="custom">Rentang Tanggal...</option>
          </select>
        </div>

        {dateFilter === 'custom' && (
          <div className="flex items-center gap-1.5 animate-in fade-in">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="py-1.5 px-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] text-neutral-200 rounded-xl focus:border-purple-500 focus:outline-hidden"
            />
            <span className="text-xs text-neutral-500">s/d</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="py-1.5 px-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] text-neutral-200 rounded-xl focus:border-purple-500 focus:outline-hidden"
            />
          </div>
        )}

        {/* Reset Filter Button */}
        {(searchQuery || selectedGudang || dateFilter !== 'all') && (
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setSelectedGudang('');
              setDateFilter('all');
              setStartDate('');
              setEndDate('');
            }}
            className="py-2 px-3 bg-[#202024] hover:bg-[#2A2A30] text-neutral-300 border border-[#32323A] rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset Filter
          </button>
        )}
      </div>

      {/* Printable Report Container Ref (Used for clean paper printing) */}
      <div ref={printRecapRef} className="space-y-6">
        {/* Printable Header - visible only when printing */}
        <div
          className="hidden print:block text-slate-900 border-b-2 pb-4 mb-4"
          style={{ borderColor: settings?.invoiceHeaderColor || '#7e22ce' }}
        >
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-3.5">
              {settings?.logoUrl && (
                <div className="w-14 h-14 bg-white rounded-lg p-1 border border-slate-300 flex items-center justify-center shrink-0">
                  <img src={settings.logoUrl} alt="Logo Toko" className="max-w-full max-h-full object-contain" />
                </div>
              )}
              <div>
                <h1
                  className="text-2xl font-black uppercase tracking-wider"
                  style={{ color: settings?.invoiceHeaderColor || '#7e22ce' }}
                >
                  {settings?.brandName || 'LAPORAN REKAPITULASI RESMI'}
                </h1>
                <p className="text-xs font-bold text-slate-600">
                  {settings?.companySubtitle || 'Sistem Inventori, PO, Surat Jalan & Penjualan Kaos Polos'}
                </p>
                {settings?.companyAddress && (
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    {settings.companyAddress} • Telp: {settings.companyPhone}
                  </p>
                )}
              </div>
            </div>
            <div className="text-right text-xs">
              <p>Dicetak: {new Date().toLocaleString('id-ID')}</p>
              <p>User: {currentUser.fullName || currentUser.username} ({currentUser.role})</p>
            </div>
          </div>
          <div className="mt-3 flex gap-6 text-xs font-medium text-slate-700 bg-slate-100 p-2 rounded">
            <span>Periode: {dateFilter === 'all' ? 'Semua Waktu' : dateFilter}</span>
            <span>Gudang: {selectedGudang || 'Semua Gudang'}</span>
            <span>Total Dokumen: {filteredSales.length + filteredOrders.length + filteredSuratJalan.length}</span>
          </div>
        </div>

        {/* SECTION 1: REKAPITULASI SALE (PENJUALAN) */}
        {(activeTab === 'all' || activeTab === 'sale') && (
          <div className="bg-[#161618] border border-[#26262B] rounded-2xl overflow-hidden shadow-sm">
            <div className="p-4 sm:p-5 border-b border-[#24242A] flex flex-wrap items-center justify-between gap-3 bg-[#131315] recap-header-bar">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-purple-600/20 border border-purple-600/40 flex items-center justify-center text-purple-400">
                  <ShoppingBag className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
                    Rekapitulasi Sale (Penjualan Kaos)
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-purple-950/70 border border-purple-800 text-purple-300">
                      {filteredSales.length} Nota
                    </span>
                  </h3>
                  <p className="text-[11px] text-neutral-400">
                    Daftar faktur / nota penjualan kasir toko & pesanan grosir pelanggan
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-xs">
                <span className="text-neutral-400">
                  Total Qty:{' '}
                  <strong className="text-white font-mono recap-header-strong">{formatNumber(totalSalePcs)} pcs</strong>
                </span>
                <span className="text-neutral-400">
                  Total Omzet:{' '}
                  <strong className="text-purple-400 font-mono text-sm">{formatRupiah(totalSaleNominal)}</strong>
                </span>
              </div>
            </div>

            {filteredSales.length === 0 ? (
              <div className="p-8 text-center text-neutral-500 text-xs">
                <ShoppingBag className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                Tidak ada data nota penjualan yang sesuai dengan filter.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-xs min-w-[850px]">
                  <thead>
                    <tr className="bg-[#101012] border-b border-[#24242A] text-neutral-400 uppercase tracking-wider text-[10px]">
                      <th className="py-3 px-3 text-center w-8">#</th>
                      <th className="py-3 px-3 text-left font-bold">No. Nota Sale</th>
                      <th className="py-3 px-3 text-left font-bold">Tanggal</th>
                      <th className="py-3 px-3 text-left font-bold">Gudang / Kasir</th>
                      <th className="py-3 px-3 text-left font-bold">Pelanggan</th>
                      <th className="py-3 px-3 text-center font-bold">Metode</th>
                      <th className="py-3 px-3 text-center font-bold">Total Pcs</th>
                      <th className="py-3 px-3 text-right font-bold">Total Nilai</th>
                      <th className="py-3 px-3 text-center font-bold">Tanda Tangan</th>
                      <th className="py-3 px-3 text-center font-bold print:hidden w-28">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#24242A]">
                    {filteredSales.map((s, idx) => {
                      const pcs = s.items?.reduce((sum, it) => sum + (Number(it.jumlah) || 0), 0) || 0;
                      const isExpanded = expandedDocId === s.nomorSale;
                      const sigCount = (s.signaturePenjual ? 1 : 0) + (s.signaturePembeli ? 1 : 0);

                      return (
                        <React.Fragment key={s.nomorSale}>
                          <tr className="hover:bg-[#1C1C20] transition-colors">
                            <td className="py-2.5 px-3 text-center text-neutral-500 font-mono text-[11px]">
                              {idx + 1}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="font-mono font-bold text-purple-400 block">{s.nomorSale}</span>
                              {s.catatan && (
                                <span className="text-[10px] text-neutral-500 truncate max-w-[160px] block">
                                  {s.catatan}
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-neutral-300 whitespace-nowrap">
                              {s.tanggal}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="font-semibold text-neutral-200 block text-[11px]">
                                {s.gudangNama || s.gudangId}
                              </span>
                              <span className="text-[10px] text-neutral-500">Kasir: {s.username}</span>
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="font-bold text-white block">{s.pelanggan || 'Pelanggan Tunai'}</span>
                              {s.kontak && <span className="text-[10px] text-neutral-400">{s.kontak}</span>}
                            </td>
                            <td className="py-2.5 px-3 text-center whitespace-nowrap">
                              {s.statusPembayaran === 'PIUTANG' ? (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-neutral-900 border border-[#2B2B32] text-neutral-400 block mb-1">
                                  {s.metode ? s.metode : '— Belum Tahu —'}
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-950/60 border border-purple-800/60 text-purple-300 block mb-1">
                                  {s.metode || 'TUNAI'}
                                </span>
                              )}
                              {s.statusPembayaran === 'PIUTANG' || (s.sisaPiutang && s.sisaPiutang > 0 && !s.jumlahBayar) ? (
                                <span className="px-1.5 py-0.2 rounded-full text-[9px] font-extrabold bg-rose-950/80 border border-rose-800 text-rose-300 inline-block">
                                  ⏳ TEMPO (Belum Bayar)
                                </span>
                              ) : s.statusPembayaran === 'SEBAGIAN' || (s.sisaPiutang && s.sisaPiutang > 0) ? (
                                <span className="px-1.5 py-0.2 rounded-full text-[9px] font-extrabold bg-amber-950/80 border border-amber-800 text-amber-300 inline-block">
                                  ⚡ DP
                                </span>
                              ) : (
                                <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-emerald-950/60 border border-emerald-800 text-emerald-400 inline-block">
                                  ✓ LUNAS
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-center font-bold text-neutral-200 font-mono">
                              {pcs} pcs
                            </td>
                            <td className="py-2.5 px-3 text-right">
                              <span className="font-mono font-bold text-white block">
                                {formatRupiah(s.totalNominal ?? s.subtotalNominal ?? 0)}
                              </span>
                              {s.sisaPiutang && s.sisaPiutang > 0 ? (
                                <span className="text-[10px] font-mono font-bold text-rose-400 block mt-0.5">
                                  Piutang: {formatRupiah(s.sisaPiutang)}
                                </span>
                              ) : null}
                            </td>
                            <td className="py-2.5 px-3 text-center whitespace-nowrap">
                              <span
                                className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  sigCount === 2
                                    ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/50'
                                    : sigCount === 1
                                    ? 'bg-amber-950/60 text-amber-300 border border-amber-800/50'
                                    : 'bg-neutral-800 text-neutral-400 border border-neutral-700/60'
                                }`}
                              >
                                <ShieldCheck className="w-3 h-3" /> {sigCount}/2 TTD
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-center print:hidden">
                              <div className="flex items-center justify-center gap-1.5">
                                {/* Edit Nota & Rincian Barang (SPV/Owner) */}
                                {isSpvOrOwner && (
                                  <button
                                    type="button"
                                    onClick={() => onOpenSaleModal(s)}
                                    className="p-1.5 bg-purple-600/20 hover:bg-purple-600 text-purple-300 hover:text-white rounded-lg transition-colors cursor-pointer"
                                    title="Edit Dokumen & Rincian Barang"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                {/* Open in Modal & Print PDF */}
                                <button
                                    type="button"
                                    onClick={() => onOpenSaleModal(s)}
                                    className="p-1.5 bg-neutral-700/40 hover:bg-neutral-600 text-neutral-300 hover:text-white rounded-lg transition-colors cursor-pointer"
                                    title="Buka Nota & Cetak PDF"
                                  >
                                    <Printer className="w-3.5 h-3.5" />
                                  </button>
                                {/* Expand Item Rows */}
                                <button
                                  type="button"
                                  onClick={() => setExpandedDocId(isExpanded ? null : s.nomorSale)}
                                  className="p-1.5 bg-[#24242A] hover:bg-[#303036] text-neutral-300 rounded-lg transition-colors cursor-pointer"
                                  title="Lihat Rincian Item"
                                >
                                  {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                                </button>
                                {/* Delete (Khusus Akses Owner & SPV) */}
                                {isSpvOrOwner ? (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setDeleteTarget({
                                        type: 'sale',
                                        id: s.nomorSale,
                                        title: `Nota Penjualan ${s.nomorSale}`,
                                      })
                                    }
                                    className="p-1.5 bg-rose-950/30 hover:bg-rose-900/60 text-rose-400 hover:text-rose-200 rounded-lg transition-colors cursor-pointer"
                                    title="Hapus Nota Sale (Akses Owner & SPV)"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                ) : (
                                  <button
                                    type="button"
                                    disabled
                                    className="p-1.5 bg-neutral-900/40 text-neutral-600 rounded-lg border border-neutral-800/80 cursor-not-allowed opacity-35 select-none"
                                    title="Aksi Hapus Terkunci (Hanya untuk Owner & SPV)"
                                  >
                                    <Trash2 className="w-3.5 h-3.5 text-neutral-600" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>

                          {/* Expanded Items Preview */}
                          {isExpanded && (
                            <tr className="bg-[#121214] border-b border-[#24242A]">
                              <td colSpan={10} className="p-3 sm:p-4">
                                <div className="bg-[#18181C] border border-[#2B2B32] rounded-xl p-3 overflow-x-auto">
                                  <div className="text-[11px] font-bold text-neutral-300 mb-2 flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                      <span>📦 Rincian Barang yang Dibeli:</span>
                                      {isSpvOrOwner && (
                                        <button
                                          type="button"
                                          onClick={() => onOpenSaleModal(s)}
                                          className="px-2 py-0.5 bg-purple-600 hover:bg-purple-700 text-white rounded-md text-[10.5px] font-bold flex items-center gap-1 transition-colors cursor-pointer shadow-xs"
                                          title="Edit Rincian Barang & Nota Penjualan"
                                        >
                                          <Edit2 className="w-3 h-3" /> Edit Rincian Barang
                                        </button>
                                      )}
                                    </div>
                                    <span className="text-neutral-500 font-normal">
                                      {s.items?.length || 0} Baris Item
                                    </span>
                                  </div>
                                  <table className="w-full text-xs min-w-[620px]">
                                    <thead>
                                      <tr className="text-neutral-500 text-[10px] border-b border-[#282830] text-left uppercase tracking-wider">
                                        <th className="pb-1.5">SKU ID</th>
                                        <th className="pb-1.5">Nama Produk & Warna</th>
                                        <th className="pb-1.5 text-center font-bold text-neutral-300">UKURAN</th>
                                        <th className="pb-1.5 text-center font-bold text-neutral-300">LENGAN</th>
                                        <th className="pb-1.5 text-center">Jumlah</th>
                                        <th className="pb-1.5 text-right">Harga Satuan</th>
                                        <th className="pb-1.5 text-right">Subtotal</th>
                                        {isSpvOrOwner && <th className="pb-1.5 text-center">Aksi</th>}
                                      </tr>
                                    </thead>
                                    <tbody className="divide-y divide-[#24242A]">
                                      {s.items?.map((it) => {
                                        const prod = products.find((p) => p.SKU_ID === it.SKU_ID);
                                        const lineSub = (Number(it.jumlah) || 0) * (Number(it.hargaSatuan) || 0);
                                        const itemUkuran = getItemUkuran(it.SKU_ID, prod);
                                        const itemLengan = getItemLengan(it.SKU_ID, prod);
                                        const warnaName = prod?.WARNA || '';

                                        return (
                                          <tr key={it.id} className="hover:bg-[#1f1f25] transition-colors">
                                            <td className="py-1 font-mono font-bold text-purple-300">{it.SKU_ID}</td>
                                            <td className="py-1 text-neutral-300">
                                              <div className="flex items-center gap-1.5">
                                                <span>{prod?.NAMA_PRODUK || 'Kaos Polos Combed'}</span>
                                                {warnaName && (
                                                  <span className="flex items-center gap-1 text-neutral-400">
                                                    <span>-</span>
                                                    <span
                                                      className="w-2.5 h-2.5 rounded-full border border-neutral-500/60 shrink-0 inline-block"
                                                      style={{ backgroundColor: getWarnaHex(warnaName) }}
                                                    />
                                                    <span className="font-semibold text-neutral-300">{warnaName}</span>
                                                  </span>
                                                )}
                                              </div>
                                            </td>
                                            <td className="py-1 text-center font-bold text-neutral-200">
                                              {itemUkuran}
                                            </td>
                                            <td className="py-1 text-center text-neutral-400">
                                              {itemLengan}
                                            </td>
                                            <td className="py-1 text-center font-bold text-white">{it.jumlah} pcs</td>
                                            <td className="py-1 text-right text-neutral-400 font-mono">
                                              {formatRupiah(it.hargaSatuan || 0)}
                                            </td>
                                            <td className="py-1 text-right font-bold text-neutral-200 font-mono">
                                              {formatRupiah(lineSub)}
                                            </td>
                                            {isSpvOrOwner && (
                                              <td className="py-1 text-center">
                                                <div className="flex items-center justify-center gap-1.5">
                                                  <button
                                                    type="button"
                                                    onClick={() => onOpenSaleModal(s)}
                                                    className="p-1 bg-[#24242A] hover:bg-purple-900/60 text-purple-300 hover:text-white rounded transition-colors cursor-pointer"
                                                    title="Edit Item di Form Nota Penjualan"
                                                  >
                                                    <Edit2 className="w-3 h-3" />
                                                  </button>
                                                  <button
                                                    type="button"
                                                    onClick={() => {
                                                      if ((s.items?.length || 0) <= 1) {
                                                        showToast(
                                                          'Faktur ini hanya memiliki 1 item barang. Untuk membatalkan seluruh transaksi, silakan gunakan tombol Hapus Faktur di baris utama.',
                                                          'info'
                                                        );
                                                        return;
                                                      }
                                                      setDeleteItemTarget({
                                                        nomorSale: s.nomorSale,
                                                        item: it,
                                                        gudangNama: s.gudangNama || s.gudangId,
                                                      });
                                                    }}
                                                    className="p-1 bg-[#24242A] hover:bg-rose-900/60 text-rose-300 hover:text-white rounded transition-colors cursor-pointer"
                                                    title="Hapus Item ini dari Faktur & Kembalikan Stok ke Gudang"
                                                  >
                                                    <Trash2 className="w-3 h-3" />
                                                  </button>
                                                </div>
                                              </td>
                                            )}
                                          </tr>
                                        );
                                      })}
                                    </tbody>
                                  </table>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* SECTION 2: REKAPITULASI PURCHASE ORDER (PO) */}
        {(activeTab === 'all' || activeTab === 'order') && (
          <div className="bg-[#161618] border border-[#26262B] rounded-2xl overflow-hidden shadow-sm">
            <div className="p-4 sm:p-5 border-b border-[#24242A] flex flex-wrap items-center justify-between gap-3 bg-[#131315] recap-header-bar">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-[#F27D26]/20 border border-[#F27D26]/40 flex items-center justify-center text-[#F27D26]">
                  <ClipboardList className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
                    Rekapitulasi Purchase Order (PO Restok)
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-orange-950/70 border border-[#F27D26]/60 text-orange-200">
                      {filteredOrders.length} PO
                    </span>
                  </h3>
                  <p className="text-[11px] text-neutral-400">
                    Daftar surat pesanan resmi pembelian bahan kaos ke konveksi & vendor
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-xs">
                <span className="text-neutral-400">
                  Total Order:{' '}
                  <strong className="text-white font-mono recap-header-strong">{formatNumber(totalOrderPcs)} pcs</strong>
                </span>
                <span className="text-neutral-400">
                  Estimasi Biaya PO:{' '}
                  <strong className="text-[#F27D26] font-mono text-sm">{formatRupiah(totalOrderNominal)}</strong>
                </span>
              </div>
            </div>

            {filteredOrders.length === 0 ? (
              <div className="p-8 text-center text-neutral-500 text-xs">
                <ClipboardList className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                Tidak ada data Purchase Order (PO) yang sesuai dengan filter.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-xs min-w-[850px]">
                  <thead>
                    <tr className="bg-[#101012] border-b border-[#24242A] text-neutral-400 uppercase tracking-wider text-[10px]">
                      <th className="py-3 px-3 text-center w-8">#</th>
                      <th className="py-3 px-3 text-left font-bold">No. Purchase Order</th>
                      <th className="py-3 px-3 text-left font-bold">Tanggal</th>
                      <th className="py-3 px-3 text-left font-bold">Gudang Pemesan</th>
                      <th className="py-3 px-3 text-left font-bold">Supplier / Konveksi</th>
                      <th className="py-3 px-3 text-center font-bold">Total Pcs</th>
                      <th className="py-3 px-3 text-right font-bold">Estimasi Nilai</th>
                      <th className="py-3 px-3 text-center font-bold">Tanda Tangan</th>
                      <th className="py-3 px-3 text-center font-bold print:hidden w-28">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#24242A]">
                    {filteredOrders.map((o, idx) => {
                      const pcs = o.items?.reduce((sum, it) => sum + (Number(it.jumlah) || 0), 0) || 0;
                      const orderVal = o.items?.reduce(
                        (sum, it) => sum + (Number(it.jumlah) || 0) * (Number(it.hargaSatuan) || 0),
                        0
                      ) || 0;
                      const isExpanded = expandedDocId === o.nomorOrder;
                      const sigCount = (o.signatureAdmin ? 1 : 0) + (o.signatureSupervisor ? 1 : 0);

                      return (
                        <React.Fragment key={o.nomorOrder}>
                          <tr className="hover:bg-[#1C1C20] transition-colors">
                            <td className="py-2.5 px-3 text-center text-neutral-500 font-mono text-[11px]">
                              {idx + 1}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="font-mono font-bold text-[#F27D26] block">{o.nomorOrder}</span>
                              {o.catatan && (
                                <span className="text-[10px] text-neutral-500 truncate max-w-[160px] block">
                                  {o.catatan}
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-neutral-300 whitespace-nowrap">
                              {o.tanggal}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="font-semibold text-neutral-200 block text-[11px]">
                                {o.gudangNama || o.gudangId}
                              </span>
                              <span className="text-[10px] text-neutral-500">Pembuat: {o.username}</span>
                            </td>
                            <td className="py-2.5 px-3 font-bold text-white">
                              {o.supplier || 'Supplier Umum'}
                            </td>
                            <td className="py-2.5 px-3 text-center font-bold text-neutral-200 font-mono">
                              {pcs} pcs
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-white">
                              {formatRupiah(orderVal)}
                            </td>
                            <td className="py-2.5 px-3 text-center whitespace-nowrap">
                              <span
                                className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  sigCount === 2
                                    ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/50'
                                    : sigCount === 1
                                    ? 'bg-amber-950/60 text-amber-300 border border-amber-800/50'
                                    : 'bg-neutral-800 text-neutral-400 border border-neutral-700/60'
                                }`}
                              >
                                <ShieldCheck className="w-3 h-3" /> {sigCount}/2 TTD
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-center print:hidden">
                              <div className="flex items-center justify-center gap-1.5">
                                {/* Edit PO & Rincian Produk (SPV/Owner) */}
                                {isSpvOrOwner && (
                                  <button
                                    type="button"
                                    onClick={() => onOpenOrderModal(o)}
                                    className="p-1.5 bg-[#F27D26]/20 hover:bg-[#F27D26] text-orange-300 hover:text-white rounded-lg transition-colors cursor-pointer"
                                    title="Edit Dokumen PO & Rincian Produk"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                {/* Open in Modal & Print PDF */}
                                <button
                                    type="button"
                                    onClick={() => onOpenOrderModal(o)}
                                    className="p-1.5 bg-neutral-700/40 hover:bg-neutral-600 text-neutral-300 hover:text-white rounded-lg transition-colors cursor-pointer"
                                    title="Buka PO & Cetak PDF"
                                  >
                                    <Printer className="w-3.5 h-3.5" />
                                  </button>
                                {/* Expand Item Rows */}
                                <button
                                  type="button"
                                  onClick={() => setExpandedDocId(isExpanded ? null : o.nomorOrder)}
                                  className="p-1.5 bg-[#24242A] hover:bg-[#303036] text-neutral-300 rounded-lg transition-colors cursor-pointer"
                                  title="Lihat Rincian Item PO"
                                >
                                  {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                                </button>
                                {/* Delete (Khusus Akses Owner & SPV) */}
                                {isSpvOrOwner ? (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setDeleteTarget({
                                        type: 'order',
                                        id: o.nomorOrder,
                                        title: `Purchase Order ${o.nomorOrder}`,
                                      })
                                    }
                                    className="p-1.5 bg-rose-950/30 hover:bg-rose-900/60 text-rose-400 hover:text-rose-200 rounded-lg transition-colors cursor-pointer"
                                    title="Hapus Purchase Order (Akses Owner & SPV)"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                ) : (
                                  <button
                                    type="button"
                                    disabled
                                    className="p-1.5 bg-neutral-900/40 text-neutral-600 rounded-lg border border-neutral-800/80 cursor-not-allowed opacity-35 select-none"
                                    title="Aksi Hapus Terkunci (Hanya untuk Owner & SPV)"
                                  >
                                    <Trash2 className="w-3.5 h-3.5 text-neutral-600" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>

                          {/* Expanded Items Preview */}
                          {isExpanded && (
                            <tr className="bg-[#121214] border-b border-[#24242A]">
                              <td colSpan={10} className="p-3 sm:p-4">
                                <div className="bg-[#18181C] border border-[#2B2B32] rounded-xl p-3 overflow-x-auto">
                                  <div className="text-[11px] font-bold text-neutral-300 mb-2 flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                      <span>📋 Rincian Produk Kaos yang Dipesan:</span>
                                      {isSpvOrOwner && (
                                        <button
                                          type="button"
                                          onClick={() => onOpenOrderModal(o)}
                                          className="px-2 py-0.5 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-md text-[10.5px] font-bold flex items-center gap-1 transition-colors cursor-pointer shadow-xs"
                                          title="Edit Rincian Produk & Dokumen PO"
                                        >
                                          <Edit2 className="w-3 h-3" /> Edit Rincian Produk
                                        </button>
                                      )}
                                    </div>
                                    <span className="text-neutral-500 font-normal">
                                      {o.items?.length || 0} Baris Item
                                    </span>
                                  </div>
                                  <table className="w-full text-xs min-w-[620px]">
                                    <thead>
                                      <tr className="text-neutral-500 text-[10px] border-b border-[#282830] text-left uppercase tracking-wider">
                                        <th className="pb-1.5">SKU ID</th>
                                        <th className="pb-1.5">Deskripsi Produk</th>
                                        <th className="pb-1.5 text-center font-bold text-neutral-300">UKURAN</th>
                                        <th className="pb-1.5 text-center font-bold text-neutral-300">LENGAN</th>
                                        <th className="pb-1.5 text-center">Jumlah Order</th>
                                        <th className="pb-1.5 text-right">Harga Satuan</th>
                                        <th className="pb-1.5 text-right">Total Estimasi</th>
                                        {isSpvOrOwner && <th className="pb-1.5 text-center">Aksi</th>}
                                      </tr>
                                    </thead>
                                    <tbody className="divide-y divide-[#24242A]">
                                      {o.items?.map((it) => {
                                        const prod = products.find((p) => p.SKU_ID === it.SKU_ID);
                                        const lineSub = (Number(it.jumlah) || 0) * (Number(it.hargaSatuan) || 0);
                                        const itemUkuran = getItemUkuran(it.SKU_ID, prod);
                                        const itemLengan = getItemLengan(it.SKU_ID, prod);
                                        const warnaName = prod?.WARNA || '';

                                        return (
                                          <tr key={it.id} className="hover:bg-[#1f1f25] transition-colors">
                                            <td className="py-1 font-mono font-bold text-orange-300">{it.SKU_ID}</td>
                                            <td className="py-1 text-neutral-300">
                                              <div className="flex items-center gap-1.5">
                                                <span>{prod?.NAMA_PRODUK || 'Kaos Polos Combed'}</span>
                                                {warnaName && (
                                                  <span className="flex items-center gap-1 text-neutral-400">
                                                    <span>-</span>
                                                    <span
                                                      className="w-2.5 h-2.5 rounded-full border border-neutral-500/60 shrink-0 inline-block"
                                                      style={{ backgroundColor: getWarnaHex(warnaName) }}
                                                    />
                                                    <span className="font-semibold text-neutral-300">{warnaName}</span>
                                                  </span>
                                                )}
                                              </div>
                                            </td>
                                            <td className="py-1 text-center font-bold text-neutral-200">
                                              {itemUkuran}
                                            </td>
                                            <td className="py-1 text-center text-neutral-400">
                                              {itemLengan}
                                            </td>
                                            <td className="py-1 text-center font-bold text-white">{it.jumlah} pcs</td>
                                            <td className="py-1 text-right text-neutral-400 font-mono">
                                              {formatRupiah(it.hargaSatuan || 0)}
                                            </td>
                                            <td className="py-1 text-right font-bold text-neutral-200 font-mono">
                                              {formatRupiah(lineSub)}
                                            </td>
                                            {isSpvOrOwner && (
                                              <td className="py-1 text-center">
                                                <button
                                                  type="button"
                                                  onClick={() => onOpenOrderModal(o)}
                                                  className="p-1 bg-[#24242A] hover:bg-orange-900/60 text-orange-300 hover:text-white rounded transition-colors cursor-pointer"
                                                  title="Edit Item di Form PO"
                                                >
                                                  <Edit2 className="w-3 h-3" />
                                                </button>
                                              </td>
                                            )}
                                          </tr>
                                        );
                                      })}
                                    </tbody>
                                  </table>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* SECTION 3: REKAPITULASI SURAT JALAN (SJ) */}
        {(activeTab === 'all' || activeTab === 'sj') && (
          <div className="bg-[#161618] border border-[#26262B] rounded-2xl overflow-hidden shadow-sm">
            <div className="p-4 sm:p-5 border-b border-[#24242A] flex flex-wrap items-center justify-between gap-3 bg-[#131315] recap-header-bar">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-rose-600/20 border border-rose-600/40 flex items-center justify-center text-rose-400">
                  <Truck className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
                    Rekapitulasi Surat Jalan (Pengiriman Barang)
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-rose-950/70 border border-rose-800 text-rose-300">
                      {filteredSuratJalan.length} Dokumen SJ
                    </span>
                  </h3>
                  <p className="text-[11px] text-neutral-400">
                    Daftar surat jalan resmi mutasi antar cabang gudang dan pengiriman ekspedisi
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-xs">
                <span className="text-neutral-400">
                  Total Fisik Terkirim:{' '}
                  <strong className="text-white font-mono recap-header-strong">{formatNumber(totalSJPcs)} pcs</strong>
                </span>
                <span className="text-neutral-400">
                  Nilai Distribusi:{' '}
                  <strong className="text-rose-400 font-mono text-sm">{formatRupiah(totalSJNominal)}</strong>
                </span>
              </div>
            </div>

            {filteredSuratJalan.length === 0 ? (
              <div className="p-8 text-center text-neutral-500 text-xs">
                <Truck className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                Tidak ada data Surat Jalan yang sesuai dengan filter.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-xs min-w-[850px]">
                  <thead>
                    <tr className="bg-[#101012] border-b border-[#24242A] text-neutral-400 uppercase tracking-wider text-[10px]">
                      <th className="py-3 px-3 text-center w-8">#</th>
                      <th className="py-3 px-3 text-left font-bold">No. Surat Jalan</th>
                      <th className="py-3 px-3 text-left font-bold">Tanggal</th>
                      <th className="py-3 px-3 text-left font-bold">Gudang Asal</th>
                      <th className="py-3 px-3 text-left font-bold">Tujuan & Penerima</th>
                      <th className="py-3 px-3 text-left font-bold">Driver / Kendaraan</th>
                      <th className="py-3 px-3 text-center font-bold">Total Pcs</th>
                      <th className="py-3 px-3 text-right font-bold">Total Nilai</th>
                      <th className="py-3 px-3 text-center font-bold">Tanda Tangan</th>
                      <th className="py-3 px-3 text-center font-bold print:hidden w-28">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#24242A]">
                    {filteredSuratJalan.map((sj, idx) => {
                      const pcs = sj.items?.reduce((sum, it) => sum + (Number(it.jumlah) || 0), 0) || 0;
                      const isExpanded = expandedDocId === sj.nomorSJ;
                      const sigCount =
                        (sj.signaturePengirim ? 1 : 0) +
                        (sj.signatureDriver ? 1 : 0) +
                        (sj.signaturePenerima ? 1 : 0);

                      return (
                        <React.Fragment key={sj.nomorSJ}>
                          <tr className="hover:bg-[#1C1C20] transition-colors">
                            <td className="py-2.5 px-3 text-center text-neutral-500 font-mono text-[11px]">
                              {idx + 1}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="font-mono font-bold text-rose-400 block">{sj.nomorSJ}</span>
                              {sj.catatan && (
                                <span className="text-[10px] text-neutral-500 truncate max-w-[160px] block">
                                  {sj.catatan}
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-neutral-300 whitespace-nowrap">
                              {sj.tanggal}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="font-semibold text-neutral-200 block text-[11px]">
                                {sj.gudangNama || sj.gudangId}
                              </span>
                              <span className="text-[10px] text-neutral-500">Admin: {sj.username}</span>
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="font-bold text-white block">{sj.tujuan}</span>
                              {sj.penerima && (
                                <span className="text-[10px] text-neutral-400">Penerima: {sj.penerima}</span>
                              )}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="text-neutral-200 block font-medium">{sj.driver || 'Kurir Reguler'}</span>
                              {sj.kendaraan && (
                                <span className="text-[10px] text-neutral-400">{sj.kendaraan}</span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-center font-bold text-rose-400 font-mono">
                              {pcs} pcs
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-white">
                              {formatRupiah(sj.totalNominal || 0)}
                            </td>
                            <td className="py-2.5 px-3 text-center whitespace-nowrap">
                              <span
                                className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  sigCount === 3
                                    ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/50'
                                    : sigCount > 0
                                    ? 'bg-amber-950/60 text-amber-300 border border-amber-800/50'
                                    : 'bg-neutral-800 text-neutral-400 border border-neutral-700/60'
                                }`}
                              >
                                <ShieldCheck className="w-3 h-3" /> {sigCount}/3 TTD
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-center print:hidden">
                              <div className="flex items-center justify-center gap-1.5">
                                {/* Edit SJ & Rincian Kaos (SPV/Owner) */}
                                {isSpvOrOwner && (
                                  <button
                                    type="button"
                                    onClick={() => onOpenSuratJalanModal(sj)}
                                    className="p-1.5 bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white rounded-lg transition-colors cursor-pointer"
                                    title="Edit Dokumen SJ & Rincian Kaos"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                {/* Open in Modal & Print PDF */}
                                <button
                                  type="button"
                                  onClick={() => onOpenSuratJalanModal(sj)}
                                  className="p-1.5 bg-neutral-700/40 hover:bg-neutral-600 text-neutral-300 hover:text-white rounded-lg transition-colors cursor-pointer"
                                  title="Buka Surat Jalan & Cetak PDF"
                                >
                                  <Printer className="w-3.5 h-3.5" />
                                </button>
                                {/* Expand Item Rows */}
                                <button
                                  type="button"
                                  onClick={() => setExpandedDocId(isExpanded ? null : sj.nomorSJ)}
                                  className="p-1.5 bg-[#24242A] hover:bg-[#303036] text-neutral-300 rounded-lg transition-colors cursor-pointer"
                                  title="Lihat Rincian Item SJ"
                                >
                                  {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                                </button>
                                {/* Delete (Khusus Akses Owner & SPV) */}
                                {isSpvOrOwner ? (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setDeleteTarget({
                                        type: 'sj',
                                        id: sj.nomorSJ,
                                        title: `Surat Jalan ${sj.nomorSJ}`,
                                      })
                                    }
                                    className="p-1.5 bg-rose-950/30 hover:bg-rose-900/60 text-rose-400 hover:text-rose-200 rounded-lg transition-colors cursor-pointer"
                                    title="Hapus Surat Jalan (Akses Owner & SPV)"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                ) : (
                                  <button
                                    type="button"
                                    disabled
                                    className="p-1.5 bg-neutral-900/40 text-neutral-600 rounded-lg border border-neutral-800/80 cursor-not-allowed opacity-35 select-none"
                                    title="Aksi Hapus Terkunci (Hanya untuk Owner & SPV)"
                                  >
                                    <Trash2 className="w-3.5 h-3.5 text-neutral-600" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>

                          {/* Expanded Items Preview */}
                          {isExpanded && (
                            <tr className="bg-[#121214] border-b border-[#24242A]">
                              <td colSpan={10} className="p-3 sm:p-4">
                                <div className="bg-[#18181C] border border-[#2B2B32] rounded-xl p-3 overflow-x-auto">
                                  <div className="text-[11px] font-bold text-neutral-300 mb-2 flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                      <span>🚚 Rincian Kaos yang Dikirim:</span>
                                      {isSpvOrOwner && (
                                        <button
                                          type="button"
                                          onClick={() => onOpenSuratJalanModal(sj)}
                                          className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded-md text-[10.5px] font-bold flex items-center gap-1 transition-colors cursor-pointer shadow-xs"
                                          title="Edit Rincian Kaos & Dokumen Surat Jalan"
                                        >
                                          <Edit2 className="w-3 h-3" /> Edit Rincian Kaos
                                        </button>
                                      )}
                                    </div>
                                    <span className="text-neutral-500 font-normal">
                                      {sj.items?.length || 0} Baris Item
                                    </span>
                                  </div>
                                  <table className="w-full text-xs min-w-[620px]">
                                    <thead>
                                      <tr className="text-neutral-500 text-[10px] border-b border-[#282830] text-left uppercase tracking-wider">
                                        <th className="pb-1.5">SKU ID</th>
                                        <th className="pb-1.5">Deskripsi Produk</th>
                                        <th className="pb-1.5 text-center font-bold text-neutral-300">UKURAN</th>
                                        <th className="pb-1.5 text-center font-bold text-neutral-300">LENGAN</th>
                                        <th className="pb-1.5 text-center">Jumlah Dikirim</th>
                                        <th className="pb-1.5">Keterangan</th>
                                        <th className="pb-1.5 text-right">Subtotal Nilai</th>
                                        {isSpvOrOwner && <th className="pb-1.5 text-center">Aksi</th>}
                                      </tr>
                                    </thead>
                                    <tbody className="divide-y divide-[#24242A]">
                                      {sj.items?.map((it) => {
                                        const prod = products.find((p) => p.SKU_ID === it.SKU_ID);
                                        const lineSub = (Number(it.jumlah) || 0) * (Number(it.hargaSatuan) || 0);
                                        const itemUkuran = getItemUkuran(it.SKU_ID, prod);
                                        const itemLengan = getItemLengan(it.SKU_ID, prod);
                                        const warnaName = prod?.WARNA || '';

                                        return (
                                          <tr key={it.id} className="hover:bg-[#1f1f25] transition-colors">
                                            <td className="py-1 font-mono font-bold text-rose-300">{it.SKU_ID}</td>
                                            <td className="py-1 text-neutral-300">
                                              <div className="flex items-center gap-1.5">
                                                <span>{prod?.NAMA_PRODUK || 'Kaos Polos Combed'}</span>
                                                {warnaName && (
                                                  <span className="flex items-center gap-1 text-neutral-400">
                                                    <span>-</span>
                                                    <span
                                                      className="w-2.5 h-2.5 rounded-full border border-neutral-500/60 shrink-0 inline-block"
                                                      style={{ backgroundColor: getWarnaHex(warnaName) }}
                                                    />
                                                    <span className="font-semibold text-neutral-300">{warnaName}</span>
                                                  </span>
                                                )}
                                              </div>
                                            </td>
                                            <td className="py-1 text-center font-bold text-neutral-200">
                                              {itemUkuran}
                                            </td>
                                            <td className="py-1 text-center text-neutral-400">
                                              {itemLengan}
                                            </td>
                                            <td className="py-1 text-center font-bold text-white">{it.jumlah} pcs</td>
                                            <td className="py-1 text-neutral-400">{it.keterangan || '—'}</td>
                                            <td className="py-1 text-right font-bold text-neutral-200 font-mono">
                                              {formatRupiah(lineSub)}
                                            </td>
                                            {isSpvOrOwner && (
                                              <td className="py-1 text-center">
                                                <button
                                                  type="button"
                                                  onClick={() => onOpenSuratJalanModal(sj)}
                                                  className="p-1 bg-[#24242A] hover:bg-rose-900/60 text-rose-300 hover:text-white rounded transition-colors cursor-pointer"
                                                  title="Edit Item di Form Surat Jalan"
                                                >
                                                  <Edit2 className="w-3 h-3" />
                                                </button>
                                              </td>
                                            )}
                                          </tr>
                                        );
                                      })}
                                    </tbody>
                                  </table>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Confirmation Modal Delete Document */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in">
          <div className="bg-[#18181C] border border-[#2B2B32] rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-400 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h3 className="text-base font-bold text-white">Konfirmasi Hapus Dokumen</h3>
              <p className="text-xs text-neutral-400 mt-1">
                Apakah Anda yakin ingin menghapus <strong className="text-white">{deleteTarget.title}</strong> dari arsip rekapitulasi?
              </p>
              {deleteTarget.type === 'sale' && (
                <div className="mt-3 p-2.5 bg-emerald-950/40 border border-emerald-800/60 rounded-xl text-left text-xs text-emerald-300 flex items-start gap-2">
                  <RotateCcw className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                  <span>
                    <strong>Pengembalian Stok Otomatis:</strong> Seluruh stok item barang di dalam faktur penjualan ini akan otomatis dikembalikan ke gudang asalnya.
                  </span>
                </div>
              )}
            </div>
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2 px-4 bg-[#24242A] hover:bg-[#303036] text-neutral-300 text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={executeDelete}
                className="flex-1 py-2 px-4 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                Ya, Hapus Dokumen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal Delete Item from Sale */}
      {deleteItemTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in">
          <div className="bg-[#18181C] border border-[#2B2B32] rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-400 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h3 className="text-base font-bold text-white">Konfirmasi Hapus Item dari Faktur</h3>
              <p className="text-xs text-neutral-400 mt-1">
                Apakah Anda yakin ingin menghapus item <strong className="text-purple-300 font-mono">{deleteItemTarget.item.SKU_ID}</strong> ({deleteItemTarget.item.jumlah} pcs) dari Faktur <strong className="text-white">{deleteItemTarget.nomorSale}</strong>?
              </p>
              <div className="mt-3 p-2.5 bg-emerald-950/40 border border-emerald-800/60 rounded-xl text-left text-xs text-emerald-300 flex items-start gap-2">
                <RotateCcw className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                <span>
                  <strong>Pengembalian Stok:</strong> Stok sebanyak <strong>{deleteItemTarget.item.jumlah} pcs</strong> akan langsung dikembalikan ke asalnya di {deleteItemTarget.gudangNama}.
                </span>
              </div>
            </div>
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteItemTarget(null)}
                className="flex-1 py-2 px-4 bg-[#24242A] hover:bg-[#303036] text-neutral-300 text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={executeDeleteItem}
                className="flex-1 py-2 px-4 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                Ya, Hapus & Kembalikan Stok
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
