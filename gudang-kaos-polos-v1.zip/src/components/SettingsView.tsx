import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  MasterGudang,
  MasterProduk,
  InventoryItem,
  LogTransaksi,
  UserAccount,
  AppSystemSettings,
  UserRole,
  OrderDocument,
  SuratJalanDocument,
  SaleDocument,
  Pelanggan,
  User,
  AppBackupData,
  CheckpointItem,
  CheckpointTriggerType,
} from '../types';
import {
  Building2,
  Tag,
  Users,
  Settings,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  QrCode,
  Download,
  Upload,
  RotateCcw,
  ShieldCheck,
  Phone,
  Mail,
  MapPin,
  Save,
  KeyRound,
  FileSpreadsheet,
  Printer,
  Sparkles,
  ToggleLeft,
  ToggleRight,
  UserPlus,
  Lock,
  Search,
  Filter,
  Layers,
  RefreshCw,
  SlidersHorizontal,
  X,
  Image as ImageIcon,
  Camera,
  Palette,
  Database,
  Clock,
  Pin,
  Copy,
  Check,
  FileJson,
  HardDrive,
} from 'lucide-react';
import { getWarnaHex } from '../utils/tshirtSvg';
import { ProductModal } from './ProductModal';
import { LabelPrintModal } from './LabelPrintModal';
import { drawBarcode128 } from '../utils/barcode128';
import { renderCodeToCanvas, generateCodeDataUrl, BarcodeFormat } from '../utils/codeRenderer';
import { MysqlSyncService } from '../services/mysqlSyncService';
import { CheckpointService, AppStateSnapshot } from '../services/checkpointService';
import { formatNumber, formatRupiah } from '../utils/formatters';

interface SettingsViewProps {
  warehouses: MasterGudang[];
  onUpdateWarehouses: (warehouses: MasterGudang[]) => void;
  users: UserAccount[];
  onUpdateUsers: (users: UserAccount[]) => void;
  settings: AppSystemSettings;
  onUpdateSettings: (settings: AppSystemSettings) => void;
  products: MasterProduk[];
  onUpdateProducts: (products: MasterProduk[]) => void;
  inventory: InventoryItem[];
  onUpdateInventory?: (inventory: InventoryItem[]) => void;
  logs: LogTransaksi[];
  orders?: OrderDocument[];
  suratJalanList?: SuratJalanDocument[];
  sales?: SaleDocument[];
  customers?: Pelanggan[];
  currentUser?: User | null;
  onImportAllData: (data: {
    warehouses?: MasterGudang[];
    users?: UserAccount[];
    settings?: AppSystemSettings;
    products?: MasterProduk[];
    inventory?: InventoryItem[];
    logs?: LogTransaksi[];
    orders?: OrderDocument[];
    suratJalanList?: SuratJalanDocument[];
    sales?: SaleDocument[];
    customers?: Pelanggan[];
  }) => void;
  onResetFactoryData: () => void;
  onOpenBackupModal?: () => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  warehouses,
  onUpdateWarehouses,
  users,
  onUpdateUsers,
  settings,
  onUpdateSettings,
  products,
  onUpdateProducts,
  inventory,
  onUpdateInventory,
  logs,
  orders = [],
  suratJalanList = [],
  sales = [],
  customers = [],
  currentUser = null,
  onImportAllData,
  onResetFactoryData,
  onOpenBackupModal,
  showToast,
}) => {
  // Authorization: Manajemen User eksklusif untuk akun OWNER
  const isOwner = Boolean(
    currentUser && (
      currentUser.role === 'OWNER' ||
      currentUser.username.toLowerCase() === 'owner'
    )
  );

  // Authorization: Aksi delete master data eksklusif untuk akun OWNER dan SPV/SUPERVISOR
  const isSpvOrOwner = Boolean(
    currentUser && (
      currentUser.role === 'OWNER' ||
      currentUser.role === 'SUPERVISOR' ||
      (currentUser.role as string) === 'SPV' ||
      currentUser.username?.toLowerCase() === 'owner' ||
      currentUser.username?.toLowerCase() === 'supervisor' ||
      currentUser.username?.toLowerCase() === 'spv'
    )
  );

  const [activeSubTab, setActiveSubTab] = useState<'warehouses' | 'product_barcode' | 'invoice_color' | 'users' | 'store_system' | 'backup_checkpoint'>('warehouses');

  // Keamanan Akses: Jika user bukan OWNER, paksa pindahkan sub-tab dari 'users' ke 'warehouses'
  useEffect(() => {
    if (!isOwner && activeSubTab === 'users') {
      setActiveSubTab('warehouses');
    }
  }, [isOwner, activeSubTab]);

  // Form State: Warehouse Add/Edit Modal
  const [isWarehouseModalOpen, setIsWarehouseModalOpen] = useState(false);
  const [editingWarehouse, setEditingWarehouse] = useState<MasterGudang | null>(null);
  const [whId, setWhId] = useState('');
  const [whName, setWhName] = useState('');
  const [whLocation, setWhLocation] = useState('');
  const [whPic, setWhPic] = useState('');
  const [whPhone, setWhPhone] = useState('');
  const [whNotes, setWhNotes] = useState('');
  const [whIsActive, setWhIsActive] = useState(true);

  // Form State: User Add/Edit Modal
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [uUsername, setUUsername] = useState('');
  const [uPassword, setUPassword] = useState('');
  const [uFullName, setUFullName] = useState('');
  const [uRole, setURole] = useState<UserRole>('STAFF');
  const [uSiteAccess, setUSiteAccess] = useState('GUDANG UTAMA');
  const [uPhone, setUPhone] = useState('');
  const [uEmail, setUEmail] = useState('');
  const [uIsActive, setUIsActive] = useState(true);

  // Product Management States
  const [editingProduct, setEditingProduct] = useState<MasterProduk | null | undefined>(undefined);
  const [labelProduct, setLabelProduct] = useState<MasterProduk | null>(null);
  const [showBatchPrintModal, setShowBatchPrintModal] = useState(false);
  const [batchPrintCopies, setBatchPrintCopies] = useState(2);
  const [batchPaperSize, setBatchPaperSize] = useState<'A4_40_LABELS' | 'THERMAL_50X30' | 'THERMAL_40X20'>('A4_40_LABELS');
  const [batchBarcodeFormat, setBatchBarcodeFormat] = useState<BarcodeFormat>(settings.barcodeFormat || 'CODE128');
  
  // Product Table Filters
  const [prodSearchQuery, setProdSearchQuery] = useState('');
  const [prodColorFilter, setProdColorFilter] = useState('ALL');
  const [prodSizeFilter, setProdSizeFilter] = useState('ALL');
  const [prodCategoryFilter, setProdCategoryFilter] = useState('ALL');
  const [prodLenganFilter, setProdLenganFilter] = useState('ALL');

  // Form State: Store & System Settings
  const [brandName, setBrandName] = useState(settings.brandName);
  const [companySubtitle, setCompanySubtitle] = useState(settings.companySubtitle);
  const [companyAddress, setCompanyAddress] = useState(settings.companyAddress);
  const [companyPhone, setCompanyPhone] = useState(settings.companyPhone);
  const [companyEmail, setCompanyEmail] = useState(settings.companyEmail);
  const [logoUrl, setLogoUrl] = useState<string>(settings.logoUrl || '');
  const [stampUrl, setStampUrl] = useState<string>(settings.stampUrl || '');
  const [useStampAsSignature, setUseStampAsSignature] = useState<boolean>(settings.useStampAsSignature || false);
  const [invoiceHeaderColor, setInvoiceHeaderColor] = useState<string>(settings.invoiceHeaderColor || '#7e22ce');
  const [defaultReorderLevel, setDefaultReorderLevel] = useState(settings.defaultReorderLevel);
  const [skuPrefix, setSkuPrefix] = useState(settings.skuPrefix);
  const [barcodeFormat, setBarcodeFormat] = useState<BarcodeFormat>(settings.barcodeFormat || 'CODE128');
  const [labelPaperSize, setLabelPaperSize] = useState(settings.labelPaperSize);
  const [enableAutoBarcode, setEnableAutoBarcode] = useState(settings.enableAutoBarcode);
  const [googleSheetsWebhookUrl, setGoogleSheetsWebhookUrl] = useState(settings.googleSheetsWebhookUrl || '');

  // Checkpoint & Backup Local States
  const [checkpoints, setCheckpoints] = useState<CheckpointItem[]>(() => CheckpointService.getCheckpoints());
  const [snapTitle, setSnapTitle] = useState('');
  const [snapNote, setSnapNote] = useState('');
  const [isTakingSnap, setIsTakingSnap] = useState(false);
  const [isCopiedJson, setIsCopiedJson] = useState(false);
  const [settingsRollbackTarget, setSettingsRollbackTarget] = useState<CheckpointItem | null>(null);

  // Checkpoint Auto Settings state
  const [chkAutoEnabled, setChkAutoEnabled] = useState(settings.checkpointSettings?.autoCheckpointEnabled ?? true);
  const [chkIntervalMin, setChkIntervalMin] = useState(settings.checkpointSettings?.intervalMinutes ?? 30);
  const [chkMaxCheckpoints, setChkMaxCheckpoints] = useState(settings.checkpointSettings?.maxCheckpoints ?? 15);
  const [chkAutoBeforeOpname, setChkAutoBeforeOpname] = useState(settings.checkpointSettings?.autoBeforeOpname ?? true);
  const [chkAutoBeforeRestore, setChkAutoBeforeRestore] = useState(settings.checkpointSettings?.autoBeforeRestore ?? true);
  const [chkAutoAfterSale, setChkAutoAfterSale] = useState(settings.checkpointSettings?.autoAfterSale ?? false);

  // In-App Custom Delete Confirmation State (Bypasses sandboxed iframe restrictions)
  const [deleteConfirmTarget, setDeleteConfirmTarget] = useState<{
    type: 'product' | 'warehouse' | 'user';
    id: string;
    title: string;
    description: string;
  } | null>(null);

  // Synchronize state when external settings change
  useEffect(() => {
    setBrandName(settings.brandName);
    setCompanySubtitle(settings.companySubtitle);
    setCompanyAddress(settings.companyAddress);
    setCompanyPhone(settings.companyPhone);
    setCompanyEmail(settings.companyEmail);
    setLogoUrl(settings.logoUrl || '');
    setStampUrl(settings.stampUrl || '');
    setUseStampAsSignature(settings.useStampAsSignature || false);
    setInvoiceHeaderColor(settings.invoiceHeaderColor || '#7e22ce');
    setDefaultReorderLevel(settings.defaultReorderLevel);
    setSkuPrefix(settings.skuPrefix);
    setBarcodeFormat(settings.barcodeFormat || 'CODE128');
    setLabelPaperSize(settings.labelPaperSize);
    setEnableAutoBarcode(settings.enableAutoBarcode);
    setGoogleSheetsWebhookUrl(settings.googleSheetsWebhookUrl || '');

    if (settings.checkpointSettings) {
      setChkAutoEnabled(settings.checkpointSettings.autoCheckpointEnabled);
      setChkIntervalMin(settings.checkpointSettings.intervalMinutes);
      setChkMaxCheckpoints(settings.checkpointSettings.maxCheckpoints);
      setChkAutoBeforeOpname(settings.checkpointSettings.autoBeforeOpname);
      setChkAutoBeforeRestore(settings.checkpointSettings.autoBeforeRestore);
      setChkAutoAfterSale(settings.checkpointSettings.autoAfterSale);
    }
  }, [settings]);

  // Handle Logo Upload with Auto-Optimization
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('File yang dipilih harus berupa format gambar (PNG, JPG, SVG, WebP)!', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (readerEvent) => {
      const result = readerEvent.target?.result as string;
      if (!result) return;

      if (file.type === 'image/svg+xml' || file.size < 200000) {
        setLogoUrl(result);
        showToast('Logo toko berhasil dimuat. Klik "Simpan Identitas & Logo Toko" untuk menerapkan ke semua nota.', 'success');
        return;
      }

      // Optimize/downscale image using offscreen canvas to keep localStorage snappy
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDimension = 360;
        let width = img.width;
        let height = img.height;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const optimizedDataUrl = canvas.toDataURL('image/png', 0.9);
          setLogoUrl(optimizedDataUrl);
          showToast('Logo toko berhasil dioptimalkan. Klik simpan untuk menerapkan.', 'success');
        } else {
          setLogoUrl(result);
        }
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  };

  const PRESET_LOGOS = [
    {
      name: 'Kaos Distro Klasik',
      badgeColor: 'bg-purple-600',
      dataUrl:
        'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100"><rect width="100" height="100" rx="20" fill="%237e22ce"/><path d="M30 25 L40 32 C45 35 55 35 60 32 L70 25 L82 35 L74 46 L70 43 L70 78 L30 78 L30 43 L26 46 L18 35 Z" fill="%23ffffff"/><circle cx="50" cy="54" r="9" fill="%23f59e0b"/><text x="50" y="73" font-family="Arial,sans-serif" font-weight="900" font-size="8" fill="%237e22ce" text-anchor="middle">DISTRO</text></svg>',
    },
    {
      name: 'Streetwear Apparel',
      badgeColor: 'bg-[#F27D26]',
      dataUrl:
        'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100"><rect width="100" height="100" rx="20" fill="%23ea580c"/><polygon points="50,15 85,35 85,75 50,95 15,75 15,35" fill="%23ffffff"/><path d="M50 25 L75 40 L50 85 L25 40 Z" fill="%23ea580c"/><text x="50" y="55" font-family="Arial,sans-serif" font-weight="900" font-size="11" fill="%23ffffff" text-anchor="middle">STREET</text></svg>',
    },
    {
      name: 'Cotton 30s Reaktif',
      badgeColor: 'bg-emerald-600',
      dataUrl:
        'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100"><rect width="100" height="100" rx="20" fill="%23059669"/><circle cx="50" cy="50" r="36" fill="%23ffffff"/><path d="M35 50 Q50 30 65 50 Q50 70 35 50" fill="%23059669"/><text x="50" y="78" font-family="Arial,sans-serif" font-weight="900" font-size="8" fill="%23059669" text-anchor="middle">COTTON</text></svg>',
    },
  ];

  // Handle Stamp Upload with Auto-Optimization
  const handleStampUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('File stempel harus berupa format gambar (PNG transparan disarankan, JPG, SVG, WebP)!', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (readerEvent) => {
      const result = readerEvent.target?.result as string;
      if (!result) return;

      if (file.type === 'image/svg+xml' || file.size < 200000) {
        setStampUrl(result);
        setUseStampAsSignature(true);
        showToast('Berkas stempel resmi toko berhasil dimuat. Klik "Simpan Identitas & Stempel Toko" untuk menerapkan.', 'success');
        return;
      }

      // Optimize/downscale image using offscreen canvas
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDimension = 360;
        let width = img.width;
        let height = img.height;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const optimizedDataUrl = canvas.toDataURL('image/png', 0.9);
          setStampUrl(optimizedDataUrl);
          setUseStampAsSignature(true);
          showToast('Berkas stempel berhasil dioptimalkan. Klik simpan untuk menerapkan.', 'success');
        } else {
          setStampUrl(result);
          setUseStampAsSignature(true);
        }
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  };

  const PRESET_STEMPEL = [
    {
      name: 'Stempel Bulat Sah & Lunas',
      badgeColor: 'bg-purple-600',
      dataUrl:
        'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200"><circle cx="100" cy="100" r="92" fill="none" stroke="%239333ea" stroke-width="6" stroke-dasharray="8 4"/><circle cx="100" cy="100" r="82" fill="none" stroke="%239333ea" stroke-width="3"/><circle cx="100" cy="100" r="54" fill="none" stroke="%239333ea" stroke-width="2"/><path id="cTop" d="M 30,100 A 70,70 0 0,1 170,100" fill="none"/><text font-family="Arial,sans-serif" font-weight="900" font-size="12" fill="%239333ea" letter-spacing="2"><textPath href="%23cTop" startOffset="50%" text-anchor="middle">DISTRO KAOS POLOS</textPath></text><path id="cBot" d="M 170,100 A 70,70 0 0,1 30,100" fill="none"/><text font-family="Arial,sans-serif" font-weight="900" font-size="11" fill="%239333ea" letter-spacing="2"><textPath href="%23cBot" startOffset="50%" text-anchor="middle">★ RESMI &amp; SAH ★</textPath></text><text x="100" y="98" font-family="Arial,sans-serif" font-weight="900" font-size="20" fill="%239333ea" text-anchor="middle">LUNAS</text><text x="100" y="118" font-family="Arial,sans-serif" font-weight="bold" font-size="10" fill="%239333ea" text-anchor="middle">GUDANG UTAMA</text></svg>',
    },
    {
      name: 'Stempel Oval Terverifikasi',
      badgeColor: 'bg-[#F27D26]',
      dataUrl:
        'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 220 150" width="220" height="150"><ellipse cx="110" cy="75" rx="100" ry="65" fill="none" stroke="%23ea580c" stroke-width="5"/><ellipse cx="110" cy="75" rx="90" ry="55" fill="none" stroke="%23ea580c" stroke-width="2"/><text x="110" y="48" font-family="Arial,sans-serif" font-weight="900" font-size="13" fill="%23ea580c" text-anchor="middle" letter-spacing="2">GUDANG UTAMA APPAREL</text><line x1="30" y1="56" x2="190" y2="56" stroke="%23ea580c" stroke-width="2"/><text x="110" y="82" font-family="Arial,sans-serif" font-weight="900" font-size="19" fill="%23ea580c" text-anchor="middle">TERVERIFIKASI</text><line x1="30" y1="92" x2="190" y2="92" stroke="%23ea580c" stroke-width="2"/><text x="110" y="112" font-family="Arial,sans-serif" font-weight="bold" font-size="10" fill="%23ea580c" text-anchor="middle">PENGESAHAN DOKUMEN</text></svg>',
    },
    {
      name: 'Stempel Kotak Navy Approved',
      badgeColor: 'bg-blue-800',
      dataUrl:
        'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 140" width="200" height="140"><rect x="10" y="10" width="180" height="120" rx="14" fill="none" stroke="%231e3a8a" stroke-width="5"/><rect x="18" y="18" width="164" height="104" rx="8" fill="none" stroke="%231e3a8a" stroke-width="2"/><text x="100" y="46" font-family="Arial,sans-serif" font-weight="900" font-size="12" fill="%231e3a8a" text-anchor="middle" letter-spacing="3">OFFICIAL WAREHOUSE</text><text x="100" y="78" font-family="Arial,sans-serif" font-weight="900" font-size="24" fill="%231e3a8a" text-anchor="middle">APPROVED</text><text x="100" y="104" font-family="Arial,sans-serif" font-weight="bold" font-size="10" fill="%231e3a8a" text-anchor="middle">KAOS COMBED 30S</text></svg>',
    },
  ];

  // Render Simulation Barcode / QR Code preview in real-time
  useEffect(() => {
    const simCanvas = document.getElementById('sim-barcode-canvas') as HTMLCanvasElement | null;
    if (simCanvas) {
      const sampleText = `${skuPrefix || 'KPCM-30S'}-HTM-L-PDK`;
      if (barcodeFormat === 'QR_CODE') {
        renderCodeToCanvas(simCanvas, sampleText, 'QR_CODE', { qrWidth: 54, qrMargin: 1 });
      } else {
        renderCodeToCanvas(simCanvas, sampleText, 'CODE128', { barWidth: 1.1, height: 28, margin: 2 });
      }
    }
  }, [skuPrefix, barcodeFormat, activeSubTab]);

  // Filtered Products List
  const filteredProducts = products.filter((p) => {
    const q = prodSearchQuery.trim().toLowerCase();
    const matchSearch =
      !q ||
      p.SKU_ID.toLowerCase().includes(q) ||
      p.NAMA_PRODUK.toLowerCase().includes(q) ||
      p.WARNA.toLowerCase().includes(q) ||
      (p.BARCODE_ID && p.BARCODE_ID.toLowerCase().includes(q));

    const matchColor = prodColorFilter === 'ALL' || p.WARNA.toUpperCase() === prodColorFilter.toUpperCase();
    const matchSize = prodSizeFilter === 'ALL' || p.UKURAN.toUpperCase() === prodSizeFilter.toUpperCase();
    const matchCat = prodCategoryFilter === 'ALL' || p.KATEGORI.toUpperCase() === prodCategoryFilter.toUpperCase();
    const matchLengan = prodLenganFilter === 'ALL' || (p.JENIS_LENGAN || 'PENDEK').toUpperCase() === prodLenganFilter.toUpperCase();

    return matchSearch && matchColor && matchSize && matchCat && matchLengan;
  });

  // Unique Colors & Sizes for Filter Dropdowns
  const uniqueColors = Array.from(new Set(products.map((p) => p.WARNA))).filter(Boolean);
  const uniqueSizes = Array.from(new Set(products.map((p) => p.UKURAN))).filter(Boolean);
  const uniqueCategories = Array.from(new Set(products.map((p) => p.KATEGORI))).filter(Boolean);

  // ==========================================
  // PRODUCT MANAGEMENT ACTIONS
  // ==========================================
  const handleSaveProduct = (prodData: MasterProduk) => {
    const exists = products.some((p) => p.SKU_ID === prodData.SKU_ID);
    let updatedProducts: MasterProduk[];

    if (exists) {
      updatedProducts = products.map((p) => (p.SKU_ID === prodData.SKU_ID ? prodData : p));
      showToast(`Produk ${prodData.SKU_ID} berhasil diperbarui.`, 'success');
    } else {
      updatedProducts = [prodData, ...products];
      showToast(`Produk baru ${prodData.SKU_ID} berhasil ditambahkan ke master data.`, 'success');
    }

    onUpdateProducts(updatedProducts);

    // Sync inventory row for all warehouses if not exists
    if (onUpdateInventory && inventory) {
      let updatedInventory = [...inventory];
      warehouses.forEach((wh) => {
        const invExists = updatedInventory.some(
          (inv) => inv.GUDANG_ID === wh.GUDANG_ID && inv.SKU_ID === prodData.SKU_ID
        );
        if (!invExists) {
          updatedInventory.push({
            GUDANG_ID: wh.GUDANG_ID,
            SKU_ID: prodData.SKU_ID,
            NAMA_PRODUK: prodData.NAMA_PRODUK,
            JUMLAH_READY: 0,
            REORDER_LEVEL: prodData.REORDER_LEVEL || defaultReorderLevel,
            REORDER: 'YES',
            WARNA: prodData.WARNA,
            UKURAN: prodData.UKURAN,
            KATEGORI: prodData.KATEGORI,
            JENIS_LENGAN: prodData.JENIS_LENGAN,
          });
        }
      });
      onUpdateInventory(updatedInventory);
    }

    setEditingProduct(undefined);
  };

  const handleDeleteProduct = (skuId: string) => {
    if (!isSpvOrOwner) {
      showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan menghapus master produk!', 'error');
      return;
    }
    const target = products.find((p) => p.SKU_ID === skuId);
    setDeleteConfirmTarget({
      type: 'product',
      id: skuId,
      title: `Hapus Produk: ${skuId}`,
      description: `Apakah Anda yakin ingin menghapus produk "${target?.NAMA_PRODUK || skuId}" (${skuId}) dari master data? Seluruh varian dan stok produk ini akan dihapus dari katalog.`,
    });
  };

  const handleSyncAllWarehouses = () => {
    if (!onUpdateInventory) return;
    let countAdded = 0;
    let updatedInventory = [...inventory];

    warehouses.forEach((wh) => {
      products.forEach((p) => {
        const exists = updatedInventory.some(
          (i) => i.GUDANG_ID === wh.GUDANG_ID && i.SKU_ID === p.SKU_ID
        );
        if (!exists) {
          updatedInventory.push({
            GUDANG_ID: wh.GUDANG_ID,
            SKU_ID: p.SKU_ID,
            NAMA_PRODUK: p.NAMA_PRODUK,
            JUMLAH_READY: 0,
            REORDER_LEVEL: p.REORDER_LEVEL || defaultReorderLevel,
            REORDER: 'YES',
            WARNA: p.WARNA,
            UKURAN: p.UKURAN,
            KATEGORI: p.KATEGORI,
            JENIS_LENGAN: p.JENIS_LENGAN,
          });
          countAdded++;
        }
      });
    });

    onUpdateInventory(updatedInventory);
    showToast(`Sinkronisasi selesai: ${countAdded} slot inventori baru dibuat di seluruh gudang.`, 'success');
  };

  const handleExportProductsCsv = () => {
    const headers = ['SKU_ID', 'NAMA_PRODUK', 'WARNA', 'UKURAN', 'KATEGORI', 'JENIS_LENGAN', 'REORDER_LEVEL', 'BARCODE_ID'];
    const rows = products.map((p) => [
      `"${p.SKU_ID}"`,
      `"${p.NAMA_PRODUK}"`,
      `"${p.WARNA}"`,
      `"${p.UKURAN}"`,
      `"${p.KATEGORI}"`,
      `"${p.JENIS_LENGAN || 'PENDEK'}"`,
      p.REORDER_LEVEL,
      `"${p.BARCODE_ID || p.SKU_ID}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `master_produk_kaos_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
    showToast('File CSV Master Produk berhasil diekspor.', 'success');
  };

  const handleExecuteBatchPrint = async () => {
    const printList = filteredProducts.length > 0 ? filteredProducts : products;
    if (printList.length === 0) {
      showToast('Tidak ada produk yang dipilih untuk dicetak!', 'error');
      return;
    }

    const targetFormat = batchBarcodeFormat || barcodeFormat;
    const isQr = targetFormat === 'QR_CODE';
    const isThermal = batchPaperSize === 'THERMAL_50X30' || batchPaperSize === 'THERMAL_40X20';

    showToast('Sedang menyiapkan lembar cetak label...', 'info');

    // Pre-generate images
    const codeImgMap: Record<string, string> = {};
    for (const prod of printList) {
      const bVal = (prod.BARCODE_ID || prod.SKU_ID).toUpperCase();
      if (!codeImgMap[bVal]) {
        codeImgMap[bVal] = await generateCodeDataUrl(
          bVal,
          targetFormat,
          isQr
            ? { qrWidth: 160, qrMargin: 1 }
            : { barWidth: 1.8, height: 50, margin: 6 }
        );
      }
    }

    const cardsHtml = printList
      .map((product) => {
        const barcodeVal = (product.BARCODE_ID || product.SKU_ID).toUpperCase();
        const imgUrl = codeImgMap[barcodeVal];
        return Array.from({ length: batchPrintCopies })
          .map(
            () => `
            <div class="label-card ${isQr ? 'qr-card' : 'bar-card'}">
              <div class="brand-title">${brandName || 'INVENTORI KAOS POLOS'}</div>
              <div class="product-name">${product.NAMA_PRODUK}</div>
              <div class="product-variant">${product.WARNA} • ${product.UKURAN} • ${product.JENIS_LENGAN || 'PENDEK'}</div>
              <div class="img-wrap">
                <img src="${imgUrl}" alt="${barcodeVal}" class="${isQr ? 'qr-img' : 'barcode-img'}" />
              </div>
              <div class="sku-code">${barcodeVal}</div>
            </div>
          `
          )
          .join('');
      })
      .join('');

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Cetak Massal ${isQr ? 'QR Code' : 'Barcode'} Label Kaos (${printList.length} Produk)</title>
        <meta charset="utf-8" />
        <style>
          @page {
            size: ${isThermal ? '58mm 40mm' : 'A4 portrait'};
            margin: ${isThermal ? '2mm' : '8mm'};
          }
          * { box-sizing: border-box; }
          body {
            font-family: system-ui, -apple-system, sans-serif;
            margin: 0;
            padding: ${isThermal ? '2px' : '10px'};
            background: #fff;
            color: #0f172a;
          }
          .grid-container {
            display: grid;
            grid-template-columns: ${isThermal ? '1fr' : 'repeat(4, 1fr)'};
            gap: ${isThermal ? '4mm' : '5mm'};
          }
          .label-card {
            border: 1px dashed #94a3b8;
            border-radius: 6px;
            padding: 6px 8px;
            text-align: center;
            background: #fff;
            page-break-inside: avoid;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: ${isThermal ? '125px' : '138px'};
          }
          .brand-title {
            font-size: 8px;
            font-weight: 800;
            text-transform: uppercase;
            color: #64748b;
            letter-spacing: 0.5px;
            margin-bottom: 2px;
          }
          .product-name {
            font-size: 11px;
            font-weight: 800;
            color: #0f172a;
            margin-bottom: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 100%;
          }
          .product-variant {
            font-size: 9px;
            font-weight: 700;
            color: #334155;
            margin-bottom: 3px;
          }
          .img-wrap {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 2px 0;
          }
          .barcode-img {
            max-height: 38px;
            max-width: 95%;
            object-fit: contain;
          }
          .qr-img {
            width: 52px;
            height: 52px;
            object-fit: contain;
          }
          .sku-code {
            font-family: monospace;
            font-size: 9px;
            font-weight: 800;
            color: #0f172a;
            letter-spacing: 1px;
            margin-top: 1px;
          }
          @media print {
            body { padding: 0; }
            .no-print { display: none !important; }
            .label-card { border: 1px solid #cbd5e1; }
          }
        </style>
      </head>
      <body>
        <div class="no-print" style="margin-bottom: 12px; padding: 10px 14px; background: #f1f5f9; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
          <span style="font-weight: bold; font-size: 13px;">Lembar Cetak Massal ${isQr ? 'QR Code 2D' : 'Barcode Code-128'} (${printList.length} SKU x ${batchPrintCopies} Pcs = ${printList.length * batchPrintCopies} Label)</span>
          <button onclick="window.print()" style="padding: 6px 16px; background: #7c3aed; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">Cetak Sekarang</button>
        </div>
        <div class="grid-container">
          ${cardsHtml}
        </div>
        <script>
          window.onload = () => {
            setTimeout(() => { window.print(); }, 400);
          };
        </script>
      </body>
      </html>
    `;

    try {
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      const blobUrl = URL.createObjectURL(blob);
      let printWin = window.open(blobUrl, '_blank');
      if (!printWin) {
        printWin = window.open('', '_blank');
        if (printWin) {
          printWin.document.open();
          printWin.document.write(html);
          printWin.document.close();
        } else {
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = `Batch_Labels_${printList.length}SKU.html`;
          document.body.appendChild(a);
          a.click();
          a.remove();
        }
      }
    } catch {
      window.print();
    }
    setShowBatchPrintModal(false);
    showToast(`Mempersiapkan cetak massal ${printList.length * batchPrintCopies} label.`, 'success');
  };

  // ==========================================
  // WAREHOUSE ACTIONS
  // ==========================================
  const handleOpenAddWarehouse = () => {
    setEditingWarehouse(null);
    const nextNum = warehouses.length + 1;
    setWhId(`GDG-0${nextNum}-CABANG`);
    setWhName(`GUDANG CABANG ${nextNum}`);
    setWhLocation('');
    setWhPic('Admin Gudang');
    setWhPhone('');
    setWhNotes('');
    setWhIsActive(true);
    setIsWarehouseModalOpen(true);
  };

  const handleOpenEditWarehouse = (wh: MasterGudang) => {
    setEditingWarehouse(wh);
    setWhId(wh.GUDANG_ID);
    setWhName(wh.NAMA_GUDANG);
    setWhLocation(wh.LOKASI || '');
    setWhPic(wh.PENANGGUNG_JAWAB || '');
    setWhPhone(wh.TELEPON || '');
    setWhNotes(wh.KETERANGAN || '');
    setWhIsActive(wh.IS_ACTIVE !== false);
    setIsWarehouseModalOpen(true);
  };

  const handleSaveWarehouse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!whId.trim() || !whName.trim()) {
      showToast('ID dan Nama Gudang wajib diisi!', 'error');
      return;
    }

    if (editingWarehouse) {
      // Update existing
      const updated = warehouses.map((w) =>
        w.GUDANG_ID === editingWarehouse.GUDANG_ID
          ? {
              ...w,
              GUDANG_ID: whId.trim().toUpperCase(),
              NAMA_GUDANG: whName.trim().toUpperCase(),
              LOKASI: whLocation.trim(),
              PENANGGUNG_JAWAB: whPic.trim(),
              TELEPON: whPhone.trim(),
              KETERANGAN: whNotes.trim(),
              IS_ACTIVE: whIsActive,
            }
          : w
      );
      onUpdateWarehouses(updated);
      showToast(`Gudang "${whName}" berhasil diperbarui.`, 'success');
    } else {
      // Create new
      if (warehouses.some((w) => w.GUDANG_ID.toUpperCase() === whId.trim().toUpperCase())) {
        showToast('ID Gudang sudah ada! Gunakan ID lain.', 'error');
        return;
      }
      const newWh: MasterGudang = {
        GUDANG_ID: whId.trim().toUpperCase(),
        NAMA_GUDANG: whName.trim().toUpperCase(),
        LOKASI: whLocation.trim(),
        PENANGGUNG_JAWAB: whPic.trim(),
        TELEPON: whPhone.trim(),
        KETERANGAN: whNotes.trim(),
        IS_ACTIVE: whIsActive,
        IS_DEFAULT: false,
      };
      onUpdateWarehouses([...warehouses, newWh]);
      showToast(`Gudang baru "${whName}" berhasil ditambahkan.`, 'success');
    }
    setIsWarehouseModalOpen(false);
  };

  const handleToggleWarehouseActive = (id: string) => {
    const target = warehouses.find((w) => w.GUDANG_ID === id);
    if (!target) return;
    const isCurrentlyActive = target.IS_ACTIVE !== false;

    // Cegah menonaktifkan jika ini adalah satu-satunya gudang aktif
    if (isCurrentlyActive) {
      const activeCount = warehouses.filter((w) => w.IS_ACTIVE !== false).length;
      if (activeCount <= 1) {
        showToast('Minimal harus ada 1 gudang yang berstatus aktif dalam sistem!', 'error');
        return;
      }
    }

    const updated = warehouses.map((w) =>
      w.GUDANG_ID === id ? { ...w, IS_ACTIVE: !isCurrentlyActive } : w
    );
    onUpdateWarehouses(updated);
    showToast(`Status gudang ${target.NAMA_GUDANG} berhasil diubah menjadi ${!isCurrentlyActive ? 'Aktif' : 'Non-Aktif'}.`, 'info');
  };

  const handleDeleteWarehouse = (id: string) => {
    if (!isSpvOrOwner) {
      showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan menghapus data gudang!', 'error');
      return;
    }
    if (warehouses.length <= 1) {
      showToast('Minimal harus ada 1 gudang aktif dalam sistem!', 'error');
      return;
    }
    const target = warehouses.find((w) => w.GUDANG_ID === id);
    setDeleteConfirmTarget({
      type: 'warehouse',
      id,
      title: `Hapus Gudang: ${target?.NAMA_GUDANG || id}`,
      description: `Apakah Anda yakin ingin menghapus gudang "${target?.NAMA_GUDANG || id}" (${id}) dari sistem? Seluruh data inventori di gudang ini akan ikut dibersihkan.`,
    });
  };

  // ==========================================
  // USER MANAGEMENT ACTIONS (EXCLUSIVELY OWNER)
  // ==========================================
  const handleOpenAddUser = () => {
    if (!isOwner) {
      showToast('Akses Ditolak: Hanya akun OWNER yang memiliki wewenang menambah akun pengguna!', 'error');
      return;
    }
    setEditingUser(null);
    setUUsername('');
    setUPassword('');
    setUFullName('');
    setURole('STAFF');
    setUSiteAccess(warehouses[0]?.NAMA_GUDANG || 'GUDANG UTAMA');
    setUPhone('');
    setUEmail('');
    setUIsActive(true);
    setIsUserModalOpen(true);
  };

  const handleOpenEditUser = (user: UserAccount) => {
    if (!isOwner) {
      showToast('Akses Ditolak: Hanya akun OWNER yang memiliki wewenang mengedit data pengguna!', 'error');
      return;
    }
    setEditingUser(user);
    setUUsername(user.username);
    setUPassword(user.password || '');
    setUFullName(user.fullName);
    setURole(user.role);
    setUSiteAccess(user.siteAccess);
    setUPhone(user.phone || '');
    setUEmail(user.email || '');
    setUIsActive(user.isActive);
    setIsUserModalOpen(true);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOwner) {
      showToast('Akses Ditolak: Hanya akun OWNER yang berhak menyimpan data pengguna!', 'error');
      return;
    }
    if (!uUsername.trim() || !uFullName.trim()) {
      showToast('Username dan Nama Lengkap wajib diisi!', 'error');
      return;
    }

    if (editingUser) {
      const updated = users.map((u) =>
        u.id === editingUser.id
          ? {
              ...u,
              username: uUsername.trim().toLowerCase(),
              fullName: uFullName.trim(),
              role: uRole,
              siteAccess: uSiteAccess,
              password: uPassword.trim() || u.password,
              phone: uPhone.trim(),
              email: uEmail.trim(),
              isActive: uIsActive,
            }
          : u
      );
      onUpdateUsers(updated);
      showToast(`Data user "${uFullName}" berhasil diperbarui.`, 'success');
    } else {
      if (users.some((u) => u.username.toLowerCase() === uUsername.trim().toLowerCase())) {
        showToast('Username sudah digunakan! Pilih username lain.', 'error');
        return;
      }
      const newUser: UserAccount = {
        id: `USR-${String(users.length + 1).padStart(3, '0')}`,
        username: uUsername.trim().toLowerCase(),
        password: uPassword.trim() || '123456',
        fullName: uFullName.trim(),
        role: uRole,
        siteAccess: uSiteAccess,
        phone: uPhone.trim(),
        email: uEmail.trim(),
        isActive: uIsActive,
        createdAt: new Date().toISOString(),
      };
      onUpdateUsers([...users, newUser]);
      showToast(`User baru "${uFullName}" berhasil ditambahkan.`, 'success');
    }
    setIsUserModalOpen(false);
  };

  const handleToggleUserActive = (id: string) => {
    if (!isOwner) {
      showToast('Akses Ditolak: Hanya akun OWNER yang berhak mengubah status aktif pengguna!', 'error');
      return;
    }
    const target = users.find((u) => u.id === id);
    if (!target) return;
    const updated = users.map((u) => (u.id === id ? { ...u, isActive: !u.isActive } : u));
    onUpdateUsers(updated);
    showToast(`Status user ${target.fullName} diubah menjadi ${!target.isActive ? 'Aktif' : 'Non-Aktif'}.`, 'info');
  };

  const handleDeleteUser = (id: string) => {
    if (!isOwner) {
      showToast('Akses Ditolak: Hanya akun OWNER yang berhak menghapus akun pengguna!', 'error');
      return;
    }
    if (users.length <= 1) {
      showToast('Minimal harus ada 1 user admin dalam sistem!', 'error');
      return;
    }
    const target = users.find((u) => u.id === id);
    setDeleteConfirmTarget({
      type: 'user',
      id,
      title: `Hapus Akun User: ${target?.fullName || target?.username || id}`,
      description: `Apakah Anda yakin ingin menghapus akun user "${target?.fullName || target?.username || id}" (${target?.username})? Pengguna ini tidak akan bisa login lagi ke sistem.`,
    });
  };

  const handleConfirmDelete = () => {
    if (!deleteConfirmTarget) return;
    const { type, id } = deleteConfirmTarget;

    if (type === 'warehouse') {
      if (!isSpvOrOwner) {
        showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan menghapus data gudang!', 'error');
        setDeleteConfirmTarget(null);
        return;
      }
      const updated = warehouses.filter((w) => w.GUDANG_ID !== id);
      onUpdateWarehouses(updated);
      if (onUpdateInventory) {
        onUpdateInventory(inventory.filter((i) => i.GUDANG_ID !== id));
      }
      showToast(`Gudang ${id} berhasil dihapus dari sistem.`, 'success');
    } else if (type === 'product') {
      if (!isSpvOrOwner) {
        showToast('Akses Ditolak: Hanya akun dengan role Owner atau SPV yang diizinkan menghapus master produk!', 'error');
        setDeleteConfirmTarget(null);
        return;
      }
      const updated = products.filter((p) => p.SKU_ID !== id);
      onUpdateProducts(updated);
      if (onUpdateInventory) {
        onUpdateInventory(inventory.filter((i) => i.SKU_ID !== id));
      }
      MysqlSyncService.deleteProduct(id).catch((err) => console.error('Firestore delete product:', err));
      showToast(`Produk ${id} berhasil dihapus dari Master Produk.`, 'success');
    } else if (type === 'user') {
      if (!isOwner) {
        showToast('Akses Ditolak: Hanya akun OWNER yang berhak menghapus akun pengguna!', 'error');
        setDeleteConfirmTarget(null);
        return;
      }
      const updated = users.filter((u) => u.id !== id);
      onUpdateUsers(updated);
      showToast(`Akun user berhasil dihapus dari sistem.`, 'success');
    }

    setDeleteConfirmTarget(null);
  };

  // ==========================================
  // SYSTEM & PRODUCT SETTINGS SAVE
  // ==========================================
  const handleSaveSystemSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const newSettings: AppSystemSettings = {
      ...settings,
      brandName: brandName.trim(),
      companySubtitle: companySubtitle.trim(),
      companyAddress: companyAddress.trim(),
      companyPhone: companyPhone.trim(),
      companyEmail: companyEmail.trim(),
      logoUrl: logoUrl.trim(),
      stampUrl: stampUrl.trim(),
      useStampAsSignature,
      invoiceHeaderColor: invoiceHeaderColor.trim() || '#7e22ce',
      defaultReorderLevel: Number(defaultReorderLevel) || 15,
      skuPrefix: skuPrefix.trim().toUpperCase(),
      barcodeFormat,
      labelPaperSize,
      enableAutoBarcode,
      googleSheetsWebhookUrl: googleSheetsWebhookUrl.trim(),
    };
    onUpdateSettings(newSettings);
    showToast('Pengaturan sistem, identitas toko, logo & stempel berhasil disimpan!', 'success');
  };

  // ==========================================
  // BACKUP & RESTORE JSON & CHECKPOINTS
  // ==========================================
  const currentStateSnapshot: AppStateSnapshot = {
    products,
    warehouses,
    inventory,
    logs,
    users,
    settings,
    orders,
    suratJalanList,
    sales,
    customers,
  };

  const handleExportBackup = () => {
    try {
      const backupData = CheckpointService.generateBackupData(currentStateSnapshot, 'Export dari Pengaturan');
      CheckpointService.downloadBackupJson(backupData);
      showToast('Berkas backup JSON komprehensif berhasil diunduh.', 'success');
    } catch {
      showToast('Gagal mengunduh berkas backup JSON.', 'error');
    }
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    const file = e.target.files?.[0];
    if (!file) return;

    fileReader.readAsText(file, 'UTF-8');
    fileReader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const result = CheckpointService.validateBackupJson(text);
        if (!result.valid || !result.data) {
          showToast(result.error || 'Format file JSON tidak valid atau korup!', 'error');
          return;
        }

        const data = result.data;
        const msg = `Pulihkan data backup dari file "${file.name}"?\n• ${data.summary.totalProducts} Produk (${formatNumber(data.summary.totalStockPcs)} Pcs)\n• ${data.summary.totalWarehouses} Gudang\n• ${data.summary.totalTransactions} Log Transaksi\n• ${data.summary.totalSales} Penjualan\n\nSafety Checkpoint cadangan akan otomatis dibuat sebelum pemulihan.`;

        if (confirm(msg)) {
          // Buat safety checkpoint otomatis
          CheckpointService.createCheckpoint(
            'AUTO_RESTORE',
            `Safety Rollback sebelum Impor ${file.name}`,
            currentUser?.fullName || currentUser?.username || 'Sistem',
            currentStateSnapshot,
            'Dibuat otomatis sebelum menimpa data sistem.',
            settings.checkpointSettings
          );

          onImportAllData(data);
          setCheckpoints(CheckpointService.getCheckpoints());
          showToast(`✅ Seluruh data berhasil dipulihkan dari "${file.name}"!`, 'success');
        }
      } catch (err) {
        showToast('Format file JSON tidak valid atau korup!', 'error');
      }
    };
    // reset input
    e.target.value = '';
  };

  const handleTakeManualSnapshot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!snapTitle.trim()) {
      showToast('Masukkan judul snapshot manual terlebih dahulu!', 'error');
      return;
    }

    setIsTakingSnap(true);
    try {
      const newChk = CheckpointService.createCheckpoint(
        'MANUAL',
        snapTitle.trim(),
        currentUser?.fullName || currentUser?.username || 'Admin',
        currentStateSnapshot,
        snapNote.trim(),
        settings.checkpointSettings
      );
      setCheckpoints(CheckpointService.getCheckpoints());
      setSnapTitle('');
      setSnapNote('');
      showToast(`✅ Snapshot "${newChk.name}" berhasil dibuat dan disimpan!`, 'success');
    } catch {
      showToast('Gagal membuat snapshot manual.', 'error');
    } finally {
      setIsTakingSnap(false);
    }
  };

  const handleExecuteSettingsRollback = () => {
    if (!settingsRollbackTarget) return;

    // Safety snapshot
    CheckpointService.createCheckpoint(
      'AUTO_RESTORE',
      `Safety Rollback sebelum Pulihkan [${settingsRollbackTarget.name}]`,
      currentUser?.fullName || currentUser?.username || 'Sistem',
      currentStateSnapshot,
      'Dibuat otomatis sebelum rollback dari halaman Pengaturan.',
      settings.checkpointSettings
    );

    onImportAllData(settingsRollbackTarget.data);
    setCheckpoints(CheckpointService.getCheckpoints());
    showToast(`✅ Sistem berhasil dikembalikan ke checkpoint "${settingsRollbackTarget.name}"!`, 'success');
    setSettingsRollbackTarget(null);
  };

  const handleSaveCheckpointSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedSettings: AppSystemSettings = {
      ...settings,
      checkpointSettings: {
        autoCheckpointEnabled: chkAutoEnabled,
        intervalMinutes: Number(chkIntervalMin) || 30,
        maxCheckpoints: Number(chkMaxCheckpoints) || 15,
        autoBeforeOpname: chkAutoBeforeOpname,
        autoBeforeRestore: chkAutoBeforeRestore,
        autoAfterSale: chkAutoAfterSale,
      },
    };
    onUpdateSettings(updatedSettings);
    showToast('Pengaturan Checkpoint Otomatis berhasil disimpan.', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Settings Header Navigation */}
      <div className="bg-[#161618] rounded-2xl border border-[#26262B] p-4 sm:p-5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F27D26]/10 border border-[#F27D26]/30 flex items-center justify-center text-[#F27D26]">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-base sm:text-lg text-white">
                Pusat Pengaturan Sistem & Konfigurasi
              </h2>
              <p className="text-xs text-neutral-400">
                Kelola gudang aktif, master produk & barcode, hak akses pengguna, serta integrasi toko
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                if (onOpenBackupModal) onOpenBackupModal();
                else setActiveSubTab('backup_checkpoint');
              }}
              className="px-3.5 py-1.5 bg-[#F27D26]/15 hover:bg-[#F27D26] text-[#F27D26] hover:text-white border border-[#F27D26]/40 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
              title="Buka Pusat Backup & Checkpoint"
            >
              <Database className="w-3.5 h-3.5" /> Backup & Checkpoint
            </button>

            <button
              type="button"
              onClick={handleExportBackup}
              className="px-3 py-1.5 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-200 border border-[#2B2B32] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Download Backup Lengkap JSON"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" /> Export JSON
            </button>
            <label className="px-3 py-1.5 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-200 border border-[#2B2B32] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer">
              <Upload className="w-3.5 h-3.5 text-blue-400" /> Restore JSON
              <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
            </label>
          </div>
        </div>

        {/* Sub Navigation Tabs */}
        <div className="flex items-center gap-2 border-t border-[#24242A] pt-4 overflow-x-auto">
          {[
            { id: 'warehouses' as const, label: `Gudang Aktif (${warehouses.filter((w) => w.IS_ACTIVE !== false).length})`, icon: Building2 },
            { id: 'product_barcode' as const, label: 'Master Produk & Barcode', icon: Tag },
            { id: 'invoice_color' as const, label: 'Warna Header Faktur', icon: Palette },
            ...(isOwner ? [{ id: 'users' as const, label: `Manajemen User (${users.length})`, icon: Users }] : []),
            { id: 'store_system' as const, label: 'Identitas Toko & Integrasi', icon: Settings },
            { id: 'backup_checkpoint' as const, label: `Backup & Checkpoint (${checkpoints.length})`, icon: Database },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeSubTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveSubTab(tab.id)}
                className={`py-2 px-3.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-[#F27D26] text-white shadow-md shadow-[#F27D26]/20'
                    : 'bg-[#1C1C20] text-neutral-300 hover:text-white border border-[#2B2B32]'
                }`}
              >
                <Icon className="w-4 h-4" /> {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SUB-TAB 1: GUDANG YANG AKTIF (WAREHOUSE MANAGEMENT) */}
      {/* ========================================================================= */}
      {activeSubTab === 'warehouses' && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="bg-[#161618] rounded-2xl border border-[#26262B] p-4 sm:p-5 shadow-xs">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-[#F27D26]" /> Konfigurasi Gudang & Multi-Cabang
                </h3>
                <p className="text-xs text-neutral-400">
                  Tambah cabang baru, atur penanggung jawab, dan aktifkan atau non-aktifkan site gudang
                </p>
              </div>

              <button
                type="button"
                onClick={handleOpenAddWarehouse}
                className="px-4 py-2 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Tambah Gudang Baru
              </button>
            </div>

            {/* Warehouse Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {warehouses.map((wh) => {
                const isActive = wh.IS_ACTIVE !== false;
                const stockCount = inventory
                  .filter((i) => i.GUDANG_ID === wh.GUDANG_ID)
                  .reduce((acc, curr) => acc + curr.JUMLAH_READY, 0);
                const skuCount = inventory.filter((i) => i.GUDANG_ID === wh.GUDANG_ID).length;

                return (
                  <div
                    key={wh.GUDANG_ID}
                    className={`rounded-2xl border p-4 transition-all flex flex-col justify-between ${
                      isActive
                        ? 'bg-[#121214] border-[#2A2A30] hover:border-[#3E3E48]'
                        : 'bg-[#121214]/60 border-neutral-800/60 opacity-65'
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <span className="px-2.5 py-0.5 rounded-md font-mono text-[11px] font-extrabold bg-[#1E1E24] text-neutral-300 border border-[#2F2F38]">
                          {wh.GUDANG_ID}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleToggleWarehouseActive(wh.GUDANG_ID)}
                            className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold flex items-center gap-1 cursor-pointer transition-colors ${
                              isActive
                                ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                                : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
                            }`}
                            title="Klik untuk toggle status aktif"
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-emerald-400' : 'bg-neutral-500'}`} />
                            {isActive ? 'Aktif' : 'Non-Aktif'}
                          </button>
                        </div>
                      </div>

                      <h4 className="font-extrabold text-base text-white mb-1">{wh.NAMA_GUDANG}</h4>

                      <div className="space-y-1 text-xs text-neutral-400 mb-3">
                        {wh.LOKASI && (
                          <div className="flex items-center gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                            <span className="truncate">{wh.LOKASI}</span>
                          </div>
                        )}
                        {wh.PENANGGUNG_JAWAB && (
                          <div className="flex items-center gap-1.5">
                            <ShieldCheck className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                            <span>PIC: <strong className="text-neutral-200">{wh.PENANGGUNG_JAWAB}</strong></span>
                          </div>
                        )}
                        {wh.TELEPON && (
                          <div className="flex items-center gap-1.5">
                            <Phone className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                            <span>{wh.TELEPON}</span>
                          </div>
                        )}
                      </div>

                      {/* Stock Summary in this warehouse */}
                      <div className="grid grid-cols-2 gap-2 bg-[#18181C] p-2.5 rounded-xl border border-[#26262C] mb-3">
                        <div className="text-center">
                          <span className="text-[10px] text-neutral-400 uppercase font-bold block">Total Stok</span>
                          <span className="text-sm font-extrabold text-emerald-400">{stockCount} pcs</span>
                        </div>
                        <div className="text-center border-l border-[#26262C]">
                          <span className="text-[10px] text-neutral-400 uppercase font-bold block">Variasi SKU</span>
                          <span className="text-sm font-extrabold text-neutral-200">{skuCount} SKU</span>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-end gap-1.5 pt-2 border-t border-[#24242A]">
                      <button
                        type="button"
                        onClick={() => handleToggleWarehouseActive(wh.GUDANG_ID)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                          isActive
                            ? 'bg-amber-950/40 hover:bg-amber-900/50 text-amber-300 border border-amber-800/40'
                            : 'bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 border border-emerald-800/40'
                        }`}
                        title={isActive ? 'Klik untuk non-aktifkan operasional gudang ini' : 'Klik untuk aktifkan kembali gudang ini'}
                      >
                        {isActive ? (
                          <>
                            <ToggleLeft className="w-3.5 h-3.5 text-amber-400" />
                            <span>Non-Aktif</span>
                          </>
                        ) : (
                          <>
                            <ToggleRight className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Aktifkan</span>
                          </>
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleOpenEditWarehouse(wh)}
                        className="px-2.5 py-1 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-200 border border-[#2B2B32] rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <Edit2 className="w-3 h-3" /> Edit
                      </button>
                      {isSpvOrOwner ? (
                        <button
                          type="button"
                          onClick={() => handleDeleteWarehouse(wh.GUDANG_ID)}
                          className="px-2.5 py-1 bg-rose-950/50 hover:bg-rose-900/60 text-rose-400 border border-rose-800/40 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                          title="Hapus Gudang (Akses Owner & SPV)"
                        >
                          <Trash2 className="w-3 h-3" /> Hapus
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled
                          className="px-2.5 py-1 bg-neutral-900/40 text-neutral-600 border border-neutral-800/80 rounded-lg text-xs font-bold flex items-center gap-1 cursor-not-allowed opacity-35 select-none"
                          title="Aksi Hapus Terkunci (Hanya untuk Owner & SPV)"
                        >
                          <Trash2 className="w-3 h-3 text-neutral-600" /> Hapus
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 2: MASTER PRODUK & BARCODE CONFIG */}
      {/* ========================================================================= */}
      {activeSubTab === 'product_barcode' && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Header & Quick Action Card */}
          <div className="bg-[#161618] rounded-2xl border border-[#26262B] p-4 sm:p-5 shadow-xs">
            <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
              <div>
                <h3 className="font-extrabold text-base sm:text-lg text-white flex items-center gap-2">
                  <Tag className="w-5 h-5 text-[#F27D26]" /> Master Data Produk Kaos & Barcode System
                </h3>
                <p className="text-xs text-neutral-400">
                  Kelola master SKU, variasi warna, ukuran, batas reorder level, dan cetak label barcode Code-128
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleExportProductsCsv}
                  className="px-3 py-1.5 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-200 border border-[#2B2B32] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Export Master SKU ke CSV"
                >
                  <Download className="w-3.5 h-3.5 text-blue-400" /> Export CSV
                </button>
                <button
                  type="button"
                  onClick={handleSyncAllWarehouses}
                  className="px-3 py-1.5 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-200 border border-[#2B2B32] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Sinkronkan SKU baru ke seluruh gudang"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-emerald-400" /> Sync Gudang
                </button>
                <button
                  type="button"
                  onClick={() => setShowBatchPrintModal(true)}
                  className="px-3.5 py-1.5 bg-purple-950/70 hover:bg-purple-900/80 text-purple-300 border border-purple-800/60 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Cetak Semua Barcode Label Sekaligus"
                >
                  <Printer className="w-3.5 h-3.5" /> Cetak Label Massal
                </button>
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-1.5 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-[#F27D26]/20 transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4" /> Tambah Produk Baru
                </button>
              </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-[#24242A]">
              <div className="bg-[#121214] p-3 rounded-xl border border-[#24242A]">
                <span className="text-[10px] uppercase font-bold text-neutral-400 block">Total Master SKU</span>
                <span className="text-lg font-extrabold text-white">{products.length} SKU</span>
              </div>
              <div className="bg-[#121214] p-3 rounded-xl border border-[#24242A]">
                <span className="text-[10px] uppercase font-bold text-neutral-400 block">Variasi Warna</span>
                <span className="text-lg font-extrabold text-[#F27D26]">{uniqueColors.length} Warna</span>
              </div>
              <div className="bg-[#121214] p-3 rounded-xl border border-[#24242A]">
                <span className="text-[10px] uppercase font-bold text-neutral-400 block">Ukuran Tersedia</span>
                <span className="text-lg font-extrabold text-emerald-400">{uniqueSizes.length} Ukuran</span>
              </div>
              <div className="bg-[#121214] p-3 rounded-xl border border-[#24242A]">
                <span className="text-[10px] uppercase font-bold text-neutral-400 block">Format Barcode</span>
                <span className="text-xs font-extrabold text-purple-400 font-mono mt-1 block">{barcodeFormat} (Auto)</span>
              </div>
            </div>
          </div>

          {/* Table & Filter Card */}
          <div className="bg-[#161618] rounded-2xl border border-[#26262B] shadow-xs overflow-hidden">
            {/* Filter Bar */}
            <div className="p-4 bg-[#121214] border-b border-[#24242A] flex flex-wrap items-center justify-between gap-3">
              <div className="flex-1 min-w-[220px] relative">
                <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={prodSearchQuery}
                  onChange={(e) => setProdSearchQuery(e.target.value)}
                  placeholder="Cari SKU ID, Nama Produk, Warna, atau Barcode..."
                  className="w-full pl-9 pr-4 py-2 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-[#F27D26] focus:outline-hidden"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* Filter Warna */}
                <select
                  value={prodColorFilter}
                  onChange={(e) => setProdColorFilter(e.target.value)}
                  className="p-2 text-xs font-bold bg-[#0F0F10] border border-[#2B2B32] text-neutral-200 rounded-xl focus:border-[#F27D26] focus:outline-hidden"
                >
                  <option value="ALL">Semua Warna ({uniqueColors.length})</option>
                  {uniqueColors.map((col) => (
                    <option key={col} value={col}>
                      {col}
                    </option>
                  ))}
                </select>

                {/* Filter Ukuran */}
                <select
                  value={prodSizeFilter}
                  onChange={(e) => setProdSizeFilter(e.target.value)}
                  className="p-2 text-xs font-bold bg-[#0F0F10] border border-[#2B2B32] text-neutral-200 rounded-xl focus:border-[#F27D26] focus:outline-hidden"
                >
                  <option value="ALL">Semua Ukuran</option>
                  {uniqueSizes.map((sz) => (
                    <option key={sz} value={sz}>
                      Size {sz}
                    </option>
                  ))}
                </select>

                {/* Filter Kategori */}
                <select
                  value={prodCategoryFilter}
                  onChange={(e) => setProdCategoryFilter(e.target.value)}
                  className="p-2 text-xs font-bold bg-[#0F0F10] border border-[#2B2B32] text-neutral-200 rounded-xl focus:border-[#F27D26] focus:outline-hidden"
                >
                  <option value="ALL">Semua Kategori</option>
                  {uniqueCategories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>

                {/* Filter Lengan */}
                <select
                  value={prodLenganFilter}
                  onChange={(e) => setProdLenganFilter(e.target.value)}
                  className="p-2 text-xs font-bold bg-[#0F0F10] border border-[#2B2B32] text-neutral-200 rounded-xl focus:border-[#F27D26] focus:outline-hidden"
                >
                  <option value="ALL">Semua Lengan</option>
                  <option value="PENDEK">Lengan Pendek</option>
                  <option value="PANJANG">Lengan Panjang</option>
                </select>

                {(prodSearchQuery || prodColorFilter !== 'ALL' || prodSizeFilter !== 'ALL' || prodCategoryFilter !== 'ALL' || prodLenganFilter !== 'ALL') && (
                  <button
                    type="button"
                    onClick={() => {
                      setProdSearchQuery('');
                      setProdColorFilter('ALL');
                      setProdSizeFilter('ALL');
                      setProdCategoryFilter('ALL');
                      setProdLenganFilter('ALL');
                    }}
                    className="px-2.5 py-2 text-xs font-bold text-rose-400 hover:text-rose-300 bg-rose-950/40 hover:bg-rose-900/50 border border-rose-800/40 rounded-xl cursor-pointer transition-colors"
                    title="Reset Filter"
                  >
                    Reset
                  </button>
                )}
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-xs">
                <thead>
                  <tr className="bg-[#121214] border-b border-[#24242A] text-neutral-400 uppercase tracking-wider text-[11px]">
                    <th className="py-3 px-4 text-left font-bold">SKU ID</th>
                    <th className="py-3 px-4 text-left font-bold">Nama Produk</th>
                    <th className="py-3 px-4 text-left font-bold">Warna</th>
                    <th className="py-3 px-4 text-center font-bold">Ukuran</th>
                    <th className="py-3 px-4 text-center font-bold">Kategori</th>
                    <th className="py-3 px-4 text-center font-bold">Lengan</th>
                    <th className="py-3 px-4 text-center font-bold">Reorder Lvl</th>
                    <th className="py-3 px-4 text-left font-bold">Barcode ID</th>
                    <th className="py-3 px-4 text-right font-bold">Aksi & Label</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#24242A]">
                  {filteredProducts.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-10 text-center text-neutral-500 italic">
                        Tidak ada master produk yang cocok dengan pencarian / filter.
                      </td>
                    </tr>
                  ) : (
                    filteredProducts.map((p) => (
                      <tr key={p.SKU_ID} className="hover:bg-[#1C1C20] transition-colors">
                        <td className="py-2.5 px-4 font-mono font-bold text-neutral-100">{p.SKU_ID}</td>
                        <td className="py-2.5 px-4 font-bold text-white">{p.NAMA_PRODUK}</td>
                        <td className="py-2.5 px-4">
                          <div className="flex items-center gap-2">
                            <span
                              className="w-3.5 h-3.5 rounded-full border border-neutral-500/60 shrink-0 shadow-xs"
                              style={{ backgroundColor: getWarnaHex(p.WARNA) }}
                            />
                            <span className="font-semibold text-neutral-200">{p.WARNA}</span>
                          </div>
                        </td>
                        <td className="py-2.5 px-4 text-center font-extrabold text-neutral-100">
                          <span className="px-2 py-0.5 rounded-md bg-[#1C1C20] border border-[#2B2B32]">
                            {p.UKURAN}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 text-center text-neutral-300">{p.KATEGORI}</td>
                        <td className="py-2.5 px-4 text-center text-neutral-400">{p.JENIS_LENGAN || 'PENDEK'}</td>
                        <td className="py-2.5 px-4 text-center font-bold text-neutral-200">{p.REORDER_LEVEL} pcs</td>
                        <td className="py-2.5 px-4 font-mono text-[11px] text-neutral-400">
                          {p.BARCODE_ID || p.SKU_ID}
                        </td>
                        <td className="py-2.5 px-4 text-right space-x-1.5 whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => setLabelProduct(p)}
                            className="px-2.5 py-1 bg-purple-950/60 hover:bg-purple-900/70 text-purple-300 border border-purple-800/50 rounded-lg text-xs font-bold transition-colors inline-flex items-center gap-1 cursor-pointer"
                            title="Cetak Barcode Label"
                          >
                            <Tag className="w-3 h-3" /> Label
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingProduct(p)}
                            className="px-2.5 py-1 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-200 border border-[#2B2B32] rounded-lg text-xs font-bold transition-colors inline-flex items-center gap-1 cursor-pointer"
                            title="Edit Master Produk"
                          >
                            <Edit2 className="w-3 h-3" /> Edit
                          </button>
                          {isSpvOrOwner ? (
                            <button
                              type="button"
                              onClick={() => handleDeleteProduct(p.SKU_ID)}
                              className="px-2 py-1 bg-rose-950/50 hover:bg-rose-900/60 text-rose-400 border border-rose-800/40 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                              title="Hapus Produk (Akses Owner & SPV)"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          ) : (
                            <button
                              type="button"
                              disabled
                              className="px-2 py-1 bg-neutral-900/40 text-neutral-600 border border-neutral-800/80 rounded-lg text-xs font-bold cursor-not-allowed opacity-35 select-none"
                              title="Aksi Hapus Terkunci (Hanya untuk Owner & SPV)"
                            >
                              <Trash2 className="w-3 h-3 text-neutral-600" />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-[#121214] border-t border-[#24242A] flex items-center justify-between text-xs text-neutral-400 px-4">
              <span>Menampilkan <strong>{filteredProducts.length}</strong> dari <strong>{products.length}</strong> produk</span>
              <span className="text-[11px] text-neutral-500">Master produk tersinkronisasi dengan seluruh database gudang</span>
            </div>
          </div>

          {/* Barcode & SKU Standard Configuration Form */}
          <form onSubmit={handleSaveSystemSettings} className="bg-[#161618] rounded-2xl border border-[#26262B] p-4 sm:p-5 shadow-xs space-y-5">
            <div>
              <h3 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-[#F27D26]" /> Konfigurasi Generator SKU & Standar Barcode
              </h3>
              <p className="text-xs text-neutral-400">
                Atur generator SKU otomatis, ambang batas minimum reorder default, serta format kertas label
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Default SKU Prefix */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Prefix Standar SKU ID
                </label>
                <input
                  type="text"
                  value={skuPrefix}
                  onChange={(e) => setSkuPrefix(e.target.value)}
                  placeholder="Contoh: KPCM-30S"
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-mono font-bold focus:border-[#F27D26] focus:outline-hidden"
                />
                <span className="text-[10px] text-neutral-500 mt-1 block">
                  Format rekomendasi: [KODE_PRODUK]-[KETEBALAN]
                </span>
              </div>

              {/* Default Reorder Level */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Ambang Batas Reorder Default (pcs)
                </label>
                <input
                  type="number"
                  value={defaultReorderLevel}
                  onChange={(e) => setDefaultReorderLevel(Number(e.target.value))}
                  min={1}
                  max={500}
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                />
                <span className="text-[10px] text-neutral-500 mt-1 block">
                  Peringatan stok menipis otomatis aktif jika stok ≤ batas ini.
                </span>
              </div>

              {/* Barcode Format */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Standar Barcode Produk
                </label>
                <select
                  value={barcodeFormat}
                  onChange={(e) => setBarcodeFormat(e.target.value as any)}
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                >
                  <option value="CODE128">Code-128 (Standar Industri Garis Batang)</option>
                  <option value="QR_CODE">QR Code 2D Matrix</option>
                  <option value="EAN13">EAN-13 Numerik</option>
                </select>
                <span className="text-[10px] text-neutral-500 mt-1 block">
                  Kompatibel dengan semua scanner barcode USB/Bluetooth & Kamera HP.
                </span>
              </div>

              {/* Label Printing Paper Layout */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Ukuran & Format Lembar Label
                </label>
                <select
                  value={labelPaperSize}
                  onChange={(e) => setLabelPaperSize(e.target.value as any)}
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                >
                  <option value="A4_40_LABELS">Kertas Stiker A4 (Grid 4x10 = 40 Label)</option>
                  <option value="THERMAL_50X30">Printer Thermal Kasir (50 x 30 mm)</option>
                  <option value="THERMAL_40X20">Printer Thermal Mini (40 x 20 mm)</option>
                  <option value="THERMAL_100X150">Printer Stiker Resi (100 x 150 mm)</option>
                </select>
                <span className="text-[10px] text-neutral-500 mt-1 block">
                  Template cetak siap pakai di menu Cetak Label Barcode.
                </span>
              </div>

              {/* Toggle Auto Barcode */}
              <div className="sm:col-span-2 flex items-center justify-between p-3.5 rounded-xl bg-[#121214] border border-[#24242A]">
                <div>
                  <h5 className="font-bold text-xs text-white">Auto-Generate Barcode ID</h5>
                  <p className="text-[11px] text-neutral-400">
                    Otomatis mengisi barcode ID sama dengan SKU saat menambah produk baru
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setEnableAutoBarcode(!enableAutoBarcode)}
                  className={`w-11 h-6 rounded-full transition-colors flex items-center px-0.5 cursor-pointer ${
                    enableAutoBarcode ? 'bg-emerald-600' : 'bg-neutral-700'
                  }`}
                >
                  <motion.div
                    className="w-5 h-5 rounded-full bg-white shadow-xs"
                    animate={{ x: enableAutoBarcode ? 20 : 0 }}
                    transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                  />
                </button>
              </div>
            </div>

            {/* Quick Preview of Generated SKU Example */}
            <div className="bg-[#121214] rounded-xl p-4 border border-[#2A2A30] flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="bg-white p-1.5 rounded-lg border border-neutral-700 flex items-center justify-center min-w-[64px] min-h-[50px]">
                  <canvas id="sim-barcode-canvas" className="block" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-neutral-400 uppercase font-bold block">Simulasi Format SKU & {barcodeFormat === 'QR_CODE' ? 'QR Code' : 'Barcode'}:</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-950/70 text-purple-300 border border-purple-800/40">
                      {barcodeFormat === 'QR_CODE' ? 'QR Code 2D Matrix' : 'Code-128'}
                    </span>
                  </div>
                  <span className="font-mono font-extrabold text-sm text-emerald-400">
                    {skuPrefix}-HTM-L-PDK
                  </span>
                </div>
              </div>

              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
              >
                <Save className="w-4 h-4" /> Simpan Pengaturan Barcode
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB: WARNA HEADER FAKTUR & DOKUMEN RESMI */}
      {/* ========================================================================= */}
      {activeSubTab === 'invoice_color' && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.2 }}
          className="bg-[#161618] rounded-2xl border border-[#26262B] p-5 sm:p-7 space-y-6 shadow-xs"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#24242A]">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-purple-950/60 border border-purple-800/40 flex items-center justify-center text-purple-400 shrink-0">
                <Palette className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-base sm:text-lg text-white">
                  Kelola Warna Header Faktur & Dokumen Resmi
                </h3>
                <p className="text-xs text-neutral-400">
                  Kustomisasi warna kop nota penjualan (Sale), surat pesanan (PO), surat jalan pengiriman (SJ), dan berita acara audit stok
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl border border-[#2A2A32] bg-[#1C1C20] text-[#F27D26]">
                HEX: {invoiceHeaderColor.toUpperCase()}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Color Picker & Presets */}
            <div className="lg:col-span-6 space-y-5">
              <div className="bg-[#111114] p-5 rounded-2xl border border-[#26262E] space-y-4">
                <label className="text-xs font-bold uppercase tracking-wider text-neutral-300 block">
                  Pilih Warna Utama Header Nota / Faktur
                </label>

                {/* Color Input Controls */}
                <div className="flex items-center gap-3.5">
                  <div className="relative">
                    <input
                      type="color"
                      value={invoiceHeaderColor}
                      onChange={(e) => setInvoiceHeaderColor(e.target.value)}
                      className="w-14 h-14 rounded-2xl cursor-pointer bg-transparent border-2 border-white/20 p-1"
                      title="Klik untuk memilih warna bebas (Color Picker)"
                    />
                  </div>
                  <div className="flex-1">
                    <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider mb-1">
                      Kode Hexadecimal Warna
                    </span>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500 font-mono text-sm font-bold">#</span>
                      <input
                        type="text"
                        value={invoiceHeaderColor.replace('#', '')}
                        onChange={(e) => setInvoiceHeaderColor(`#${e.target.value}`)}
                        placeholder="7e22ce"
                        maxLength={6}
                        className="w-full pl-8 pr-3 py-2.5 text-sm font-mono font-extrabold text-neutral-100 uppercase bg-[#0F0F10] border border-[#2B2B32] rounded-xl focus:border-[#F27D26] focus:outline-hidden"
                      />
                    </div>
                  </div>
                </div>

                {/* Preset Swatches */}
                <div className="space-y-2 pt-2">
                  <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">
                    Pilihan Palet Warna Distro Populer:
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {[
                      { name: 'Ungu Distro', hex: '#7e22ce' },
                      { name: 'Oranye Distro', hex: '#ea580c' },
                      { name: 'Biru Royal Navy', hex: '#1e3a8a' },
                      { name: 'Hijau Emerald', hex: '#065f46' },
                      { name: 'Hitam Onyx', hex: '#18181b' },
                      { name: 'Merah Marun', hex: '#881337' },
                      { name: 'Abu Slate', hex: '#334155' },
                      { name: 'Biru Kobalt', hex: '#2563eb' },
                      { name: 'Teal Tosca', hex: '#0f766e' },
                    ].map((preset) => (
                      <button
                        key={preset.hex}
                        type="button"
                        onClick={() => setInvoiceHeaderColor(preset.hex)}
                        className={`p-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-all cursor-pointer ${
                          invoiceHeaderColor.toLowerCase() === preset.hex.toLowerCase()
                            ? 'border-white bg-[#282830] text-white shadow-md scale-102 font-bold ring-2 ring-white/20'
                            : 'border-[#2E2E38] bg-[#161618] text-neutral-300 hover:text-white hover:border-[#40404C]'
                        }`}
                      >
                        <span
                          className="w-4 h-4 rounded-full shrink-0 border border-white/30 shadow-xs"
                          style={{ backgroundColor: preset.hex }}
                        />
                        <span className="truncate">{preset.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Action Buttons: Simpan & Batal */}
                <div className="pt-3 border-t border-[#26262E] flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setInvoiceHeaderColor(settings.invoiceHeaderColor || '#7e22ce');
                      showToast('Warna header dikembalikan ke pengaturan tersimpan.', 'info');
                    }}
                    className="px-4 py-3 bg-[#1F1F24] hover:bg-[#2A2A32] text-neutral-300 hover:text-white font-bold text-xs uppercase tracking-wider rounded-xl border border-[#2E2E38] transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                    title="Batalkan perubahan warna header"
                  >
                    <RotateCcw className="w-4 h-4" /> Batal
                  </button>
                  <button
                    type="button"
                    onClick={(e) => handleSaveSystemSettings(e as any)}
                    className="flex-1 py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-purple-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Save className="w-4 h-4" /> Simpan Warna Header Faktur
                  </button>
                </div>
              </div>
            </div>

            {/* Right Column: Live Interactive Preview */}
            <div className="lg:col-span-6 space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-300 block">
                🔴 Pratinjau Langsung Simulasi Kop Faktur Cetak
              </span>
              <div className="bg-white rounded-2xl p-5 shadow-xl border border-slate-300 space-y-4 text-slate-900">
                {/* Simulated Invoice Header */}
                <div
                  className="p-5 rounded-xl text-white transition-colors duration-200 flex items-start justify-between gap-4 shadow-sm"
                  style={{ backgroundColor: invoiceHeaderColor }}
                >
                  <div className="flex items-center gap-3.5">
                    {logoUrl ? (
                      <div className="w-14 h-14 bg-white rounded-xl p-1 shadow-xs flex items-center justify-center shrink-0 overflow-hidden border border-white/30">
                        <img src={logoUrl} alt="Logo Toko" className="max-w-full max-h-full object-contain" />
                      </div>
                    ) : (
                      <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center shrink-0 border border-white/30">
                        <Building2 className="w-6 h-6 text-white" />
                      </div>
                    )}
                    <div>
                      <h4 className="text-base sm:text-lg font-black uppercase tracking-wide leading-tight">
                        {brandName || 'DISTRO KAOS COMBED 30S'}
                      </h4>
                      <p className="text-xs text-white/90 font-medium mt-0.5">
                        {companySubtitle || 'Sistem Manajemen Inventori Multi-Gudang & Barcode POS'}
                      </p>
                      <p className="text-[10px] text-white/80 mt-1 leading-relaxed">
                        {companyAddress || 'Jl. Tekstil Raya No. 88, Bandung'} • Telp: {companyPhone || '0812-3456-7890'}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="bg-black/25 border border-white/30 px-2.5 py-1 rounded-lg text-right">
                      <span className="text-[9px] text-white/90 uppercase font-bold block">FAKTUR / NOTA</span>
                      <span className="font-mono font-bold text-xs">INV-20261005-001</span>
                    </div>
                  </div>
                </div>

                {/* Simulated document table snippet */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 space-y-1.5">
                  <div className="flex justify-between font-semibold text-slate-800">
                    <span>Pelanggan: Pembeli Ritel Grosir</span>
                    <span>Tanggal: 05 Okt 2026</span>
                  </div>
                  <div className="border-t border-slate-200 pt-1.5 flex justify-between">
                    <span>Item: KAOS POLOS 30S COMBED HITAM (L) x 12 pcs</span>
                    <span className="font-bold text-slate-900 font-mono">Rp 540.000</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
      {/* ========================================================================= */}
      {/* SUB-TAB 3: MANAJEMEN USER (KHUSUS OWNER) */}
      {/* ========================================================================= */}
      {activeSubTab === 'users' && (
        !isOwner ? (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#161618] rounded-2xl border border-rose-900/40 p-8 text-center space-y-4"
          >
            <div className="w-14 h-14 rounded-2xl bg-rose-950/60 border border-rose-800/60 text-rose-400 flex items-center justify-center mx-auto">
              <Lock className="w-7 h-7" />
            </div>
            <div className="max-w-md mx-auto space-y-1.5">
              <h3 className="font-extrabold text-base text-white">Akses Manajemen Pengguna Terkunci</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Halaman Manajemen Akun & Hak Akses Pengguna hanya dapat diakses oleh akun Pemilik (Role <strong className="text-rose-300">OWNER</strong>).
                Akun Anda ({currentUser?.username || 'User'} - {currentUser?.role || 'STAFF'}) tidak memiliki hak wewenang untuk melihat atau memodifikasi kredensial pengguna lain.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveSubTab('warehouses')}
              className="px-4 py-2 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-200 border border-[#2B2B32] rounded-xl text-xs font-bold inline-flex items-center gap-2 cursor-pointer transition-colors"
            >
              Kembali ke Pengaturan Gudang
            </button>
          </motion.div>
        ) : (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="bg-[#161618] rounded-2xl border border-[#26262B] p-4 sm:p-5 shadow-xs">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-[#F27D26]" /> Manajemen Akun & Hak Akses Pengguna
                </h3>
                <p className="text-xs text-neutral-400">
                  Atur login admin, role supervisor, staff gudang, serta pembatasan akses lokasi gudang
                </p>
              </div>

              <button
                type="button"
                onClick={handleOpenAddUser}
                className="px-4 py-2 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <UserPlus className="w-4 h-4" /> Tambah User Baru
              </button>
            </div>

            {/* Users Table */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-xs">
                <thead>
                  <tr className="bg-[#121214] border-b border-[#24242A] text-neutral-400 uppercase tracking-wider text-[11px]">
                    <th className="py-3 px-4 text-left font-bold">User</th>
                    <th className="py-3 px-4 text-left font-bold">Username</th>
                    <th className="py-3 px-4 text-center font-bold">Role</th>
                    <th className="py-3 px-4 text-left font-bold">Hak Akses Gudang</th>
                    <th className="py-3 px-4 text-left font-bold">Kontak</th>
                    <th className="py-3 px-4 text-center font-bold">Status</th>
                    <th className="py-3 px-4 text-right font-bold">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#24242A]">
                  {users.map((u) => (
                    <tr key={u.id} className="hover:bg-[#1C1C20] transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-[#24242C] border border-[#3A3A45] flex items-center justify-center font-bold text-xs text-neutral-200">
                            {u.fullName.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-extrabold text-white">{u.fullName}</div>
                            <span className="text-[10px] text-neutral-500 font-mono">{u.id}</span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 font-mono font-bold text-neutral-200">{u.username}</td>

                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                            u.role === 'ADMIN'
                              ? 'bg-amber-950/60 text-amber-300 border border-amber-800/50'
                              : u.role === 'SUPERVISOR' || u.role === 'MANAGER'
                              ? 'bg-purple-950/60 text-purple-300 border border-purple-800/50'
                              : 'bg-blue-950/60 text-blue-300 border border-blue-800/50'
                          }`}
                        >
                          {u.role}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-md font-bold text-[11px] bg-[#1E1E24] text-neutral-300 border border-[#2F2F38]">
                          {u.siteAccess}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-neutral-400">
                        {u.phone || u.email ? (
                          <div className="space-y-0.5">
                            {u.phone && <div className="text-[11px] text-neutral-300">{u.phone}</div>}
                            {u.email && <div className="text-[10px] text-neutral-500">{u.email}</div>}
                          </div>
                        ) : (
                          <span className="text-neutral-600">-</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <button
                          type="button"
                          onClick={() => handleToggleUserActive(u.id)}
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition-colors ${
                            u.isActive
                              ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                              : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
                          }`}
                        >
                          {u.isActive ? '✓ Aktif' : '✗ Non-Aktif'}
                        </button>
                      </td>

                      <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => handleOpenEditUser(u)}
                          className="px-2.5 py-1 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-200 border border-[#2B2B32] rounded-lg text-xs font-bold transition-colors inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Edit2 className="w-3 h-3" /> Edit
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteUser(u.id)}
                          className="px-2 py-1 bg-rose-950/50 hover:bg-rose-900/60 text-rose-400 border border-rose-800/40 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Permission Matrix Guide */}
            <div className="mt-6 p-4 rounded-xl bg-[#121214] border border-[#24242A]">
              <h4 className="font-bold text-xs text-white mb-2 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> Matriks Otorisasi & Hak Akses Berdasarkan Role
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-[11px] text-neutral-400">
                <div className="p-2.5 bg-[#18181C] rounded-lg border border-[#24242A]">
                  <strong className="text-amber-300 block mb-1">👑 ADMIN</strong>
                  Akses penuh seluruh fitur: Master Produk, Koreksi Stok, Surat Jalan, Order PO, Kasir Penjualan, dan Pengaturan Sistem.
                </div>
                <div className="p-2.5 bg-[#18181C] rounded-lg border border-[#24242A]">
                  <strong className="text-purple-300 block mb-1">🛡️ SUPERVISOR / MANAGER</strong>
                  Otorisasi approval Tanda Tangan Digital pada Order PO & Surat Jalan, audit log mutasi, dan monitoring multi-gudang.
                </div>
                <div className="p-2.5 bg-[#18181C] rounded-lg border border-[#24242A]">
                  <strong className="text-blue-300 block mb-1">📦 STAFF GUDANG</strong>
                  Pindai Barcode, Input Barang Masuk, Surat Jalan Kirim, dan Pencarian Cepat Stok Gudang lokal.
                </div>
              </div>
            </div>
          </div>
        </motion.div>
        )
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 4: IDENTITAS TOKO & INTEGRASI */}
      {/* ========================================================================= */}
      {activeSubTab === 'store_system' && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <form onSubmit={handleSaveSystemSettings} className="bg-[#161618] rounded-2xl border border-[#26262B] p-4 sm:p-5 shadow-xs space-y-5">
            <div>
              <h3 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
                <Building2 className="w-4 h-4 text-[#F27D26]" /> Identitas Brand & Kop Dokumen Resmi
              </h3>
              <p className="text-xs text-neutral-400">
                Informasi dan logo ini otomatis terintegrasi ke seluruh dokumen: Nota Sale, Purchase Order (PO), Surat Jalan (SJ), dan Berita Acara Stok Opname.
              </p>
            </div>

            {/* SECTION UPLOAD & KELOLA LOGO TOKO */}
            <div className="bg-[#121214] border border-[#2B2B32] rounded-2xl p-4 sm:p-5 space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-[#24242A]">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 text-purple-400" /> Logo Resmi Toko / Usaha
                  </h4>
                  <p className="text-[11px] text-neutral-400 mt-0.5">
                    Logo akan tercetak di pojok kiri atas semua nota, faktur, surat jalan, dan purchase order
                  </p>
                </div>

                {logoUrl && (
                  <button
                    type="button"
                    onClick={() => {
                      setLogoUrl('');
                      showToast('Logo dihapus. Klik simpan untuk menerapkan.', 'info');
                    }}
                    className="py-1 px-2.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Hapus Logo
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
                {/* Logo Box Preview */}
                <div className="md:col-span-4 flex flex-col items-center justify-center p-4 bg-[#0A0A0C] border border-[#26262B] rounded-2xl">
                  <div className="w-28 h-28 bg-white rounded-2xl p-2.5 shadow-lg border border-slate-200 flex items-center justify-center overflow-hidden relative group">
                    {logoUrl ? (
                      <img
                        src={logoUrl}
                        alt="Logo Toko"
                        className="max-w-full max-h-full object-contain"
                      />
                    ) : (
                      <div className="flex flex-col items-center justify-center text-slate-400 text-center">
                        <ImageIcon className="w-8 h-8 text-slate-300 mb-1" />
                        <span className="text-[10px] font-bold">Belum Ada Logo</span>
                      </div>
                    )}
                  </div>
                  <span className="text-[10px] font-medium text-neutral-400 mt-2">
                    Pratinjau Logo di Kertas Nota
                  </span>
                </div>

                {/* Upload & Presets Actions */}
                <div className="md:col-span-8 space-y-3.5">
                  <div>
                    <label className="block text-xs font-bold text-neutral-200 mb-1.5">
                      Unggah Berkas Gambar Logo
                    </label>
                    <div className="flex flex-wrap items-center gap-2.5">
                      <label className="py-2 px-3.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer shadow-sm transition-all hover:scale-102 active:scale-98">
                        <Camera className="w-4 h-4" />
                        <span>Pilih Gambar dari Komputer</span>
                        <input
                          type="file"
                          accept="image/png,image/jpeg,image/svg+xml,image/webp"
                          onChange={handleLogoUpload}
                          className="hidden"
                        />
                      </label>
                      <span className="text-[11px] text-neutral-400">
                        Format: PNG (transparan disarankan), JPG, SVG, WebP
                      </span>
                    </div>
                  </div>

                  {/* Preset Quick Logos */}
                  <div>
                    <span className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1.5">
                      Atau Gunakan Logo Siap Pakai:
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {PRESET_LOGOS.map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setLogoUrl(preset.dataUrl);
                            showToast(`Logo preset "${preset.name}" dipilih. Klik simpan untuk menerapkan!`, 'success');
                          }}
                          className="py-1.5 px-3 bg-[#18181C] hover:bg-[#25252B] border border-[#2B2B32] hover:border-purple-600 rounded-xl text-xs font-medium text-neutral-300 flex items-center gap-2 transition-all cursor-pointer"
                        >
                          <div className={`w-3.5 h-3.5 rounded-full ${preset.badgeColor} shrink-0`} />
                          <span>{preset.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION UPLOAD & KELOLA STEMPEL RESMI TOKO (PENGGANTI TANDA TANGAN) */}
              <div className="bg-[#101012] border border-[#2B2B32] rounded-2xl p-4 sm:p-5 space-y-4">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-[#24242A]">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-[#F27D26]" /> Stempel Resmi Usaha / Toko (Pengganti Tanda Tangan)
                    </h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5">
                      Unggah cap stempel toko untuk otomatis mengesahkan Surat Jalan, Nota Penjualan, dan Purchase Order tanpa perlu tanda tangan manual berulang kali.
                    </p>
                  </div>

                  {stampUrl && (
                    <button
                      type="button"
                      onClick={() => {
                        setStampUrl('');
                        setUseStampAsSignature(false);
                        showToast('Stempel toko dihapus. Klik simpan untuk menerapkan.', 'info');
                      }}
                      className="py-1 px-2.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Hapus Stempel
                    </button>
                  )}
                </div>

                {/* Toggle Opsi Pengganti Tanda Tangan */}
                <div className="bg-[#161618] border border-[#2B2B32] p-3 rounded-xl flex items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <label htmlFor="toggle-stamp-signature" className="text-xs font-bold text-white cursor-pointer flex items-center gap-2">
                      <span>Otomatis Gunakan Stempel Resmi untuk Menggantikan Tanda Tangan</span>
                      {useStampAsSignature && (
                        <span className="text-[10px] bg-emerald-950/80 text-emerald-400 border border-emerald-800/80 px-2 py-0.2 rounded-full font-bold">
                          Aktif
                        </span>
                      )}
                    </label>
                    <p className="text-[11px] text-neutral-400">
                      Jika diaktifkan, kolom tanda tangan kasir/admin di Nota, SJ, dan PO akan otomatis terisi cap stempel resmi toko ini.
                    </p>
                  </div>
                  <input
                    id="toggle-stamp-signature"
                    type="checkbox"
                    checked={useStampAsSignature}
                    onChange={(e) => setUseStampAsSignature(e.target.checked)}
                    className="w-5 h-5 accent-[#F27D26] cursor-pointer rounded shrink-0"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
                  {/* Stamp Box Preview */}
                  <div className="md:col-span-4 flex flex-col items-center justify-center p-4 bg-[#0A0A0C] border border-[#26262B] rounded-2xl">
                    <div className="w-28 h-28 bg-white rounded-2xl p-2.5 shadow-lg border border-slate-200 flex items-center justify-center overflow-hidden relative group">
                      {stampUrl ? (
                        <img
                          src={stampUrl}
                          alt="Stempel Toko"
                          className="max-w-full max-h-full object-contain rotate-[-4deg]"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center text-slate-400 text-center">
                          <ShieldCheck className="w-8 h-8 text-slate-300 mb-1" />
                          <span className="text-[10px] font-bold">Belum Ada Stempel</span>
                        </div>
                      )}
                    </div>
                    <span className="text-[10px] font-medium text-neutral-400 mt-2">
                      Pratinjau Cap Stempel di Dokumen
                    </span>
                  </div>

                  {/* Upload & Presets Actions */}
                  <div className="md:col-span-8 space-y-3.5">
                    <div>
                      <label className="block text-xs font-bold text-neutral-200 mb-1.5">
                        Unggah Berkas Gambar Cap Stempel
                      </label>
                      <div className="flex flex-wrap items-center gap-2.5">
                        <label className="py-2 px-3.5 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer shadow-sm transition-all hover:scale-102 active:scale-98">
                          <Camera className="w-4 h-4" />
                          <span>Pilih Berkas Stempel Toko</span>
                          <input
                            type="file"
                            accept="image/png,image/jpeg,image/svg+xml,image/webp"
                            onChange={handleStampUpload}
                            className="hidden"
                          />
                        </label>
                        <span className="text-[11px] text-neutral-400">
                          Format: PNG (transparan disarankan), JPG, SVG, WebP
                        </span>
                      </div>
                    </div>

                    {/* Preset Quick Stamps */}
                    <div>
                      <span className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1.5">
                        Atau Gunakan Format Stempel Siap Pakai:
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {PRESET_STEMPEL.map((preset, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => {
                              setStampUrl(preset.dataUrl);
                              setUseStampAsSignature(true);
                              showToast(`Stempel preset "${preset.name}" dipilih dan diaktifkan. Klik simpan untuk menerapkan!`, 'success');
                            }}
                            className="py-1.5 px-3 bg-[#18181C] hover:bg-[#25252B] border border-[#2B2B32] hover:border-[#F27D26] rounded-xl text-xs font-medium text-neutral-300 flex items-center gap-2 transition-all cursor-pointer"
                          >
                            <div className={`w-3.5 h-3.5 rounded-full ${preset.badgeColor} shrink-0`} />
                            <span>{preset.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Warna Header Faktur & Kop Dokumen */}
              <div className="mt-4 pt-4 border-t border-[#24242A]">
                <div className="flex items-center justify-between mb-2.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5">
                    <Palette className="w-4 h-4 text-[#F27D26]" />
                    Warna Header Faktur & Kop Dokumen Resmi
                  </label>
                  <span className="text-[11px] font-mono text-[#F27D26] font-bold bg-[#1C1C20] px-2 py-0.5 rounded border border-[#2A2A32]">
                    {invoiceHeaderColor.toUpperCase()}
                  </span>
                </div>
                
                <div className="flex flex-wrap items-center gap-3">
                  {/* Color Picker + HEX input */}
                  <div className="flex items-center gap-2 bg-[#0F0F10] border border-[#2B2B32] p-1.5 rounded-xl">
                    <input
                      type="color"
                      value={invoiceHeaderColor}
                      onChange={(e) => setInvoiceHeaderColor(e.target.value)}
                      className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0 p-0"
                      title="Pilih Warna Kustom"
                    />
                    <input
                      type="text"
                      value={invoiceHeaderColor}
                      onChange={(e) => setInvoiceHeaderColor(e.target.value)}
                      placeholder="#7e22ce"
                      maxLength={7}
                      className="w-20 text-xs font-mono font-bold text-neutral-200 uppercase bg-transparent border-0 focus:outline-hidden"
                    />
                  </div>

                  {/* Preset Colors */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    {[
                      { name: 'Ungu Distro', hex: '#7e22ce' },
                      { name: 'Oranye Signature', hex: '#ea580c' },
                      { name: 'Biru Navy', hex: '#1e40af' },
                      { name: 'Hijau Zamrud', hex: '#047857' },
                      { name: 'Merah Crimson', hex: '#be123c' },
                      { name: 'Hitam Elegan', hex: '#18181b' },
                      { name: 'Cokelat Vintage', hex: '#78350f' },
                      { name: 'Teal Modern', hex: '#0f766e' },
                    ].map((preset) => (
                      <button
                        key={preset.hex}
                        type="button"
                        onClick={() => setInvoiceHeaderColor(preset.hex)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
                          invoiceHeaderColor.toLowerCase() === preset.hex.toLowerCase()
                            ? 'border-white bg-[#282830] text-white shadow-xs scale-105'
                            : 'border-[#2E2E38] bg-[#161618] text-neutral-400 hover:text-neutral-200 hover:border-[#40404C]'
                        }`}
                      >
                        <span
                          className="w-3 h-3 rounded-full shrink-0 border border-white/20"
                          style={{ backgroundColor: preset.hex }}
                        />
                        <span>{preset.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Live Preview Kop Nota Simulation */}
              <div className="mt-4 pt-4 border-t border-[#24242A]">
                <span className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-2">
                  🔴 Simulasi Tampilan Kop di Nota Resmi:
                </span>
                <div
                  className="text-white p-4 sm:p-5 rounded-xl shadow-md flex flex-wrap items-center justify-between gap-4 transition-colors duration-200"
                  style={{ backgroundColor: invoiceHeaderColor }}
                >
                  <div className="flex items-center gap-3.5">
                    {logoUrl ? (
                      <div className="w-14 h-14 bg-white rounded-xl p-1 shadow-sm flex items-center justify-center shrink-0 overflow-hidden border border-white/30">
                        <img src={logoUrl} alt="Logo Toko" className="max-w-full max-h-full object-contain" />
                      </div>
                    ) : (
                      <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center shrink-0 border border-white/30">
                        <Building2 className="w-6 h-6 text-white" />
                      </div>
                    )}
                    <div>
                      <h5 className="text-base sm:text-lg font-black uppercase tracking-wide">
                        {brandName || 'NAMA BRAND TOKO'}
                      </h5>
                      <p className="text-xs text-white/90 font-medium">
                        {companySubtitle || 'Tagline / Deskripsi Usaha'}
                      </p>
                      <p className="text-[10px] text-white/80 mt-0.5 max-w-lg">
                        {companyAddress || 'Alamat Lengkap Toko'} • Telp/WA: {companyPhone || '08xx-xxxx-xxxx'}
                      </p>
                    </div>
                  </div>
                  <div className="text-right text-xs">
                    <span className="px-2.5 py-1 bg-black/30 border border-white/30 rounded-lg font-mono font-bold text-[11px] text-white block">
                      NO. DOKUMEN RESMI
                    </span>
                    <span className="text-[10px] text-white/80 mt-1 block">
                      Terbit Otomatis Sistem
                    </span>
                  </div>
                </div>

                {/* Stamp Simulation Preview in Document */}
                {stampUrl && (
                  <div className="mt-3 p-3 bg-white rounded-xl border border-slate-300 flex flex-wrap items-center justify-between gap-3 text-slate-800">
                    <div className="flex items-center gap-3">
                      <div className="w-14 h-14 bg-slate-50 border border-slate-200 rounded-lg p-1 flex items-center justify-center overflow-hidden shadow-xs shrink-0">
                        <img src={stampUrl} alt="Cap Stempel" className="max-h-full max-w-full object-contain rotate-[-4deg]" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                          <span>Simulasi Pengesahan di Nota, SJ & PO</span>
                          <span className="text-[9px] font-mono bg-purple-100 text-purple-700 px-1.5 py-0.2 rounded font-bold">
                            E-Stamp
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-600 mt-0.5">
                          {useStampAsSignature
                            ? '✓ Mode Aktif: Cap stempel ini otomatis disematkan pada kolom tanda tangan dokumen.'
                            : '⚪ Mode Manual: Cap stempel dapat dipilih pada pop-up tanda tangan dokumen.'}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> Stempel Terverifikasi
                    </span>
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Nama Brand / Usaha
                </label>
                <input
                  type="text"
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value)}
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Tagline / Deskripsi Usaha
                </label>
                <input
                  type="text"
                  value={companySubtitle}
                  onChange={(e) => setCompanySubtitle(e.target.value)}
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 focus:border-[#F27D26] focus:outline-hidden"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Alamat Lengkap Kantor / Gudang Utama
                </label>
                <input
                  type="text"
                  value={companyAddress}
                  onChange={(e) => setCompanyAddress(e.target.value)}
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 focus:border-[#F27D26] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  No. Telepon / WhatsApp
                </label>
                <input
                  type="text"
                  value={companyPhone}
                  onChange={(e) => setCompanyPhone(e.target.value)}
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 focus:border-[#F27D26] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Email Bisnis
                </label>
                <input
                  type="email"
                  value={companyEmail}
                  onChange={(e) => setCompanyEmail(e.target.value)}
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 focus:border-[#F27D26] focus:outline-hidden"
                />
              </div>
            </div>

            {/* Google Sheets Sync Integration */}
            <div className="border-t border-[#24242A] pt-4">
              <h4 className="font-extrabold text-xs text-white mb-1 flex items-center gap-1.5">
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" /> Integrasi Sinkronisasi Google Sheets (GAS Webhook)
              </h4>
              <p className="text-[11px] text-neutral-400 mb-3">
                Hubungkan URL Google Apps Script Web App untuk otomatis mencatat mutasi ke spreadsheet secara real-time
              </p>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Google Apps Script Web App URL
                </label>
                <input
                  type="url"
                  value={googleSheetsWebhookUrl}
                  onChange={(e) => setGoogleSheetsWebhookUrl(e.target.value)}
                  placeholder="https://script.google.com/macros/s/AKfycbx.../exec"
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-mono focus:border-[#F27D26] focus:outline-hidden"
                />
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
              >
                <Save className="w-4 h-4" /> Simpan Identitas & Integrasi
              </button>
            </div>
          </form>

          {/* Danger Zone: Factory Reset */}
          <div className="bg-rose-950/20 rounded-2xl border border-rose-800/40 p-4 sm:p-5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h4 className="font-extrabold text-sm text-rose-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-400" /> Zona Bahaya: Reset Data Pabrik (Factory Reset)
                </h4>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Kembalikan seluruh data master produk, inventori, transaksi, dan akun ke data demo awal bawaan.
                </p>
              </div>

              <button
                type="button"
                onClick={onResetFactoryData}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Reset ke Data Awal
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 6: PUSAT BACKUP MANUAL & CHECKPOINT OTOMATIS */}
      {/* ========================================================================= */}
      {activeSubTab === 'backup_checkpoint' && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Header Stats Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#161618] rounded-2xl border border-[#26262B] p-4 text-xs">
            <div className="bg-[#101012] p-3 rounded-xl border border-[#24242A]">
              <span className="text-[10px] text-neutral-400 block font-medium">Checkpoint Tersimpan</span>
              <span className="font-extrabold text-base text-white flex items-center gap-1.5 mt-0.5">
                <Layers className="w-4 h-4 text-[#F27D26]" /> {checkpoints.length} / {chkMaxCheckpoints} Slot
              </span>
            </div>

            <div className="bg-[#101012] p-3 rounded-xl border border-[#24242A]">
              <span className="text-[10px] text-neutral-400 block font-medium">Checkpoint Terakhir</span>
              <span className="font-extrabold text-xs sm:text-sm text-neutral-200 flex items-center gap-1.5 mt-0.5 truncate">
                <Clock className="w-4 h-4 text-blue-400 shrink-0" />
                <span className="truncate">
                  {checkpoints[0] ? CheckpointService.formatRelativeTime(checkpoints[0].timestamp) : 'Belum Ada'}
                </span>
              </span>
            </div>

            <div className="bg-[#101012] p-3 rounded-xl border border-[#24242A]">
              <span className="text-[10px] text-neutral-400 block font-medium">Total Data Aktif</span>
              <span className="font-extrabold text-xs sm:text-sm text-emerald-400 flex items-center gap-1.5 mt-0.5 truncate">
                <HardDrive className="w-4 h-4 shrink-0" />
                <span>{products.length} SKU • {formatNumber(currentStateSnapshot.inventory.reduce((s, i) => s + (Number(i.JUMLAH_READY) || 0), 0))} Pcs</span>
              </span>
            </div>

            <div className="bg-[#101012] p-3 rounded-xl border border-[#24242A]">
              <span className="text-[10px] text-neutral-400 block font-medium">Status Auto-Checkpoint</span>
              <span className="font-extrabold text-xs sm:text-sm text-white flex items-center gap-1.5 mt-0.5">
                <span className={`w-2 h-2 rounded-full ${chkAutoEnabled ? 'bg-emerald-400 animate-pulse' : 'bg-neutral-600'}`} />
                <span className={chkAutoEnabled ? 'text-emerald-300' : 'text-neutral-400'}>
                  {chkAutoEnabled ? `Tiap ${chkIntervalMin} Menit` : 'Non-Aktif'}
                </span>
              </span>
            </div>
          </div>

          {/* Action Cards: Create Manual & Download JSON */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* 1. Create Manual Snapshot */}
            <div className="bg-[#161618] rounded-2xl border border-[#26262B] p-5 space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
                  <Save className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-sm sm:text-base text-white">
                    Buat Snapshot Checkpoint Manual
                  </h4>
                  <p className="text-xs text-neutral-400">
                    Ambil salinan cadangan instan ke penyimpanan sistem sebelum melakukan perubahan
                  </p>
                </div>
              </div>

              <form onSubmit={handleTakeManualSnapshot} className="space-y-3 text-xs">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    Nama / Label Snapshot *
                  </label>
                  <input
                    type="text"
                    value={snapTitle}
                    onChange={(e) => setSnapTitle(e.target.value)}
                    placeholder="misal: Sebelum Tutup Shift 1 / Sebelum Update Stok Lebaran"
                    required
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    Catatan Tambahan (Opsional)
                  </label>
                  <input
                    type="text"
                    value={snapNote}
                    onChange={(e) => setSnapNote(e.target.value)}
                    placeholder="Keterangan kondisi inventori atau alasan backup..."
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-[11px] text-neutral-400">
                    Disematkan (pinned) otomatis agar aman
                  </span>
                  <button
                    type="submit"
                    disabled={isTakingSnap}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer disabled:opacity-50"
                  >
                    <Save className="w-4 h-4" />
                    <span>{isTakingSnap ? 'Menyimpan...' : 'Simpan Checkpoint'}</span>
                  </button>
                </div>
              </form>
            </div>

            {/* 2. Download File JSON & Copy Clipboard */}
            <div className="bg-[#161618] rounded-2xl border border-[#26262B] p-5 space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-950 border border-blue-800 flex items-center justify-center text-blue-400">
                  <Download className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-sm sm:text-base text-white">
                    Unduh Berkas Arsip (.JSON) Komprehensif
                  </h4>
                  <p className="text-xs text-neutral-400">
                    Ekspor seluruh master produk, gudang, inventori, log transaksi, faktur & dokumen
                  </p>
                </div>
              </div>

              <div className="p-3 bg-[#101012] rounded-xl border border-[#24242A] text-xs text-neutral-300 space-y-1">
                <span className="font-bold text-white block">Cakupan Data Cadangan:</span>
                <p className="text-[11px] text-neutral-400">
                  Menyimpan {products.length} SKU produk, {warehouses.length} gudang, {inventory.length} slot stok, {logs.length} transaksi, {sales.length} faktur penjualan, serta seluruh dokumen PO & Surat Jalan.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleExportBackup}
                  className="flex-1 py-2.5 px-3.5 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-[#F27D26]/20 cursor-pointer"
                >
                  <Download className="w-4 h-4" /> Unduh Berkas JSON (.json)
                </button>

                <label className="py-2.5 px-3.5 bg-[#1F1F24] hover:bg-[#282830] text-neutral-200 border border-[#2E2E38] rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer">
                  <Upload className="w-4 h-4 text-blue-400" />
                  <span>Pulihkan File</span>
                  <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
                </label>
              </div>
            </div>
          </div>

          {/* Checkpoint History Table */}
          <div className="bg-[#161618] rounded-2xl border border-[#26262B] p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h4 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
                  <Layers className="w-4 h-4 text-[#F27D26]" /> Riwayat Titik Pemulihan (Checkpoints)
                </h4>
                <p className="text-xs text-neutral-400">
                  Klik "Pulihkan" pada salah satu snapshot untuk rollback sistem ke titik tersebut
                </p>
              </div>

              {checkpoints.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Bersihkan semua checkpoint otomatis berkala? Snapshot manual dan yang disematkan (pinned) akan tetap dipertahankan.')) {
                      const updated = CheckpointService.clearCheckpoints(true);
                      setCheckpoints(updated);
                      showToast('Riwayat checkpoint otomatis berhasil dibersihkan.', 'success');
                    }
                  }}
                  className="px-3 py-1.5 bg-[#1C1C20] hover:bg-rose-950/40 text-neutral-300 hover:text-rose-300 border border-[#2B2B32] hover:border-rose-800 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Bersihkan Auto-Checkpoint
                </button>
              )}
            </div>

            {checkpoints.length === 0 ? (
              <div className="p-8 text-center border border-dashed border-[#2B2B32] rounded-xl text-neutral-400 space-y-2">
                <Database className="w-8 h-8 text-neutral-600 mx-auto" />
                <p className="text-xs font-bold text-neutral-300">Belum Ada Checkpoint Tersimpan</p>
                <p className="text-[11px] text-neutral-500">
                  Buat snapshot manual di atas atau tunggu interval otomatis berjalan.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {checkpoints.map((chk, idx) => {
                  const isNewest = idx === 0;
                  return (
                    <div
                      key={chk.id}
                      className={`p-3.5 sm:p-4 rounded-xl border bg-[#111114] flex flex-wrap items-center justify-between gap-3 ${
                        isNewest ? 'border-[#F27D26]/50 shadow-sm shadow-[#F27D26]/10' : 'border-[#24242A]'
                      }`}
                    >
                      <div className="space-y-1 min-w-[200px] flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                              chk.triggerType === 'MANUAL'
                                ? 'bg-emerald-950/70 border-emerald-800 text-emerald-300'
                                : chk.triggerType === 'AUTO_OPNAME'
                                ? 'bg-purple-950/70 border-purple-800 text-purple-300'
                                : chk.triggerType === 'AUTO_RESTORE'
                                ? 'bg-amber-950/70 border-amber-800 text-amber-300'
                                : 'bg-blue-950/70 border-blue-800 text-blue-300'
                            }`}
                          >
                            {chk.triggerType === 'MANUAL'
                              ? 'Manual'
                              : chk.triggerType === 'AUTO_OPNAME'
                              ? 'Opname'
                              : chk.triggerType === 'AUTO_RESTORE'
                              ? 'Safety Rollback'
                              : 'Otomatis'}
                          </span>

                          {chk.isPinned && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/60 border border-amber-800/60 text-amber-300 flex items-center gap-1">
                              <Pin className="w-2.5 h-2.5" /> Disematkan
                            </span>
                          )}

                          {isNewest && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 border border-emerald-800 text-emerald-300">
                              Terbaru
                            </span>
                          )}

                          <span className="text-[11px] text-neutral-400 font-mono">
                            {new Date(chk.timestamp).toLocaleString('id-ID')}
                          </span>
                        </div>

                        <h5 className="font-extrabold text-sm text-white">{chk.name}</h5>
                        {chk.note && <p className="text-xs text-neutral-400 italic">"{chk.note}"</p>}

                        <div className="text-[11px] text-neutral-400 flex flex-wrap items-center gap-2 pt-0.5">
                          <span>{chk.data.summary.totalProducts} Produk ({formatNumber(chk.data.summary.totalStockPcs)} Pcs)</span>
                          <span>•</span>
                          <span>{chk.data.summary.totalTransactions} Log</span>
                          <span>•</span>
                          <span>{chk.data.summary.totalSales} Penjualan</span>
                          <span>•</span>
                          <span>{chk.sizeKb} KB</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {/* Pin Button */}
                        <button
                          type="button"
                          onClick={() => {
                            const updated = CheckpointService.togglePin(chk.id);
                            setCheckpoints(updated);
                            showToast('Status sematan checkpoint diperbarui.', 'info');
                          }}
                          className={`p-2 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                            chk.isPinned
                              ? 'bg-amber-950/50 text-amber-300 border-amber-800'
                              : 'bg-[#18181C] text-neutral-400 border-[#2B2B32] hover:text-white'
                          }`}
                          title="Sematkan / Lepaskan Sematan"
                        >
                          <Pin className="w-3.5 h-3.5" />
                        </button>

                        {/* Download JSON Button */}
                        <button
                          type="button"
                          onClick={() =>
                            CheckpointService.downloadBackupJson(
                              chk.data,
                              `checkpoint_${chk.id}_${chk.name.replace(/[^a-zA-Z0-9]/g, '_')}.json`
                            )
                          }
                          className="p-2 bg-[#18181C] hover:bg-[#202026] text-neutral-300 hover:text-white border border-[#2B2B32] rounded-xl text-xs font-bold cursor-pointer"
                          title="Unduh JSON"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>

                        {/* Rollback Button */}
                        <button
                          type="button"
                          onClick={() => setSettingsRollbackTarget(chk)}
                          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm cursor-pointer"
                          title="Pulihkan data sistem ke checkpoint ini"
                        >
                          <RotateCcw className="w-3.5 h-3.5" /> Pulihkan
                        </button>

                        {/* Delete Button */}
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`Hapus checkpoint "${chk.name}"?`)) {
                              const updated = CheckpointService.deleteCheckpoint(chk.id);
                              setCheckpoints(updated);
                              showToast(`Checkpoint "${chk.name}" dihapus.`, 'info');
                            }
                          }}
                          className="p-2 bg-[#18181C] hover:bg-rose-950/60 text-neutral-400 hover:text-rose-400 border border-[#2B2B32] hover:border-rose-800 rounded-xl text-xs font-bold cursor-pointer"
                          title="Hapus"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Automatic Checkpoint Configuration Form */}
          <form onSubmit={handleSaveCheckpointSettings} className="bg-[#161618] rounded-2xl border border-[#26262B] p-5 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-[#24242A]">
              <div>
                <h4 className="font-extrabold text-sm sm:text-base text-white">
                  Konfigurasi Checkpoint Otomatis Sistem
                </h4>
                <p className="text-xs text-neutral-400">
                  Atur interval otomatis snapshot dan pemicu peristiwa (event triggers)
                </p>
              </div>
              <button
                type="button"
                onClick={() => setChkAutoEnabled(!chkAutoEnabled)}
                className={`px-3 py-1.5 rounded-full font-bold text-xs cursor-pointer transition-colors ${
                  chkAutoEnabled
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
                }`}
              >
                {chkAutoEnabled ? '✓ AKTIF' : '✗ NON-AKTIF'}
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Interval Waktu Checkpoint Otomatis
                </label>
                <select
                  value={chkIntervalMin}
                  onChange={(e) => setChkIntervalMin(Number(e.target.value))}
                  disabled={!chkAutoEnabled}
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden disabled:opacity-50"
                >
                  <option value={15}>Setiap 15 Menit (Sangat Aman)</option>
                  <option value={30}>Setiap 30 Menit (Direkomendasikan)</option>
                  <option value={60}>Setiap 1 Jam</option>
                  <option value={120}>Setiap 2 Jam</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Batas Maksimal Checkpoint Tersimpan
                </label>
                <select
                  value={chkMaxCheckpoints}
                  onChange={(e) => setChkMaxCheckpoints(Number(e.target.value))}
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                >
                  <option value={5}>5 Slot Terakhir</option>
                  <option value={10}>10 Slot Terakhir</option>
                  <option value={15}>15 Slot Terakhir (Direkomendasikan)</option>
                  <option value={20}>20 Slot Terakhir</option>
                </select>
              </div>
            </div>

            <div className="pt-2 border-t border-[#24242A] space-y-2.5">
              <span className="font-bold text-neutral-200 block">Pemicu Otomatis (Event Triggers):</span>

              <label className="flex items-center justify-between p-3 rounded-xl bg-[#111114] border border-[#24242A] cursor-pointer">
                <div>
                  <span className="font-bold text-white block">Sebelum Penyetujuan Berita Acara Stok Opname</span>
                  <span className="text-[10px] text-neutral-400">Otomatis buat snapshot sebelum angka stok disesuaikan</span>
                </div>
                <input
                  type="checkbox"
                  checked={chkAutoBeforeOpname}
                  onChange={(e) => setChkAutoBeforeOpname(e.target.checked)}
                  className="rounded accent-[#F27D26]"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-[#111114] border border-[#24242A] cursor-pointer">
                <div>
                  <span className="font-bold text-white block">Safety Checkpoint Sebelum Restore / Reset Pabrik</span>
                  <span className="text-[10px] text-neutral-400">Pastikan selalu ada titik cadangan darurat sebelum data digantikan</span>
                </div>
                <input
                  type="checkbox"
                  checked={chkAutoBeforeRestore}
                  onChange={(e) => setChkAutoBeforeRestore(e.target.checked)}
                  className="rounded accent-[#F27D26]"
                />
              </label>
            </div>

            <div className="flex justify-end pt-1">
              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer"
              >
                <Save className="w-4 h-4" /> Simpan Konfigurasi Otomatis
              </button>
            </div>
          </form>

          {/* Rollback Confirmation Overlay in Settings View */}
          {settingsRollbackTarget && (
            <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4">
              <div className="bg-[#18181C] rounded-2xl border border-rose-800/80 p-5 sm:p-6 max-w-lg w-full space-y-4 shadow-2xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-rose-950 border border-rose-800 flex items-center justify-center text-rose-400 shrink-0">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-base text-rose-300">
                      Konfirmasi Rollback ke Checkpoint
                    </h4>
                    <p className="text-xs text-neutral-400">
                      Mengembalikan seluruh data inventori ke: {settingsRollbackTarget.name}
                    </p>
                  </div>
                </div>

                <div className="p-3 bg-[#101012] rounded-xl border border-[#24242A] text-xs space-y-1">
                  <div className="text-neutral-400">Waktu: <strong className="text-white">{new Date(settingsRollbackTarget.timestamp).toLocaleString('id-ID')}</strong></div>
                  <div className="text-neutral-400">Isi: <strong className="text-white">{settingsRollbackTarget.data.summary.totalProducts} Produk • {formatNumber(settingsRollbackTarget.data.summary.totalStockPcs)} Pcs</strong></div>
                </div>

                <p className="text-xs text-neutral-300">
                  Safety checkpoint dari data saat ini akan dibuat otomatis sebelum rollback berjalan.
                </p>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setSettingsRollbackTarget(null)}
                    className="px-4 py-2 bg-[#24242A] text-neutral-300 rounded-xl text-xs font-bold cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={handleExecuteSettingsRollback}
                    className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" /> Ya, Pulihkan Sekarang
                  </button>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: TAMBAH / EDIT GUDANG */}
      {/* ========================================================================= */}
      {isWarehouseModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-[#161618] border border-[#2B2B32] rounded-2xl w-full max-w-2xl sm:max-w-3xl overflow-hidden shadow-2xl"
          >
            <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214]">
              <h3 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
                <Building2 className="w-4 h-4 text-[#F27D26]" />
                {editingWarehouse ? 'Edit Data Gudang' : 'Tambah Gudang Cabang Baru'}
              </h3>
              <button
                type="button"
                onClick={() => setIsWarehouseModalOpen(false)}
                className="text-neutral-400 hover:text-white text-xs font-bold px-2 py-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveWarehouse} className="p-5 sm:p-7 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    ID Gudang (Kode Unik) *
                  </label>
                  <input
                    type="text"
                    value={whId}
                    onChange={(e) => setWhId(e.target.value)}
                    placeholder="Contoh: GDG-03-SURABAYA"
                    required
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-mono font-bold uppercase focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    Nama Gudang *
                  </label>
                  <input
                    type="text"
                    value={whName}
                    onChange={(e) => setWhName(e.target.value)}
                    placeholder="Contoh: GUDANG CABANG SURABAYA"
                    required
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold uppercase focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                  Lokasi / Alamat Gudang
                </label>
                <input
                  type="text"
                  value={whLocation}
                  onChange={(e) => setWhLocation(e.target.value)}
                  placeholder="Contoh: Jl. Rungkut Industri No. 12"
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 focus:border-[#F27D26] focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    Penanggung Jawab (PIC)
                  </label>
                  <input
                    type="text"
                    value={whPic}
                    onChange={(e) => setWhPic(e.target.value)}
                    placeholder="Nama PIC"
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    No. Telepon Gudang
                  </label>
                  <input
                    type="text"
                    value={whPhone}
                    onChange={(e) => setWhPhone(e.target.value)}
                    placeholder="0812-xxxx-xxxx"
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                  Catatan / Keterangan
                </label>
                <input
                  type="text"
                  value={whNotes}
                  onChange={(e) => setWhNotes(e.target.value)}
                  placeholder="Keterangan fungsi gudang..."
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 focus:border-[#F27D26] focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-[#121214] border border-[#24242A]">
                <div>
                  <span className="font-bold text-white block">Status Aktif Gudang</span>
                  <span className="text-[10px] text-neutral-400">Gudang aktif dapat dipilih untuk transaksi</span>
                </div>
                <button
                  type="button"
                  onClick={() => setWhIsActive(!whIsActive)}
                  className={`px-3 py-1 rounded-full font-bold text-[10px] cursor-pointer ${
                    whIsActive ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-neutral-800 text-neutral-400'
                  }`}
                >
                  {whIsActive ? '✓ Aktif' : '✗ Non-Aktif'}
                </button>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#24242A]">
                <button
                  type="button"
                  onClick={() => setIsWarehouseModalOpen(false)}
                  className="px-4 py-2 bg-[#1C1C20] text-neutral-300 rounded-xl font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl font-bold cursor-pointer"
                >
                  Simpan Gudang
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: TAMBAH / EDIT USER */}
      {/* ========================================================================= */}
      {isUserModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-[#161618] border border-[#2B2B32] rounded-2xl w-full max-w-2xl sm:max-w-3xl overflow-hidden shadow-2xl"
          >
            <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214]">
              <h3 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-[#F27D26]" />
                {editingUser ? 'Edit Data Pengguna' : 'Tambah Akun Pengguna Baru'}
              </h3>
              <button
                type="button"
                onClick={() => setIsUserModalOpen(false)}
                className="text-neutral-400 hover:text-white text-xs font-bold px-2 py-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="p-5 sm:p-7 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    Username Login *
                  </label>
                  <input
                    type="text"
                    value={uUsername}
                    onChange={(e) => setUUsername(e.target.value)}
                    placeholder="misal: budi_gudang"
                    required
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    Password / PIN *
                  </label>
                  <input
                    type="text"
                    value={uPassword}
                    onChange={(e) => setUPassword(e.target.value)}
                    placeholder={editingUser ? 'Kosongkan jika tetap' : 'Password'}
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-mono focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    Nama Lengkap & Jabatan *
                  </label>
                  <input
                    type="text"
                    value={uFullName}
                    onChange={(e) => setUFullName(e.target.value)}
                    placeholder="Contoh: Budi Santoso (Admin Gudang)"
                    required
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    Role / Tingkatan
                  </label>
                  <select
                    value={uRole}
                    onChange={(e) => setURole(e.target.value as UserRole)}
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                  >
                    <option value="OWNER">OWNER (Pemilik Usaha - Akses Penuh & Koreksi)</option>
                    <option value="SUPERVISOR">SUPERVISOR / SPV (Approval & Koreksi Stok)</option>
                    <option value="ADMIN">ADMIN (Operasional Gudang)</option>
                    <option value="STAFF">STAFF (Scan & Input)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    Hak Akses Gudang
                  </label>
                  <select
                    value={uSiteAccess}
                    onChange={(e) => setUSiteAccess(e.target.value)}
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                  >
                    <option value="SEMUA GUDANG">SEMUA GUDANG</option>
                    {warehouses.map((w) => (
                      <option key={w.GUDANG_ID} value={w.NAMA_GUDANG}>
                        {w.NAMA_GUDANG}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    No. WhatsApp / HP
                  </label>
                  <input
                    type="text"
                    value={uPhone}
                    onChange={(e) => setUPhone(e.target.value)}
                    placeholder="0812-xxxx-xxxx"
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={uEmail}
                    onChange={(e) => setUEmail(e.target.value)}
                    placeholder="nama@email.com"
                    className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 focus:border-[#F27D26] focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-[#121214] border border-[#24242A]">
                <div>
                  <span className="font-bold text-white block">Status Akun Aktif</span>
                  <span className="text-[10px] text-neutral-400">User non-aktif tidak dapat login ke sistem</span>
                </div>
                <button
                  type="button"
                  onClick={() => setUIsActive(!uIsActive)}
                  className={`px-3 py-1 rounded-full font-bold text-[10px] cursor-pointer ${
                    uIsActive ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-neutral-800 text-neutral-400'
                  }`}
                >
                  {uIsActive ? '✓ Aktif' : '✗ Non-Aktif'}
                </button>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#24242A]">
                <button
                  type="button"
                  onClick={() => setIsUserModalOpen(false)}
                  className="px-4 py-2 bg-[#1C1C20] text-neutral-300 rounded-xl font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#F27D26] hover:bg-[#d96c1d] text-white rounded-xl font-bold cursor-pointer"
                >
                  Simpan User
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: PRODUCT ADD / EDIT */}
      {/* ========================================================================= */}
      {editingProduct !== undefined && (
        <ProductModal
          isOpen={editingProduct !== undefined}
          onClose={() => setEditingProduct(undefined)}
          productToEdit={editingProduct}
          onSave={handleSaveProduct}
        />
      )}

      {/* ========================================================================= */}
      {/* MODAL: SINGLE PRODUCT LABEL PRINT */}
      {/* ========================================================================= */}
      {labelProduct && (
        <LabelPrintModal
          isOpen={!!labelProduct}
          onClose={() => setLabelProduct(null)}
          product={labelProduct}
          barcodeFormat={barcodeFormat}
          brandName={brandName}
          paperFormat={labelPaperSize}
        />
      )}

      {/* ========================================================================= */}
      {/* MODAL: BATCH PRINT LABELS */}
      {/* ========================================================================= */}
      {showBatchPrintModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-[#161618] border border-[#2B2B32] rounded-2xl w-full max-w-md overflow-hidden shadow-2xl"
          >
            <div className="p-4 border-b border-[#24242A] flex items-center justify-between bg-[#121214]">
              <h3 className="font-extrabold text-sm text-white flex items-center gap-2">
                <Printer className="w-4 h-4 text-purple-400" />
                Cetak Barcode Label Massal
              </h3>
              <button
                type="button"
                onClick={() => setShowBatchPrintModal(false)}
                className="text-neutral-400 hover:text-white text-xs font-bold px-2 py-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-4 sm:p-5 space-y-4 text-xs">
              <div className="bg-[#121214] p-3 rounded-xl border border-[#24242A]">
                <span className="text-[11px] text-neutral-400 block mb-1">Target Cetak:</span>
                <span className="font-bold text-white text-sm block">
                  {filteredProducts.length > 0
                    ? `${filteredProducts.length} Produk (Sesuai Filter Aktif)`
                    : `${products.length} Semua Produk Master`}
                </span>
                <span className="text-[10px] text-neutral-500 mt-1 block">
                  Total label yang akan dihasilkan: <strong>{(filteredProducts.length || products.length) * batchPrintCopies} Label</strong>
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                  Format Simbol Label
                </label>
                <select
                  value={batchBarcodeFormat}
                  onChange={(e) => setBatchBarcodeFormat(e.target.value as any)}
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                >
                  <option value="CODE128">Code-128 (Barcode Garis 1D)</option>
                  <option value="QR_CODE">QR Code 2D Matrix</option>
                  <option value="EAN13">EAN-13 Numerik</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                  Jumlah Copy per SKU (pcs)
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setBatchPrintCopies((c) => Math.max(1, c - 1))}
                    className="w-9 h-9 rounded-xl bg-[#0F0F10] border border-[#2B2B32] text-white font-bold hover:bg-[#1C1C20] cursor-pointer"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={batchPrintCopies}
                    onChange={(e) => setBatchPrintCopies(Math.max(1, Number(e.target.value)))}
                    className="flex-1 text-center font-bold text-sm bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-white py-2 focus:border-[#F27D26] focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => setBatchPrintCopies((c) => Math.min(20, c + 1))}
                    className="w-9 h-9 rounded-xl bg-[#0F0F10] border border-[#2B2B32] text-white font-bold hover:bg-[#1C1C20] cursor-pointer"
                  >
                    +
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                  Ukuran & Tata Letak Kertas
                </label>
                <select
                  value={batchPaperSize}
                  onChange={(e) => setBatchPaperSize(e.target.value as any)}
                  className="w-full p-2.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-100 font-bold focus:border-[#F27D26] focus:outline-hidden"
                >
                  <option value="A4_40_LABELS">Kertas A4 Grid (4 Kolom x 10 Baris)</option>
                  <option value="THERMAL_50X30">Printer Thermal Kasir (50 x 30 mm)</option>
                  <option value="THERMAL_40X20">Printer Thermal Mini (40 x 20 mm)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#24242A]">
                <button
                  type="button"
                  onClick={() => setShowBatchPrintModal(false)}
                  className="px-4 py-2 bg-[#1C1C20] text-neutral-300 rounded-xl font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleExecuteBatchPrint}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold flex items-center gap-1.5 cursor-pointer shadow-md shadow-purple-600/30"
                >
                  <Printer className="w-3.5 h-3.5" /> Buka Lembar Cetak
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* IN-APP DELETE CONFIRMATION MODAL */}
      {deleteConfirmTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-[#161618] rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-[#2A2A30] text-[#E0E0E0] animate-in zoom-in-95 duration-150">
            <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] text-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base leading-tight text-rose-300">Konfirmasi Hapus</h3>
                  <p className="text-[11px] text-neutral-400">Tindakan permanen dan tidak dapat dibatalkan</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDeleteConfirmTarget(null)}
                className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div className="p-3.5 rounded-xl bg-rose-950/20 border border-rose-900/40 text-xs text-neutral-300 space-y-1.5">
                <div className="font-bold text-white text-sm">{deleteConfirmTarget.title}</div>
                <p className="text-neutral-400 leading-relaxed text-[11.5px]">{deleteConfirmTarget.description}</p>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setDeleteConfirmTarget(null)}
                  className="px-4 py-2 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 rounded-xl text-xs font-bold transition-colors cursor-pointer border border-[#2B2B32]"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-md shadow-rose-600/30"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Ya, Hapus Sekarang
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
