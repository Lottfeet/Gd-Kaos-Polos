import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  InventoryItem,
  MasterGudang,
  MasterProduk,
  StockOpnameItem,
  StockOpnameSession,
  User,
  AppSystemSettings,
  LogTransaksi,
} from '../types';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import { formatRupiah, terbilangRupiah } from '../utils/formatters';
import { getWarnaHex } from '../utils/tshirtSvg';
import {
  ClipboardCheck,
  Search,
  Camera,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Printer,
  FileCheck,
  TrendingDown,
  TrendingUp,
  X,
  ShieldCheck,
  ArrowRight,
  Filter,
  ExternalLink,
  ArrowDownToLine,
  Info,
  Clock,
  Check,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { printElement, downloadPrintableHtml, openPrintableInNewWindow } from '../utils/printHelper';

interface StockOpnameViewProps {
  inventory: InventoryItem[];
  products: MasterProduk[];
  warehouses: MasterGudang[];
  currentUser: User;
  logs?: LogTransaksi[];
  onApplyAdjustment: (
    session: StockOpnameSession,
    adjustments: {
      gudangId: string;
      skuId: string;
      newStock: number;
      oldStock: number;
      diff: number;
      reason: string;
    }[]
  ) => void;
  showToast: (text: string, type: 'success' | 'error' | 'info') => void;
  settings?: AppSystemSettings;
}

export const StockOpnameView: React.FC<StockOpnameViewProps> = ({
  inventory,
  products,
  warehouses,
  currentUser,
  logs = [],
  onApplyAdjustment,
  showToast,
  settings,
}) => {
  // Determine initial warehouse
  const defaultWarehouseId = currentUser.siteAccess.includes('TOKO') ? 'GDG-02-TOKO' : 'GDG-01-ERVO';
  const [selectedGudangId, setSelectedGudangId] = useState<string>(defaultWarehouseId);

  // Session metadata
  const [nomorOpname, setNomorOpname] = useState<string>('');
  const [tanggal, setTanggal] = useState<string>('');
  const [auditor, setAuditor] = useState<string>(currentUser.fullName || currentUser.username);
  const [catatanUmum, setCatatanUmum] = useState<string>('Pemeriksaan fisik stok berkala');
  const [isApplied, setIsApplied] = useState<boolean>(false);

  // Filter & Search states
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterVariance, setFilterVariance] = useState<'all' | 'variance' | 'minus' | 'plus' | 'match'>('all');

  // Scanner modal
  const [showScanner, setShowScanner] = useState<boolean>(false);
  const [lastScannedSku, setLastScannedSku] = useState<string | null>(null);

  // Printable Berita Acara Modal
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);
  const printableRef = useRef<HTMLDivElement>(null);
  const [printStatus, setPrintStatus] = useState<string | null>(null);

  const handlePrintBA = () => {
    if (!printableRef.current) return;
    printElement(
      printableRef.current,
      {
        title: `Berita Acara Stok Opname - ${nomorOpname}`,
        filename: `BA_Opname_${nomorOpname}`,
      },
      (msg) => {
        setPrintStatus(msg);
        setTimeout(() => setPrintStatus(null), 5000);
      }
    );
  };

  const handleOpenNewTabBA = () => {
    if (!printableRef.current) return;
    const ok = openPrintableInNewWindow(printableRef.current.outerHTML, {
      title: `Berita Acara Stok Opname - ${nomorOpname}`,
      filename: `BA_Opname_${nomorOpname}`,
    });
    if (ok) {
      setPrintStatus('Dokumen berita acara dibuka di tab baru siap cetak.');
    } else {
      downloadPrintableHtml(printableRef.current.outerHTML, {
        title: `Berita Acara Stok Opname - ${nomorOpname}`,
        filename: `BA_Opname_${nomorOpname}`,
      });
      setPrintStatus('Popup diblokir, berkas cetak diunduh otomatis.');
    }
    setTimeout(() => setPrintStatus(null), 5000);
  };

  const handleDownloadBA = () => {
    if (!printableRef.current) return;
    downloadPrintableHtml(printableRef.current.outerHTML, {
      title: `Berita Acara Stok Opname - ${nomorOpname}`,
      filename: `BA_Opname_${nomorOpname}`,
    });
    setPrintStatus('Berkas HTML cetak berhasil diunduh.');
    setTimeout(() => setPrintStatus(null), 4000);
  };

  // Stock Opname Items State
  const [opnameItems, setOpnameItems] = useState<StockOpnameItem[]>([]);

  // Multi-day SO State & Modals
  const DRAFT_STORAGE_KEY = `INVENTORY_SO_DRAFT_${selectedGudangId}`;
  const [hasLoadedDraft, setHasLoadedDraft] = useState<boolean>(false);
  const [tanggalMulai, setTanggalMulai] = useState<string>('');

  // Modals for confirmation (bypasses iframe window.confirm restriction)
  const [showApplyConfirmModal, setShowApplyConfirmModal] = useState<boolean>(false);
  const [showResetConfirmModal, setShowResetConfirmModal] = useState<boolean>(false);
  const [showSyncAllConfirmModal, setShowSyncAllConfirmModal] = useState<boolean>(false);
  const [showNewSessionConfirmModal, setShowNewSessionConfirmModal] = useState<boolean>(false);
  const [showMultiDayInfoModal, setShowMultiDayInfoModal] = useState<boolean>(false);
  const [selectedMutationDetail, setSelectedMutationDetail] = useState<{
    item: StockOpnameItem;
    mutation: {
      mutasiPascaHitung: number;
      qtyMasuk: number;
      qtyKeluar: number;
      stokSistemTerkini: number;
      reconciledFinalStock: number;
      hasMutation: boolean;
      mutationCount: number;
      relevantLogs: LogTransaksi[];
    };
  } | null>(null);

  // Generate Session ID & Init items when warehouse changes or component mounts
  useEffect(() => {
    // 1. Cek apakah ada draft opname yang belum selesai tersimpan di localStorage untuk gudang ini
    const savedDraft = localStorage.getItem(DRAFT_STORAGE_KEY);
    if (savedDraft) {
      try {
        const parsed = JSON.parse(savedDraft);
        if (parsed && Array.isArray(parsed.items) && parsed.items.length > 0) {
          setNomorOpname(parsed.nomorOpname);
          setTanggal(new Date().toISOString().split('T')[0]); // Tanggal hari ini
          setTanggalMulai(parsed.tanggalMulai || parsed.tanggal);
          setAuditor(parsed.auditor || currentUser.fullName || currentUser.username);
          setCatatanUmum(parsed.catatanUmum || 'Pemeriksaan fisik stok berkala');
          setIsApplied(false);
          setHasLoadedDraft(true);

          // Update stokSistem terkini dari database inventory
          const warehouseInventory = inventory.filter((inv) => inv.GUDANG_ID === selectedGudangId);
          const syncedItems: StockOpnameItem[] = parsed.items.map((savedItem: StockOpnameItem) => {
            const currentInv = warehouseInventory.find((inv) => inv.SKU_ID === savedItem.SKU_ID);
            const currentSystemQty = currentInv ? currentInv.JUMLAH_READY : 0;
            const isCounted = !!savedItem.isCounted;
            const physicalStock = isCounted ? (savedItem.stokFisik ?? 0) : 0;
            const selisih = physicalStock - currentSystemQty;
            return {
              ...savedItem,
              stokSistem: currentSystemQty,
              stokFisik: physicalStock,
              selisih,
              nilaiSelisih: selisih * savedItem.hargaHpp,
              isCounted,
            };
          });

          setOpnameItems(syncedItems);
          return;
        }
      } catch (e) {
        console.error('Error loading SO draft:', e);
      }
    }

    // 2. Jika belum ada draft, inisialisasi sesi SO baru
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const dateCode = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`;
    const randSeq = String(Math.floor(100 + Math.random() * 900));
    setNomorOpname(`SO-${dateCode}-${randSeq}`);
    setTanggal(now.toISOString().split('T')[0]);
    setTanggalMulai(now.toISOString().split('T')[0]);
    setIsApplied(false);
    setHasLoadedDraft(false);

    // Populate items from current warehouse inventory
    const warehouseInventory = inventory.filter((inv) => inv.GUDANG_ID === selectedGudangId);
    const initialItems: StockOpnameItem[] = products.map((prod) => {
      const invItem = warehouseInventory.find((inv) => inv.SKU_ID === prod.SKU_ID);
      const systemQty = invItem ? invItem.JUMLAH_READY : 0;
      const hpp = prod.HARGA_HPP || 30000;

      return {
        SKU_ID: prod.SKU_ID,
        namaProduk: prod.NAMA_PRODUK,
        warna: prod.WARNA,
        ukuran: prod.UKURAN,
        jenisLengan: prod.JENIS_LENGAN,
        stokSistem: systemQty,
        stokFisik: 0, // DEFAULT STOK FISIK ADALAH 0 (Sesuai Permintaan User: pic1)
        selisih: 0 - systemQty,
        hargaHpp: hpp,
        hargaJual: prod.HARGA_JUAL || 45000,
        nilaiSelisih: (0 - systemQty) * hpp,
        catatan: '',
        isCounted: false,
        systemStockAtCount: systemQty,
      };
    });

    setOpnameItems(initialItems);
  }, [selectedGudangId, inventory, products]);

  // Simpan otomatis draft SO ke localStorage setiap kali ada input hitungan
  useEffect(() => {
    if (!isApplied && opnameItems.length > 0) {
      const draft = {
        nomorOpname,
        tanggal,
        tanggalMulai: tanggalMulai || tanggal,
        selectedGudangId,
        auditor,
        catatanUmum,
        items: opnameItems,
        savedAt: new Date().toISOString(),
      };
      localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(draft));
    }
  }, [opnameItems, nomorOpname, tanggal, tanggalMulai, selectedGudangId, auditor, catatanUmum, isApplied, DRAFT_STORAGE_KEY]);

  // Menghitung mutasi transaksi pasca-hitung (Solusi Opname Berhari-hari)
  const calculateItemMutation = (item: StockOpnameItem) => {
    const currentInvStock = inventory.find(
      (inv) => inv.GUDANG_ID === selectedGudangId && inv.SKU_ID === item.SKU_ID
    )?.JUMLAH_READY ?? item.stokSistem;

    if (!item.isCounted || !item.countedAt || !logs || logs.length === 0) {
      return {
        mutasiPascaHitung: 0,
        qtyMasuk: 0,
        qtyKeluar: 0,
        stokSistemTerkini: currentInvStock,
        reconciledFinalStock: item.isCounted ? item.stokFisik : currentInvStock,
        hasMutation: false,
        mutationCount: 0,
        relevantLogs: [] as LogTransaksi[],
      };
    }

    const countTime = new Date(item.countedAt).getTime();
    const relevantLogs = logs.filter(
      (l) =>
        l.SKU_ID === item.SKU_ID &&
        l.GUDANG_ID === selectedGudangId &&
        new Date(l.TIMESTAMP).getTime() > countTime
    );

    let qtyMasuk = 0;
    let qtyKeluar = 0;
    relevantLogs.forEach((l) => {
      if (l.JUMLAH > 0) qtyMasuk += l.JUMLAH;
      else if (l.JUMLAH < 0) qtyKeluar += Math.abs(l.JUMLAH);
    });

    const netMutasi = qtyMasuk - qtyKeluar;
    const hasMutation = relevantLogs.length > 0 && netMutasi !== 0;

    // Varian fisik asli saat audit
    const baseSystem = item.systemStockAtCount ?? item.stokSistem;
    const auditVariance = item.stokFisik - baseSystem;

    // Stok akhir yang diselaraskan:
    // Stok sistem saat ini + varian selisih fisik asli (setara dengan stokFisik + netMutasi)
    const reconciledFinalStock = Math.max(0, currentInvStock + auditVariance);

    return {
      mutasiPascaHitung: netMutasi,
      qtyMasuk,
      qtyKeluar,
      stokSistemTerkini: currentInvStock,
      reconciledFinalStock,
      hasMutation,
      mutationCount: relevantLogs.length,
      relevantLogs,
    };
  };

  // Update physical count for an item
  const handleUpdatePhysicalStock = (skuId: string, newPhysicalQty: number, catatan?: string) => {
    if (isApplied) return;
    const qty = Math.max(0, newPhysicalQty);
    const nowIso = new Date().toISOString();

    setOpnameItems((prev) =>
      prev.map((item) => {
        if (item.SKU_ID !== skuId) return item;
        const currentSystemStock = inventory.find(
          (inv) => inv.GUDANG_ID === selectedGudangId && inv.SKU_ID === skuId
        )?.JUMLAH_READY ?? item.stokSistem;

        const selisih = qty - currentSystemStock;
        const nilaiSelisih = selisih * item.hargaHpp;
        return {
          ...item,
          stokSistem: currentSystemStock,
          stokFisik: qty,
          selisih,
          nilaiSelisih,
          catatan: catatan !== undefined ? catatan : item.catatan,
          isCounted: true,
          countedAt: item.countedAt || nowIso,
          systemStockAtCount: item.systemStockAtCount ?? currentSystemStock,
        };
      })
    );
  };

  // Quick adjust (+1, -1, +5, -5)
  const handleQuickAdjust = (skuId: string, delta: number) => {
    if (isApplied) return;
    const target = opnameItems.find((i) => i.SKU_ID === skuId);
    if (!target) return;
    handleUpdatePhysicalStock(skuId, target.stokFisik + delta);
  };

  // Samakan satu item ke stok sistem
  const handleResetItemToSystem = (skuId: string) => {
    if (isApplied) return;
    const target = opnameItems.find((i) => i.SKU_ID === skuId);
    if (!target) return;
    handleUpdatePhysicalStock(skuId, target.stokSistem, '');
  };

  // Buka dialog konfirmasi samakan semua
  const handleResetAllToSystem = () => {
    if (isApplied) return;
    setShowSyncAllConfirmModal(true);
  };

  const handleConfirmSyncAllToSystem = () => {
    if (isApplied) return;
    const nowIso = new Date().toISOString();
    setOpnameItems((prev) =>
      prev.map((item) => ({
        ...item,
        stokFisik: item.stokSistem,
        selisih: 0,
        nilaiSelisih: 0,
        isCounted: true,
        countedAt: nowIso,
        systemStockAtCount: item.stokSistem,
      }))
    );
    setShowSyncAllConfirmModal(false);
    showToast('Semua item fisik telah disamakan dengan stok sistem.', 'info');
  };

  // Memulai sesi baru dari awal (menghapus draft multi-hari)
  const handleStartNewSession = () => {
    localStorage.removeItem(DRAFT_STORAGE_KEY);
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const dateCode = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`;
    const randSeq = String(Math.floor(100 + Math.random() * 900));
    setNomorOpname(`SO-${dateCode}-${randSeq}`);
    setTanggal(now.toISOString().split('T')[0]);
    setTanggalMulai(now.toISOString().split('T')[0]);
    setIsApplied(false);
    setHasLoadedDraft(false);

    const warehouseInventory = inventory.filter((inv) => inv.GUDANG_ID === selectedGudangId);
    const freshItems: StockOpnameItem[] = products.map((prod) => {
      const invItem = warehouseInventory.find((inv) => inv.SKU_ID === prod.SKU_ID);
      const systemQty = invItem ? invItem.JUMLAH_READY : 0;
      const hpp = prod.HARGA_HPP || 30000;
      return {
        SKU_ID: prod.SKU_ID,
        namaProduk: prod.NAMA_PRODUK,
        warna: prod.WARNA,
        ukuran: prod.UKURAN,
        jenisLengan: prod.JENIS_LENGAN,
        stokSistem: systemQty,
        stokFisik: 0,
        selisih: 0 - systemQty,
        hargaHpp: hpp,
        hargaJual: prod.HARGA_JUAL || 45000,
        nilaiSelisih: (0 - systemQty) * hpp,
        catatan: '',
        isCounted: false,
        systemStockAtCount: systemQty,
      };
    });
    setOpnameItems(freshItems);
    setShowNewSessionConfirmModal(false);
    showToast('Sesi Stok Opname baru dimulai. Stok fisik awal 0.', 'info');
  };

  // Konfirmasi Batal / Reset Audit
  const handleResetAudit = () => {
    setShowResetConfirmModal(true);
  };

  const handleConfirmResetAudit = () => {
    localStorage.removeItem(DRAFT_STORAGE_KEY);
    const warehouseInventory = inventory.filter((inv) => inv.GUDANG_ID === selectedGudangId);
    const resetItems: StockOpnameItem[] = products.map((prod) => {
      const invItem = warehouseInventory.find((inv) => inv.SKU_ID === prod.SKU_ID);
      const systemQty = invItem ? invItem.JUMLAH_READY : 0;
      return {
        SKU_ID: prod.SKU_ID,
        namaProduk: prod.NAMA_PRODUK,
        warna: prod.WARNA,
        ukuran: prod.UKURAN,
        jenisLengan: prod.JENIS_LENGAN,
        stokSistem: systemQty,
        stokFisik: 0,
        selisih: 0 - systemQty,
        hargaHpp: prod.HARGA_HPP || 30000,
        hargaJual: prod.HARGA_JUAL || 45000,
        nilaiSelisih: (0 - systemQty) * (prod.HARGA_HPP || 30000),
        catatan: '',
        isCounted: false,
        systemStockAtCount: systemQty,
      };
    });
    setOpnameItems(resetItems);
    setAuditor(currentUser.fullName || currentUser.username);
    setCatatanUmum('Pemeriksaan fisik stok berkala');
    setIsApplied(false);
    setHasLoadedDraft(false);
    setShowResetConfirmModal(false);
    showToast('Seluruh input hitungan fisik telah di-reset ke 0.', 'info');
  };

  // Handle Barcode Scanned during Opname
  const handleBarcodeScanned = (code: string) => {
    const cleanCode = code.trim().toUpperCase();
    const matched = products.find(
      (p) =>
        p.SKU_ID.toUpperCase() === cleanCode ||
        (p.BARCODE_ID && p.BARCODE_ID.toUpperCase() === cleanCode)
    );

    if (matched) {
      const sku = matched.SKU_ID;
      const targetItem = opnameItems.find((i) => i.SKU_ID === sku);
      if (targetItem) {
        handleQuickAdjust(sku, 1);
        setLastScannedSku(sku);
        showToast(`Scan ${sku}: Stok fisik dihitung +1 pcs (Total: ${targetItem.stokFisik + 1})`, 'success');
        setTimeout(() => setLastScannedSku(null), 2500);
      } else {
        showToast(`Produk ${sku} tidak ada dalam daftar opname gudang ini.`, 'error');
      }
    } else {
      showToast(`Barcode "${cleanCode}" tidak ditemukan di Master Produk.`, 'error');
    }
  };

  // Summary Metrics
  const summaryMetrics = useMemo(() => {
    const totalItems = opnameItems.length;
    let matchCount = 0;
    let minusCount = 0;
    let plusCount = 0;
    let totalSelisihPcs = 0;
    let totalNilaiSelisihNominal = 0;
    let totalSistemPcs = 0;
    let totalFisikPcs = 0;
    let countedCount = 0;

    opnameItems.forEach((item) => {
      totalSistemPcs += item.stokSistem;
      totalFisikPcs += item.stokFisik;
      totalSelisihPcs += item.selisih;
      totalNilaiSelisihNominal += item.nilaiSelisih;

      if (item.isCounted) countedCount++;

      if (item.selisih === 0) matchCount++;
      else if (item.selisih < 0) minusCount++;
      else plusCount++;
    });

    const varianceCount = minusCount + plusCount;

    return {
      totalItems,
      matchCount,
      minusCount,
      plusCount,
      varianceCount,
      countedCount,
      totalSistemPcs,
      totalFisikPcs,
      totalSelisihPcs,
      totalNilaiSelisihNominal,
    };
  }, [opnameItems]);

  // Filtered Items for Display
  const filteredOpnameItems = useMemo(() => {
    return opnameItems.filter((item) => {
      // Variance filter
      if (filterVariance === 'variance' && item.selisih === 0) return false;
      if (filterVariance === 'minus' && item.selisih >= 0) return false;
      if (filterVariance === 'plus' && item.selisih <= 0) return false;
      if (filterVariance === 'match' && item.selisih !== 0) return false;

      // Search query
      const q = searchQuery.toLowerCase().trim();
      if (!q) return true;
      return (
        item.SKU_ID.toLowerCase().includes(q) ||
        item.namaProduk.toLowerCase().includes(q) ||
        item.warna.toLowerCase().includes(q) ||
        item.ukuran.toLowerCase().includes(q)
      );
    });
  }, [opnameItems, filterVariance, searchQuery]);

  // Open modal konfirmasi penerapan penyesuaian (Bypass confirm dialog)
  const handleApplyAdjustment = () => {
    if (isApplied) return;
    setShowApplyConfirmModal(true);
  };

  // Eksekusi penerapan penyesuaian stok opname dengan rekonsiliasi mutasi berjalan
  const executeApplyAdjustment = () => {
    if (isApplied) return;

    const currentWarehouse = warehouses.find((w) => w.GUDANG_ID === selectedGudangId);

    // Kumpulkan penyesuaian per item dengan rekonsiliasi mutasi berjalan
    const itemsWithAdjustments = opnameItems.map((item) => {
      const mutation = calculateItemMutation(item);
      const finalStock = item.isCounted ? mutation.reconciledFinalStock : item.stokSistem;
      const currentSystemStock = mutation.stokSistemTerkini;
      const diff = finalStock - currentSystemStock;
      return {
        item,
        finalStock,
        currentSystemStock,
        diff,
        mutation,
      };
    });

    const adjustments = itemsWithAdjustments
      .filter((i) => i.diff !== 0)
      .map((i) => {
        let reason = i.item.catatan || `Penyesuaian hasil stok opname ${nomorOpname}`;
        if (i.mutation.hasMutation) {
          reason += ` [Rekonsiliasi mutasi: Fisik ${i.item.stokFisik} pcs, Mutasi pasca-hitung ${i.mutation.mutasiPascaHitung > 0 ? '+' : ''}${i.mutation.mutasiPascaHitung} pcs]`;
        }
        return {
          gudangId: selectedGudangId,
          skuId: i.item.SKU_ID,
          newStock: i.finalStock,
          oldStock: i.currentSystemStock,
          diff: i.diff,
          reason,
        };
      });

    const sessionDoc: StockOpnameSession = {
      id: `SES-${Date.now()}`,
      nomorOpname,
      tanggal,
      tanggalMulai: tanggalMulai || tanggal,
      gudangId: selectedGudangId,
      gudangNama: currentWarehouse?.NAMA_GUDANG || selectedGudangId,
      auditor,
      status: 'SELESAI',
      catatan: catatanUmum,
      items: opnameItems.map((i) => {
        const m = calculateItemMutation(i);
        return {
          ...i,
          stokAkhirRekonsiliasi: m.reconciledFinalStock,
          mutasiPascaHitung: m.mutasiPascaHitung,
        };
      }),
      totalItemSistem: summaryMetrics.totalSistemPcs,
      totalItemFisik: summaryMetrics.totalFisikPcs,
      totalSelisihPcs: summaryMetrics.totalSelisihPcs,
      totalNilaiSelisihNominal: summaryMetrics.totalNilaiSelisihNominal,
      appliedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      hasReconciliation: itemsWithAdjustments.some((i) => i.mutation.hasMutation),
    };

    onApplyAdjustment(sessionDoc, adjustments);
    setIsApplied(true);
    localStorage.removeItem(DRAFT_STORAGE_KEY);
    setShowApplyConfirmModal(false);

    try {
      confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
    } catch {
      // ignore
    }

    showToast(`Penyesuaian stok opname ${nomorOpname} (${adjustments.length} SKU) berhasil diterapkan ke sistem!`, 'success');
  };

  const currentWarehouseName =
    warehouses.find((w) => w.GUDANG_ID === selectedGudangId)?.NAMA_GUDANG || selectedGudangId;

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Multi-Day SO Active Banner (Solusi Opname Berhari-hari) */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-blue-950/30 border border-blue-800/40 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs shadow-xs">
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center justify-center shrink-0 mt-0.5 sm:mt-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <strong className="text-blue-300 font-extrabold text-sm">
                {hasLoadedDraft ? 'Sesi Opname Multi-Hari Aktif' : 'Sistem Audit & Rekonsiliasi Multi-Hari'}
              </strong>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-900/60 border border-blue-700/60 text-blue-200">
                Otomatis Tersimpan
              </span>
              {hasLoadedDraft && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950/70 border border-emerald-800/60 text-emerald-300">
                  Progres: {summaryMetrics.countedCount}/{summaryMetrics.totalItems} SKU dihitung
                </span>
              )}
            </div>
            <p className="text-neutral-300 text-[11.5px] mt-0.5 leading-relaxed">
              {hasLoadedDraft
                ? `Melanjutkan sesi opname yang dimulai pada ${tanggalMulai || tanggal}. Jika esok hari ada transaksi (penjualan/barang masuk), sistem otomatis melakukan Rekonsiliasi Mutasi Berjalan agar transaksi tidak hilang.`
                : 'Progres hitungan fisik real otomatis tersimpan di perangkat ini. Anda dapat menghitung sebagian barang hari ini dan melanjutkannya esok hari tanpa khawatir transaksi tertimpa.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
          <button
            type="button"
            onClick={() => setShowMultiDayInfoModal(true)}
            className="px-3 py-1.5 bg-blue-900/60 hover:bg-blue-800/80 text-blue-200 border border-blue-700/60 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
          >
            <Info className="w-3.5 h-3.5" /> Cara Kerja Multi-Hari
          </button>
          {hasLoadedDraft && !isApplied && (
            <button
              type="button"
              onClick={() => setShowNewSessionConfirmModal(true)}
              className="px-3 py-1.5 bg-[#1C1C20] hover:bg-rose-950/60 text-neutral-300 hover:text-rose-300 border border-[#2B2B32] rounded-xl text-xs font-bold transition-colors cursor-pointer"
              title="Reset draft dan mulai sesi opname baru"
            >
              Mulai Sesi Baru
            </button>
          )}
        </div>
      </div>

      {/* Top Header Card */}
      <div className="bg-[#161618] rounded-2xl border border-[#26262B] p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center shrink-0">
              <ClipboardCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-extrabold text-white">
                  Stok Opname (Audit Fisik Gudang)
                </h2>
                <span className="font-mono text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-950/70 border border-blue-800/60 text-blue-300">
                  {nomorOpname}
                </span>
                {isApplied ? (
                  <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-emerald-950/70 border border-emerald-800/60 text-emerald-300 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> SUDAH DISESUAIKAN KE SISTEM
                  </span>
                ) : (
                  <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-amber-950/70 border border-amber-800/60 text-amber-300 animate-pulse">
                    ● DALAM PROSES HITUNG
                  </span>
                )}
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                Bandingkan stok sistem dengan stok fisik real di gudang, hitung selisih nominal, dan sesuaikan stok otomatis.
              </p>
            </div>
          </div>

          {/* Top Actions */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Warehouse Select */}
            <div className="flex items-center gap-1.5 bg-[#121214] px-3 py-1.5 rounded-xl border border-[#2B2B32]">
              <span className="text-[11px] font-bold text-neutral-400">Gudang:</span>
              <select
                value={selectedGudangId}
                onChange={(e) => setSelectedGudangId(e.target.value)}
                disabled={isApplied}
                className="bg-transparent text-xs font-bold text-[#F27D26] focus:outline-hidden cursor-pointer"
              >
                {warehouses.map((wh) => (
                  <option key={wh.GUDANG_ID} value={wh.GUDANG_ID} className="bg-[#161618] text-neutral-200">
                    {wh.NAMA_GUDANG}
                  </option>
                ))}
              </select>
            </div>

            {/* Scan Barcode Button */}
            <button
              type="button"
              onClick={() => setShowScanner(true)}
              className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-blue-600/20 transition-all cursor-pointer"
            >
              <Camera className="w-4 h-4" /> Scan Fisik (+1)
            </button>

            {/* Print Berita Acara Button */}
            <button
              type="button"
              onClick={() => setShowPrintModal(true)}
              className="px-3 py-2 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-200 hover:text-white border border-[#2B2B32] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" /> Cetak Berita Acara
            </button>

            {/* Batal / Reset Audit Button */}
            <button
              type="button"
              onClick={handleResetAudit}
              className="px-3.5 py-2 bg-[#1F1F24] hover:bg-[#2A2A32] text-neutral-300 hover:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 border border-[#2E2E38] transition-all cursor-pointer shrink-0"
              title="Batalkan audit dan reset input fisik ke 0"
            >
              <RotateCcw className="w-4 h-4" /> Reset ke 0
            </button>

            {/* Apply Adjustments Button */}
            <button
              type="button"
              onClick={handleApplyAdjustment}
              disabled={isApplied}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-all cursor-pointer ${
                isApplied
                  ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/25'
              }`}
            >
              <FileCheck className="w-4 h-4" />
              {isApplied ? 'Stok Telah Disesuaikan' : 'Terapkan Penyesuaian Stok'}
            </button>
          </div>
        </div>

        {/* Auditor & Catatan Input Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 pt-3 border-t border-[#24242A] text-xs">
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-1">
              Petugas / Auditor
            </label>
            <input
              type="text"
              value={auditor}
              onChange={(e) => setAuditor(e.target.value)}
              disabled={isApplied}
              placeholder="Nama auditor / admin"
              className="w-full p-2 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-lg text-neutral-200 focus:outline-hidden focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-1">
              Tanggal Pelaksanaan
            </label>
            <input
              type="date"
              value={tanggal}
              onChange={(e) => setTanggal(e.target.value)}
              disabled={isApplied}
              className="w-full p-2 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-lg text-neutral-200 focus:outline-hidden focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-1">
              Catatan / Lingkup Opname
            </label>
            <input
              type="text"
              value={catatanUmum}
              onChange={(e) => setCatatanUmum(e.target.value)}
              disabled={isApplied}
              placeholder="Contoh: Stok opname akhir bulan"
              className="w-full p-2 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-lg text-neutral-200 focus:outline-hidden focus:border-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Summary KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total SKU */}
        <div className="bg-[#161618] rounded-xl p-3 border border-[#26262B]">
          <span className="text-[10px] font-bold uppercase text-neutral-400 block">Total SKU</span>
          <span className="text-xl font-extrabold text-white block mt-0.5">{summaryMetrics.totalItems} SKU</span>
          <span className="text-[10px] text-neutral-500 block mt-0.5">Sistem: {summaryMetrics.totalSistemPcs} pcs</span>
        </div>

        {/* Fisik Total */}
        <div className="bg-[#161618] rounded-xl p-3 border border-[#26262B]">
          <span className="text-[10px] font-bold uppercase text-blue-400 block">Total Fisik</span>
          <span className="text-xl font-extrabold text-blue-400 block mt-0.5">{summaryMetrics.totalFisikPcs} pcs</span>
          <span className="text-[10px] text-neutral-500 block mt-0.5">Hasil hitung real</span>
        </div>

        {/* Sesuai (Match) */}
        <div className="bg-[#161618] rounded-xl p-3 border border-[#26262B]">
          <span className="text-[10px] font-bold uppercase text-emerald-400 block">Sesuai (Match)</span>
          <span className="text-xl font-extrabold text-emerald-400 block mt-0.5">{summaryMetrics.matchCount} SKU</span>
          <span className="text-[10px] text-emerald-500/80 block mt-0.5">Selisih 0 pcs</span>
        </div>

        {/* Selisih Kurang (Minus) */}
        <div className="bg-[#161618] rounded-xl p-3 border border-[#26262B]">
          <span className="text-[10px] font-bold uppercase text-rose-400 block">Minus / Kurang</span>
          <span className="text-xl font-extrabold text-rose-400 block mt-0.5">{summaryMetrics.minusCount} SKU</span>
          <span className="text-[10px] text-rose-500/80 block mt-0.5">Fisik &lt; Sistem</span>
        </div>

        {/* Selisih Lebih (Plus) */}
        <div className="bg-[#161618] rounded-xl p-3 border border-[#26262B]">
          <span className="text-[10px] font-bold uppercase text-cyan-400 block">Lebih / Plus</span>
          <span className="text-xl font-extrabold text-cyan-400 block mt-0.5">{summaryMetrics.plusCount} SKU</span>
          <span className="text-[10px] text-cyan-500/80 block mt-0.5">Fisik &gt; Sistem</span>
        </div>

        {/* Estimasi Nilai Selisih Nominal */}
        <div className="bg-[#161618] rounded-xl p-3 border border-[#26262B]">
          <span className="text-[10px] font-bold uppercase text-neutral-400 block">Nilai Selisih (HPP)</span>
          <span
            className={`text-base sm:text-lg font-extrabold font-mono block mt-0.5 truncate ${
              summaryMetrics.totalNilaiSelisihNominal === 0
                ? 'text-emerald-400'
                : summaryMetrics.totalNilaiSelisihNominal < 0
                ? 'text-rose-400'
                : 'text-cyan-400'
            }`}
          >
            {formatRupiah(summaryMetrics.totalNilaiSelisihNominal)}
          </span>
          <span className="text-[10px] text-neutral-500 block mt-0.5">
            Net: {summaryMetrics.totalSelisihPcs > 0 ? '+' : ''}
            {summaryMetrics.totalSelisihPcs} pcs
          </span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-[#161618] rounded-2xl border border-[#26262B] p-3.5 flex flex-wrap items-center justify-between gap-3 shadow-xs">
        {/* Left Filter Buttons */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-xs font-bold text-neutral-400 mr-1 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Filter:
          </span>
          {[
            { id: 'all' as const, label: `Semua (${summaryMetrics.totalItems})` },
            { id: 'variance' as const, label: `Ada Selisih (${summaryMetrics.varianceCount})` },
            { id: 'minus' as const, label: `Hanya Kurang (${summaryMetrics.minusCount})` },
            { id: 'plus' as const, label: `Hanya Lebih (${summaryMetrics.plusCount})` },
            { id: 'match' as const, label: `Sesuai (${summaryMetrics.matchCount})` },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setFilterVariance(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                filterVariance === tab.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-[#121214] text-neutral-400 hover:text-neutral-200 border border-[#2B2B32]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Right Search Field & Quick Reset */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari SKU, kaos, warna..."
              className="pl-8 pr-3 py-1.5 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-xl text-neutral-200 placeholder-neutral-500 focus:outline-hidden focus:border-blue-500 w-48 sm:w-56"
            />
          </div>

          {!isApplied && (
            <button
              type="button"
              onClick={handleResetAllToSystem}
              className="p-1.5 text-neutral-400 hover:text-neutral-200 bg-[#121214] hover:bg-[#1E1E22] border border-[#2B2B32] rounded-xl transition-colors cursor-pointer"
              title="Samakan seluruh hasil hitung fisik dengan stok sistem"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Main Stock Opname Table */}
      <div className="bg-[#161618] rounded-2xl border border-[#26262B] overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-xs min-w-[1000px]">
            <thead>
              <tr className="bg-[#121214] border-b border-[#24242A] text-neutral-400 uppercase tracking-wider text-[11px]">
                <th className="py-3 px-3 text-left font-bold w-12 min-w-[48px]">No</th>
                <th className="py-3 px-3 text-left font-bold min-w-[180px]">Produk / SKU ID</th>
                <th className="py-3 px-3 text-center font-bold min-w-[110px]">Warna</th>
                <th className="py-3 px-3 text-center font-bold min-w-[70px]">Ukuran</th>
                <th className="py-3 px-3 text-center font-bold min-w-[95px]">Stok Sistem</th>
                <th className="py-3 px-3 text-center font-bold min-w-[220px]">Stok Fisik Real (Default 0)</th>
                <th className="py-3 px-3 text-center font-bold min-w-[105px]">Selisih</th>
                <th className="py-3 px-3 text-right font-bold min-w-[95px]">Harga HPP</th>
                <th className="py-3 px-3 text-right font-bold min-w-[110px]">Nilai Selisih</th>
                <th className="py-3 px-3 text-left font-bold min-w-[150px]">Catatan / Alasan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#24242A]">
              {filteredOpnameItems.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-10 text-center text-neutral-500 italic">
                    Tidak ada item yang sesuai dengan filter atau kata kunci pencarian.
                  </td>
                </tr>
              ) : (
                filteredOpnameItems.map((item, idx) => {
                  const isScanned = lastScannedSku === item.SKU_ID;
                  const mutation = calculateItemMutation(item);
                  const isMatch = item.selisih === 0;
                  const isMinus = item.selisih < 0;
                  const isPlus = item.selisih > 0;

                  return (
                    <tr
                      key={item.SKU_ID}
                      className={`transition-colors ${
                        isScanned
                          ? 'bg-blue-950/40 ring-1 ring-blue-500'
                          : isMinus
                          ? 'hover:bg-rose-950/20'
                          : isPlus
                          ? 'hover:bg-cyan-950/20'
                          : 'hover:bg-[#1C1C20]'
                      }`}
                    >
                      {/* No */}
                      <td className="py-2.5 px-3 text-neutral-500 text-center font-mono">{idx + 1}</td>

                      {/* SKU & Name */}
                      <td className="py-2.5 px-3">
                        <div className="font-mono font-bold text-neutral-200 whitespace-nowrap">{item.SKU_ID}</div>
                        <div className="text-[11px] text-neutral-400 line-clamp-1">{item.namaProduk}</div>
                      </td>

                      {/* Warna */}
                      <td className="py-2.5 px-3 text-center whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <span
                            className="w-3 h-3 rounded-full border border-neutral-500/60 shrink-0"
                            style={{ backgroundColor: getWarnaHex(item.warna) }}
                          />
                          <span className="font-medium text-neutral-300">{item.warna}</span>
                        </div>
                      </td>

                      {/* Ukuran */}
                      <td className="py-2.5 px-3 text-center font-extrabold text-neutral-200">{item.ukuran}</td>

                      {/* Stok Sistem */}
                      <td className="py-2.5 px-3 text-center font-extrabold text-sm text-neutral-300 whitespace-nowrap">
                        {item.stokSistem} pcs
                      </td>

                      {/* Stok Fisik Real (Interactive control) */}
                      <td className="py-2.5 px-4 text-center">
                        <div className="flex flex-col items-center gap-1">
                          <div className="inline-flex items-center gap-1">
                            {!isApplied && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => handleQuickAdjust(item.SKU_ID, -5)}
                                  className="w-6 h-6 rounded bg-[#121214] hover:bg-[#202026] text-neutral-400 hover:text-white border border-[#2B2B32] text-[10px] font-bold flex items-center justify-center transition-colors cursor-pointer"
                                  title="Kurang 5"
                                >
                                  -5
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleQuickAdjust(item.SKU_ID, -1)}
                                  className="w-6 h-6 rounded bg-[#121214] hover:bg-[#202026] text-neutral-400 hover:text-white border border-[#2B2B32] text-xs font-bold flex items-center justify-center transition-colors cursor-pointer"
                                  title="Kurang 1"
                                >
                                  -
                                </button>
                              </>
                            )}

                            <input
                              type="number"
                              min="0"
                              value={item.stokFisik}
                              onChange={(e) =>
                                handleUpdatePhysicalStock(item.SKU_ID, parseInt(e.target.value) || 0)
                              }
                              disabled={isApplied}
                              className={`w-16 py-1 px-1.5 text-center text-xs font-mono font-black rounded-lg border focus:outline-hidden ${
                                isMatch
                                  ? 'bg-[#121214] text-neutral-200 border-[#2B2B32]'
                                  : isMinus
                                  ? 'bg-rose-950/40 text-rose-300 border-rose-800 focus:border-rose-500'
                                  : 'bg-cyan-950/40 text-cyan-300 border-cyan-800 focus:border-cyan-500'
                              }`}
                            />

                            {!isApplied && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => handleQuickAdjust(item.SKU_ID, 1)}
                                  className="w-6 h-6 rounded bg-[#121214] hover:bg-[#202026] text-neutral-400 hover:text-white border border-[#2B2B32] text-xs font-bold flex items-center justify-center transition-colors cursor-pointer"
                                  title="Tambah 1"
                                >
                                  +
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleQuickAdjust(item.SKU_ID, 5)}
                                  className="w-6 h-6 rounded bg-[#121214] hover:bg-[#202026] text-neutral-400 hover:text-white border border-[#2B2B32] text-[10px] font-bold flex items-center justify-center transition-colors cursor-pointer"
                                  title="Tambah 5"
                                >
                                  +5
                                </button>
                                {!isMatch && (
                                  <button
                                    type="button"
                                    onClick={() => handleResetItemToSystem(item.SKU_ID)}
                                    className="text-[10px] px-1.5 py-0.5 rounded bg-[#1E1E24] hover:bg-[#282832] text-neutral-400 hover:text-neutral-200 border border-[#2B2B32] ml-1 transition-colors cursor-pointer"
                                    title="Samakan dengan stok sistem"
                                  >
                                    Pas
                                  </button>
                                )}
                              </>
                            )}
                          </div>

                          {/* Status Hitung & Indikator Mutasi Esok Hari */}
                          <div className="flex flex-col items-center gap-0.5">
                            {!item.isCounted ? (
                              <span className="text-[9.5px] text-neutral-500 font-medium">
                                Belum dihitung (Default 0)
                              </span>
                            ) : (
                              <span className="text-[9.5px] text-emerald-400 font-bold flex items-center gap-0.5">
                                <Check className="w-2.5 h-2.5" /> Dihitung: {item.stokFisik} pcs
                              </span>
                            )}

                            {/* Mutasi Pasca-Hitung (Solusi SO Multi-Hari) */}
                            {mutation.hasMutation && (
                              <button
                                type="button"
                                onClick={() => setSelectedMutationDetail({ item, mutation })}
                                className="mt-0.5 px-2 py-0.5 rounded-full bg-amber-950/80 border border-amber-600/70 text-amber-300 hover:bg-amber-900 text-[9.5px] font-bold flex items-center gap-1 transition-all cursor-pointer shadow-xs animate-pulse hover:animate-none"
                                title="Klik untuk melihat rincian transaksi esok hari / pasca-hitung"
                              >
                                <Clock className="w-2.5 h-2.5 text-amber-400" />
                                <span>
                                  Mutasi: {mutation.mutasiPascaHitung > 0 ? '+' : ''}{mutation.mutasiPascaHitung} → Akhir: {mutation.reconciledFinalStock} pcs
                                </span>
                              </button>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Selisih Badge */}
                      <td className="py-2.5 px-4 text-center">
                        {isMatch ? (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/60 border border-emerald-800/50 text-emerald-400">
                            ✓ Sesuai (0)
                          </span>
                        ) : isMinus ? (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-950/70 border border-rose-800/60 text-rose-300">
                            ⚠ {item.selisih} pcs
                          </span>
                        ) : (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-cyan-950/70 border border-cyan-800/60 text-cyan-300">
                            ↑ +{item.selisih} pcs
                          </span>
                        )}

                        {mutation.hasMutation && (
                          <div className="mt-1">
                            <span className="inline-block text-[9px] font-bold px-1.5 py-0.5 rounded bg-blue-950/80 border border-blue-700/60 text-blue-300">
                              Akhir: {mutation.reconciledFinalStock - mutation.stokSistemTerkini > 0 ? '+' : ''}{mutation.reconciledFinalStock - mutation.stokSistemTerkini} pcs
                            </span>
                          </div>
                        )}
                      </td>

                      {/* Harga HPP */}
                      <td className="py-2.5 px-4 text-right font-mono text-neutral-400">
                        {formatRupiah(item.hargaHpp)}
                      </td>

                      {/* Nilai Selisih Nominal */}
                      <td className="py-2.5 px-4 text-right font-mono font-bold">
                        <span
                          className={
                            isMatch
                              ? 'text-neutral-500'
                              : isMinus
                              ? 'text-rose-400 font-extrabold'
                              : 'text-cyan-400 font-extrabold'
                          }
                        >
                          {item.nilaiSelisih > 0 ? '+' : ''}
                          {formatRupiah(item.nilaiSelisih)}
                        </span>
                      </td>

                      {/* Catatan / Alasan */}
                      <td className="py-2.5 px-4">
                        <input
                          type="text"
                          value={item.catatan || ''}
                          onChange={(e) =>
                            handleUpdatePhysicalStock(item.SKU_ID, item.stokFisik, e.target.value)
                          }
                          disabled={isApplied}
                          placeholder={!isMatch ? 'Alasan selisih...' : 'Catatan item (opsional)'}
                          className="w-full p-1 text-xs bg-[#0F0F10] border border-[#2B2B32] rounded-lg text-neutral-200 placeholder-neutral-600 focus:outline-hidden focus:border-blue-500"
                        />
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            <tfoot>
              <tr className="bg-[#121214] border-t-2 border-[#24242A] text-neutral-300 font-bold">
                <td colSpan={4} className="py-3 px-4 text-right uppercase text-xs">
                  TOTAL KESELURUHAN:
                </td>
                <td className="py-3 px-4 text-center font-extrabold text-sm text-neutral-100">
                  {summaryMetrics.totalSistemPcs} pcs
                </td>
                <td className="py-3 px-4 text-center font-extrabold text-sm text-blue-400">
                  {summaryMetrics.totalFisikPcs} pcs
                </td>
                <td className="py-3 px-4 text-center font-extrabold text-xs">
                  <span
                    className={
                      summaryMetrics.totalSelisihPcs === 0
                        ? 'text-emerald-400'
                        : summaryMetrics.totalSelisihPcs < 0
                        ? 'text-rose-400'
                        : 'text-cyan-400'
                    }
                  >
                    {summaryMetrics.totalSelisihPcs > 0 ? '+' : ''}
                    {summaryMetrics.totalSelisihPcs} pcs
                  </span>
                </td>
                <td></td>
                <td className="py-3 px-4 text-right font-mono font-black text-sm">
                  <span
                    className={
                      summaryMetrics.totalNilaiSelisihNominal === 0
                        ? 'text-emerald-400'
                        : summaryMetrics.totalNilaiSelisihNominal < 0
                        ? 'text-rose-400'
                        : 'text-cyan-400'
                    }
                  >
                    {formatRupiah(summaryMetrics.totalNilaiSelisihNominal)}
                  </span>
                </td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Barcode Scanner Modal for Opname Counting */}
      <BarcodeScannerModal
        isOpen={showScanner}
        onClose={() => setShowScanner(false)}
        onScan={handleBarcodeScanned}
        title="Pindai Fisik Barcode Kaos (Stok Opname)"
      />

      {/* Printable Berita Acara Modal */}
      {showPrintModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-1 sm:p-2 bg-black/85 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#161618] rounded-2xl shadow-2xl w-full max-w-[99vw] 2xl:max-w-[1850px] overflow-hidden border border-[#2A2A30] flex flex-col h-[97vh] text-[#E0E0E0]">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] text-white shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-600/30">
                  <Printer className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base sm:text-lg leading-tight">
                    Pratinjau Cetak: Berita Acara Stok Opname (BA-SO)
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Dokumen resmi hasil penghitungan fisik inventori dan penyesuaian nominal
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrintBA}
                  className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Printer className="w-4 h-4" /> Cetak / Unduh PDF
                </button>
                <button
                  type="button"
                  onClick={() => setShowPrintModal(false)}
                  className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Printable Document Body */}
            <div className="flex-1 bg-[#0D0D0F] p-4 sm:p-6 overflow-y-auto flex flex-col items-center">
              {printStatus && (
                <div className="mb-3 w-full max-w-5xl p-2.5 bg-blue-950/80 border border-blue-700 rounded-xl text-xs text-blue-200 flex items-center justify-between animate-in fade-in">
                  <div className="flex items-center gap-2">
                    <Info className="w-4 h-4 text-blue-400 shrink-0" />
                    <span>{printStatus}</span>
                  </div>
                  <button onClick={() => setPrintStatus(null)} className="text-blue-300 hover:text-white text-xs cursor-pointer">✕</button>
                </div>
              )}

              <div ref={printableRef} className="w-full max-w-6xl 2xl:max-w-7xl bg-white shadow-2xl rounded-xl overflow-hidden border border-slate-300 printable-document text-slate-900">
                {/* Header Kop dengan Logo Terintegrasi & Warna Kustom */}
                <div
                  className="printable-header-banner text-white p-6 flex items-start justify-between transition-colors duration-200"
                  style={{ backgroundColor: settings?.invoiceHeaderColor || '#1d4ed8' }}
                >
                  <div className="flex items-center gap-4">
                    {settings?.logoUrl ? (
                      <div className="w-16 h-16 bg-white rounded-xl p-1 shadow-md flex items-center justify-center shrink-0 overflow-hidden border border-white/30">
                        <img
                          src={settings.logoUrl}
                          alt="Logo Toko"
                          className="max-w-full max-h-full object-contain"
                        />
                      </div>
                    ) : null}
                    <div>
                      <h2 className="text-xl font-extrabold tracking-wide uppercase text-white">
                        {settings?.brandName || 'BERITA ACARA STOK OPNAME (BA-SO)'}
                      </h2>
                      <p className="text-xs text-blue-100 mt-0.5">
                        {settings?.companySubtitle || 'Laporan Hasil Audit Fisik & Rekonsiliasi Inventori'}
                      </p>
                      {settings?.companyAddress && (
                        <p className="text-[10px] text-blue-200 mt-1 max-w-lg leading-relaxed">
                          {settings.companyAddress}
                          {settings.companyPhone ? ` • Telp: ${settings.companyPhone}` : ''}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right text-xs space-y-1">
                    <div className="doc-header-badge inline-block bg-blue-950/70 border border-blue-300/40 px-3 py-1.5 rounded-lg text-right shadow-sm">
                      <span className="text-[10px] text-blue-100 block uppercase font-bold tracking-wider">BERITA ACARA OPNAME</span>
                      <span className="font-mono font-bold text-white text-sm">{nomorOpname}</span>
                    </div>
                    <div className="mt-1">
                      <span className="text-blue-100">Tanggal: </span>
                      <span className="font-semibold text-white">{tanggal}</span>
                    </div>
                  </div>
                </div>

                {/* Meta Details */}
                <div className="p-5 border-b border-slate-200 grid grid-cols-2 gap-4 text-xs bg-slate-50/50">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                      LOKASI GUDANG
                    </span>
                    <div className="font-bold text-sm text-slate-900">{currentWarehouseName}</div>
                    <div className="text-slate-600">Kode: {selectedGudangId}</div>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                      AUDITOR / PETUGAS OPNAME
                    </span>
                    <div className="font-bold text-sm text-slate-900">{auditor}</div>
                    <div className="text-slate-600">Status: {isApplied ? 'Telah Disesuaikan' : 'Proses Audit'}</div>
                  </div>
                  <div className="col-span-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                      CATATAN AUDIT
                    </span>
                    <div className="font-medium text-slate-800">{catatanUmum || '—'}</div>
                  </div>
                </div>

                {/* Table of Audited Products */}
                <div className="p-4 sm:p-6 overflow-x-auto">
                  <table className="w-full border-collapse text-xs min-w-[650px]">
                    <thead>
                      <tr className="bg-blue-50 border-b-2 border-blue-200 text-slate-700">
                        <th className="py-2.5 px-3 text-left font-bold w-10">No</th>
                        <th className="py-2.5 px-3 text-left font-bold">SKU ID</th>
                        <th className="py-2.5 px-3 text-left font-bold">Deskripsi Kaos</th>
                        <th className="py-2.5 px-3 text-center font-bold">Warna</th>
                        <th className="py-2.5 px-3 text-center font-bold">Size</th>
                        <th className="py-2.5 px-3 text-center font-bold">Sistem</th>
                        <th className="py-2.5 px-3 text-center font-bold">Fisik</th>
                        <th className="py-2.5 px-3 text-center font-bold">Selisih</th>
                        <th className="py-2.5 px-3 text-right font-bold">Nilai Selisih</th>
                        <th className="py-2.5 px-3 text-left font-bold">Keterangan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {opnameItems.map((item, i) => (
                        <tr key={item.SKU_ID} className={item.selisih !== 0 ? 'bg-amber-50/40' : 'hover:bg-slate-50'}>
                          <td className="py-2 px-3 text-slate-500">{i + 1}</td>
                          <td className="py-2 px-3 font-mono font-bold text-slate-800">{item.SKU_ID}</td>
                          <td className="py-2 px-3 font-semibold text-slate-900">{item.namaProduk}</td>
                          <td className="py-2 px-3 text-center text-slate-700">{item.warna}</td>
                          <td className="py-2 px-3 text-center font-bold text-slate-800">{item.ukuran}</td>
                          <td className="py-2 px-3 text-center text-slate-600">{item.stokSistem} pcs</td>
                          <td className="py-2 px-3 text-center font-extrabold text-blue-700">{item.stokFisik} pcs</td>
                          <td className="py-2 px-3 text-center font-bold">
                            {item.selisih === 0 ? (
                              <span className="text-emerald-700">0</span>
                            ) : item.selisih < 0 ? (
                              <span className="text-rose-700">{item.selisih} pcs</span>
                            ) : (
                              <span className="text-blue-700">+{item.selisih} pcs</span>
                            )}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold">
                            <span className={item.selisih === 0 ? 'text-slate-400' : item.selisih < 0 ? 'text-rose-700' : 'text-blue-700'}>
                              {item.nilaiSelisih > 0 ? '+' : ''}
                              {formatRupiah(item.nilaiSelisih)}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-slate-500">{item.catatan || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="bg-blue-50/70 border-t-2 border-blue-200 font-bold text-slate-700">
                        <td colSpan={5} className="py-3 px-3 text-right uppercase text-xs">
                          TOTAL REKONSILIASI:
                        </td>
                        <td className="py-3 px-3 text-center text-sm font-extrabold text-slate-700">
                          {summaryMetrics.totalSistemPcs} pcs
                        </td>
                        <td className="py-3 px-3 text-center text-sm font-extrabold text-blue-700">
                          {summaryMetrics.totalFisikPcs} pcs
                        </td>
                        <td className="py-3 px-3 text-center text-sm font-extrabold text-slate-900">
                          {summaryMetrics.totalSelisihPcs > 0 ? '+' : ''}
                          {summaryMetrics.totalSelisihPcs} pcs
                        </td>
                        <td className="py-3 px-3 text-right text-sm font-mono font-black text-slate-900">
                          {formatRupiah(summaryMetrics.totalNilaiSelisihNominal)}
                        </td>
                        <td></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                {/* 3 Signatures Approval Blocks */}
                <div className="p-6 border-t border-slate-200 grid grid-cols-3 gap-6 text-xs bg-slate-50/40">
                  <div className="text-center">
                    <span className="text-slate-600 block mb-1 font-medium">Petugas Opname (Auditor):</span>
                    <div className="w-full h-20 border border-dashed border-slate-300 rounded-lg bg-white flex items-center justify-center relative">
                      <span className="text-[10px] text-slate-400 italic">Tanda Tangan</span>
                    </div>
                    <span className="font-bold text-slate-900 mt-1 block border-t border-slate-300 pt-0.5 text-[11px]">
                      {auditor}
                    </span>
                    <span className="text-[9px] text-slate-500">Auditor Lapangan</span>
                  </div>

                  <div className="text-center">
                    <span className="text-slate-600 block mb-1 font-medium">Kepala Gudang:</span>
                    <div className="w-full h-20 border border-dashed border-slate-300 rounded-lg bg-white flex items-center justify-center relative">
                      <span className="text-[10px] text-slate-400 italic">Tanda Tangan</span>
                    </div>
                    <span className="font-bold text-slate-900 mt-1 block border-t border-slate-300 pt-0.5 text-[11px]">
                      ( .................................... )
                    </span>
                    <span className="text-[9px] text-slate-500">Penanggung Jawab Gudang</span>
                  </div>

                  <div className="text-center">
                    <span className="text-slate-600 block mb-1 font-medium">Supervisor / Manager:</span>
                    <div className="w-full h-20 border border-dashed border-slate-300 rounded-lg bg-white flex items-center justify-center relative">
                      <span className="text-[10px] text-slate-400 italic">Tanda Tangan & Cap</span>
                    </div>
                    <span className="font-bold text-slate-900 mt-1 block border-t border-slate-300 pt-0.5 text-[11px]">
                      ( .................................... )
                    </span>
                    <span className="text-[9px] text-slate-500">Manager Logistik</span>
                  </div>
                </div>
              </div>

              {/* Action Bar Cetak */}
              <div className="mt-4 mb-2 flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={handlePrintBA}
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-lg flex items-center gap-2 transition-all cursor-pointer hover:scale-102 active:scale-98"
                >
                  <Printer className="w-4 h-4" /> Cetak Dokumen BA-SO / Simpan PDF
                </button>
                <button
                  type="button"
                  onClick={handleOpenNewTabBA}
                  className="px-4 py-2.5 bg-[#1C1C22] hover:bg-[#282830] text-blue-300 hover:text-white text-xs font-bold rounded-xl border border-blue-900/60 flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" /> Buka Lembar Cetak
                </button>
                <button
                  type="button"
                  onClick={handleDownloadBA}
                  className="px-4 py-2.5 bg-[#1C1C22] hover:bg-[#282830] text-neutral-300 hover:text-white text-xs font-bold rounded-xl border border-[#2B2B32] flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <ArrowDownToLine className="w-3.5 h-3.5" /> Unduh Dokumen (HTML)
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 1. MODAL KONFIRMASI TERAPKAN PENYESUAIAN STOK */}
      {showApplyConfirmModal && (() => {
        const itemsWithAdjustments = opnameItems.map((item) => {
          const mutation = calculateItemMutation(item);
          const finalStock = item.isCounted ? mutation.reconciledFinalStock : item.stokSistem;
          const currentSystemStock = mutation.stokSistemTerkini;
          const diff = finalStock - currentSystemStock;
          return {
            item,
            finalStock,
            currentSystemStock,
            diff,
            mutation,
          };
        });
        const pendingAdjustments = itemsWithAdjustments.filter((i) => i.diff !== 0);
        const reconciledItems = itemsWithAdjustments.filter((i) => i.mutation.hasMutation);

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
            <div className="bg-[#161618] rounded-2xl shadow-2xl max-w-2xl w-full border border-[#2A2A30] flex flex-col max-h-[92vh] overflow-hidden text-neutral-200">
              {/* Header */}
              <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
                    <FileCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base sm:text-lg text-white">
                      Konfirmasi Penerapan Stok Opname
                    </h3>
                    <p className="text-xs text-neutral-400">
                      Gudang: <span className="text-white font-bold">{currentWarehouseName}</span> • Dokumen: <span className="font-mono text-blue-300 font-bold">{nomorOpname}</span>
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowApplyConfirmModal(false)}
                  className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Body */}
              <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs">
                {/* Summary Metrics Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="bg-[#101012] p-2.5 rounded-xl border border-[#24242A]">
                    <span className="text-[10px] text-neutral-400 block uppercase font-bold">Total SKU</span>
                    <span className="text-base font-extrabold text-white">{summaryMetrics.totalItems} SKU</span>
                  </div>
                  <div className="bg-[#101012] p-2.5 rounded-xl border border-[#24242A]">
                    <span className="text-[10px] text-emerald-400 block uppercase font-bold">Dihitung Fisik</span>
                    <span className="text-base font-extrabold text-emerald-400">{summaryMetrics.countedCount} SKU</span>
                  </div>
                  <div className="bg-[#101012] p-2.5 rounded-xl border border-[#24242A]">
                    <span className="text-[10px] text-amber-400 block uppercase font-bold">Akan Disesuaikan</span>
                    <span className="text-base font-extrabold text-amber-400">{pendingAdjustments.length} SKU</span>
                  </div>
                  <div className="bg-[#101012] p-2.5 rounded-xl border border-[#24242A]">
                    <span className="text-[10px] text-blue-400 block uppercase font-bold">Nilai Selisih HPP</span>
                    <span className="text-base font-extrabold text-blue-300 font-mono">
                      {formatRupiah(summaryMetrics.totalNilaiSelisihNominal)}
                    </span>
                  </div>
                </div>

                {/* Multi-Day Reconciliation Banner */}
                {reconciledItems.length > 0 && (
                  <div className="p-3.5 rounded-xl bg-blue-950/40 border border-blue-800/50 text-blue-200">
                    <div className="flex items-center gap-2 font-bold text-xs text-blue-300">
                      <Clock className="w-4 h-4 text-blue-400 shrink-0" />
                      <span>Rekonsiliasi Mutasi Multi-Hari Aktif ({reconciledItems.length} SKU)</span>
                    </div>
                    <p className="mt-1 text-[11px] leading-relaxed text-neutral-300">
                      Terdapat {reconciledItems.length} SKU yang mengalami transaksi berjalan (penjualan/pembelian) setelah hitungan fisik diambil. Sistem secara otomatis menyelaraskan stok akhir dengan mutasi tersebut sehingga transaksi esok harinya <strong className="text-white">TIDAK AKAN HILANG</strong>.
                    </p>
                  </div>
                )}

                {/* Items to Adjust List */}
                <div>
                  <h4 className="font-bold text-xs text-neutral-300 mb-2 flex items-center justify-between">
                    <span>Rincian SKU yang Akan Disesuaikan ({pendingAdjustments.length} SKU):</span>
                    {pendingAdjustments.length > 0 && (
                      <span className="text-[11px] text-neutral-400 font-normal">
                        Stok Sistem Baru akan disesuaikan otomatis
                      </span>
                    )}
                  </h4>

                  {pendingAdjustments.length === 0 ? (
                    <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-800/40 text-center text-emerald-300">
                      <CheckCircle2 className="w-6 h-6 mx-auto mb-1 text-emerald-400" />
                      <p className="font-bold">Semua stok fisik sesuai dengan stok sistem!</p>
                      <p className="text-[11px] text-neutral-400 mt-0.5">
                        Tidak ada selisih stok yang perlu diubah. Klik tombol di bawah untuk menyelesaikan sesi Berita Acara Opname.
                      </p>
                    </div>
                  ) : (
                    <div className="border border-[#26262B] rounded-xl overflow-x-auto max-h-56 overflow-y-auto">
                      <table className="w-full text-left text-[11px] min-w-[500px]">
                        <thead className="bg-[#121214] text-neutral-400 uppercase text-[10px] sticky top-0 border-b border-[#26262B]">
                          <tr>
                            <th className="py-2 px-3">SKU / Produk</th>
                            <th className="py-2 px-2 text-center">Sistem Saat Ini</th>
                            <th className="py-2 px-2 text-center">Fisik Hitung</th>
                            <th className="py-2 px-2 text-center">Stok Akhir Baru</th>
                            <th className="py-2 px-2 text-center">Selisih Net</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#24242A]">
                          {pendingAdjustments.map(({ item, finalStock, currentSystemStock, diff }) => (
                            <tr key={item.SKU_ID} className="hover:bg-[#1A1A1E]">
                              <td className="py-2 px-3">
                                <span className="font-mono font-bold text-neutral-200">{item.SKU_ID}</span>
                                <span className="text-[10px] text-neutral-400 block line-clamp-1">{item.namaProduk}</span>
                              </td>
                              <td className="py-2 px-2 text-center font-mono text-neutral-400">
                                {currentSystemStock} pcs
                              </td>
                              <td className="py-2 px-2 text-center font-mono font-bold text-blue-300">
                                {item.stokFisik} pcs
                              </td>
                              <td className="py-2 px-2 text-center font-mono font-black text-emerald-300">
                                {finalStock} pcs
                              </td>
                              <td className="py-2 px-2 text-center font-mono font-bold">
                                <span className={diff > 0 ? 'text-cyan-400' : 'text-rose-400'}>
                                  {diff > 0 ? `+${diff}` : diff} pcs
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Audit & Log Note */}
                <div className="p-3 rounded-xl bg-[#121214] border border-[#24242A] text-[11px] text-neutral-400 space-y-1">
                  <div className="flex items-center justify-between">
                    <span>Auditor / Penanggung Jawab:</span>
                    <span className="font-bold text-neutral-200">{auditor}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Tanggal Pelaksanaan:</span>
                    <span className="font-bold text-neutral-200">{tanggal}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Status Transaksi Log:</span>
                    <span className="text-emerald-400 font-bold">Otomatis dicatat ke Log Transaksi & Sinkron Cloud</span>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-4 border-t border-[#24242A] flex items-center justify-end gap-2.5 bg-[#121214] shrink-0">
                <button
                  type="button"
                  onClick={() => setShowApplyConfirmModal(false)}
                  className="px-4 py-2 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 hover:text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  Batal / Periksa Lagi
                </button>
                <button
                  type="button"
                  onClick={executeApplyAdjustment}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-600/25 flex items-center gap-1.5 cursor-pointer"
                >
                  <FileCheck className="w-4 h-4" />
                  Ya, Terapkan Sekarang ({pendingAdjustments.length} SKU)
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* 2. MODAL KONFIRMASI RESET SELURUH HITUNGAN KE 0 */}
      {showResetConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#161618] rounded-2xl shadow-2xl max-w-md w-full border border-[#2A2A30] p-5 text-neutral-200">
            <div className="w-11 h-11 rounded-xl bg-rose-600/20 text-rose-400 border border-rose-500/30 flex items-center justify-center mb-3.5">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-base text-white">Reset Seluruh Hitungan Fisik ke 0?</h3>
            <p className="text-xs text-neutral-400 mt-1.5 leading-relaxed">
              Seluruh kolom <strong className="text-white">Stok Fisik Real</strong> untuk gudang <strong className="text-white">{currentWarehouseName}</strong> akan dikembalikan ke nilai default <strong className="text-white">0 pcs</strong> dan draft hitungan saat ini akan dibersihkan.
            </p>
            <div className="flex items-center justify-end gap-2 mt-5">
              <button
                type="button"
                onClick={() => setShowResetConfirmModal(false)}
                className="px-4 py-2 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmResetAudit}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Ya, Reset ke 0
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. MODAL KONFIRMASI SAMAKAN SEMUA KE STOK SISTEM */}
      {showSyncAllConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#161618] rounded-2xl shadow-2xl max-w-md w-full border border-[#2A2A30] p-5 text-neutral-200">
            <div className="w-11 h-11 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center mb-3.5">
              <RotateCcw className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-base text-white">Samakan Fisik dengan Stok Sistem?</h3>
            <p className="text-xs text-neutral-400 mt-1.5 leading-relaxed">
              Tindakan ini akan mengisi seluruh kolom <strong className="text-white">Stok Fisik Real</strong> sama persis dengan angka Stok Sistem saat ini sehingga selisih menjadi 0 pcs.
            </p>
            <div className="flex items-center justify-end gap-2 mt-5">
              <button
                type="button"
                onClick={() => setShowSyncAllConfirmModal(false)}
                className="px-4 py-2 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmSyncAllToSystem}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" /> Ya, Samakan Semua
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. MODAL KONFIRMASI MULAI SESI BARU */}
      {showNewSessionConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#161618] rounded-2xl shadow-2xl max-w-md w-full border border-[#2A2A30] p-5 text-neutral-200">
            <div className="w-11 h-11 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center mb-3.5">
              <ClipboardCheck className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-base text-white">Mulai Sesi Stok Opname Baru?</h3>
            <p className="text-xs text-neutral-400 mt-1.5 leading-relaxed">
              Draft sesi opname saat ini (<strong className="text-blue-300 font-mono">{nomorOpname}</strong>) akan dihapus dan sesi baru akan dibuat dengan tanggal hari ini dan stok fisik default 0.
            </p>
            <div className="flex items-center justify-end gap-2 mt-5">
              <button
                type="button"
                onClick={() => setShowNewSessionConfirmModal(false)}
                className="px-4 py-2 bg-[#1C1C20] hover:bg-[#28282E] text-neutral-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleStartNewSession}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" /> Ya, Buat Sesi Baru
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. MODAL PANDUAN SOLUSI SO MULTI-HARI (JIKA ADA TRANSAKSI ESOK HARI) */}
      {showMultiDayInfoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#161618] rounded-2xl shadow-2xl max-w-2xl w-full border border-[#2A2A30] flex flex-col max-h-[92vh] overflow-hidden text-neutral-200">
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-[#24242A] flex items-center justify-between bg-[#121214] shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base sm:text-lg text-white">
                    Solusi Stok Opname Multi-Hari (Rolling Reconciliation)
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Mekanisme cerdas jika barang sudah dihitung hari ini, lalu esok harinya ada transaksi penjualan / barang masuk
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowMultiDayInfoModal(false)}
                className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Body */}
            <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs leading-relaxed">
              <div className="p-3.5 rounded-xl bg-blue-950/30 border border-blue-800/40 text-blue-200">
                <strong className="text-white font-bold block mb-1">
                  ❓ Masalah Nyata di Gudang:
                </strong>
                <span>
                  Penghitungan fisik ribuan barang butuh waktu 2–5 hari. Toko tidak bisa tutup total, sehingga di esok harinya tetap terjadi transaksi penjualan kasir atau penerimaan barang baru. Jika sistem menimpa stok secara manual, maka <strong>transaksi kemarin akan terhapus/hilang</strong> dan stok menjadi kacau.
                </span>
              </div>

              <div>
                <h4 className="font-bold text-sm text-white mb-2 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Mekanisme Solusi Cerdas Sistem Inventorika:
                </h4>

                <div className="space-y-3">
                  <div className="p-3 bg-[#121214] rounded-xl border border-[#26262B]">
                    <div className="font-bold text-neutral-200 flex items-center gap-2 text-xs">
                      <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-black">1</span>
                      Pencatatan Waktu (Timestamp) Akurat Per SKU
                    </div>
                    <p className="text-neutral-400 text-[11.5px] mt-1 pl-7">
                      Saat petugas menghitung fisik barang, sistem mencatat tanggal dan jam persis kapan hitungan fisik tersebut diambil.
                    </p>
                  </div>

                  <div className="p-3 bg-[#121214] rounded-xl border border-[#26262B]">
                    <div className="font-bold text-neutral-200 flex items-center gap-2 text-xs">
                      <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-black">2</span>
                      Pelacakan Mutasi Pasca-Hitung (Post-Count Mutations)
                    </div>
                    <p className="text-neutral-400 text-[11.5px] mt-1 pl-7">
                      Jika esok hari ada transaksi (Penjualan / Surat Jalan / Barang Masuk / Koreksi), sistem otomatis mendeteksi mutasi yang terjadi <em>setelah</em> jam hitung fisik tersebut.
                    </p>
                  </div>

                  <div className="p-3 bg-[#121214] rounded-xl border border-[#26262B]">
                    <div className="font-bold text-neutral-200 flex items-center gap-2 text-xs">
                      <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-black">3</span>
                      Formula Rekonsiliasi Otomatis (Anti Transaksi Hilang)
                    </div>
                    <div className="mt-2 pl-7">
                      <div className="p-2.5 bg-neutral-900 rounded-lg border border-neutral-700 font-mono text-[11px] text-emerald-300">
                        Stok Akhir = Stok Sistem Terkini + (Stok Fisik Hitung - Stok Sistem Saat Hitung)
                        <br />
                        <span className="text-neutral-400 text-[10.5px]">
                          (Setara dengan: Stok Fisik Dihitung + Mutasi Masuk - Mutasi Keluar Esok Hari)
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contoh Simulasi */}
              <div className="p-3.5 rounded-xl bg-amber-950/20 border border-amber-800/40 text-neutral-300">
                <strong className="text-amber-300 font-bold block mb-1.5 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  Simulasi Nyata:
                </strong>
                <ul className="space-y-1.5 text-[11.5px] list-disc list-inside">
                  <li>
                    <strong>Hari ke-1 (pk 15:00)</strong>: Kaos Hitam XL dihitung fisik = <span className="text-white font-bold">98 pcs</span> (Sistem saat itu = 100 pcs, berarti ada barang hilang 2 pcs).
                  </li>
                  <li>
                    <strong>Hari ke-2 (pk 10:00)</strong>: Terjadi transaksi penjualan kasir = <span className="text-rose-400 font-bold">10 pcs</span>. Stok sistem turun menjadi <span className="text-white font-bold">90 pcs</span>.
                  </li>
                  <li>
                    <strong>Hari ke-3 (Opname Diterapkan)</strong>: Sistem menerapkan stok akhir = <span className="text-emerald-400 font-extrabold">88 pcs</span> (bukan 98 pcs).
                  </li>
                  <li className="text-amber-200 font-medium">
                    🎯 <strong>Hasil</strong>: Penjualan 10 pcs hari ke-2 TETAP AMAN dan tercatat, dan selisih kehilangan 2 pcs tetap terkoreksi dengan presisi!
                  </li>
                </ul>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-[#24242A] flex items-center justify-end bg-[#121214] shrink-0">
              <button
                type="button"
                onClick={() => setShowMultiDayInfoModal(false)}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                Mengerti, Lanjutkan Opname
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. MODAL RINCIAN MUTASI PASCA-HITUNG PER SKU */}
      {selectedMutationDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#161618] rounded-2xl shadow-2xl max-w-lg w-full border border-[#2A2A30] p-5 text-neutral-200">
            <div className="flex items-center justify-between pb-3 border-b border-[#24242A]">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <h4 className="font-extrabold text-sm text-white">
                  Rincian Mutasi Pasca-Hitung ({selectedMutationDetail.item.SKU_ID})
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setSelectedMutationDetail(null)}
                className="w-7 h-7 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="py-3 text-xs space-y-2">
              <div className="grid grid-cols-2 gap-2 text-[11px] bg-[#121214] p-2.5 rounded-xl border border-[#24242A]">
                <div>
                  <span className="text-neutral-400 block">Waktu Dihitung:</span>
                  <span className="font-bold text-white">
                    {selectedMutationDetail.item.countedAt
                      ? new Date(selectedMutationDetail.item.countedAt).toLocaleString('id-ID')
                      : '-'}
                  </span>
                </div>
                <div>
                  <span className="text-neutral-400 block">Fisik Dihitung:</span>
                  <span className="font-bold text-blue-300">
                    {selectedMutationDetail.item.stokFisik} pcs
                  </span>
                </div>
                <div>
                  <span className="text-neutral-400 block">Net Mutasi:</span>
                  <span className="font-bold text-amber-400 font-mono">
                    {selectedMutationDetail.mutation.mutasiPascaHitung > 0 ? '+' : ''}
                    {selectedMutationDetail.mutation.mutasiPascaHitung} pcs
                  </span>
                </div>
                <div>
                  <span className="text-neutral-400 block">Stok Rekonsiliasi Akhir:</span>
                  <span className="font-bold text-emerald-300 font-mono">
                    {selectedMutationDetail.mutation.reconciledFinalStock} pcs
                  </span>
                </div>
              </div>

              <div className="mt-2">
                <span className="text-[11px] font-bold text-neutral-300 block mb-1">
                  Daftar Transaksi Setelah Hitungan Fisik ({selectedMutationDetail.mutation.relevantLogs?.length || 0}):
                </span>
                <div className="space-y-1.5 max-h-48 overflow-y-auto">
                  {selectedMutationDetail.mutation.relevantLogs && selectedMutationDetail.mutation.relevantLogs.length > 0 ? (
                    selectedMutationDetail.mutation.relevantLogs.map((lg) => (
                      <div
                        key={lg.TRANSAKSI_ID}
                        className="p-2 rounded-lg bg-[#0F0F10] border border-[#24242A] flex items-center justify-between text-[11px]"
                      >
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono font-bold text-neutral-300">{lg.TRANSAKSI_ID}</span>
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-neutral-800 text-neutral-300">
                              {lg.TIPE_TRANSAKSI}
                            </span>
                          </div>
                          <span className="text-[10px] text-neutral-500 block">
                            {new Date(lg.TIMESTAMP).toLocaleString('id-ID')} • {lg.USERS}
                          </span>
                        </div>
                        <div className="font-mono font-bold">
                          <span className={lg.JUMLAH > 0 ? 'text-emerald-400' : 'text-rose-400'}>
                            {lg.JUMLAH > 0 ? `+${lg.JUMLAH}` : lg.JUMLAH} pcs
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-neutral-500 italic text-[11px]">Belum ada log mutasi.</p>
                  )}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-[#24242A] flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedMutationDetail(null)}
                className="px-4 py-1.5 bg-[#1C1C20] hover:bg-[#28282E] text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
