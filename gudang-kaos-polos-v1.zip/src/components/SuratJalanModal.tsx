import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  InventoryItem,
  MasterGudang,
  MasterProduk,
  OrderItem,
  SignatureData,
  SuratJalanDocument,
  User,
  AppSystemSettings,
} from '../types';
import { DigitalSignatureModal } from './DigitalSignatureModal';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import {
  Truck,
  Plus,
  Trash2,
  Camera,
  PenTool,
  CheckCircle,
  Printer,
  X,
  ShieldCheck,
  AlertTriangle,
  DollarSign,
  Lock,
  Info,
  RotateCcw,
  Building2,
  Edit2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { formatRupiah, terbilangRupiah } from '../utils/formatters';
import { printElement } from '../utils/printHelper';

interface SuratJalanModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: MasterProduk[];
  inventory: InventoryItem[];
  warehouses?: MasterGudang[];
  currentUser: User;
  onSaveSuratJalan: (sj: SuratJalanDocument) => void;
  initialDoc?: SuratJalanDocument | null;
  settings?: AppSystemSettings;
}

export const SuratJalanModal: React.FC<SuratJalanModalProps> = ({
  isOpen,
  onClose,
  products,
  inventory,
  warehouses,
  currentUser,
  onSaveSuratJalan,
  initialDoc,
  settings,
}) => {
  const printableRef = useRef<HTMLDivElement>(null);
  const [printStatus, setPrintStatus] = useState<string | null>(null);

  // Cek otorisasi role: Hanya SUPERVISOR, SPV, OWNER, ADMIN, dan MANAGER yang berwenang mengubah form surat jalan
  const isSpvOrOwner =
    !currentUser ||
    currentUser?.role === 'SUPERVISOR' ||
    currentUser?.role === 'OWNER' ||
    (currentUser?.role as string) === 'SPV' ||
    currentUser?.role === 'ADMIN' ||
    currentUser?.role === 'MANAGER';

  // Cek apakah user berwenang memilih gudang asal (Owner, Supervisor, atau siteAccess mencakup SEMUA)
  const hasAllWarehouseAccess =
    currentUser?.siteAccess?.toUpperCase().includes('SEMUA') ||
    currentUser?.role === 'OWNER' ||
    currentUser?.role === 'SUPERVISOR';

  // Daftar gudang aktif yang valid
  const activeWarehouses = useMemo(() => {
    if (!warehouses || warehouses.length === 0) {
      return [
        { GUDANG_ID: 'GDG-01-ERVO', NAMA_GUDANG: 'GUDANG UTAMA', LOKASI: 'Pusat Distribusi Utama - Blok A', IS_ACTIVE: true, IS_DEFAULT: true },
        { GUDANG_ID: 'GDG-02-TOKO', NAMA_GUDANG: 'GUDANG TOKO', LOKASI: 'Outlet Ritel & Display - Lantai 1', IS_ACTIVE: true, IS_DEFAULT: false },
      ];
    }
    const filtered = warehouses.filter((w) => w.IS_ACTIVE !== false);
    return filtered.length > 0 ? filtered : warehouses;
  }, [warehouses]);

  const getDefaultGudangId = () => {
    if (initialDoc?.gudangId) return initialDoc.gudangId;
    if (currentUser?.siteAccess?.includes('TOKO')) return 'GDG-02-TOKO';
    if (currentUser?.siteAccess?.includes('UTAMA') || currentUser?.siteAccess?.includes('ERVO')) return 'GDG-01-ERVO';
    const def = activeWarehouses.find((w) => w.IS_DEFAULT);
    return def ? def.GUDANG_ID : activeWarehouses[0]?.GUDANG_ID || 'GDG-01-ERVO';
  };

  const [selectedGudangId, setSelectedGudangId] = useState<string>(getDefaultGudangId);
  const [nomorSJ, setNomorSJ] = useState('');
  const [tanggal, setTanggal] = useState('');
  const [tujuan, setTujuan] = useState('');
  const [penerima, setPenerima] = useState('');
  const [driver, setDriver] = useState('');
  const [kendaraan, setKendaraan] = useState('');
  const [catatan, setCatatan] = useState('');
  const [tampilkanNominal, setTampilkanNominal] = useState<boolean>(true);
  const [items, setItems] = useState<OrderItem[]>([]);

  // 3 Digital Signatures
  const [sigPengirim, setSigPengirim] = useState<SignatureData | undefined>(undefined);
  const [sigDriver, setSigDriver] = useState<SignatureData | undefined>(undefined);
  const [sigPenerima, setSigPenerima] = useState<SignatureData | undefined>(undefined);
  const [activeSigRole, setActiveSigRole] = useState<'pengirim' | 'driver' | 'penerima' | null>(null);

  // Barcode scanner
  const [scannerTargetRowId, setScannerTargetRowId] = useState<string | null>(null);
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [stockErrors, setStockErrors] = useState<string[]>([]);

  useEffect(() => {
    if (isOpen) {
      if (initialDoc) {
        setNomorSJ(initialDoc.nomorSJ);
        setTanggal(initialDoc.tanggal);
        if (initialDoc.gudangId) {
          setSelectedGudangId(initialDoc.gudangId);
        }
        setTujuan(initialDoc.tujuan);
        setPenerima(initialDoc.penerima || '');
        setDriver(initialDoc.driver || '');
        setKendaraan(initialDoc.kendaraan || '');
        setCatatan(initialDoc.catatan || '');
        setTampilkanNominal(initialDoc.tampilkanNominal ?? true);
        setItems(initialDoc.items || []);
        setSigPengirim(initialDoc.signaturePengirim);
        setSigDriver(initialDoc.signatureDriver);
        setSigPenerima(initialDoc.signaturePenerima);
        setIsSaved(false);
        setStockErrors([]);
        setPrintStatus(null);
        return;
      }

      const now = new Date();
      const pad = (n: number) => String(n).padStart(2, '0');
      const dateStr = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`;
      const randomSeq = String(Math.floor(1000 + Math.random() * 9000));
      setNomorSJ(`SJ-${dateStr}-${randomSeq}`);
      setTanggal(`${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`);
      setSelectedGudangId(getDefaultGudangId());
      setTujuan('');
      setPenerima('');
      setDriver('');
      setKendaraan('');
      setCatatan('');
      setTampilkanNominal(true);
      setSigPengirim(undefined);
      setSigDriver(undefined);
      setSigPenerima(undefined);
      setIsSaved(false);
      setStockErrors([]);
      setPrintStatus(null);
      setItems([
        {
          id: 'item-1',
          SKU_ID: '',
          jumlah: 1,
          hargaSatuan: 0,
          subtotal: 0,
          keterangan: '',
        },
      ]);
    }
  }, [isOpen, products, currentUser, initialDoc, warehouses]);

  // Handler Batal: Kembalikan seluruh form surat jalan ke default kosong bersih
  const handleResetForm = () => {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const dateStr = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`;
    const randomSeq = String(Math.floor(1000 + Math.random() * 9000));
    setNomorSJ(`SJ-${dateStr}-${randomSeq}`);
    setTanggal(`${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`);
    setSelectedGudangId(getDefaultGudangId());
    setTujuan('');
    setPenerima('');
    setDriver('');
    setKendaraan('');
    setCatatan('');
    setTampilkanNominal(true);
    setSigPengirim(undefined);
    setSigDriver(undefined);
    setSigPenerima(undefined);
    setIsSaved(false);
    setStockErrors([]);
    setPrintStatus(null);
    setItems([
      {
        id: `item-${Date.now()}`,
        SKU_ID: '',
        jumlah: 1,
        hargaSatuan: 0,
        subtotal: 0,
        keterangan: '',
      },
    ]);
  };

  const getAvailableStock = (skuId: string) => {
    if (!skuId) return 0;
    const inv = inventory.find((i) => i.GUDANG_ID === selectedGudangId && i.SKU_ID === skuId);
    return inv ? inv.JUMLAH_READY : 0;
  };

  const addItem = () => {
    if (!isSpvOrOwner) return;
    setIsSaved(false);
    setItems((prev) => [
      ...prev,
      {
        id: `item-${Date.now()}`,
        SKU_ID: '',
        jumlah: 1,
        hargaSatuan: 0,
        subtotal: 0,
        keterangan: '',
      },
    ]);
  };

  const removeItem = (id: string) => {
    if (!isSpvOrOwner || items.length <= 1) return;
    setIsSaved(false);
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  const updateItem = (id: string, updates: Partial<OrderItem>) => {
    if (!isSpvOrOwner) return;
    setIsSaved(false);
    setItems((prev) =>
      prev.map((i) => {
        if (i.id !== id) return i;
        const updated = { ...i, ...updates };
        if (updates.SKU_ID !== undefined && updates.SKU_ID !== i.SKU_ID) {
          const matchedProd = products.find((p) => p.SKU_ID === updates.SKU_ID);
          updated.hargaSatuan = matchedProd?.HARGA_JUAL || matchedProd?.HARGA_HPP || 0;
        }
        const qty = Number(updated.jumlah) || 0;
        const price = Number(updated.hargaSatuan) || 0;
        updated.subtotal = qty * price;
        return updated;
      })
    );
  };

  const handleBarcodeScanned = (decodedText: string) => {
    if (!isSpvOrOwner) return;
    const match = products.find(
      (p) =>
        p.SKU_ID.toUpperCase() === decodedText.toUpperCase() ||
        (p.BARCODE_ID && p.BARCODE_ID.toUpperCase() === decodedText.toUpperCase())
    );

    if (match && scannerTargetRowId) {
      updateItem(scannerTargetRowId, {
        SKU_ID: match.SKU_ID,
        hargaSatuan: match.HARGA_JUAL || match.HARGA_HPP || 45000,
      });
    } else if (match) {
      const price = match.HARGA_JUAL || match.HARGA_HPP || 45000;
      const qty = 10;
      setItems((prev) => [
        ...prev,
        {
          id: `item-${Date.now()}`,
          SKU_ID: match.SKU_ID,
          jumlah: qty,
          hargaSatuan: price,
          subtotal: qty * price,
          keterangan: 'Hasil Scan Barcode',
        },
      ]);
    } else {
      alert(`Produk dengan barcode/SKU "${decodedText}" tidak ditemukan dalam Master Produk.`);
    }
    setScannerTargetRowId(null);
  };

  const totalQty = items.reduce((sum, item) => sum + (Number(item.jumlah) || 0), 0);
  const totalNominal = items.reduce(
    (sum, item) => sum + (item.subtotal !== undefined ? item.subtotal : (Number(item.jumlah) || 0) * (Number(item.hargaSatuan) || 0)),
    0
  );

  const handleSave = () => {
    if (!isSpvOrOwner) {
      alert('Akses Ditolak: Hanya user SPV dan Owner yang berwenang menyimpan surat jalan.');
      return;
    }

    if (!tujuan.trim()) {
      alert('Tujuan pengiriman wajib diisi.');
      return;
    }

    const errors: string[] = [];
    const validItems: OrderItem[] = [];

    items.forEach((item) => {
      if (!item.SKU_ID || Number(item.jumlah) <= 0) return;
      const stock = getAvailableStock(item.SKU_ID);
      if (stock < Number(item.jumlah)) {
        errors.push(`Stok tidak cukup untuk SKU "${item.SKU_ID}". Tersedia: ${stock} pcs, diminta kirim: ${item.jumlah} pcs.`);
      } else {
        const qty = Number(item.jumlah) || 0;
        const price = Number(item.hargaSatuan) || 0;
        validItems.push({
          ...item,
          jumlah: qty,
          hargaSatuan: price,
          subtotal: qty * price,
        });
      }
    });

    if (errors.length > 0) {
      setStockErrors(errors);
      alert('Gagal membuat Surat Jalan: Stok gudang tidak mencukupi untuk beberapa barang. Silakan periksa daftar kesalahan.');
      return;
    }

    if (validItems.length === 0) {
      alert('Minimal satu barang harus memiliki SKU dan jumlah yang valid.');
      return;
    }

    setStockErrors([]);

    const selectedWarehouse = activeWarehouses.find((w) => w.GUDANG_ID === selectedGudangId);

    const doc: SuratJalanDocument = {
      nomorSJ,
      tanggal,
      gudangId: selectedGudangId,
      gudangNama: selectedWarehouse?.NAMA_GUDANG || currentUser.siteAccess,
      username: currentUser.username,
      tujuan,
      penerima,
      driver,
      kendaraan,
      catatan,
      tampilkanNominal,
      totalNominal,
      items: validItems,
      signaturePengirim: sigPengirim,
      signatureDriver: sigDriver,
      signaturePenerima: sigPenerima,
      createdAt: new Date().toISOString(),
    };

    onSaveSuratJalan(doc);
    setIsSaved(true);

    try {
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    } catch {
      // ignore
    }
  };

  const handlePrint = () => {
    if (!printableRef.current) return;
    printElement(
      printableRef.current,
      {
        title: `Surat Jalan Pengiriman - ${nomorSJ}`,
        filename: `SuratJalan_${nomorSJ}`,
      },
      (msg) => {
        setPrintStatus(msg);
        setTimeout(() => setPrintStatus(null), 5000);
      }
    );
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-1 sm:p-2 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
        <div className="bg-[#161618] rounded-2xl shadow-2xl w-full max-w-[99vw] 2xl:max-w-[1850px] overflow-hidden border border-[#2A2A30] flex flex-col h-[97vh] text-[#E0E0E0]">
          {/* Header Modal */}
          <div className="p-3.5 sm:p-4 border-b border-[#24242A] flex items-center justify-between bg-[#121214] text-white shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow-md shadow-rose-600/30">
                <Truck className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm sm:text-base leading-tight text-white flex items-center gap-2">
                  Form Surat Jalan Barang (Pengiriman Gudang)
                  <span className="font-mono text-xs font-bold text-rose-400 bg-rose-950/60 border border-rose-800/50 px-2 py-0.5 rounded-full">
                    {nomorSJ}
                  </span>
                  {!isSpvOrOwner && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-950/70 border border-amber-800/60 text-amber-300 flex items-center gap-1">
                      <Lock className="w-3 h-3 text-amber-400" /> Read Only (SPV/Owner Only)
                    </span>
                  )}
                </h3>
                <p className="text-[11px] text-neutral-400">Otomatis mengurangi stok gudang dan mengesahkan tanda tangan 3 pihak</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-[#1C1C20] hover:bg-[#28282E] text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-[#2B2B32] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body Content */}
          <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
            {/* Left: Form Controls (Lebar Diperluas Agar Kolom Input & Dropdown Nyaman & Optimal) */}
            <div className="w-full lg:w-[420px] xl:w-[480px] 2xl:w-[520px] bg-[#121214] border-r border-[#24242A] p-3 sm:p-4 overflow-y-auto space-y-3 shrink-0">
              {/* Otorisasi Read-Only Banner */}
              {!isSpvOrOwner && (
                <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-800/60 text-amber-300 text-xs flex items-start gap-2 shadow-xs">
                  <Lock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-amber-200 text-[11px] flex items-center gap-1">
                      Mode Baca Saja (Terkunci)
                    </div>
                    <div className="text-[10px] text-amber-300/80 leading-tight mt-0.5">
                      Kolom input ini terkunci untuk akun <strong>{currentUser.username}</strong> ({currentUser.role}). Hanya user <strong>SPV</strong> dan <strong>Owner</strong> yang berwenang mengubah rincian surat jalan.
                    </div>
                  </div>
                </div>
              )}

              {/* Alert notice about automatic stock reduction */}
              <div className="bg-amber-950/30 border border-amber-800/40 rounded-xl p-2 flex items-start gap-2 text-[11px] text-amber-300 leading-snug">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  Saat dokumen disimpan, stok di <strong>{activeWarehouses.find((w) => w.GUDANG_ID === selectedGudangId)?.NAMA_GUDANG || selectedGudangId}</strong> otomatis terpotong.
                </span>
              </div>

              {stockErrors.length > 0 && (
                <div className="bg-rose-950/40 border border-rose-800/50 rounded-xl p-2.5 text-xs text-rose-300 space-y-1">
                  <div className="font-bold flex items-center gap-1.5 text-rose-200">
                    <X className="w-4 h-4" /> Kendala Stok:
                  </div>
                  {stockErrors.map((err, i) => (
                    <div key={i}>• {err}</div>
                  ))}
                </div>
              )}

              {/* Delivery Meta Fields */}
              <div className="space-y-2 bg-[#161618] p-2.5 rounded-xl border border-[#26262B] shadow-xs">
                {/* Pilihan Gudang Asal Pengiriman */}
                <div className="bg-[#111114] p-2.5 rounded-xl border border-[#26262B] space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-rose-400" />
                      Gudang Asal Pengirim *
                    </label>
                    {hasAllWarehouseAccess ? (
                      <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-rose-950/70 border border-rose-800/60 text-rose-300">
                        Multi-Gudang
                      </span>
                    ) : (
                      <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-neutral-800 border border-neutral-700 text-neutral-400 flex items-center gap-0.5">
                        <Lock className="w-2.5 h-2.5" /> Terkunci
                      </span>
                    )}
                  </div>

                  {hasAllWarehouseAccess && !initialDoc ? (
                    <select
                      value={selectedGudangId}
                      disabled={!isSpvOrOwner}
                      onChange={(e) => {
                        setSelectedGudangId(e.target.value);
                        setStockErrors([]);
                      }}
                      className="w-full p-2 text-xs font-bold bg-[#0D0D10] border border-rose-900/50 rounded-lg text-rose-200 focus:border-rose-500 focus:outline-hidden cursor-pointer"
                    >
                      {activeWarehouses.map((wh) => (
                        <option key={wh.GUDANG_ID} value={wh.GUDANG_ID} className="bg-[#161618] text-neutral-200">
                          {wh.NAMA_GUDANG} ({wh.GUDANG_ID}) {wh.LOKASI ? `— ${wh.LOKASI}` : ''}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div className="p-2 bg-[#0D0D10] border border-[#26262E] rounded-lg flex items-center justify-between text-xs">
                      <span className="font-bold text-neutral-200">
                        {activeWarehouses.find((w) => w.GUDANG_ID === selectedGudangId)?.NAMA_GUDANG || selectedGudangId}
                      </span>
                      <span className="text-[10px] font-mono text-rose-400">{selectedGudangId}</span>
                    </div>
                  )}
                  <p className="text-[9.5px] text-neutral-400 leading-tight">
                    Stok barang yang dikirim akan dipotong langsung dari unit gudang asal ini.
                  </p>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">Nomor SJ</label>
                  <input
                    type="text"
                    value={nomorSJ}
                    readOnly
                    className="w-full p-1.5 text-xs font-mono font-bold bg-[#0F0F10] border border-[#2B2B32] rounded-lg text-rose-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">Tanggal Kirim</label>
                  <input
                    type="date"
                    value={tanggal}
                    readOnly={!isSpvOrOwner}
                    onChange={(e) => setTanggal(e.target.value)}
                    className={`w-full p-1.5 text-xs rounded-lg ${
                      isSpvOrOwner
                        ? 'bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 focus:outline-hidden focus:border-rose-500'
                        : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed select-none'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">Tujuan Pengiriman *</label>
                  <input
                    type="text"
                    value={tujuan}
                    readOnly={!isSpvOrOwner}
                    onChange={(e) => setTujuan(e.target.value)}
                    placeholder="Nama toko / cabang"
                    className={`w-full p-1.5 text-xs rounded-lg ${
                      isSpvOrOwner
                        ? 'bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 placeholder-neutral-600 focus:border-rose-500 focus:outline-hidden'
                        : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed select-none'
                    }`}
                  />
                </div>

                <div className="grid grid-cols-2 gap-1.5">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">Penerima</label>
                    <input
                      type="text"
                      value={penerima}
                      readOnly={!isSpvOrOwner}
                      onChange={(e) => setPenerima(e.target.value)}
                      placeholder="Nama PIC"
                      className={`w-full p-1.5 text-xs rounded-lg ${
                        isSpvOrOwner
                          ? 'bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 placeholder-neutral-600 focus:border-rose-500 focus:outline-hidden'
                          : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed select-none'
                      }`}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">Driver</label>
                    <input
                      type="text"
                      value={driver}
                      readOnly={!isSpvOrOwner}
                      onChange={(e) => setDriver(e.target.value)}
                      placeholder="Pengantar"
                      className={`w-full p-1.5 text-xs rounded-lg ${
                        isSpvOrOwner
                          ? 'bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 placeholder-neutral-600 focus:border-rose-500 focus:outline-hidden'
                          : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed select-none'
                      }`}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-1.5">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">Nopol Mobil</label>
                    <input
                      type="text"
                      value={kendaraan}
                      readOnly={!isSpvOrOwner}
                      onChange={(e) => setKendaraan(e.target.value)}
                      placeholder="B 1234 ABC"
                      className={`w-full p-1.5 text-xs rounded-lg ${
                        isSpvOrOwner
                          ? 'bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 placeholder-neutral-600 focus:border-rose-500 focus:outline-hidden'
                          : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed select-none'
                      }`}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-0.5">Catatan</label>
                    <input
                      type="text"
                      value={catatan}
                      readOnly={!isSpvOrOwner}
                      onChange={(e) => setCatatan(e.target.value)}
                      placeholder="Pengiriman"
                      className={`w-full p-1.5 text-xs rounded-lg ${
                        isSpvOrOwner
                          ? 'bg-[#0F0F10] border border-[#2B2B32] text-neutral-100 placeholder-neutral-600 focus:border-rose-500 focus:outline-hidden'
                          : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed select-none'
                      }`}
                    />
                  </div>
                </div>
              </div>

              {/* Toggle Nominal */}
              <div className="bg-[#161618] p-2 rounded-xl border border-[#26262B] flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-rose-400" />
                  <span className="text-[11px] font-bold text-neutral-200">Sertakan Nominal Rp</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={tampilkanNominal}
                    disabled={!isSpvOrOwner}
                    onChange={(e) => setTampilkanNominal(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4 bg-[#2B2B32] peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-rose-600"></div>
                </label>
              </div>

              {/* Items Section */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-300">
                    Daftar Item ({items.length})
                  </span>
                  {isSpvOrOwner && (
                    <button
                      type="button"
                      onClick={addItem}
                      className="px-2 py-0.5 bg-rose-950/70 hover:bg-rose-900 border border-rose-800/80 text-rose-300 text-[10px] font-bold rounded-md flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Plus className="w-3 h-3" /> Tambah
                    </button>
                  )}
                </div>

                <div className="space-y-2 max-h-56 overflow-y-auto pr-0.5">
                  {items.map((item, idx) => {
                    const stock = getAvailableStock(item.SKU_ID);
                    const isInsufficient = stock < Number(item.jumlah);
                    const prod = products.find((p) => p.SKU_ID === item.SKU_ID);

                    return (
                      <div
                        key={item.id}
                        className={`p-2 rounded-xl space-y-1.5 border shadow-xs transition-all ${
                          isInsufficient ? 'bg-rose-950/30 border-rose-800/80' : 'bg-[#161618] border-[#26262B]'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                            <span className="text-[10px] font-bold text-neutral-200">#{idx + 1}</span>
                            {prod?.WARNA && (
                              <span className="text-[9px] text-neutral-400 truncate max-w-[120px]">
                                · {prod.WARNA} {prod.UKURAN}
                              </span>
                            )}
                          </div>
                          {isSpvOrOwner && (
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => setScannerTargetRowId(item.id)}
                                className="p-1 text-neutral-400 hover:text-rose-400 bg-[#1E1E24] hover:bg-[#282830] rounded transition-colors border border-[#2B2B32] cursor-pointer"
                                title="Pindai Barcode"
                              >
                                <Camera className="w-3 h-3" />
                              </button>
                              {items.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => removeItem(item.id)}
                                  className="p-1 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded transition-colors cursor-pointer"
                                  title="Hapus baris"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          )}
                        </div>

                        {/* SKU Selector */}
                        <select
                          value={item.SKU_ID}
                          disabled={!isSpvOrOwner}
                          onChange={(e) => updateItem(item.id, { SKU_ID: e.target.value })}
                          className={`w-full p-1.5 text-[11px] rounded-lg font-mono ${
                            isSpvOrOwner
                              ? 'bg-[#0D0D10] border border-[#26262E] text-neutral-200 focus:border-rose-500 focus:outline-hidden'
                              : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed'
                          }`}
                        >
                          <option value="">-- Pilih SKU Kaos --</option>
                          {products.map((p) => (
                            <option key={p.SKU_ID} value={p.SKU_ID}>
                              {p.SKU_ID} ({p.WARNA} {p.UKURAN})
                            </option>
                          ))}
                        </select>

                        {/* Stock status */}
                        <div className="flex items-center justify-between text-[10px] px-0.5">
                          <span className="text-neutral-500">Stok Ready:</span>
                          <span className={`font-bold ${!item.SKU_ID ? 'text-neutral-500' : stock < 10 ? 'text-rose-400' : 'text-emerald-400'}`}>
                            {item.SKU_ID ? `${stock} pcs ${stock < Number(item.jumlah) ? '⚠️ Kurang!' : ''}` : '-'}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-1.5">
                          <div>
                            <label className="block text-[9px] text-neutral-400 font-semibold mb-0.5">Qty Kirim</label>
                            <input
                              type="number"
                              min="1"
                              value={item.jumlah}
                              readOnly={!isSpvOrOwner}
                              onChange={(e) => updateItem(item.id, { jumlah: parseInt(e.target.value) || 0 })}
                              className={`w-full p-1 text-xs font-bold rounded-lg text-center ${
                                isSpvOrOwner
                                  ? 'bg-[#0D0D10] border border-[#26262E] text-neutral-100 focus:outline-hidden focus:border-rose-500'
                                  : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed'
                              }`}
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] text-neutral-400 font-semibold mb-0.5">Ket/Koli</label>
                            <input
                              type="text"
                              value={item.keterangan || ''}
                              readOnly={!isSpvOrOwner}
                              onChange={(e) => updateItem(item.id, { keterangan: e.target.value })}
                              placeholder="Koli / Box"
                              className={`w-full p-1 text-xs rounded-lg ${
                                isSpvOrOwner
                                  ? 'bg-[#0D0D10] border border-[#26262E] text-neutral-200 placeholder-neutral-600 focus:outline-hidden focus:border-rose-500'
                                  : 'bg-[#141418] border border-amber-900/40 text-neutral-400 cursor-not-allowed'
                              }`}
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 3 Signatures Box */}
              <div className="bg-[#161618] p-2 rounded-xl border border-[#26262B] space-y-1.5 shadow-xs">
                <div className="flex items-center justify-between">
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                    Tanda Tangan 3 Pihak
                  </span>
                  {settings?.useStampAsSignature && settings?.stampUrl && (
                    <span className="text-[9px] font-bold text-rose-300 bg-rose-950/60 px-1.5 py-0.2 rounded border border-rose-800/60 flex items-center gap-0.5">
                      <ShieldCheck className="w-2.5 h-2.5" /> Stempel Toko Aktif
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-1.5">
                  <div className="p-1.5 rounded-lg bg-[#111114] border border-[#26262E] text-center flex flex-col justify-between">
                    <div>
                      <div className="text-[8px] font-bold text-neutral-400 uppercase">Pengirim</div>
                      <div className="text-[9px] font-bold truncate mt-0.5">
                        {sigPengirim ? (
                          <span className="text-emerald-400 font-bold">{sigPengirim.name}</span>
                        ) : settings?.useStampAsSignature && settings?.stampUrl ? (
                          <span className="text-purple-300 font-bold text-[8px]">Stempel Toko</span>
                        ) : (
                          <span className="text-neutral-500 italic text-[8.5px]">Belum TTD</span>
                        )}
                      </div>
                    </div>
                    {isSpvOrOwner && (
                      <div className="flex items-center gap-1 mt-1">
                        <button
                          type="button"
                          onClick={() => setActiveSigRole('pengirim')}
                          className="flex-1 py-0.5 text-[8px] font-bold text-rose-300 hover:bg-rose-950/60 border border-rose-800/80 rounded transition-colors cursor-pointer"
                        >
                          {sigPengirim ? 'Ubah' : 'TTD'}
                        </button>
                        {settings?.stampUrl && !sigPengirim && (
                          <button
                            type="button"
                            onClick={() => {
                              setSigPengirim({
                                name: settings.brandName || currentUser.username,
                                roleTitle: 'Pengirim (Stempel Toko)',
                                imageDataUrl: settings.stampUrl!,
                                signedAt: new Date().toISOString(),
                              });
                            }}
                            className="py-0.5 px-1 text-[8px] font-bold text-purple-300 hover:bg-purple-950/60 border border-purple-800/80 rounded transition-colors cursor-pointer"
                            title="Terapkan Stempel Resmi Toko"
                          >
                            Cap
                          </button>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="p-1.5 rounded-lg bg-[#111114] border border-[#26262E] text-center flex flex-col justify-between">
                    <div>
                      <div className="text-[8px] font-bold text-neutral-400 uppercase">Driver</div>
                      <div className="text-[9px] font-bold truncate mt-0.5">
                        {sigDriver ? (
                          <span className="text-emerald-400 font-bold">{sigDriver.name}</span>
                        ) : (
                          <span className="text-neutral-500 italic text-[8.5px]">Belum TTD</span>
                        )}
                      </div>
                    </div>
                    {isSpvOrOwner && (
                      <button
                        type="button"
                        onClick={() => setActiveSigRole('driver')}
                        className="mt-1 w-full py-0.5 text-[8px] font-bold text-rose-300 hover:bg-rose-950/60 border border-rose-800/80 rounded transition-colors cursor-pointer"
                      >
                        {sigDriver ? 'Ubah' : 'TTD'}
                      </button>
                    )}
                  </div>

                  <div className="p-1.5 rounded-lg bg-[#111114] border border-[#26262E] text-center flex flex-col justify-between">
                    <div>
                      <div className="text-[8px] font-bold text-neutral-400 uppercase">Penerima</div>
                      <div className="text-[9px] font-bold truncate mt-0.5">
                        {sigPenerima ? (
                          <span className="text-emerald-400 font-bold">{sigPenerima.name}</span>
                        ) : (
                          <span className="text-neutral-500 italic text-[8.5px]">Belum TTD</span>
                        )}
                      </div>
                    </div>
                    {isSpvOrOwner && (
                      <button
                        type="button"
                        onClick={() => setActiveSigRole('penerima')}
                        className="mt-1 w-full py-0.5 text-[8px] font-bold text-rose-300 hover:bg-rose-950/60 border border-rose-800/80 rounded transition-colors cursor-pointer"
                      >
                        {sigPenerima ? 'Ubah' : 'TTD'}
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons: Batal & Simpan */}
              <div className="pt-1 flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleResetForm}
                  className="px-4 py-2.5 bg-[#1F1F24] hover:bg-[#2A2A32] text-neutral-300 hover:text-white font-bold text-xs uppercase tracking-wider rounded-xl border border-[#2E2E38] transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                  title="Kembalikan form ke default kosong"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Batal
                </button>
                {isSpvOrOwner ? (
                  <button
                    type="button"
                    onClick={handleSave}
                    className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md shadow-rose-600/30 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {isSaved ? (
                      <>
                        <CheckCircle className="w-4 h-4" /> Surat Jalan Tersimpan (Klik untuk Simpan Ulang)
                      </>
                    ) : initialDoc ? (
                      <>
                        <Edit2 className="w-4 h-4" /> Simpan Perubahan Surat Jalan
                      </>
                    ) : (
                      'Simpan SJ & Potong Stok'
                    )}
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled
                    className="flex-1 py-2.5 bg-neutral-800 border border-neutral-700 text-neutral-400 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-not-allowed opacity-80"
                    title="Hanya SPV dan Owner yang berwenang menyimpan perubahan surat jalan"
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-400" /> Read Only (SPV/Owner Only)
                  </button>
                )}
              </div>
            </div>

            {/* Right: Real-time Printable Surat Jalan Document Preview (Maksimal: Sangat Luas) */}
            <div className="flex-1 bg-[#09090B] p-2 sm:p-5 overflow-y-auto flex flex-col items-center border-l border-[#202024]">
              {printStatus && (
                <div className="mb-3 w-full max-w-5xl p-2.5 bg-rose-950/80 border border-rose-700 rounded-xl text-xs text-rose-200 flex items-center justify-between animate-in fade-in">
                  <div className="flex items-center gap-2">
                    <Info className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{printStatus}</span>
                  </div>
                  <button onClick={() => setPrintStatus(null)} className="text-rose-300 hover:text-white text-xs cursor-pointer">✕</button>
                </div>
              )}

              <div ref={printableRef} className="w-full max-w-full 2xl:max-w-7xl bg-white shadow-2xl rounded-2xl overflow-hidden border border-slate-300 printable-document text-slate-900">
                {/* Header Kop SJ dengan Logo Terintegrasi & Warna Kustom */}
                <div
                  className="printable-header-banner text-white p-4 sm:p-6 flex flex-col sm:flex-row sm:items-start justify-between gap-4 transition-colors duration-200"
                  style={{ backgroundColor: settings?.invoiceHeaderColor || '#be123c' }}
                >
                  <div className="flex items-center gap-4">
                    {settings?.logoUrl ? (
                      <div className="w-16 h-16 bg-white rounded-xl p-1 shadow-md flex items-center justify-center shrink-0 overflow-hidden border border-white/30">
                        <img
                          src={settings.logoUrl}
                          alt="Logo Toko"
                          className="max-w-full max-h-full object-contain"
                        />
                      </div>
                    ) : null}
                    <div>
                      <h2 className="text-xl font-extrabold tracking-wide uppercase text-white">
                        {settings?.brandName || 'SURAT JALAN PENGIRIMAN (SJ)'}
                      </h2>
                      <p className="text-xs text-rose-100 mt-0.5">
                        {settings?.companySubtitle || 'Sistem Manajemen Pengiriman Antar Gudang & Ekspedisi'}
                      </p>
                      {settings?.companyAddress && (
                        <p className="text-[10px] text-rose-200 mt-1 max-w-lg leading-relaxed">
                          {settings.companyAddress}
                          {settings.companyPhone ? ` • Telp/WA: ${settings.companyPhone}` : ''}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right text-xs space-y-1">
                    <div className="doc-header-badge inline-block bg-black/35 border border-white/40 px-3 py-1.5 rounded-lg text-right shadow-sm">
                      <span className="text-[10px] text-white/90 block uppercase font-bold tracking-wider">DOKUMEN RESMI SJ</span>
                      <span className="font-mono font-bold text-white text-sm">{nomorSJ}</span>
                    </div>
                    <div className="mt-1">
                      <span className="text-white/80">Tanggal Kirim: </span>
                      <span className="font-semibold text-white">{tanggal}</span>
                    </div>
                  </div>
                </div>

                {/* Sub-header Information Grid */}
                {(() => {
                  const selectedWarehouse = activeWarehouses.find((w) => w.GUDANG_ID === selectedGudangId);
                  const displayGudangNama = selectedWarehouse?.NAMA_GUDANG || initialDoc?.gudangNama || 'GUDANG PENGIRIM';
                  const displayGudangId = selectedWarehouse?.GUDANG_ID || selectedGudangId || initialDoc?.gudangId || 'GDG';
                  const pengirimNama = initialDoc?.username || currentUser.username;

                  return (
                    <div className="p-5 border-b border-slate-200 grid grid-cols-2 gap-4 text-xs bg-slate-50/50">
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                          GUDANG ASAL PENGIRIM
                        </span>
                        <div className="font-bold text-sm text-slate-900">{displayGudangNama}</div>
                        <div className="text-slate-600">
                          Unit: <strong>{displayGudangId}</strong> | Disiapkan oleh: {pengirimNama}
                        </div>
                        {selectedWarehouse?.LOKASI && (
                          <div className="text-[10px] text-slate-500 mt-0.5">Alamat: {selectedWarehouse.LOKASI}</div>
                        )}
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                          TUJUAN PENGIRIMAN
                        </span>
                        <div className="font-bold text-sm text-slate-900">{tujuan || '—'}</div>
                        <div className="text-slate-600">Penerima (PIC): {penerima || '—'}</div>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                          LOGISTIK & ARMADA
                        </span>
                        <div className="font-semibold text-slate-800">Driver: {driver || '—'}</div>
                        <div className="text-slate-600">Kendaraan / Nopol: {kendaraan || '—'}</div>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                          CATATAN PENGIRIMAN
                        </span>
                        <div className="font-medium text-slate-800">{catatan || '—'}</div>
                      </div>
                    </div>
                  );
                })()}

                {/* Table of Items */}
                <div className="p-4 sm:p-6 overflow-x-auto">
                  <table className="w-full border-collapse text-xs min-w-[500px]">
                    <thead>
                      <tr className="bg-rose-50 border-b-2 border-rose-200 text-slate-700">
                        <th className="py-2.5 px-3 text-left font-bold w-10">No</th>
                        <th className="py-2.5 px-3 text-left font-bold">SKU ID</th>
                        <th className="py-2.5 px-3 text-left font-bold">Nama Produk & Spesifikasi Kaos</th>
                        <th className="py-2.5 px-3 text-center font-bold w-24">Jumlah Dikirim</th>
                        <th className="py-2.5 px-3 text-left font-bold">Keterangan / Koli</th>
                        {tampilkanNominal && (
                          <th className="py-2.5 px-3 text-right font-bold w-32">Estimasi Nilai</th>
                        )}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {items.filter((item) => item.SKU_ID).length === 0 ? (
                        <tr>
                          <td colSpan={tampilkanNominal ? 6 : 5} className="py-6 text-center text-slate-400 italic">
                            Belum ada item barang dipilih. Silakan pilih SKU Kaos pada form di sebelah kiri.
                          </td>
                        </tr>
                      ) : (
                        items
                          .filter((item) => item.SKU_ID)
                          .map((item, i) => {
                            const prod = products.find((p) => p.SKU_ID === item.SKU_ID);
                            const lineSubtotal = (Number(item.jumlah) || 0) * (Number(item.hargaSatuan) || 0);

                            return (
                              <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                                <td className="py-2.5 px-3 text-slate-500 font-mono text-center">{i + 1}</td>
                                <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{item.SKU_ID}</td>
                                <td className="py-2.5 px-3">
                                  <div className="font-semibold text-slate-800">{prod?.NAMA_PRODUK || 'Kaos Polos Combed'}</div>
                                  {prod?.WARNA && (
                                    <div className="text-[10px] text-slate-500 mt-0.5">
                                      Warna: <strong>{prod.WARNA}</strong> | Ukuran: <strong>{prod.UKURAN}</strong>
                                    </div>
                                  )}
                                </td>
                                <td className="py-2.5 px-3 text-center font-extrabold text-slate-900 font-mono text-sm">
                                  {item.jumlah} pcs
                                </td>
                                <td className="py-2.5 px-3 text-slate-600">{item.keterangan || '—'}</td>
                                {tampilkanNominal && (
                                  <td className="py-2.5 px-3 text-right font-mono text-slate-700">
                                    {formatRupiah(lineSubtotal)}
                                  </td>
                                )}
                              </tr>
                            );
                          })
                      )}
                    </tbody>
                    <tfoot>
                      <tr className="border-t-2 border-slate-300 bg-slate-50 font-bold text-slate-800">
                        <td colSpan={3} className="py-3 px-3 text-right">TOTAL FISIK DIKIRIM:</td>
                        <td className="py-3 px-3 text-center font-mono font-extrabold text-sm text-rose-700">
                          {totalQty} pcs
                        </td>
                        <td></td>
                        {tampilkanNominal && (
                          <td className="py-3 px-3 text-right font-mono font-extrabold text-sm text-slate-900">
                            {formatRupiah(totalNominal)}
                          </td>
                        )}
                      </tr>
                    </tfoot>
                  </table>
                </div>

                {/* 3 Digital Signatures Grid */}
                <div className="p-4 sm:p-6 pt-4 grid grid-cols-1 sm:grid-cols-3 gap-5 sm:gap-6 text-xs">
                  {/* Pengirim */}
                  <div className="flex flex-col items-center text-center">
                    <span className="text-slate-600 mb-1.5 font-medium">Diserahkan oleh (Pengirim):</span>
                    <div className="w-36 h-20 border border-dashed border-slate-300 rounded-lg bg-white flex items-center justify-center relative overflow-hidden">
                      {sigPengirim ? (
                        <>
                          <img
                            src={sigPengirim.imageDataUrl}
                            alt="TTD Pengirim"
                            className="max-h-16 max-w-[130px] object-contain"
                          />
                          <div className="absolute top-0.5 right-0.5 text-[8px] font-bold text-emerald-600 bg-emerald-50 px-1 rounded flex items-center gap-0.5">
                            <ShieldCheck className="w-2.5 h-2.5" /> Terverifikasi
                          </div>
                        </>
                      ) : settings?.useStampAsSignature && settings?.stampUrl ? (
                        <>
                          <img
                            src={settings.stampUrl}
                            alt="Stempel Toko"
                            className="max-h-16 max-w-[130px] object-contain drop-shadow-sm rotate-[-3deg]"
                          />
                          <div className="absolute top-0.5 right-0.5 text-[8px] font-bold text-rose-700 bg-rose-50 px-1 rounded flex items-center gap-0.5 border border-rose-200">
                            <ShieldCheck className="w-2.5 h-2.5 text-rose-600" /> Stempel Sah
                          </div>
                        </>
                      ) : (
                        <span className="text-[9px] text-slate-400 italic">Belum bertanda tangan</span>
                      )}
                    </div>
                    <span className="font-bold text-slate-900 mt-1 border-t border-slate-300 pt-0.5 w-28 text-[11px] truncate">
                      {sigPengirim
                        ? sigPengirim.name
                        : settings?.useStampAsSignature && settings?.stampUrl
                        ? settings.brandName || currentUser.username
                        : '( .............................. )'}
                    </span>
                    <span className="text-[9px] text-slate-500">
                      {sigPengirim
                        ? 'Admin Pengirim'
                        : settings?.useStampAsSignature && settings?.stampUrl
                        ? 'Disahkan Stempel Toko'
                        : '(Belum Ditandatangani)'}
                    </span>
                  </div>

                  {/* Driver */}
                  <div className="flex flex-col items-center text-center">
                    <span className="text-slate-600 mb-1.5 font-medium">Dibawa oleh (Kurir/Driver):</span>
                    <div className="w-36 h-20 border border-dashed border-slate-300 rounded-lg bg-white flex items-center justify-center relative overflow-hidden">
                      {sigDriver ? (
                        <>
                          <img
                            src={sigDriver.imageDataUrl}
                            alt="TTD Driver"
                            className="max-h-16 max-w-[130px] object-contain"
                          />
                          <div className="absolute top-0.5 right-0.5 text-[8px] font-bold text-emerald-600 bg-emerald-50 px-1 rounded flex items-center gap-0.5">
                            <ShieldCheck className="w-2.5 h-2.5" /> Terverifikasi
                          </div>
                        </>
                      ) : (
                        <span className="text-[9px] text-slate-400 italic">Belum bertanda tangan</span>
                      )}
                    </div>
                    <span className="font-bold text-slate-900 mt-1 border-t border-slate-300 pt-0.5 w-28 text-[11px] truncate">
                      {sigDriver ? sigDriver.name : '( .............................. )'}
                    </span>
                    <span className="text-[9px] text-slate-500">
                      {sigDriver ? 'Driver / Ekspedisi' : '(Belum Ditandatangani)'}
                    </span>
                  </div>

                  {/* Penerima */}
                  <div className="flex flex-col items-center text-center">
                    <span className="text-slate-600 mb-1.5 font-medium">Diterima oleh (Penerima):</span>
                    <div className="w-36 h-20 border border-dashed border-slate-300 rounded-lg bg-white flex items-center justify-center relative overflow-hidden">
                      {sigPenerima ? (
                        <>
                          <img
                            src={sigPenerima.imageDataUrl}
                            alt="TTD Penerima"
                            className="max-h-16 max-w-[130px] object-contain"
                          />
                          <div className="absolute top-0.5 right-0.5 text-[8px] font-bold text-emerald-600 bg-emerald-50 px-1 rounded flex items-center gap-0.5">
                            <ShieldCheck className="w-2.5 h-2.5" /> Terverifikasi
                          </div>
                        </>
                      ) : (
                        <span className="text-[9px] text-slate-400 italic">Belum bertanda tangan</span>
                      )}
                    </div>
                    <span className="font-bold text-slate-900 mt-1 border-t border-slate-300 pt-0.5 w-28 text-[11px] truncate">
                      {sigPenerima ? sigPenerima.name : '( .............................. )'}
                    </span>
                    <span className="text-[9px] text-slate-500">
                      {sigPenerima ? 'Penerima Cabang' : '(Belum Ditandatangani)'}
                    </span>
                  </div>
                </div>

                {/* Legal Timestamp */}
                <div className="px-6 py-2.5 bg-slate-100 border-t border-slate-200 text-center text-[10px] text-slate-500">
                  Surat Jalan Resmi Terotentikasi Digital • Sistem Inventori Kaos Polos •{' '}
                  {new Date().toLocaleString('id-ID')}
                </div>
              </div>

              {/* Action Bar Cetak Surat Jalan: Hanya tampil setelah tombol Simpan Surat Jalan diklik atau saat melihat dokumen tersimpan */}
              <div className="mt-4 mb-2 flex items-center justify-center">
                {isSaved && (
                  <button
                    type="button"
                    onClick={handlePrint}
                    className="px-6 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-lg flex items-center gap-2 transition-all cursor-pointer hover:scale-102 active:scale-98 animate-in fade-in"
                  >
                    <Printer className="w-4 h-4" /> Cetak Surat Jalan / Simpan PDF
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Barcode Scanner Modal */}
      {scannerTargetRowId && isSpvOrOwner && (
        <BarcodeScannerModal
          isOpen={!!scannerTargetRowId}
          onClose={() => setScannerTargetRowId(null)}
          onScanSuccess={handleBarcodeScanned}
          title="Pindai Barcode Kaos untuk Surat Jalan"
          subtitle="Arahkan kamera pada barcode label kaos yang akan dikirim"
        />
      )}

      {/* Signature Modal */}
      {activeSigRole && isSpvOrOwner && (
        <DigitalSignatureModal
          isOpen={!!activeSigRole}
          onClose={() => setActiveSigRole(null)}
          settings={settings}
          defaultSignerName={
            activeSigRole === 'pengirim'
              ? currentUser.username
              : activeSigRole === 'driver'
              ? driver || 'Driver Ekspedisi'
              : penerima || 'Penerima Barang'
          }
          roleLabel={
            activeSigRole === 'pengirim'
              ? 'Admin Pengirim Gudang'
              : activeSigRole === 'driver'
              ? 'Driver / Pengantar'
              : 'Penerima Barang di Tujuan'
          }
          onSaveSignature={(sig) => {
            if (activeSigRole === 'pengirim') setSigPengirim(sig);
            if (activeSigRole === 'driver') setSigDriver(sig);
            if (activeSigRole === 'penerima') setSigPenerima(sig);
          }}
        />
      )}
    </>
  );
};
