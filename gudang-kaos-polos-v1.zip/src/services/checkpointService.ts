import {
  AppBackupData,
  AppBackupSummary,
  CheckpointItem,
  CheckpointTriggerType,
  CheckpointSettings,
  MasterProduk,
  MasterGudang,
  InventoryItem,
  LogTransaksi,
  UserAccount,
  AppSystemSettings,
  OrderDocument,
  SuratJalanDocument,
  SaleDocument,
  Pelanggan,
  StockOpnameSession,
} from '../types';

export const CHECKPOINTS_STORAGE_KEY = 'inv_kaos_checkpoints_v2';
export const LAST_CHECKPOINT_TIMESTAMP_KEY = 'inv_kaos_last_checkpoint_ts';

export interface AppStateSnapshot {
  products: MasterProduk[];
  warehouses: MasterGudang[];
  inventory: InventoryItem[];
  logs: LogTransaksi[];
  users: UserAccount[];
  settings: AppSystemSettings;
  orders: OrderDocument[];
  suratJalanList: SuratJalanDocument[];
  sales: SaleDocument[];
  customers: Pelanggan[];
  soHistory?: StockOpnameSession[];
}

export class CheckpointService {
  /**
   * Menghasilkan ringkasan dan metadata komprehensif dari state aplikasi
   */
  public static generateBackupData(state: AppStateSnapshot, source = 'Sistem Web Kaos Polos'): AppBackupData {
    const totalStockPcs = (state.inventory || []).reduce((acc, curr) => acc + (Number(curr.JUMLAH_READY) || 0), 0);

    let soHistory = state.soHistory;
    if (!soHistory) {
      try {
        const rawSo = localStorage.getItem('INVENTORY_SO_HISTORY');
        if (rawSo) soHistory = JSON.parse(rawSo);
      } catch {
        soHistory = [];
      }
    }

    const summary: AppBackupSummary = {
      totalProducts: (state.products || []).length,
      totalWarehouses: (state.warehouses || []).length,
      totalInventorySlots: (state.inventory || []).length,
      totalStockPcs,
      totalTransactions: (state.logs || []).length,
      totalOrders: (state.orders || []).length,
      totalSuratJalan: (state.suratJalanList || []).length,
      totalSales: (state.sales || []).length,
      totalCustomers: (state.customers || []).length,
      totalSoSessions: (soHistory || []).length,
    };

    return {
      app: 'Distro Kaos Polos Combed 30s Inventory',
      version: '2.5',
      exportedAt: new Date().toISOString(),
      source,
      summary,
      products: state.products || [],
      warehouses: state.warehouses || [],
      inventory: state.inventory || [],
      logs: state.logs || [],
      users: state.users || [],
      settings: state.settings,
      orders: state.orders || [],
      suratJalanList: state.suratJalanList || [],
      sales: state.sales || [],
      customers: state.customers || [],
      soHistory: soHistory || [],
    };
  }

  /**
   * Menghitung estimasi ukuran byte/KB data
   */
  public static calculateSizeKb(data: unknown): number {
    try {
      const str = JSON.stringify(data);
      const bytes = new Blob([str]).size;
      return Math.round((bytes / 1024) * 10) / 10;
    } catch {
      return 0;
    }
  }

  /**
   * Mengambil semua checkpoints dari localStorage
   */
  public static getCheckpoints(): CheckpointItem[] {
    try {
      const raw = localStorage.getItem(CHECKPOINTS_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      }
      return [];
    } catch (e) {
      console.error('Gagal membaca checkpoints dari storage:', e);
      return [];
    }
  }

  /**
   * Membuat checkpoint baru (baik Manual maupun Otomatis)
   */
  public static createCheckpoint(
    triggerType: CheckpointTriggerType,
    name: string,
    creator: string,
    state: AppStateSnapshot,
    note?: string,
    settings?: CheckpointSettings
  ): CheckpointItem {
    const backupData = this.generateBackupData(state, `Checkpoint [${triggerType}]`);
    const sizeKb = this.calculateSizeKb(backupData);
    const now = new Date();
    const id = `CHK-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}${String(now.getSeconds()).padStart(2, '0')}-${Math.floor(100 + Math.random() * 900)}`;

    const newCheckpoint: CheckpointItem = {
      id,
      timestamp: now.toISOString(),
      name,
      triggerType,
      creator: creator || 'Sistem Otomatis',
      note: note || '',
      sizeKb,
      isPinned: triggerType === 'MANUAL', // Manual default pinned agar tidak mudah terprune
      data: backupData,
    };

    const maxLimit = settings?.maxCheckpoints || 15;
    const existing = this.getCheckpoints();

    // Sisipkan item baru di paling depan
    let list = [newCheckpoint, ...existing];

    // Jika melebihi limit, prune item tertua yang bukan pinned
    if (list.length > maxLimit) {
      const pinned = list.filter((item) => item.isPinned);
      const unpinned = list.filter((item) => !item.isPinned);

      const allowedUnpinned = Math.max(1, maxLimit - pinned.length);
      const keptUnpinned = unpinned.slice(0, allowedUnpinned);

      list = [...pinned, ...keptUnpinned].sort(
        (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
    }

    try {
      localStorage.setItem(CHECKPOINTS_STORAGE_KEY, JSON.stringify(list));
      localStorage.setItem(LAST_CHECKPOINT_TIMESTAMP_KEY, now.toISOString());
    } catch (e) {
      console.warn('Gagal menyimpan checkpoint (kemungkinan kuota localStorage penuh):', e);
      // Coba simpan dengan hanya mempertahankan 3 checkpoint terakhir
      try {
        const minimalList = list.slice(0, 3);
        localStorage.setItem(CHECKPOINTS_STORAGE_KEY, JSON.stringify(minimalList));
      } catch (inner) {
        console.error('Storage penuh tidak dapat menyimpan checkpoint:', inner);
      }
    }

    return newCheckpoint;
  }

  /**
   * Menghapus checkpoint berdasarkan ID
   */
  public static deleteCheckpoint(id: string): CheckpointItem[] {
    const current = this.getCheckpoints();
    const updated = current.filter((c) => c.id !== id);
    localStorage.setItem(CHECKPOINTS_STORAGE_KEY, JSON.stringify(updated));
    return updated;
  }

  /**
   * Toggle Pin status checkpoint agar aman dari auto-pruning
   */
  public static togglePin(id: string): CheckpointItem[] {
    const current = this.getCheckpoints();
    const updated = current.map((c) => (c.id === id ? { ...c, isPinned: !c.isPinned } : c));
    localStorage.setItem(CHECKPOINTS_STORAGE_KEY, JSON.stringify(updated));
    return updated;
  }

  /**
   * Menghapus semua checkpoint (opsi simpan pinned)
   */
  public static clearCheckpoints(keepPinned = true): CheckpointItem[] {
    const current = this.getCheckpoints();
    const updated = keepPinned ? current.filter((c) => c.isPinned) : [];
    localStorage.setItem(CHECKPOINTS_STORAGE_KEY, JSON.stringify(updated));
    return updated;
  }

  /**
   * Men-download backup JSON ke storage lokal perangkat
   */
  public static downloadBackupJson(backupData: AppBackupData, customFileName?: string): void {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const dateStr = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
    const filename = customFileName || `backup_inventori_kaos_${dateStr}.json`;

    const jsonStr = JSON.stringify(backupData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  /**
   * Validasi struktur dan parsing konten file JSON backup
   */
  public static validateBackupJson(jsonString: string): {
    valid: boolean;
    data?: AppBackupData;
    error?: string;
  } {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed || typeof parsed !== 'object') {
        return { valid: false, error: 'Berkas tidak berformat objek JSON yang valid.' };
      }

      // Validasi fleksibel: mendukung format baru maupun format legacy
      const products = Array.isArray(parsed.products) ? parsed.products : [];
      const warehouses = Array.isArray(parsed.warehouses) ? parsed.warehouses : [];
      const inventory = Array.isArray(parsed.inventory) ? parsed.inventory : [];

      if (products.length === 0 && warehouses.length === 0 && inventory.length === 0) {
        return {
          valid: false,
          error: 'Format data backup tidak dikenali atau kosong. Tidak ditemukan data produk, gudang, maupun inventori.',
        };
      }

      // Standarisasi payload lengkap
      const backupData: AppBackupData = {
        app: parsed.app || 'Distro Kaos Polos Combed 30s Inventory',
        version: parsed.version || '2.0',
        exportedAt: parsed.exportedAt || parsed.exportDate || new Date().toISOString(),
        source: parsed.source || 'Import File JSON',
        summary: parsed.summary || {
          totalProducts: products.length,
          totalWarehouses: warehouses.length,
          totalInventorySlots: inventory.length,
          totalStockPcs: inventory.reduce((s: number, i: any) => s + (Number(i.JUMLAH_READY) || 0), 0),
          totalTransactions: Array.isArray(parsed.logs) ? parsed.logs.length : 0,
          totalOrders: Array.isArray(parsed.orders) ? parsed.orders.length : 0,
          totalSuratJalan: Array.isArray(parsed.suratJalanList) ? parsed.suratJalanList.length : 0,
          totalSales: Array.isArray(parsed.sales) ? parsed.sales.length : 0,
          totalCustomers: Array.isArray(parsed.customers) ? parsed.customers.length : 0,
          totalSoSessions: Array.isArray(parsed.soHistory) ? parsed.soHistory.length : 0,
        },
        products,
        warehouses,
        inventory,
        logs: Array.isArray(parsed.logs) ? parsed.logs : [],
        users: Array.isArray(parsed.users) ? parsed.users : [],
        settings: parsed.settings || {},
        orders: Array.isArray(parsed.orders) ? parsed.orders : [],
        suratJalanList: Array.isArray(parsed.suratJalanList) ? parsed.suratJalanList : [],
        sales: Array.isArray(parsed.sales) ? parsed.sales : [],
        customers: Array.isArray(parsed.customers) ? parsed.customers : [],
        soHistory: Array.isArray(parsed.soHistory) ? parsed.soHistory : [],
      };

      return { valid: true, data: backupData };
    } catch (e: any) {
      return { valid: false, error: `Gagal membaca berkas JSON: ${e?.message || 'Sintaks tidak valid'}` };
    }
  }

  /**
   * Format waktu relatif (misal: "Baru saja", "5 menit lalu")
   */
  public static formatRelativeTime(isoString: string): string {
    try {
      const past = new Date(isoString).getTime();
      const now = Date.now();
      const diffSec = Math.floor((now - past) / 1000);

      if (diffSec < 45) return 'Baru saja';
      if (diffSec < 90) return '1 menit lalu';
      const diffMin = Math.floor(diffSec / 60);
      if (diffMin < 60) return `${diffMin} menit lalu`;
      const diffHour = Math.floor(diffMin / 60);
      if (diffHour < 24) return `${diffHour} jam lalu`;
      const diffDays = Math.floor(diffHour / 24);
      if (diffDays === 1) return 'Kemarin';
      if (diffDays < 7) return `${diffDays} hari lalu`;
      return new Date(isoString).toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return isoString;
    }
  }
}
