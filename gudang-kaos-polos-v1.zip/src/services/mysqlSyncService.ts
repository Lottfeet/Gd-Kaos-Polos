import {
  OfflineSyncService,
  PendingSyncItem,
  isOfflineError,
} from './offlineSyncService';
import {
  MasterProduk,
  InventoryItem,
  MasterGudang,
  Pelanggan,
  SaleDocument,
  OrderDocument,
  SuratJalanDocument,
  LogTransaksi,
  AppSystemSettings,
} from '../types';

export interface DbStatusResponse {
  connected: boolean;
  type?: 'direct' | 'bridge';
  bridgeUrl?: string;
  host: string;
  port: number;
  user: string;
  database: string;
  tableCounts: Record<string, number>;
  error?: string | null;
  message?: string;
}

export interface PullDataResponse {
  success: boolean;
  error?: string;
  counts?: Record<string, number>;
  data?: {
    products: MasterProduk[];
    inventory: InventoryItem[];
    warehouses: MasterGudang[];
    customers: Pelanggan[];
    sales: SaleDocument[];
    orders: OrderDocument[];
    suratJalanList: SuratJalanDocument[];
    logs: LogTransaksi[];
    settings?: AppSystemSettings;
    users?: any[];
  };
}

export const MysqlSyncService = {
  // Test MySQL Connection & Table Status
  async testConnection(): Promise<DbStatusResponse> {
    try {
      const res = await fetch('/api/db/status');
      if (!res.ok) {
        throw new Error(`Server status returned ${res.status}`);
      }
      const data: DbStatusResponse = await res.json();
      return data;
    } catch (err: any) {
      return {
        connected: false,
        host: 'localhost',
        port: 3306,
        user: 'root',
        database: 'db_kaospolos',
        tableCounts: {},
        error: err.message || 'Koneksi ke backend server gagal',
      };
    }
  },

  // Pull All Data from MySQL Database
  async pullAllDataFromDatabase(): Promise<PullDataResponse> {
    try {
      const res = await fetch('/api/db/pull-all');
      if (!res.ok) {
        const errorJson = await res.json().catch(() => ({}));
        throw new Error(errorJson.error || `HTTP ${res.status}`);
      }
      const result: PullDataResponse = await res.json();
      return result;
    } catch (err: any) {
      return {
        success: false,
        error: err.message || 'Gagal memuat data dari database MySQL',
      };
    }
  },

  // Push / Migrate All Local Data into MySQL Database
  async migrateLocalDataToDatabase(appData: {
    products: MasterProduk[];
    inventory: InventoryItem[];
    warehouses: MasterGudang[];
    customers: Pelanggan[];
    sales: SaleDocument[];
    orders: OrderDocument[];
    suratJalanList: SuratJalanDocument[];
    logs: LogTransaksi[];
    settings?: AppSystemSettings;
    users?: any[];
  }): Promise<{ success: boolean; count: number; error?: string }> {
    try {
      const res = await fetch('/api/db/push-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(appData),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || `HTTP ${res.status}`);
      }
      return { success: true, count: data.count || 0 };
    } catch (err: any) {
      return {
        success: false,
        count: 0,
        error: err.message || 'Gagal mengirim data ke database MySQL',
      };
    }
  },

  // Generic Sync Item Execution
  async sendSyncItem(action: string, key: string, data?: any): Promise<boolean> {
    try {
      const res = await fetch('/api/db/sync-item', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, key, data }),
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  // Sync Products
  async saveProduct(product: MasterProduk): Promise<void> {
    const key = product.SKU_ID;
    const title = `Produk ${product.SKU_ID} (${product.NAMA_PRODUK})`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('saveProduct', key, product, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('saveProduct', key, product);
      if (success) {
        OfflineSyncService.removeByKey('saveProduct', key);
      } else {
        OfflineSyncService.enqueue('saveProduct', key, product, title, false, 'Gagal kirim ke MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('saveProduct', key, product, title, false, error?.message);
    }
  },

  async deleteProduct(skuId: string): Promise<void> {
    const title = `Hapus Produk ${skuId}`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('deleteProduct', skuId, null, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('deleteProduct', skuId);
      if (success) {
        OfflineSyncService.removeByKey('deleteProduct', skuId);
      } else {
        OfflineSyncService.enqueue('deleteProduct', skuId, null, title, false, 'Gagal hapus dari MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('deleteProduct', skuId, null, title, false, error?.message);
    }
  },

  // Sync Inventory
  async saveInventoryItem(item: InventoryItem): Promise<void> {
    const docId = `${item.GUDANG_ID}_${item.SKU_ID}`;
    const title = `Stok Gudang ${item.GUDANG_ID} - SKU ${item.SKU_ID} (${item.JUMLAH_READY} pcs)`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('saveInventoryItem', docId, item, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('saveInventoryItem', docId, item);
      if (success) {
        OfflineSyncService.removeByKey('saveInventoryItem', docId);
      } else {
        OfflineSyncService.enqueue('saveInventoryItem', docId, item, title, false, 'Gagal simpan ke MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('saveInventoryItem', docId, item, title, false, error?.message);
    }
  },

  async deleteInventoryItem(_docId: string): Promise<void> {
    // Inventory usually soft-managed by quantity or warehouse
  },

  // Sync Customer
  async saveCustomer(customer: Pelanggan): Promise<void> {
    const key = customer.id;
    const title = `Pelanggan ${customer.nama} (${customer.id})`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('saveCustomer', key, customer, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('saveCustomer', key, customer);
      if (success) {
        OfflineSyncService.removeByKey('saveCustomer', key);
      } else {
        OfflineSyncService.enqueue('saveCustomer', key, customer, title, false, 'Gagal simpan pelanggan ke MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('saveCustomer', key, customer, title, false, error?.message);
    }
  },

  async deleteCustomer(customerId: string): Promise<void> {
    const title = `Hapus Pelanggan ${customerId}`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('deleteCustomer', customerId, null, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('deleteCustomer', customerId);
      if (success) {
        OfflineSyncService.removeByKey('deleteCustomer', customerId);
      } else {
        OfflineSyncService.enqueue('deleteCustomer', customerId, null, title, false, 'Gagal hapus pelanggan dari MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('deleteCustomer', customerId, null, title, false, error?.message);
    }
  },

  // Sync Sales
  async saveSale(sale: SaleDocument): Promise<void> {
    const key = sale.nomorSale;
    const title = `Faktur Penjualan ${sale.nomorSale} (${sale.pelanggan || 'Umum'})`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('saveSale', key, sale, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('saveSale', key, sale);
      if (success) {
        OfflineSyncService.removeByKey('saveSale', key);
      } else {
        OfflineSyncService.enqueue('saveSale', key, sale, title, false, 'Gagal simpan penjualan ke MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('saveSale', key, sale, title, false, error?.message);
    }
  },

  async deleteSale(nomorSale: string): Promise<void> {
    const title = `Hapus Faktur Penjualan ${nomorSale}`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('deleteSale', nomorSale, null, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('deleteSale', nomorSale);
      if (success) {
        OfflineSyncService.removeByKey('deleteSale', nomorSale);
      } else {
        OfflineSyncService.enqueue('deleteSale', nomorSale, null, title, false, 'Gagal hapus penjualan dari MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('deleteSale', nomorSale, null, title, false, error?.message);
    }
  },

  // Sync Orders
  async saveOrder(order: OrderDocument): Promise<void> {
    const key = order.nomorOrder;
    const title = `PO Pesanan ${order.nomorOrder} (${order.supplier})`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('saveOrder', key, order, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('saveOrder', key, order);
      if (success) {
        OfflineSyncService.removeByKey('saveOrder', key);
      } else {
        OfflineSyncService.enqueue('saveOrder', key, order, title, false, 'Gagal simpan PO ke MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('saveOrder', key, order, title, false, error?.message);
    }
  },

  async deleteOrder(nomorOrder: string): Promise<void> {
    const title = `Hapus PO Pesanan ${nomorOrder}`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('deleteOrder', nomorOrder, null, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('deleteOrder', nomorOrder);
      if (success) {
        OfflineSyncService.removeByKey('deleteOrder', nomorOrder);
      } else {
        OfflineSyncService.enqueue('deleteOrder', nomorOrder, null, title, false, 'Gagal hapus PO dari MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('deleteOrder', nomorOrder, null, title, false, error?.message);
    }
  },

  // Sync Surat Jalan
  async saveSuratJalan(sj: SuratJalanDocument): Promise<void> {
    const key = sj.nomorSJ;
    const title = `Surat Jalan ${sj.nomorSJ} (${sj.tujuan})`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('saveSuratJalan', key, sj, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('saveSuratJalan', key, sj);
      if (success) {
        OfflineSyncService.removeByKey('saveSuratJalan', key);
      } else {
        OfflineSyncService.enqueue('saveSuratJalan', key, sj, title, false, 'Gagal simpan SJ ke MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('saveSuratJalan', key, sj, title, false, error?.message);
    }
  },

  async deleteSuratJalan(nomorSJ: string): Promise<void> {
    const title = `Hapus Surat Jalan ${nomorSJ}`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('deleteSuratJalan', nomorSJ, null, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('deleteSuratJalan', nomorSJ);
      if (success) {
        OfflineSyncService.removeByKey('deleteSuratJalan', nomorSJ);
      } else {
        OfflineSyncService.enqueue('deleteSuratJalan', nomorSJ, null, title, false, 'Gagal hapus SJ dari MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('deleteSuratJalan', nomorSJ, null, title, false, error?.message);
    }
  },

  // Sync Warehouses
  async saveWarehouse(wh: MasterGudang): Promise<void> {
    const key = wh.GUDANG_ID;
    const title = `Gudang ${wh.NAMA_GUDANG} (${wh.GUDANG_ID})`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('saveWarehouse', key, wh, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('saveWarehouse', key, wh);
      if (success) {
        OfflineSyncService.removeByKey('saveWarehouse', key);
      } else {
        OfflineSyncService.enqueue('saveWarehouse', key, wh, title, false, 'Gagal simpan gudang ke MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('saveWarehouse', key, wh, title, false, error?.message);
    }
  },

  // Sync Logs
  async saveLog(log: LogTransaksi): Promise<void> {
    const key = log.TRANSAKSI_ID;
    const title = `Log ${log.TIPE_TRANSAKSI} - ${log.SKU_ID} (${log.JUMLAH} pcs)`;

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('saveLog', key, log, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('saveLog', key, log);
      if (success) {
        OfflineSyncService.removeByKey('saveLog', key);
      } else {
        OfflineSyncService.enqueue('saveLog', key, log, title, false, 'Gagal simpan log ke MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('saveLog', key, log, title, false, error?.message);
    }
  },

  async deleteLog(transaksiId: string): Promise<void> {
    const title = `Hapus Log ${transaksiId}`;
    if (!navigator.onLine) {
      OfflineSyncService.enqueue('deleteLog', transaksiId, null, title, false);
      return;
    }
    try {
      const success = await this.sendSyncItem('deleteLog', transaksiId);
      if (success) {
        OfflineSyncService.removeByKey('deleteLog', transaksiId);
      } else {
        OfflineSyncService.enqueue('deleteLog', transaksiId, null, title, false, 'Gagal hapus log dari MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('deleteLog', transaksiId, null, title, false, error?.message);
    }
  },

  // Sync Settings
  async saveSettings(settings: AppSystemSettings): Promise<void> {
    const key = 'default';
    const title = 'Pengaturan Sistem Toko';

    if (!navigator.onLine) {
      OfflineSyncService.enqueue('saveSettings', key, settings, title, false);
      return;
    }

    try {
      const success = await this.sendSyncItem('saveSettings', key, settings);
      if (success) {
        OfflineSyncService.removeByKey('saveSettings', key);
      } else {
        OfflineSyncService.enqueue('saveSettings', key, settings, title, false, 'Gagal simpan setting ke MySQL');
      }
    } catch (error: any) {
      OfflineSyncService.enqueue('saveSettings', key, settings, title, false, error?.message);
    }
  },

  // Process Offline Queue against MySQL API
  async processPendingQueue(
    onProgress?: (processed: number, total: number, item: PendingSyncItem) => void
  ) {
    return OfflineSyncService.processQueue(async (item: PendingSyncItem) => {
      try {
        const ok = await this.sendSyncItem(item.action, item.key, item.data);
        return { success: ok, error: ok ? undefined : 'Gagal mengeksekusi ke MySQL' };
      } catch (err: any) {
        return { success: false, error: err.message };
      }
    }, onProgress);
  },

  // Periodic polling to keep multiple devices in sync without Firebase
  subscribeToDatabaseChanges(callbacks: {
    onSyncUpdated?: (data: any) => void;
  }): () => void {
    let intervalId: any = null;

    const checkUpdates = async () => {
      if (!navigator.onLine) return;
      try {
        const res = await this.pullAllDataFromDatabase();
        if (res.success && res.data && callbacks.onSyncUpdated) {
          callbacks.onSyncUpdated(res.data);
        }
      } catch (err) {
        console.warn('MySQL polling check failed:', err);
      }
    };

    // Run poll every 25 seconds
    intervalId = setInterval(checkUpdates, 25000);

    const onVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        checkUpdates();
      }
    };

    const onOnline = () => {
      checkUpdates();
      this.processPendingQueue();
    };

    window.addEventListener('visibilitychange', onVisibilityChange);
    window.addEventListener('online', onOnline);

    return () => {
      if (intervalId) clearInterval(intervalId);
      window.removeEventListener('visibilitychange', onVisibilityChange);
      window.removeEventListener('online', onOnline);
    };
  },
};
