export interface PushNotificationItem {
  id: string;
  title: string;
  body: string;
  timestamp: string;
  category: 'STOK' | 'SALE' | 'ORDER' | 'SJ' | 'CLOUD' | 'SISTEM';
  read: boolean;
}

const STORAGE_KEY = 'inv_kaos_notifications_v1';
const LISTENERS: Array<(notifications: PushNotificationItem[]) => void> = [];

// Audio Chime Synthesizer using Web Audio API
function playChimeSound() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    // Dual-tone chime (Pleasant high bell)
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    osc1.frequency.exponentialRampToValueAtTime(880.0, now + 0.12); // A5

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(880.0, now);
    osc2.frequency.exponentialRampToValueAtTime(1174.66, now + 0.18); // D6

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.5);
    osc2.stop(now + 0.5);
  } catch (err) {
    // Non-fatal if audio context blocked before user gesture
    console.debug('Audio chime non-fatal:', err);
  }
}

export const PushNotificationService = {
  // Ambil permission status browser saat ini
  getPermission(): NotificationPermission {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return 'denied';
    }
    return Notification.permission;
  },

  // Minta izin notifikasi browser
  async requestPermission(): Promise<NotificationPermission> {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return 'denied';
    }
    try {
      const perm = await Notification.requestPermission();
      return perm;
    } catch (err) {
      console.warn('Error requesting notification permission:', err);
      return 'denied';
    }
  },

  // Ambil riwayat notifikasi dari local storage
  getHistory(): PushNotificationItem[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (err) {
      console.warn('Error reading notifications history:', err);
    }
    return [];
  },

  // Simpan riwayat
  saveHistory(items: PushNotificationItem[]) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items.slice(0, 50)));
      LISTENERS.forEach((cb) => cb(items));
    } catch (err) {
      console.warn('Error saving notifications:', err);
    }
  },

  // Kirim push notification ke browser dan catat di in-app notification center
  sendNotification(
    title: string,
    body: string,
    category: 'STOK' | 'SALE' | 'ORDER' | 'SJ' | 'CLOUD' | 'SISTEM' = 'SISTEM'
  ): PushNotificationItem {
    const newItem: PushNotificationItem = {
      id: `NOTIF-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title,
      body,
      timestamp: new Date().toISOString(),
      category,
      read: false,
    };

    // 1. Simpan ke riwayat lokal
    const current = this.getHistory();
    this.saveHistory([newItem, ...current]);

    // 2. Mainkan suara chime
    playChimeSound();

    // 3. Tampilkan Web Push Notification jika diizinkan browser
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') {
        try {
          new Notification(title, {
            body,
            icon: '/favicon.ico',
            tag: category,
          });
        } catch (err) {
          console.warn('Web notification dispatch error:', err);
        }
      }
    }

    return newItem;
  },

  // Tandai semua sebagai telah dibaca
  markAllAsRead() {
    const current = this.getHistory();
    const updated = current.map((item) => ({ ...item, read: true }));
    this.saveHistory(updated);
  },

  // Hapus semua notifikasi
  clearAll() {
    this.saveHistory([]);
  },

  // Hitung notifikasi belum dibaca
  getUnreadCount(): number {
    return this.getHistory().filter((item) => !item.read).length;
  },

  // Berlangganan perubahan notifikasi
  subscribe(callback: (notifications: PushNotificationItem[]) => void): () => void {
    LISTENERS.push(callback);
    return () => {
      const idx = LISTENERS.indexOf(callback);
      if (idx >= 0) LISTENERS.splice(idx, 1);
    };
  },
};
