// Offline & Server Auto-Sync Service
// Mengelola antrean transaksi di LocalStorage saat server MySQL offline atau jaringan terputus,
// dan otomatis mengunggah kembali (auto-upload) data saat tersambung kembali ke MySQL / phpMyAdmin.

export type PendingSyncAction =
  | 'saveSale'
  | 'deleteSale'
  | 'saveOrder'
  | 'deleteOrder'
  | 'saveSuratJalan'
  | 'deleteSuratJalan'
  | 'saveInventoryItem'
  | 'saveProduct'
  | 'deleteProduct'
  | 'saveCustomer'
  | 'deleteCustomer'
  | 'saveLog'
  | 'deleteLog'
  | 'saveSettings'
  | 'saveWarehouse';

export interface PendingSyncItem {
  id: string;
  action: PendingSyncAction;
  key: string;
  data?: any;
  title: string;
  timestamp: string;
  attempts: number;
  lastError?: string;
  isQuotaLimit?: boolean;
}

export interface SyncStatusState {
  pendingCount: number;
  isQuotaLimited: boolean;
  isOffline: boolean;
  isSyncing: boolean;
  lastSyncTime: string | null;
  lastError: string | null;
  lastQuotaResetDate: string | null;
}

const STORAGE_QUEUE_KEY = 'inv_kaos_pending_sync_queue';
const STORAGE_STATUS_KEY = 'inv_kaos_sync_status';
const SYNC_EVENT_NAME = 'inv_kaos_sync_queue_event';

// Deteksi apakah error disebabkan oleh koneksi atau kuota/limit
export function isQuotaError(error: any): boolean {
  if (!error) return false;
  const msg = (typeof error === 'string' ? error : error.message || error.toString() || '').toLowerCase();
  return (
    msg.includes('quota') ||
    msg.includes('limit') ||
    msg.includes('too many connections') ||
    msg.includes('max_connections')
  );
}

// Deteksi apakah error disebabkan oleh offline / network failure
export function isOfflineError(error: any): boolean {
  if (typeof navigator !== 'undefined' && !navigator.onLine) return true;
  if (!error) return false;
  const msg = (typeof error === 'string' ? error : error.message || error.toString() || '').toLowerCase();
  const code = (error.code || '').toLowerCase();
  return (
    code === 'unavailable' ||
    code === 'econnrefused' ||
    code === 'etimedout' ||
    code === 'enetunreach' ||
    msg.includes('offline') ||
    msg.includes('econnrefused') ||
    msg.includes('failed to fetch') ||
    msg.includes('network') ||
    msg.includes('connection failed')
  );
}

class OfflineSyncServiceImpl {
  private listeners: Set<(status: SyncStatusState) => void> = new Set();
  private isSyncingInProgress = false;

  constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('storage', (e) => {
        if (e.key === STORAGE_QUEUE_KEY || e.key === STORAGE_STATUS_KEY) {
          this.notifyListeners();
        }
      });

      // Deteksi online/offline browser
      window.addEventListener('online', () => {
        this.setOffline(false);
        this.notifyListeners();
      });

      window.addEventListener('offline', () => {
        this.setOffline(true);
        this.notifyListeners();
      });
    }
  }

  // Ambil semua item di antrean
  public getQueue(): PendingSyncItem[] {
    try {
      const raw = localStorage.getItem(STORAGE_QUEUE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      console.warn('Gagal membaca antrean pending sync dari localStorage:', e);
      return [];
    }
  }

  private saveQueue(queue: PendingSyncItem[]): void {
    try {
      localStorage.setItem(STORAGE_QUEUE_KEY, JSON.stringify(queue));
      this.setStatusState({ pendingCount: queue.length });
      this.notifyListeners();
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent(SYNC_EVENT_NAME, { detail: { queue } }));
      }
    } catch (e) {
      console.error('Gagal menyimpan antrean pending sync:', e);
    }
  }

  // Tambahkan aksi ke antrean
  public enqueue(
    action: PendingSyncAction,
    key: string,
    data: any,
    itemTitle: string,
    isQuota = false,
    errorMsg?: string
  ): void {
    const queue = this.getQueue();
    const existingIndex = queue.findIndex((q) => q.action === action && q.key === key);
    const now = new Date().toISOString();

    if (existingIndex >= 0) {
      queue[existingIndex] = {
        ...queue[existingIndex],
        data,
        title: itemTitle,
        timestamp: now,
        attempts: queue[existingIndex].attempts + 1,
        lastError: errorMsg || queue[existingIndex].lastError,
        isQuotaLimit: isQuota || queue[existingIndex].isQuotaLimit,
      };
    } else {
      if (action.startsWith('delete')) {
        const correspondingSaveAction = action.replace('delete', 'save') as PendingSyncAction;
        const saveIdx = queue.findIndex((q) => q.action === correspondingSaveAction && q.key === key);
        if (saveIdx >= 0) {
          queue.splice(saveIdx, 1);
        }
      }

      const newItem: PendingSyncItem = {
        id: `sync_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        action,
        key,
        data,
        title: itemTitle,
        timestamp: now,
        attempts: 1,
        lastError: errorMsg,
        isQuotaLimit: isQuota,
      };
      queue.push(newItem);
    }

    this.saveQueue(queue);

    if (isQuota) {
      this.setQuotaLimited(true, errorMsg);
    }
  }

  public removeByKey(action: PendingSyncAction, key: string): void {
    const queue = this.getQueue();
    const filtered = queue.filter((q) => !(q.action === action && q.key === key));
    if (filtered.length !== queue.length) {
      this.saveQueue(filtered);
    }
  }

  public removeById(id: string): void {
    const queue = this.getQueue();
    const filtered = queue.filter((q) => q.id !== id);
    this.saveQueue(filtered);
  }

  public clearQueue(): void {
    this.saveQueue([]);
    this.setStatusState({ lastError: null });
  }

  public isQuotaLimited(): boolean {
    const status = this.getStatus();
    return Boolean(status.isQuotaLimited);
  }

  public setQuotaLimited(limited: boolean, reason?: string): void {
    const current = this.getStatus();
    const today = new Date().toDateString();
    this.setStatusState({
      isQuotaLimited: limited,
      lastQuotaResetDate: limited ? today : current.lastQuotaResetDate,
      lastError: reason || (limited ? 'Koneksi database terbatas' : current.lastError),
    });
  }

  public isOffline(): boolean {
    if (typeof navigator !== 'undefined' && !navigator.onLine) return true;
    return this.getStatus().isOffline;
  }

  public setOffline(offline: boolean): void {
    this.setStatusState({ isOffline: offline });
  }

  public getStatus(): SyncStatusState {
    const queue = this.getQueue();
    let isLimited = false;
    let isOff = typeof navigator !== 'undefined' ? !navigator.onLine : false;
    let lastSync = null;
    let lastErr = null;
    let lastReset = null;

    try {
      const raw = localStorage.getItem(STORAGE_STATUS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        isLimited = Boolean(parsed.isQuotaLimited);
        if (parsed.isOffline !== undefined) isOff = Boolean(parsed.isOffline);
        lastSync = parsed.lastSyncTime || null;
        lastErr = parsed.lastError || null;
        lastReset = parsed.lastQuotaResetDate || null;
      }
    } catch {}

    return {
      pendingCount: queue.length,
      isQuotaLimited: isLimited,
      isOffline: isOff,
      isSyncing: this.isSyncingInProgress,
      lastSyncTime: lastSync,
      lastError: lastErr,
      lastQuotaResetDate: lastReset,
    };
  }

  public setStatusState(partial: Partial<SyncStatusState>): void {
    try {
      const current = this.getStatus();
      const updated: SyncStatusState = {
        ...current,
        ...partial,
      };
      localStorage.setItem(STORAGE_STATUS_KEY, JSON.stringify(updated));
      this.notifyListeners();
    } catch (e) {
      console.warn('Gagal mengupdate sync status:', e);
    }
  }

  public subscribe(listener: (status: SyncStatusState) => void): () => void {
    this.listeners.add(listener);
    listener(this.getStatus());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners(): void {
    const status = this.getStatus();
    this.listeners.forEach((fn) => {
      try {
        fn(status);
      } catch (err) {
        console.error('Error in sync listener:', err);
      }
    });
  }

  // Proses upload seluruh antrean yang tertunda ke database MySQL
  public async processQueue(
    executor: (item: PendingSyncItem) => Promise<{ success: boolean; isQuota?: boolean; error?: string }>,
    onProgress?: (processed: number, total: number, currentItem: PendingSyncItem) => void
  ): Promise<{
    success: boolean;
    processed: number;
    remaining: number;
    quotaStopped?: boolean;
    error?: string;
  }> {
    if (this.isSyncingInProgress) {
      return { success: false, processed: 0, remaining: this.getQueue().length, error: 'Sinkronisasi sedang berjalan...' };
    }

    const queue = this.getQueue();
    if (queue.length === 0) {
      return { success: true, processed: 0, remaining: 0 };
    }

    this.isSyncingInProgress = true;
    this.notifyListeners();

    let processedCount = 0;
    const initialTotal = queue.length;

    try {
      for (const item of [...queue]) {
        if (onProgress) {
          onProgress(processedCount, initialTotal, item);
        }

        const res = await executor(item);

        if (res.success) {
          this.removeById(item.id);
          processedCount++;
          const curStatus = this.getStatus();
          if (curStatus.isQuotaLimited) {
            this.setQuotaLimited(false);
          }
        } else {
          if (isOfflineError(res.error)) {
            this.setOffline(true);
            this.isSyncingInProgress = false;
            this.notifyListeners();
            return {
              success: false,
              processed: processedCount,
              remaining: this.getQueue().length,
              error: 'Koneksi terputus saat mengunggah. Transaksi tersimpan di antrean lokal.',
            };
          }

          const currentQueue = this.getQueue();
          const target = currentQueue.find((q) => q.id === item.id);
          if (target) {
            target.attempts += 1;
            target.lastError = res.error || 'Gagal sinkronisasi';
            this.saveQueue(currentQueue);
          }
        }
      }

      const remainingCount = this.getQueue().length;
      if (remainingCount === 0) {
        this.setStatusState({
          isQuotaLimited: false,
          lastSyncTime: new Date().toISOString(),
          lastError: null,
        });
      }

      this.isSyncingInProgress = false;
      this.notifyListeners();

      return {
        success: remainingCount === 0,
        processed: processedCount,
        remaining: remainingCount,
      };
    } catch (err: any) {
      this.isSyncingInProgress = false;
      this.notifyListeners();
      return {
        success: false,
        processed: processedCount,
        remaining: this.getQueue().length,
        error: err?.message || 'Terjadi kesalahan sistem saat sinkronisasi antrean.',
      };
    }
  }

  public exportQueueAsJson(): string {
    const queue = this.getQueue();
    const payload = {
      exportedAt: new Date().toISOString(),
      appName: 'Inventori Kaos Polos',
      totalItems: queue.length,
      items: queue,
    };
    return JSON.stringify(payload, null, 2);
  }
}

export const OfflineSyncService = new OfflineSyncServiceImpl();
