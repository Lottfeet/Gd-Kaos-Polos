export type UserRole = 'ADMIN' | 'STAFF' | 'SUPERVISOR' | 'MANAGER' | 'OWNER';

export interface User {
  username: string;
  role: UserRole;
  siteAccess: string; // e.g. 'GUDANG UTAMA' | 'GUDANG TOKO' | 'SEMUA GUDANG'
  fullName?: string;
}

export interface UserAccount {
  id: string;
  username: string;
  password?: string;
  fullName: string;
  role: UserRole;
  siteAccess: string; // Gudang yang diakses: 'GUDANG UTAMA' | 'GUDANG TOKO' | 'SEMUA GUDANG'
  isActive: boolean;
  phone?: string;
  email?: string;
  createdAt: string;
  lastLogin?: string;
}

export interface MasterGudang {
  GUDANG_ID: string;
  NAMA_GUDANG: string;
  LOKASI?: string;
  PENANGGUNG_JAWAB?: string;
  IS_ACTIVE?: boolean;
  IS_DEFAULT?: boolean;
  TELEPON?: string;
  KETERANGAN?: string;
}

export interface CheckpointSettings {
  autoCheckpointEnabled: boolean; // default true
  intervalMinutes: number; // e.g. 15, 30, 60, 120
  maxCheckpoints: number; // default 15
  autoBeforeOpname: boolean; // default true
  autoBeforeRestore: boolean; // default true
  autoAfterSale: boolean; // default false
}

export interface AppSystemSettings {
  brandName: string;
  companySubtitle: string;
  companyAddress: string;
  companyPhone: string;
  companyEmail: string;
  logoUrl?: string; // Base64 data URL atau link gambar logo resmi toko
  stampUrl?: string; // Base64 data URL stempel / cap resmi toko
  useStampAsSignature?: boolean; // Pilihan apakah stempel resmi otomatis menggantikan tanda tangan di nota & dokumen
  invoiceHeaderColor?: string; // Warna HEX header Faktur / Nota (misal: #7e22ce)
  defaultReorderLevel: number;
  skuPrefix: string;
  barcodeFormat: 'CODE128' | 'QR_CODE' | 'EAN13';
  labelPaperSize: 'A4_40_LABELS' | 'THERMAL_50X30' | 'THERMAL_40X20' | 'THERMAL_100X150';
  enableAutoBarcode: boolean;
  enableStockWarningSound: boolean;
  googleSheetsWebhookUrl?: string;
  checkpointSettings?: CheckpointSettings;
}

export interface MasterProduk {
  SKU_ID: string;
  NAMA_PRODUK: string;
  WARNA: string;
  UKURAN: string;
  KATEGORI: string;
  JENIS_LENGAN: 'PENDEK' | 'PANJANG' | '3P4' | '7P8' | string;
  REORDER_LEVEL: number;
  BARCODE_ID?: string;
  HARGA_HPP?: number; // Biaya Pokok Produksi / Beli per pcs
  HARGA_JUAL?: number; // Patokan Harga Jual ke pelanggan / ritel per pcs
}

export interface InventoryItem {
  GUDANG_ID: string;
  SKU_ID: string;
  NAMA_PRODUK: string;
  JUMLAH_READY: number;
  REORDER_LEVEL: number;
  REORDER: 'YES' | 'NO';
  ORDER_DATE?: string;
  WARNA?: string;
  UKURAN?: string;
  KATEGORI?: string;
  JENIS_LENGAN?: string;
}

export type TransactionType = 'MASUK' | 'KELUAR' | 'ORDER' | 'SALE' | 'KOREKSI';

export interface LogTransaksi {
  TIMESTAMP: string;
  TRANSAKSI_ID: string;
  SKU_ID: string;
  GUDANG_ID: string;
  JUMLAH: number;
  TIPE_TRANSAKSI: TransactionType;
  USERS: string;
  KETERANGAN: string;
}

export interface SignatureData {
  name: string;
  roleTitle?: string;
  imageDataUrl: string; // PNG Base64
  signedAt: string; // ISO string
}

export interface OrderItem {
  id: string;
  SKU_ID: string;
  jumlah: number;
  hargaSatuan?: number; // Harga per pcs (Rp)
  subtotal?: number; // Total nominal baris: jumlah * hargaSatuan
  keterangan?: string;
}

export interface OrderDocument {
  nomorOrder: string;
  tanggal: string;
  gudangId: string;
  gudangNama: string;
  username: string;
  supplier: string;
  kontak?: string;
  alamat?: string;
  metode?: string;
  catatan: string;
  subtotalNominal?: number;
  diskonNominal?: number;
  totalNominal?: number;
  statusPembayaran?: 'LUNAS' | 'PIUTANG' | 'SEBAGIAN';
  jumlahBayar?: number;
  sisaPiutang?: number;
  jatuhTempo?: string;
  tampilkanNominal?: boolean;
  items: OrderItem[];
  signatureAdmin?: SignatureData;
  signatureSupervisor?: SignatureData;
  createdAt: string;
}

export interface SuratJalanDocument {
  nomorSJ: string;
  tanggal: string;
  gudangId: string;
  gudangNama: string;
  username: string;
  tujuan: string;
  penerima: string;
  driver: string;
  kendaraan: string;
  catatan: string;
  tampilkanNominal?: boolean; // Pilihan tampilkan nominal harga pada surat jalan
  totalNominal?: number; // Total nilai pengiriman barang
  items: OrderItem[];
  signaturePengirim?: SignatureData;
  signatureDriver?: SignatureData;
  signaturePenerima?: SignatureData;
  createdAt: string;
}

export interface PembayaranPiutang {
  id: string;
  tanggal: string; // YYYY-MM-DD
  jumlahBayar: number;
  metode: string; // 'TUNAI' | 'TRANSFER' | 'QRIS' | string
  catatan?: string;
  kasir?: string;
  createdAt: string;
}

export type TipePelanggan = 'GROSIR' | 'RITEL' | 'RESELLER' | 'KONVEKSI' | 'DISTRO' | 'UMUM';

export interface Pelanggan {
  id: string; // e.g. 'CUST-001'
  nama: string;
  telepon: string;
  alamat?: string;
  kota?: string;
  tipe: TipePelanggan;
  plafonPiutang?: number; // Maksimal batas kredit piutang (Rp)
  catatan?: string;
  createdAt: string;
}

export interface SaleDocument {
  nomorSale: string;
  tanggal: string;
  gudangId: string;
  gudangNama: string;
  username: string;
  pelanggan: string;
  pelangganId?: string; // Relasi ke ID Pelanggan
  tipePelanggan?: TipePelanggan; // Kategori Pelanggan
  kontak: string;
  alamat?: string;
  metode: string;
  catatan: string;
  subtotalNominal?: number; // Subtotal sebelum diskon
  diskonNominal?: number; // Potongan diskon (Rp)
  totalNominal?: number; // Grand total tagihan / terbayar
  // Status Pembayaran & Piutang Pelanggan
  statusPembayaran?: 'LUNAS' | 'PIUTANG' | 'SEBAGIAN'; // Status pembayaran
  jumlahBayar?: number; // Nominal yang sudah dibayar pada saat transaksi (DP / tunai awal)
  sisaPiutang?: number; // Sisa piutang yang belum terbayar (totalNominal - total sudah dibayar)
  jatuhTempo?: string; // Tanggal jatuh tempo pelunasan (YYYY-MM-DD)
  riwayatPelunasan?: PembayaranPiutang[]; // Riwayat cicilan / pelunasan bertahap
  items: OrderItem[];
  signaturePenjual?: SignatureData;
  signaturePembeli?: SignatureData;
  createdAt: string;
}

export interface StockOpnameItem {
  SKU_ID: string;
  namaProduk: string;
  warna: string;
  ukuran: string;
  jenisLengan?: string;
  stokSistem: number;
  stokFisik: number;
  selisih: number; // stokFisik - stokSistem (0: pas, <0: minus/kurang, >0: plus/lebih)
  hargaHpp: number;
  hargaJual?: number;
  nilaiSelisih: number; // selisih * hargaHpp
  catatan?: string;
  // Multi-day SO tracking & mutasi berjalan
  countedAt?: string; // Tanggal & jam saat barang dihitung fisik
  systemStockAtCount?: number; // Snapshot stok sistem saat dihitung
  mutasiPascaHitung?: number; // Total mutasi keluar/masuk setelah barang dihitung
  stokAkhirRekonsiliasi?: number; // Stok akhir yang disesuaikan setelah memperhitungkan mutasi
  isCounted?: boolean; // Menandai apakah item sudah dihitung secara fisik
}

export interface StockOpnameSession {
  id: string;
  nomorOpname: string;
  tanggal: string;
  tanggalMulai?: string;
  gudangId: string;
  gudangNama: string;
  auditor: string;
  status: 'DRAFT' | 'SELESAI';
  catatan?: string;
  items: StockOpnameItem[];
  totalItemSistem: number;
  totalItemFisik: number;
  totalSelisihPcs: number;
  totalNilaiSelisihNominal: number;
  appliedAt?: string;
  createdAt: string;
  hasReconciliation?: boolean;
}

export type AppThemeMode = 'dark' | 'light';

export interface AppBackupSummary {
  totalProducts: number;
  totalWarehouses: number;
  totalInventorySlots: number;
  totalStockPcs: number;
  totalTransactions: number;
  totalOrders: number;
  totalSuratJalan: number;
  totalSales: number;
  totalCustomers: number;
  totalSoSessions: number;
}

export interface AppBackupData {
  app: string;
  version: string;
  exportedAt: string;
  source: string;
  summary: AppBackupSummary;
  products: MasterProduk[];
  warehouses: MasterGudang[];
  inventory: InventoryItem[];
  logs: LogTransaksi[];
  users: UserAccount[];
  settings: AppSystemSettings;
  orders: OrderDocument[];
  suratJalanList: SuratJalanDocument[];
  sales: SaleDocument[];
  customers: Pelanggan[];
  soHistory?: StockOpnameSession[];
}

export type CheckpointTriggerType =
  | 'MANUAL'
  | 'AUTO_INTERVAL'
  | 'AUTO_OPNAME'
  | 'AUTO_RESTORE'
  | 'AUTO_SALE'
  | 'AUTO_STOCK_IN'
  | 'AUTO_STARTUP';

export interface CheckpointItem {
  id: string; // e.g. 'CHK-20261007-123456'
  timestamp: string;
  name: string;
  triggerType: CheckpointTriggerType;
  creator: string;
  note?: string;
  sizeKb: number;
  isPinned?: boolean;
  data: AppBackupData;
}
