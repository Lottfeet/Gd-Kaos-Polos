// Code-128B Barcode Generator in Pure TypeScript

const CODE128_TABLE = [
  [2,1,2,2,2,2],[2,2,2,1,2,2],[2,2,2,2,2,1],[1,2,1,2,2,3],
  [1,2,1,3,2,2],[1,3,1,2,2,2],[1,2,2,2,1,3],[1,2,2,3,1,2],
  [1,3,2,2,1,2],[2,2,1,2,1,3],[2,2,1,3,1,2],[2,3,1,2,1,2],
  [1,1,2,2,3,2],[1,2,2,1,3,2],[1,2,2,2,3,1],[1,1,3,2,2,2],
  [1,2,3,1,2,2],[1,2,3,2,2,1],[2,2,3,2,1,1],[2,2,1,1,3,2],
  [2,2,1,2,3,1],[2,1,3,2,1,2],[2,2,3,1,1,2],[3,1,2,1,3,1],
  [3,1,1,2,2,2],[3,2,1,1,2,2],[3,2,1,2,2,1],[3,1,2,2,1,2],
  [3,2,2,1,1,2],[3,2,2,2,1,1],[2,1,2,1,2,3],[2,1,2,3,2,1],
  [2,3,2,1,2,1],[1,1,1,3,2,3],[1,3,1,1,2,3],[1,3,1,3,2,1],
  [1,1,2,3,1,3],[1,3,2,1,1,3],[1,3,2,3,1,1],[2,1,1,3,1,3],
  [2,1,3,1,1,3],[2,3,1,1,1,3],[1,1,2,1,3,3],[1,1,2,3,3,1],
  [1,3,2,1,3,1],[1,1,3,1,2,3],[1,1,3,3,2,1],[1,3,3,1,2,1],
  [3,1,3,1,2,1],[2,1,1,3,3,1],[2,3,1,1,3,1],[1,1,3,1,3,2],
  [1,1,3,2,3,1],[1,3,3,2,1,1],[3,3,1,1,2,1],[2,1,3,3,1,1],
  [1,3,1,3,3,1],[1,3,3,3,1,1],[3,1,3,3,1,1],[3,3,3,1,1,1],
  [3,1,2,1,1,3],[3,1,1,2,1,3],[3,3,1,2,1,1],[2,1,2,1,3,2],
  [2,1,2,3,1,2],[2,3,2,1,1,2],[1,1,1,1,3,3],[1,1,1,3,1,3],
  [1,3,1,1,1,3],[1,1,2,1,1,4],[1,1,4,1,1,2],[1,2,1,1,4,1],
  [1,2,4,1,1,1],[1,4,1,1,2,1],[1,4,2,1,1,1],[4,1,1,2,1,1],
  [4,1,2,1,1,1],[1,1,2,2,1,3],[1,1,2,1,2,3],[2,1,2,1,3,1],
  [1,3,1,2,1,3],[1,2,2,2,4,1],[1,4,1,2,2,1],[2,1,4,2,1,1],
  [2,2,4,1,1,1],[4,1,1,1,2,2],[4,2,1,1,2,1],[4,2,2,1,1,1],
  [2,1,2,2,1,3],[2,1,2,3,1,1],[2,3,2,2,1,1],[3,1,1,1,2,3],
  [3,1,2,1,1,3],[3,3,1,1,1,3],[3,1,1,3,1,2],[3,1,1,2,3,1],
  [1,1,2,1,3,2],[1,1,2,1,3,2],
  [2,1,1,1,1,4],[4,1,1,1,1,2],[1,1,1,1,4,2],[1,1,4,2,1,1],
  [2,1,2,3,2,1] // Stop pattern (index 106)
];

export interface BarcodeOptions {
  barWidth?: number;
  height?: number;
  margin?: number;
  color?: string;
  background?: string;
}

export function drawBarcode128(
  canvas: HTMLCanvasElement,
  text: string,
  opts: BarcodeOptions = {}
): void {
  const barW = opts.barWidth || 1.5;
  const height = opts.height || 40;
  const margin = opts.margin || 8;
  const color = opts.color || '#000000';
  const background = opts.background || '#ffffff';

  if (!canvas || !text) return;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const codes: number[] = [104]; // Start B
  let sum = 104;

  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i) - 32;
    const charCode = (c < 0 || c > 95) ? 0 : c;
    codes.push(charCode);
    sum += charCode * (i + 1);
  }

  codes.push(sum % 103);
  codes.push(106); // Stop pattern

  let totalModules = 0;
  codes.forEach((idx) => {
    const pat = CODE128_TABLE[Math.min(idx, CODE128_TABLE.length - 1)] || CODE128_TABLE[0];
    pat.forEach((m) => { totalModules += m; });
  });
  totalModules += 2; // Quiet zone

  const totalWidth = margin * 2 + totalModules * barW;
  canvas.width = Math.ceil(totalWidth);
  canvas.height = height;

  ctx.fillStyle = background;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = color;
  let x = margin;
  codes.forEach((idx) => {
    const pat = CODE128_TABLE[Math.min(idx, CODE128_TABLE.length - 1)] || CODE128_TABLE[0];
    let isBar = true;
    pat.forEach((width) => {
      if (isBar) {
        ctx.fillRect(Math.round(x), 0, Math.ceil(width * barW), height);
      }
      x += width * barW;
      isBar = !isBar;
    });
  });
}

export function generateBarcodeDataUrl(text: string, opts?: BarcodeOptions): string {
  if (typeof document === 'undefined') return '';
  const canvas = document.createElement('canvas');
  drawBarcode128(canvas, text, opts);
  return canvas.toDataURL('image/png');
}
