import QRCode from 'qrcode';
import { drawBarcode128, generateBarcodeDataUrl, BarcodeOptions } from './barcode128';

export type BarcodeFormat = 'CODE128' | 'QR_CODE' | 'EAN13';

export interface CodeRenderOptions extends BarcodeOptions {
  qrWidth?: number;
  qrMargin?: number;
}

/**
 * Render barcode (Code-128, QR Code, or EAN-13) to an HTML Canvas
 */
export async function renderCodeToCanvas(
  canvas: HTMLCanvasElement,
  text: string,
  format: BarcodeFormat = 'CODE128',
  opts: CodeRenderOptions = {}
): Promise<void> {
  if (!canvas || !text) return;

  if (format === 'QR_CODE') {
    const size = opts.qrWidth || opts.height ? Math.max(opts.height || 64, 64) : 72;
    await QRCode.toCanvas(canvas, text, {
      width: size,
      margin: opts.qrMargin !== undefined ? opts.qrMargin : 1,
      color: {
        dark: opts.color || '#000000',
        light: opts.background || '#ffffff',
      },
      errorCorrectionLevel: 'M',
    });
  } else {
    // CODE128 or EAN13 fallback
    drawBarcode128(canvas, text, {
      barWidth: opts.barWidth || 1.3,
      height: opts.height || 36,
      margin: opts.margin || 4,
      color: opts.color || '#000000',
      background: opts.background || '#ffffff',
    });
  }
}

/**
 * Generate Data URL (PNG base64) for Code-128 or QR Code
 */
export async function generateCodeDataUrl(
  text: string,
  format: BarcodeFormat = 'CODE128',
  opts: CodeRenderOptions = {}
): Promise<string> {
  if (!text) return '';

  if (format === 'QR_CODE') {
    const size = opts.qrWidth || 120;
    try {
      return await QRCode.toDataURL(text, {
        width: size,
        margin: opts.qrMargin !== undefined ? opts.qrMargin : 1,
        color: {
          dark: opts.color || '#000000',
          light: opts.background || '#ffffff',
        },
        errorCorrectionLevel: 'M',
      });
    } catch (err) {
      console.error('Failed to generate QR Data URL', err);
      return '';
    }
  } else {
    return generateBarcodeDataUrl(text, opts);
  }
}
