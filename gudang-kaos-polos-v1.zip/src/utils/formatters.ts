/**
 * Currency & Number Formatters for Indonesian Rupiah
 */

export function formatRupiah(val: number | undefined | null): string {
  if (val === undefined || val === null || isNaN(val)) return 'Rp 0';
  return 'Rp ' + Math.round(val).toLocaleString('id-ID');
}

export function formatNumber(val: number | undefined | null): string {
  if (val === undefined || val === null || isNaN(val)) return '0';
  return Math.round(val).toLocaleString('id-ID');
}

const SATUAN = ['', 'Satu', 'Dua', 'Tiga', 'Empat', 'Lima', 'Enam', 'Tujuh', 'Delapan', 'Sembilan', 'Sepuluh', 'Sebelas'];

function bilang(n: number): string {
  n = Math.floor(Math.abs(n));
  if (n < 12) return SATUAN[n];
  if (n < 20) return bilang(n - 10) + ' Belas';
  if (n < 100) return bilang(Math.floor(n / 10)) + ' Puluh ' + bilang(n % 10);
  if (n < 200) return 'Seratus ' + bilang(n - 100);
  if (n < 1000) return bilang(Math.floor(n / 100)) + ' Ratus ' + bilang(n % 100);
  if (n < 2000) return 'Seribu ' + bilang(n - 1000);
  if (n < 1000000) return bilang(Math.floor(n / 1000)) + ' Ribu ' + bilang(n % 1000);
  if (n < 1000000000) return bilang(Math.floor(n / 1000000)) + ' Juta ' + bilang(n % 1000000);
  if (n < 1000000000000) return bilang(Math.floor(n / 1000000000)) + ' Miliar ' + bilang(n % 1000000000);
  return bilang(Math.floor(n / 1000000000000)) + ' Triliun ' + bilang(n % 1000000000000);
}

export function terbilangRupiah(amount: number): string {
  if (!amount || isNaN(amount) || amount === 0) return 'Nol Rupiah';
  const hasil = bilang(amount).replace(/\s+/g, ' ').trim();
  return hasil + ' Rupiah';
}
