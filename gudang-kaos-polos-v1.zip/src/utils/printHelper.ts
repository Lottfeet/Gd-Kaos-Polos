/**
 * Universal Printing & Document Export Utility
 * Handles direct window/iframe printing, new-tab rendering, and sandbox-safe PDF/HTML download.
 */

export interface PrintOptions {
  title?: string;
  filename?: string;
  isThermal?: boolean;
}

export function generatePrintableHtml(contentHtml: string, options?: PrintOptions): string {
  const title = options?.title || 'Dokumen Resmi Inventori';
  const isThermal = options?.isThermal || false;

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${title}</title>
  <!-- Load Tailwind CSS for instant matching of all utility classes -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    
    @page {
      size: ${isThermal ? '58mm 40mm' : 'A4 portrait'};
      margin: ${isThermal ? '2mm' : '8mm 6mm'};
    }
    
    html, body {
      margin: 0;
      padding: 0;
      background: #ffffff !important;
      color: #0f172a !important;
      font-family: 'Outfit', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 12px;
      line-height: 1.4;
    }

    .print-container {
      width: 100%;
      max-width: ${isThermal ? '100%' : '210mm'};
      margin: 0 auto;
      background: #ffffff;
      padding: ${isThermal ? '2mm' : '4mm'};
    }

    .no-print-bar {
      position: sticky;
      top: 0;
      z-index: 9999;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 12px 20px;
      background: #111827;
      color: #f3f4f6;
      font-size: 13px;
      font-weight: 600;
      border-bottom: 2px solid #ea580c;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .no-print-bar .btn-print {
      background: #ea580c;
      color: #ffffff;
      border: none;
      padding: 8px 18px;
      border-radius: 8px;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: background 0.15s ease;
    }

    .no-print-bar .btn-print:hover {
      background: #c2410c;
    }

    .no-print-bar .btn-close {
      background: #374151;
      color: #e5e7eb;
      border: none;
      padding: 8px 14px;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.15s ease;
    }

    .no-print-bar .btn-close:hover {
      background: #4b5563;
    }

    @media print {
      .no-print-bar {
        display: none !important;
      }
      .print-container {
        padding: 0 !important;
        margin: 0 !important;
        max-width: 100% !important;
      }
    }
  </style>
</head>
<body>
  <div class="no-print-bar">
    <div style="display: flex; align-items: center; gap: 8px;">
      <span style="font-size: 16px;">🖨️</span>
      <span><strong>Pratinjau Cetak:</strong> ${title}</span>
    </div>
    <div style="display: flex; align-items: center; gap: 8px;">
      <button class="btn-print" onclick="window.print()">
        <span>🖨️ Cetak Dokumen / Simpan PDF (Ctrl + P)</span>
      </button>
      <button class="btn-close" onclick="window.close()">
        ✕ Tutup
      </button>
    </div>
  </div>
  <div class="print-container">
    ${contentHtml}
  </div>
  <script>
    // Automatically trigger print dialog when page finishes loading
    window.addEventListener('load', function() {
      setTimeout(function() {
        try {
          window.print();
        } catch (e) {
          console.warn('Auto print notice:', e);
        }
      }, 500);
    });
  </script>
</body>
</html>`;
}

/**
 * Downloads the printable document as a standalone HTML file.
 */
export function downloadPrintableHtml(contentHtml: string, options?: PrintOptions): void {
  const filename = (options?.filename || options?.title || 'dokumen_cetak')
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '_') + '.html';

  const fullHtml = generatePrintableHtml(contentHtml, options);
  const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();

  setTimeout(() => URL.revokeObjectURL(url), 15000);
}

/**
 * Opens document in a dedicated new tab/window with auto-print.
 */
export function openPrintableInNewWindow(contentHtml: string, options?: PrintOptions): boolean {
  try {
    const fullHtml = generatePrintableHtml(contentHtml, options);
    const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
    const blobUrl = URL.createObjectURL(blob);

    const win = window.open(blobUrl, '_blank');
    if (win) {
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
      return true;
    }
  } catch (err) {
    console.warn('Cannot open blob window, trying blank document write:', err);
  }

  try {
    const win = window.open('', '_blank');
    if (win) {
      const fullHtml = generatePrintableHtml(contentHtml, options);
      win.document.open();
      win.document.write(fullHtml);
      win.document.close();
      return true;
    }
  } catch (err2) {
    console.warn('window.open also blocked:', err2);
  }

  return false;
}

/**
 * Master Print Function
 * Tries direct isolated print, hidden iframe print, popup window, and file download fallback.
 */
export function printElement(
  element: HTMLElement | null,
  options?: PrintOptions,
  onNotify?: (msg: string, type: 'success' | 'info' | 'error') => void
): boolean {
  if (!element) {
    if (onNotify) onNotify('Elemen dokumen tidak ditemukan untuk dicetak.', 'error');
    return false;
  }

  const htmlContent = element.outerHTML;
  let printSuccess = false;

  // STEP 1: Mount clean clone into #isolated-print-mount for native window.print()
  let mountEl = document.getElementById('isolated-print-mount');
  if (!mountEl) {
    mountEl = document.createElement('div');
    mountEl.id = 'isolated-print-mount';
    document.body.appendChild(mountEl);
  }
  mountEl.innerHTML = htmlContent;
  document.body.classList.add('is-printing-document');

  // Function to cleanup DOM after print
  const cleanup = () => {
    document.body.classList.remove('is-printing-document');
    if (mountEl) mountEl.innerHTML = '';
  };

  window.addEventListener('afterprint', cleanup, { once: true });
  setTimeout(cleanup, 20000);

  // STEP 2: Try hidden iframe printing (Most reliable inside sandboxed web preview)
  try {
    const hiddenIframe = document.createElement('iframe');
    hiddenIframe.setAttribute(
      'style',
      'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden;z-index:-1;'
    );
    document.body.appendChild(hiddenIframe);

    const fullHtml = generatePrintableHtml(htmlContent, options);
    const doc = hiddenIframe.contentWindow?.document;
    if (doc) {
      doc.open();
      doc.write(fullHtml);
      doc.close();

      setTimeout(() => {
        try {
          hiddenIframe.contentWindow?.focus();
          hiddenIframe.contentWindow?.print();
          printSuccess = true;
          if (onNotify) {
            onNotify('Membuka kotak dialog cetak...', 'success');
          }
        } catch (iframeErr) {
          console.warn('Iframe print restricted:', iframeErr);
          // Fallback to window.print()
          try {
            window.print();
            printSuccess = true;
          } catch (winErr) {
            console.warn('window.print restricted by sandbox:', winErr);
          }
        } finally {
          setTimeout(() => {
            hiddenIframe.remove();
          }, 30000);
        }
      }, 350);
    }
  } catch (err) {
    console.warn('Failed to build print iframe:', err);
    // Direct attempt
    try {
      window.print();
      printSuccess = true;
    } catch (e) {
      console.warn('Direct window.print failed:', e);
    }
  }

  // STEP 3: If running in an iframe environment, ALSO open in new window or provide download
  // so the user is NEVER blocked if the browser's iframe sandbox prevents modal printing!
  setTimeout(() => {
    const openedNewTab = openPrintableInNewWindow(htmlContent, options);
    if (!openedNewTab) {
      // If popup was blocked, download the standalone printable HTML file directly
      downloadPrintableHtml(htmlContent, options);
      if (onNotify) {
        onNotify('Dokumen siap cetak telah diunduh (bisa langsung dicetak atau disimpan ke PDF).', 'info');
      }
    } else {
      if (onNotify) {
        onNotify('Lembar dokumen cetak dibuka di tab baru dengan dialog print.', 'success');
      }
    }
  }, 250);

  return true;
}
