export const WARNA_MAP: Record<string, string> = {
  'HITAM': '#1c1c1e',
  'PUTIH': '#FCFCFC',
  'MERCAB': '#FF0000',
  'BENHUR': '#0000FF',
  'NAVY': '#0A2252',
  'HIJAU': '#009933',
  'ABU': '#8b9198',
  'CREAM': '#e8dcc8',
  'MAROON': '#7D2730',
  'TOSCA': '#02A092',
  'UNGU': '#7b2fbe',
  'ORANGE': '#e5621b',
  'COKLAT': '#7c4a1e',
  'KUNING KENARI': '#FFFF00',
  'BROKEN WHITE': '#FFFFF5',
  'ORANGE BATA': '#B24B2C',
  'HIJAU PUCUK': '#8DC54A',
  'HIJAU MINT': '#91D3B8',
  'UNGU TUA': '#483A5E',
  'TOSCA MUDA': '#79CBBD',
  'ABU SEDANG': '#B2B6C1',
  'LIGHT GREY': '#B7B3B0',
  'HIJAU BOTOL': '#304F4A',
  'PINK': '#FEB7D9',
  'DEEP BLUE': '#256E8F',
  'HONEY': '#D2A12B',
  'FUCHSIA': '#C22B72',
  'STEEL BLUE': '#536C8A',
  'LAVENDER': '#AB96C1',
  'LIGHT BROWN': '#C1B3A8',
  'BEIGE': '#BCAEA3',
  'PEONY PINK': '#C99798',
  'TERRACOTTA': '#BF8472',
  'MAGENTA': '#892F62',
  'COKLAT KOPI': '#453B3A',
  'TURKIS TUA': '#027DB0',
  'ARMY': '#4C4F3A',
  'BIRU MUDA': '#80A2CE',
  'MUSTARD': '#D9A444',
  'BABY YELLOW': '#F1EA8E',
  'COKLAT SUSU': '#9D8D74',
  'KUNING EMAS': '#F8A717',
  'ATLANTIC SEA': '#274F59',
  'BLUSH RED': '#B05C69',
  'OLIVE GREEN': '#A29E79',
  'ROYAL PURPLE': '#69427A',
  'DUSTY PINK': '#D1B3B1',
  'ELECTRIK LIME': '#D3D529',
  'BUTTER': '#F2E2C1',
  'OCEAN BLUE': '#37699C',
  'TURKIS MUDA': '#6AC0D7',
  'CACTUS GREEN': '#647354',
  'STONE GREY': '#585C65',
  'MINERAL GREEN': '#78938A',
  'SKY BLUE': '#9DBCD9',
  'SAGE GREEN': '#93998D',
  'DARK MUSTRAD': '#A66C2A',
  'ALMOND BROWN': '#B18A5F',
  'SAFARI': '#AFA895',
  'ABU TUA': '#515151',
  'BURGUNDI': '#6A1A24',
};

const CUSTOM_COLORS_STORAGE_KEY = 'inv_kaos_custom_colors';

export interface CustomColorItem {
  name: string;
  hex: string;
  isCustom?: boolean;
}

// Ambil daftar warna kustom yang tersimpan di localStorage
export function getCustomColors(): CustomColorItem[] {
  try {
    const saved = localStorage.getItem(CUSTOM_COLORS_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        return parsed.map((item) => ({
          name: item.name.toUpperCase().trim(),
          hex: item.hex.startsWith('#') ? item.hex : `#${item.hex}`,
          isCustom: true,
        }));
      }
    }
  } catch (err) {
    console.warn('Error reading custom colors from storage:', err);
  }
  return [];
}

// Simpan atau tambahkan warna kustom baru secara otomatis
export function saveCustomColor(namaWarna: string, hexCode: string): CustomColorItem {
  const cleanName = namaWarna.toUpperCase().trim();
  const cleanHex = hexCode.startsWith('#') ? hexCode : `#${hexCode}`;

  const current = getCustomColors();
  const existingIdx = current.findIndex((c) => c.name === cleanName);

  let updated: CustomColorItem[];
  if (existingIdx >= 0) {
    updated = [...current];
    updated[existingIdx] = { name: cleanName, hex: cleanHex, isCustom: true };
  } else {
    updated = [{ name: cleanName, hex: cleanHex, isCustom: true }, ...current];
  }

  try {
    localStorage.setItem(CUSTOM_COLORS_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn('Error saving custom color to storage:', err);
  }

  // Perbarui juga ke cache memori WARNA_MAP
  WARNA_MAP[cleanName] = cleanHex;

  return { name: cleanName, hex: cleanHex, isCustom: true };
}

// Dapatkan seluruh warna (kombinasi warna standar + warna kustom yang telah dibuat)
export function getAllAvailableColors(): CustomColorItem[] {
  const custom = getCustomColors();
  const standard: CustomColorItem[] = Object.entries(WARNA_MAP).map(([name, hex]) => ({
    name,
    hex,
    isCustom: false,
  }));

  // Gabungkan dan hindari duplikasi
  const seen = new Set<string>();
  const all: CustomColorItem[] = [];

  // Dahulukan kustom jika ada
  custom.forEach((c) => {
    if (!seen.has(c.name)) {
      seen.add(c.name);
      all.push(c);
    }
  });

  // Tambahkan warna standar
  standard.forEach((s) => {
    if (!seen.has(s.name)) {
      seen.add(s.name);
      all.push(s);
    }
  });

  return all;
}

// Hasilkan singkatan 3 huruf cerdas untuk komponen kode SKU
export function getWarnaAbbreviation(namaWarna?: string): string {
  if (!namaWarna) return 'HTM';
  const clean = namaWarna.toUpperCase().trim();

  // Pemetaan singkatan umum industri konveksi
  const knownAbbreviations: Record<string, string> = {
    'HITAM': 'HTM',
    'PUTIH': 'PUT',
    'MERCAB': 'MCB',
    'BENHUR': 'BNH',
    'NAVY': 'NVY',
    'MAROON': 'MRN',
    'TOSCA': 'TSC',
    'BURGUNDI': 'BGD',
    'TERRACOTTA': 'TRC',
    'KUNING': 'KNG',
    'KUNING KENARI': 'KKN',
    'KUNING EMAS': 'KEM',
    'HIJAU': 'HJU',
    'HIJAU BOTOL': 'HBT',
    'HIJAU ARMY': 'ARM',
    'ARMY': 'ARM',
    'ORANGE': 'ORG',
    'ORANGE BATA': 'OBT',
    'COKLAT': 'CKL',
    'COKLAT SUSU': 'CSU',
    'COKLAT KOPI': 'CKP',
    'UNGU': 'UNG',
    'UNGU TUA': 'UTU',
    'MUSTARD': 'MST',
    'LAVENDER': 'LVN',
    'FUCHSIA': 'FCS',
    'PEONY PINK': 'PPK',
    'PINK': 'PNK',
    'BABY YELLOW': 'BYL',
    'BIRU MUDA': 'BMD',
    'TURKIS': 'TRK',
    'TURKIS MUDA': 'TKM',
    'TURKIS TUA': 'TKT',
    'ABU': 'ABU',
    'ABU TUA': 'ABT',
    'ABU SEDANG': 'ABS',
    'LIGHT GREY': 'LGY',
    'CREAM': 'CRM',
    'BEIGE': 'BGE',
    'SAGE GREEN': 'SGE',
    'LILAC': 'LLC',
  };

  if (knownAbbreviations[clean]) {
    return knownAbbreviations[clean];
  }

  // Algoritma konsonan untuk warna baru/custom
  const consonants = clean.replace(/[^B-DF-HJ-NP-TV-Z]/g, '');
  if (consonants.length >= 3) {
    return consonants.slice(0, 3);
  }

  // Jika huruf konsonan kurang dari 3, ambil karakter pertama
  const letters = clean.replace(/[^A-Z]/g, '');
  if (letters.length >= 3) {
    return letters.slice(0, 3);
  }
  return letters.padEnd(3, 'X');
}

export function getWarnaHex(namaWarna?: string): string {
  if (!namaWarna) return '#94a3b8';
  const clean = namaWarna.toUpperCase().trim();

  // 1. Cek in-memory map
  if (WARNA_MAP[clean]) return WARNA_MAP[clean];

  // 2. Cek custom colors di localStorage
  const custom = getCustomColors();
  const match = custom.find((c) => c.name === clean);
  if (match) {
    WARNA_MAP[clean] = match.hex;
    return match.hex;
  }

  // 3. Jika warna berupa kode hex langsung (#xxxxxx)
  if (/^#[0-9A-F]{6}$/i.test(clean) || /^#[0-9A-F]{3}$/i.test(clean)) {
    return clean;
  }

  // 4. Default fallback
  return '#94a3b8';
}

export function darkenColor(hex: string, amount: number): string {
  const clean = hex.replace('#', '');
  const r = Math.max(0, parseInt(clean.slice(0, 2), 16) - amount);
  const g = Math.max(0, parseInt(clean.slice(2, 4), 16) - amount);
  const b = Math.max(0, parseInt(clean.slice(4, 6), 16) - amount);
  return '#' + [r, g, b].map((c) => c.toString(16).padStart(2, '0')).join('');
}

export function renderShirtPath(jenisLengan?: string, fill = '#1c1c1e', stroke = '#000000') {
  const key = (jenisLengan || 'PENDEK').toUpperCase().trim();

  if (key === 'PANJANG') {
    return `
      <g transform="translate(8, 8) scale(4)">
        <path d="M10.3 2.28c0,0 -2.08,-0.23 -2.66,-2.28 -0.5,0.1 -2.03,0.33 -3.03,0.57 -1.16,0.29 -2.18,1.17 -2.35,2.4l-2.24 16.06 2.34 0.19 2.34 -12.12 0 13.53 5.6 0 5.61 0 0 -13.53 2.34 12.12 2.33 -0.19 -2.23 -16.06c-0.17,-1.23 -1.2,-2.11 -2.35,-2.4 -1.01,-0.24 -2.53,-0.47 -3.03,-0.57 -0.58,2.05 -2.67,2.28 -2.67,2.28z" 
          fill="${fill}"
          stroke="${stroke}"
          stroke-width="0.35"
          stroke-linejoin="round" />
      </g>
    `;
  }

  if (key === '3P4' || key === '3/4') {
    return `
      <g transform="translate(40, 8) scale(0.84)">
        <path d="M10.3 11.96c0,0 -10.94,-1.21 -14,-11.96 -3.66,0.71 -17.8,2.82 -20.36,4.54 -2.7,1.82 -6.32,5.65 -7.91,11.04l-11.37 38.45 15.72 5.66 8.48 -22.38 0 71.09 29.44 0 29.44 0 0 -71.09 8.48 22.38 15.72 -5.66 -11.37 -38.45c-1.59,-5.39 -5.21,-9.22 -7.91,-11.04 -2.56,-1.72 -16.71,-3.83 -20.36,-4.54 -3.06,10.75 -14,11.96 -14,11.96z" 
          fill="${fill}"
          stroke="${stroke}"
          stroke-width="0.35"
          stroke-linejoin="round" />
      </g>
    `;
  }

  if (key === '7P8' || key === '7/8') {
    return `
      <g transform="translate(21, 8) scale(3)">
        <path d="M10.3 3.24c0,0 -2.96,-0.33 -3.79,-3.24 -0.99,0.19 -4.82,0.76 -5.51,1.23 -0.73,0.49 -1.88,1.49 -2.14,2.99l-2.76 15.52 3.9 1.4 2.33 -11.04 0 19.24 7.97 0 7.97 0 0 -19.24 2.33 11.04 3.9 -1.4 -2.76 -15.52c-0.27,-1.5 -1.41,-2.5 -2.14,-2.99 -0.69,-0.47 -4.52,-1.04 -5.51,-1.23 -0.83,2.91 -3.79,3.24 -3.79,3.24z" 
          fill="${fill}"
          stroke="${stroke}"
          stroke-width="0.35"
          stroke-linejoin="round" />
      </g>
    `;
  }

  // Default PENDEK
  return `
    <g transform="translate(23, 8) scale(2.6)">
      <path d="M10.3 3.73c0,0 -3.39,-0.38 -4.34,-3.73 -0.72,0.14 -2.76,0.46 -4.35,0.81 -2.21,0.48 -3.56,1.44 -4.42,4.04l-2.49 7.54 5.25 2.45 1.22 -3.22 0 22.15 9.13 0 9.13 0 0 -22.15 1.22 3.22 5.25 -2.45 -2.48 -7.54c-0.86,-2.6 -2.22,-3.56 -4.42,-4.04 -1.6,-0.35 -3.63,-0.67 -4.36,-0.81 -0.94,3.35 -4.34,3.73 -4.34,3.73z" 
        fill="${fill}"
        stroke="${stroke}"
        stroke-width="0.35"
        stroke-linejoin="round" />
    </g>
  `;
}
